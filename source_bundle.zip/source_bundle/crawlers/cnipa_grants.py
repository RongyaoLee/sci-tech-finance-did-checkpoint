from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
import requests,csv,re,hashlib
P=Path(__file__).resolve().parent
cities=set('北京 天津 上海 重庆 广州 长春 武汉 南京 杭州 西安 济南 沈阳 成都 哈尔滨 大连 青岛 宁波 厦门 深圳'.split())
types={2:'发明',3:'实用新型',4:'外观设计'}
def get(it):
 y,k=it; url=f'https://www.cnipa.gov.cn/tjxx/jianbao/year{y}/b/b{k}.html'
 for i in range(3):
  try:
   r=requests.get(url,timeout=25);r.raise_for_status();break
  except requests.RequestException:
   if i==2:raise
 s=BeautifulSoup(r.content,'html.parser',from_encoding='utf-8')
 assert types[k]+'专利授权量' in ''.join(s.stripped_strings)
 rows=[];years=[]
 for tr in s.find_all('tr'):
  cs=[''.join(t.stripped_strings) for t in tr.find_all('td',recursive=False)]
  if cs and '地区' in cs[0] and len(cs[0])<25:years=[int(re.search(r'(20\d\d)',v)[1]) for v in cs if re.search(r'20\d\d\s*年',v)]
  if cs and cs[0] in cities:
   assert years==[y-5,y-1,y] and len(cs)==6
   rows.extend((cs[0],yr,types[k],int(v.replace(',','')),y,url,hashlib.sha256(r.content).hexdigest()) for yr,v in zip(years,cs[-3:]) if yr>=2017)
 assert len(set(x[0] for x in rows))==19
 return rows
def save(name,headers,rows):
 with (P/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(headers);w.writerows(rows)
if __name__=='__main__':
 with ThreadPoolExecutor(3) as ex: rows=sum(ex.map(get,[(y,k) for y in range(2020,2026) for k in types]),[])
 ds={}
 for c,y,k,v,*_ in rows:
  d=ds.setdefault((c,y),{});assert k not in d or d[k]==v;d[k]=v
 assert len(ds)==171
 save('逐数来源.csv',['城市','观测年','类型','件数','年报版次','来源','页面SHA256'],rows)
 save('19城三类专利授权_2017至2025.csv',['城市','年份',*types.values(),'三类合计'],[(c,y,*[d[v] for v in types.values()],sum(d.values())) for (c,y),d in sorted(ds.items())])
 print(len(rows),len(ds))
