# -*- coding: utf-8 -*-
"""Download + parse 高企 cert list sources into per-source JSON."""
import os, re, json, sys, hashlib
from urllib.parse import urljoin
from lxml import html as LH
import cert_fetch as F
import cert_parse_pdf as P

CACHE = os.path.join("cert_lists", "_cache")
OUT = os.path.join(CACHE, "parsed")
os.makedirs(OUT, exist_ok=True)


def pdf_links(article_url):
    r = F.get(article_url)
    t = F.text(r)
    doc = LH.fromstring(t)
    out = []
    for a in doc.xpath("//a[@href]"):
        href = urljoin(r.url, a.get("href") or "")
        if re.search(r"\.pdf(\?|$)", href, re.I):
            out.append(href)
    return out


def download(url, key, name_hint=""):
    p = os.path.join(CACHE, key + ".pdf")
    if os.path.exists(p) and os.path.getsize(p) > 5000:
        return p
    r = F.get(url, timeout=60)
    if not r.content[:4] == b"%PDF":
        raise RuntimeError(f"not pdf: {url[:80]} head={r.content[:20]!r}")
    open(p, "wb").write(r.content)
    return p


def process(key, src, year, batch, region_hint=None, kind="province"):
    """src: article url or direct pdf url"""
    js = os.path.join(OUT, key + ".json")
    if os.path.exists(js):
        d = json.load(open(js, encoding="utf-8"))
        print(f"[cached] {key}: {len(d['rows'])} rows")
        return d
    if src.lower().endswith(".pdf") or "download/downfile" in src or "/files/" in src:
        pdf_url, art = src, src
    else:
        links = pdf_links(src)
        if not links:
            raise RuntimeError("no pdf in " + src)
        pdf_url, art = links[0], src
    p = download(pdf_url, key)
    rows = P.parse_pdf(p, region_col_hint=region_hint)
    d = {"key": key, "src": art, "pdf": pdf_url, "year": year, "batch": batch,
         "kind": kind, "pages": None, "rows": rows}
    json.dump(d, open(js, "w", encoding="utf-8"), ensure_ascii=False)
    withcert = sum(1 for r in rows if r["cert"])
    withreg = sum(1 for r in rows if r["region"])
    print(f"[done] {key}: rows={len(rows)} cert={withcert} region={withreg} pdf={os.path.basename(p)}")
    return d


if __name__ == "__main__":
    import cert_sources as S
    only = sys.argv[1:] or None
    for s in S.SOURCES:
        if only and s["key"] not in only:
            continue
        try:
            process(**s)
        except Exception as e:
            print("ERR", s["key"], type(e).__name__, str(e)[:200])
