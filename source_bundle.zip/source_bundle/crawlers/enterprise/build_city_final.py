# -*- coding: utf-8 -*-
"""生成「城市级高新技术企业」终版总表（带数据来源标注）。

数据来源（五源，优先级 EPS > HBN > CNKI > 地市名单 > 各省认定名单汇总）：
1. HBN 社科研究数据库（嘉博环球，山东财经大学机构账号）
   `work\\lib_city\\HBN_数值.csv`，指标形如「高新技术企业数:湖南省怀化市:年」
2. CNKI 中国经济社会大数据研究平台
   `work\\cnki_gaoqi.sqlite` 的 hits 表，area 精确到地级市/区县
3. 各省「认定名单」（国家网备案公告 + 省级公布件）
   `work\\cert_lists\\*.csv`，按 城市+认定年度 去重企业数汇总

用法：
    python build_city_final.py
    python build_city_final.py --out ..\\outputs\\高企城市面板_终版.xlsx
"""
from __future__ import annotations

import argparse
import csv
import re
import sqlite3
from collections import Counter, defaultdict
from pathlib import Path

WORK = Path(__file__).resolve().parent
LIB_DIR = WORK / "lib_city"
CERT_DIR = WORK / "cert_lists"
CNKI_DB = WORK / "cnki_gaoqi.sqlite"
HBN_CSV = LIB_DIR / "HBN_数值.csv"
DEFAULT_OUT = WORK.parent / "outputs" / "高企城市面板_终版.xlsx"

PILOT = ("济南市", "上海市", "南京市", "杭州市", "合肥市", "嘉兴市", "北京市")
COUNT_UNITS = ("家", "户", "个", "户数", "家数")

# 指标名 -> 口径（顺序即优先级：先判更具体的说法，再落到通用「企业数」）
SCOPE_RULES = (
    (("服务中心", "孵化器", "孵化"), "服务机构数"),
    (("净增",), "净增数"),
    (("有效期内", "在有效期"), "有效期内数"),
    (("新增", "新认定", "当年认定"), "新增认定数"),
    (("规模以上", "规上"), "规上企业数"),
    (("国家级",), "期末存量(国家级)"),
    (("认定",), "认定数"),
    (("数量", "企业数", "个数", "户数", "家数", "总数"), "期末存量"),
)


def norm_prov(name: str) -> str:
    """省份名归一：上海市/上海/内蒙古自治区/内蒙古 都折成同一个键。"""
    text = (name or "").strip()
    text = re.sub(r"(省|市|自治区|维吾尔|壮族|回族|特别行政区)$", "", text)
    text = text.replace("维吾尔", "").replace("壮族", "").replace("回族", "")
    return text


def year_cell(value):
    """年份统一写成整数，Excel 里能排序、Stata 里能直接用。"""
    text = str(value or "").strip()
    return int(text) if re.fullmatch(r"\d{4}", text) else text


def to_number(text) -> float | None:
    if text is None:
        return None
    cleaned = str(text).replace(",", "").replace("，", "").replace(" ", "").strip()
    if not re.match(r"^-?\d+(?:\.\d+)?$", cleaned):
        return None
    return float(cleaned)


CANON: dict[str, str] = {}
LEVEL = {"地级市": 0, "区县": 1, "园区/其它": 2}


def load_canon() -> dict[str, str]:
    """用 342 个地级市名单建「别名 -> 标准市名」映射（直辖市把「市辖区」改名）。"""
    import json
    path = WORK / "cert_lists" / "cities.json"
    fix = {"11": "北京市", "12": "天津市", "31": "上海市", "50": "重庆市"}
    table: dict[str, str] = {}
    if not path.exists():
        return table
    for item in json.loads(path.read_text(encoding="utf-8")):
        name = fix.get(item.get("provinceCode"), item.get("name")) if item.get("name") == "市辖区" else item.get("name")
        if not name:
            continue
        table[name] = name
        table[name.replace("市", "")] = name
        table[re.sub(r"(地区|自治州|盟)$", "", name)] = name
    for name in ("北京市", "天津市", "上海市", "重庆市"):
        table[name.replace("市", "")] = name
    return table


PROVINCES = {
    "河北省", "山西省", "辽宁省", "吉林省", "黑龙江省", "江苏省", "浙江省", "安徽省",
    "福建省", "江西省", "山东省", "河南省", "湖北省", "湖南省", "广东省", "海南省",
    "四川省", "贵州省", "云南省", "陕西省", "甘肃省", "青海省", "台湾省",
    "内蒙古自治区", "广西壮族自治区", "西藏自治区", "宁夏回族自治区", "新疆维吾尔自治区",
}


def city_level(name: str) -> str:
    text = (name or "").strip()
    if text in CANON:
        return "地级市"
    if text in PROVINCES:
        return "省"
    if re.search(r"(区|县|旗|新区|开发区)$", text):
        return "区县"
    return "园区/其它"


def canon_city(name: str) -> str:
    text = (name or "").strip()
    if text in CANON:
        return CANON[text]
    stripped = re.sub(r"(市辖区|地区|自治州|盟|林区)$", "", text)
    if stripped in CANON:
        return CANON[stripped]
    return text


def norm_city(name: str) -> str:
    """把「市辖区 / 地区 / 自治州 / 盟 / 市」等后缀统一掉，便于三源对齐。"""
    text = (name or "").strip()
    if not text:
        return ""
    text = text.replace("市辖区", "市区")
    text = re.sub(r"(地区|自治州|自治县|盟|林区)$", "", text)
    text = re.sub(r"市$", "", text)
    text = text.replace("市区", "市")
    return text


def scope_of(indicator: str) -> str:
    text = indicator or ""
    for keys, title in SCOPE_RULES:
        if any(key in text for key in keys):
            return title
    return "期末存量"


def read_hbn(rows: list[dict]) -> None:
    if not HBN_CSV.exists():
        print("跳过 HBN：文件不存在")
        return
    count = 0
    with HBN_CSV.open("r", encoding="utf-8-sig", newline="") as handle:
        for item in csv.DictReader(handle):
            unit = (item.get("单位") or "").strip()
            value = to_number(item.get("数值"))
            if value is None:
                continue
            indicator = item.get("指标") or ""
            if "高新技术企业" not in indicator and "高企" not in indicator:
                continue
            if unit not in COUNT_UNITS:
                continue
            rows.append({
                "来源": "HBN社科研究数据库",
                "省": item.get("省") or "",
                "城市": item.get("城市") or "",
                "城市键": canon_city(item.get("城市")),
                "年份": (item.get("年份") or "").strip(),
                "数值": value,
                "单位": unit,
                "口径": scope_of(indicator),
                "指标": indicator,
                "出处": f"{item.get('来源URL') or 'https://ssd.harborn.cn/data/index'} · 序列{item.get('序列号')}",
            })
            count += 1
    print(f"HBN：{count} 行")


def read_cnki(rows: list[dict]) -> None:
    if not CNKI_DB.exists():
        print("跳过 CNKI：库不存在")
        return
    db = sqlite3.connect(f"file:{CNKI_DB}?mode=ro", uri=True, timeout=30)
    count = 0
    for area, province, period, indicator, value, unit, yearbook in db.execute(
        "SELECT area, province, period, indicator, value, unit, yearbook FROM hits"
    ):
        if "高新技术企业" not in (indicator or ""):
            continue
        if (unit or "").strip() not in COUNT_UNITS:
            continue
        number = to_number(value)
        if number is None:
            continue
        year = re.sub(r"[^0-9]", "", period or "")[:4]
        if not year:
            continue
        rows.append({
            "来源": "CNKI统计指标库",
            "省": province or "",
            "城市": area or "",
            "城市键": canon_city(area),
            "年份": year,
            "数值": number,
            "单位": unit,
            "口径": scope_of(indicator),
            "指标": indicator,
            "出处": f"{yearbook or ''}".strip(" ·"),
        })
        count += 1
    db.close()
    print(f"CNKI：{count} 行")


LIB_SKIP = {"HBN_数值.csv", "cnopendata_高企_字段字典.csv", "入口清单.csv"}


DUPLICATE_EXPORTS = ("标准表头", "合并面板", "异常值清单", "字段字典", "入口清单", "可访问性",
                     "README", "中国社会科学研究数据库")


def read_lib_extra(rows: list[dict]) -> None:
    """lib_city 下其它数据库导出的 CSV（EPS 等），表头 省,城市,年份,指标,数值,单位,口径,来源URL。"""
    if not LIB_DIR.exists():
        return
    total = 0
    for path in sorted(LIB_DIR.glob("*.csv")):
        if path.name in LIB_SKIP or path.name.startswith("_"):
            continue
        # 子智能体另存的「标准表头 / 合并面板 / 异常清单」是上面主文件的副本，读进来会让同一数值被叠加
        if any(word in path.stem for word in DUPLICATE_EXPORTS):
            continue
        source = path.stem
        count = 0
        try:
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                for item in csv.DictReader(handle):
                    value = to_number(item.get("数值"))
                    indicator = item.get("指标") or ""
                    if value is None or ("高新技术企业" not in indicator and "高企" not in indicator):
                        continue
                    scope_text = item.get("口径") or ""
                    if "市辖区" in scope_text or "市区" in scope_text:
                        scope = "期末存量(市辖区)"
                    elif "存量" in scope_text or "全市" in scope_text:
                        scope = "期末存量"
                    else:
                        scope = scope_of(indicator)
                    rows.append({
                        "来源": source,
                        "省": item.get("省") or "",
                        "城市": item.get("城市") or "",
                        "城市键": canon_city(item.get("城市")),
                        "年份": (item.get("年份") or "").strip(),
                        "数值": value,
                        "单位": (item.get("单位") or "").strip(),
                        "口径": scope,
                        "指标": indicator,
                        "出处": item.get("来源URL") or "",
                    })
                    count += 1
        except Exception as exc:  # noqa: BLE001
            print(f"  读取 {path.name} 失败：{type(exc).__name__}: {exc}")
        if count:
            print(f"  {source}：{count} 行")
        total += count
    print(f"lib_city 其它库：{total} 行")


def read_cert_city(rows: list[dict]) -> dict:
    """各省名单按 城市+认定年度 去重企业数（城市只取名单自带地区列）。"""
    if not CERT_DIR.exists():
        print("跳过 cert_lists：目录不存在")
        return {}
    bucket: defaultdict = defaultdict(set)
    province_bucket: defaultdict = defaultdict(set)
    # 备份文件（*.bak.csv / *.bak_city.csv）不是省文件，读进来会让同一省被算 2~3 遍
    files = sorted(path for path in CERT_DIR.glob("*.csv")
                   if not path.stem.startswith("_") and ".bak" not in path.name)
    for path in files:
        try:
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                for item in csv.DictReader(handle):
                    name = (item.get("企业名称") or "").strip()
                    year = (item.get("认定年度") or "").strip()
                    if not name or not year:
                        continue
                    city = (item.get("城市") or "").strip()
                    province = path.stem.replace("省", "").replace("市", "")
                    province_bucket[(province, year)].add(name)
                    if city:
                        bucket[(province, canon_city(city), city, year)].add(name)
        except Exception as exc:  # noqa: BLE001
            print(f"  读取 {path.name} 失败：{type(exc).__name__}: {exc}")
    count = 0
    for (province, key, city, year), names in bucket.items():
        rows.append({
            "来源": "各省认定名单",
            "省": province,
            "城市": city,
            "城市键": key,
            "年份": year,
            "数值": float(len(names)),
            "单位": "家",
            "口径": "认定数",
            "指标": "名单去重企业数",
            "出处": f"{province}认定名单附件",
        })
        count += 1
    print(f"名单汇总：城市级 {count} 组")
    return dict(province_bucket)


CITY_DIR = WORK / "city_lists"
BAD_LIST = ("奖补", "奖励", "补助", "培育", "兑付", "资助")


def read_city_lists(rows: list[dict]) -> None:
    """地市级名单（work/city_lists/*.csv）按 城市+认定年度 去重企业数。

    只认「认定年度」有值的行，奖补/奖励/培育库类名单一律不要——那些不是认定名单。
    名单口径只是「已公开名单里的家数」，天然是下界，所以优先级排在 CNKI 之后。
    """
    if not CITY_DIR.exists():
        print("跳过 city_lists：目录不存在")
        return
    bucket: defaultdict = defaultdict(set)
    for path in sorted(CITY_DIR.glob("*.csv")):
        try:
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                for item in csv.DictReader(handle):
                    kind = (item.get("名单类型") or "")
                    if any(word in kind for word in BAD_LIST):
                        continue
                    name = (item.get("企业名称") or "").strip()
                    city = (item.get("城市") or "").strip()
                    year = (item.get("认定年度") or "").strip()
                    if not name or not city or not re.fullmatch(r"20\d{2}", year):
                        continue
                    province = (item.get("省") or path.stem).strip()
                    bucket[(province.replace("省", ""), canon_city(city), city, year)].add(name)
        except Exception as exc:  # noqa: BLE001
            print(f"  读取 {path.name} 失败：{type(exc).__name__}: {exc}")
    for (province, key, city, year), names in bucket.items():
        rows.append({
            "来源": "地市认定名单",
            "省": province,
            "城市": city,
            "城市键": key,
            "年份": year,
            "数值": float(len(names)),
            "单位": "家",
            "口径": "地市名单数",
            "指标": "地市名单去重企业数",
            "出处": f"{city}{year} 认定名单",
        })
    print(f"地市名单：城市级 {len(bucket)} 组 · 企业行 {sum(len(v) for v in bucket.values())}")


def pick(cands: list[dict]) -> dict:
    """同城同年多来源时按优先级选一条，并记下所有来源。"""
    order = {"EPS_城市高企": 0, "HBN社科研究数据库": 1, "CNKI统计指标库": 2,
             "地市认定名单": 3, "各省认定名单": 4}
    scopes = {"期末存量": 0, "认定数": 1, "新增认定数": 2, "有效期内数": 3, "期末存量(市辖区)": 4,
              "地市名单数": 5}
    cands.sort(key=lambda c: (order.get(c["来源"], 9), scopes.get(c["口径"], 9), -c["数值"]))
    best = cands[0]
    best = dict(best)
    best["全部来源"] = "；".join(sorted({c["来源"] for c in cands}))
    best["来源值"] = "；".join(f"{c['来源'].split('社科')[0].split('统计')[0].split('各省')[0] or c['来源']}={c['数值']:g}"
                              for c in cands[:4])
    return best


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()

    CANON.update(load_canon())
    print(f"城市名映射 {len(CANON)} 条")
    rows: list[dict] = []
    read_hbn(rows)
    read_lib_extra(rows)
    read_cnki(rows)
    province_counts = read_cert_city(rows)
    read_city_lists(rows)
    if not rows:
        print("没有任何数据")
        return 1

    by_city_year: defaultdict = defaultdict(list)
    for item in rows:
        if not item["城市键"]:
            continue
        # 三源写市名的方式不一致（「济南」/「济南市」都有），合并前再做一次归一，
        # 否则同一个城市会被拆成两行、让 DID 的样本凭空变多。
        item["城市键"] = canon_city(item["城市键"])
        item["城市"] = item["城市键"]
        item["省"] = norm_prov(item["省"])
        by_city_year[(item["省"], item["城市键"], item["年份"])].append(item)

    panel = [pick(cands) for key, cands in sorted(by_city_year.items())]

    from openpyxl import Workbook
    from openpyxl.utils import get_column_letter

    wb = Workbook()

    # 总表做成「一行一个城市-年份」的宽表：各口径分列，每列带自己的来源
    from openpyxl import Workbook as _WB  # noqa: F401  (占位，保持导入位置不变)
    ws = wb.active
    ws.title = "01总表·城市年度"
    scopes = ("期末存量", "期末存量(市辖区)", "认定数", "新增认定数", "有效期内数", "地市名单数")
    header = ["省", "城市", "地方层级", "年份"]
    for scope in scopes:
        header += [scope, f"{scope}·来源"]
    header += ["全部来源", "各来源取值"]
    ws.append(header)
    level_of = city_level

    # 宽表必须吃「同一个城市-年份的全部候选」，只吃 pick() 的结果会让每行只剩一个口径
    grouped: defaultdict = defaultdict(list)
    for cell, cands in by_city_year.items():
        for item in cands:
            grouped[(cell[0], item["城市"], cell[2])].append(item)
    for (province, city, year), cands in sorted(grouped.items()):
        per_scope: dict[str, dict] = {}
        for item in cands:
            current = per_scope.get(item["口径"])
            if current is None or item["数值"] > current["数值"]:
                per_scope[item["口径"]] = item
        line = [province, city, level_of(city), year_cell(year)]
        for scope in scopes:
            hit = per_scope.get(scope)
            line += [hit["数值"] if hit else None, hit["来源"] if hit else ""]
        line += ["；".join(sorted({c["来源"] for c in cands})),
                 "；".join(f"{c['来源']}/{c['口径']}={c['数值']:g}" for c in cands[:4])]
        ws.append(line)

    ws2 = wb.create_sheet("02来源对照")
    ws2.append(["省", "城市", "年份", "EPS城市年鉴", "HBN", "CNKI", "名单汇总", "采用值", "采用来源"])
    for key, cands in sorted(by_city_year.items()):
        eps = next((c["数值"] for c in cands if c["来源"].startswith("EPS")), None)
        hbn = next((c["数值"] for c in cands if c["来源"].startswith("HBN")), None)
        cnki = next((c["数值"] for c in cands if c["来源"].startswith("CNKI")), None)
        cert = next((c["数值"] for c in cands if c["来源"].startswith("各省")), None)
        best = pick(cands)
        ws2.append([key[0], cands[0]["城市"], year_cell(key[2]), eps, hbn, cnki, cert, best["数值"], best["来源"]])

    ws3 = wb.create_sheet("03七个试点城市")
    ws3.append(["城市", "年份", "期末存量", "认定数", "新增认定数", "有效期内数", "数据来源"])
    for city in PILOT:
        key_base = canon_city(city)
        for year in sorted({k[2] for k in by_city_year if k[1] == key_base}):
            cands = [c for k, v in by_city_year.items() if k[1] == key_base and k[2] == year for c in v]
            buckets = defaultdict(list)
            for item in cands:
                buckets[item["口径"]].append(item)
            picknum = lambda scope: (max(buckets[scope], key=lambda c: c["数值"])["数值"] if buckets[scope] else None)
            ws3.append([city, year_cell(year), picknum("期末存量"), picknum("认定数"), picknum("新增认定数"),
                        picknum("有效期内数"), "；".join(sorted({c["来源"] for c in cands}))])

    ws4 = wb.create_sheet("04数据来源说明")
    ws4.append(["来源", "地址", "覆盖范围", "口径", "本次行数", "说明"])
    src_count = Counter(item["来源"] for item in rows)
    ws4.append(["HBN社科研究数据库", "https://ssd.harborn.cn/data/index",
                "区县经济/地方经济/宏观经济/黄河流域等库，省-市-区县三级树",
                "统计年鉴口径的年末企业数、新增数", src_count["HBN社科研究数据库"],
                "机构账号 sdufe 登录；序列按城市枚举，数值直接取时序"])
    ws4.append(["EPS全球统计数据平台·中国城市数据库", "https://olap.epsnet.com.cn",
                "293 个城市 × 2023–2024，全市与市辖区两套口径",
                "《中国城市统计年鉴》口径的国家级高新技术企业数（个）", src_count["EPS_城市高企"],
                "校外 IP 直登（loginType=IP），cube 627 / 指标 1407；单次导出限 200 行"])
    ws4.append(["CNKI中国经济社会大数据研究平台", "https://data.cnki.net/valueSearch/index",
                "统计公报/年鉴知识元，area 可到地级市与区县",
                "公报原文口径（认定数、有效期内数、规上数等）", src_count["CNKI统计指标库"],
                "Playwright 取 cookie 后调 GetOneBoxSearch 接口"])
    ws4.append(["各省认定名单", "http://www.innocom.gov.cn/gqrdw/（备案公告栏目）",
                "已收录省份的企业级证书名单，城市仅取附件自带的地区列",
                "按名单去重的当年认定企业数", src_count["各省认定名单"],
                "证书编号 GR+年度4+省码2+顺序6，第7-10位不是行政区划码，不能反推城市"])
    ws4.append([])
    ws4.append(["地市认定名单", "各市科技局/省厅公布名单（work/city_lists）",
                "37 个地市，含拟认定公示与有效期名单，部分城市只有公示批次",
                "按名单去重的当年认定企业数（批次不全时偏小）", src_count["地市认定名单"],
                "只作补充：口径与「各省认定名单」不同层，单列「地市名单数」，不并入「认定数」"])
    ws4.append(["口径优先级", "EPS（2023/2024 年鉴）> HBN > CNKI > 地市名单 > 各省名单；"
                "同源同城同年取口径更靠前、数值更大的一条", "", "", "", ""])
    ws4.append(["地方层级", "省（仅 CNKI 省级记录）/ 地级市（含直辖市）/ 区县 / 园区·其它", "", "", "",
                "做城市级 DID 时请筛「地方层级=地级市」，共约 4,800 行 / 319 个城市"])
    ws4.append(["年份提示", "", "", "", "",
                "存量：2023/2024 覆盖 300+ 市可放心用；2025 只有 118 市且多为年中口径，"
                "建议只做稳健性检验。认定数：2021 起才有城市级覆盖，2024 最好（269 市）"])
    ws4.append(["推断标注", "", "", "", "",
                "陕西省 2024/2025 年约 4,700 行的城市是按同名企业 3 年复审周期推断回填的，"
                "不来自官方件地区列；严格口径请剔除该省这两年城市。其余省份城市均取自官方名单地区列"])
    ws4.append(["企业级城市", "", "", "", "",
                "work/city_lists 的 38 个地市名单已回填进 work/cert_lists 各省名单（19.96 万行），"
                "企业级城市覆盖 60.3 万/133.7 万行；剩 12 省省厅公布件本身无地区列"])

    ws5 = wb.create_sheet("05城市×年份覆盖")
    ws5.append(["省", "城市", "最早年份", "最晚年份", "有数据年份数", "数据来源"])
    cover: defaultdict = defaultdict(set)
    for item in panel:
        cover[(item["省"], item["城市"])].add((item["年份"], item["来源"]))
    for (province, city), pairs in sorted(cover.items()):
        years = sorted({y for y, _ in pairs})
        ws5.append([province, city, years[0], years[-1], len(years),
                    "；".join(sorted({s for _, s in pairs}))])

    ws6 = wb.create_sheet("06省级名单汇总")
    ws6.append(["省", "认定年度", "名单企业数", "来源"])
    for (province, year), names in sorted(province_counts.items()):
        ws6.append([province, year, len(names), "各省认定名单"])

    widths = {
        "01总表·城市年度": [10, 14, 10, 8, 12, 20, 12, 20, 12, 20, 12, 20, 12, 20, 34, 60],
        "02来源对照": [10, 14, 8, 14, 12, 12, 12, 12, 20],
        "03七个试点城市": [12, 8, 12, 12, 12, 12, 30],
        "04数据来源说明": [26, 42, 40, 30, 10, 46],
        "05城市×年份覆盖": [10, 14, 10, 10, 10, 34],
        "06省级名单汇总": [10, 10, 12, 20],
    }
    for name, cols in widths.items():
        sheet = wb[name]
        for idx, width in enumerate(cols, 1):
            sheet.column_dimensions[get_column_letter(idx)].width = width
        sheet.freeze_panes = "A2"

    args.out.parent.mkdir(parents=True, exist_ok=True)
    tmp = args.out.with_suffix(".tmp.xlsx")
    wb.save(tmp)
    tmp.replace(args.out)
    cities = {(item["省"], item["城市"]) for item in panel}
    print(f"已导出 {args.out}")
    print(f"  总表 {len(panel)} 行 · 城市 {len(cities)} 个 · 年份 {min(i['年份'] for i in panel)}-{max(i['年份'] for i in panel)}")
    print(f"  来源分布 {dict(Counter(i['来源'] for i in panel))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
