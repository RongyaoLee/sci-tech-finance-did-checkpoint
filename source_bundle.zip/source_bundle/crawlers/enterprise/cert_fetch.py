"""Shared polite fetch helpers for the 高企 certificate-number crawl."""
import os, time, random, threading
import requests, urllib3

urllib3.disable_warnings()

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
}

_LOCK = threading.Lock()
_LAST = {}
MIN_INTERVAL = 0.5  # <=2 req/s per host

S = requests.Session()
S.headers.update(HEADERS)
S.verify = False
try:
    S.trust_env = True
except Exception:
    pass


def _throttle(host):
    with _LOCK:
        now = time.time()
        last = _LAST.get(host, 0.0)
        wait = MIN_INTERVAL - (now - last)
        if wait > 0:
            time.sleep(wait)
        _LAST[host] = time.time()


def get(url, timeout=30, tries=3, allow_http_fallback=True, **kw):
    """GET with per-host rate limit, UA, retries and http fallback."""
    from urllib.parse import urlsplit
    last_exc = None
    urls = [url]
    if allow_http_fallback and url.startswith("https://"):
        urls.append("http://" + url[len("https://"):])
    for attempt in range(tries):
        for u in urls:
            host = urlsplit(u).netloc
            _throttle(host)
            try:
                r = S.get(u, timeout=timeout, **kw)
                if r.status_code >= 400:
                    last_exc = RuntimeError(f"HTTP {r.status_code} {u}")
                    continue
                return r
            except Exception as e:  # SSLError, SSLEOFError, ConnectionError ...
                last_exc = e
                continue
        time.sleep(1.0 + attempt * 1.5)
    raise last_exc if last_exc else RuntimeError("fetch failed")


def text(r):
    """Decode response body honoring charset meta / apparent encoding."""
    raw = r.content
    enc = None
    ct = r.headers.get("Content-Type", "")
    if "charset=" in ct:
        enc = ct.split("charset=")[-1].split(";")[0].strip().strip('"')
    if not enc or enc.lower() in ("iso-8859-1", "latin-1"):
        head = raw[:4000].decode("ascii", "ignore").lower()
        for cand in ("utf-8", "gbk", "gb2312"):
            if cand in head:
                enc = cand
                break
    if not enc or enc.lower() in ("iso-8859-1", "latin-1"):
        enc = "utf-8"
    try:
        return raw.decode(enc, "replace")
    except LookupError:
        return raw.decode("utf-8", "replace")
