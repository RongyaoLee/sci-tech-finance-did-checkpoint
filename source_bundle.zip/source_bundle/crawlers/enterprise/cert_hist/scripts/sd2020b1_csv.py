# -*- coding: utf-8 -*-
"""Write 山东_2020_第1批.csv from the decoded rows (UTF-8 BOM)."""
import csv, json, os, sys, re
import pymupdf
import sd2020b1_decode as D

SRC_URL = ("http://www.innocom.gov.cn/gqrdw/c101460/202012/963012c3b2054bba84bd02ee883694b5"
           "/files/aa73c8b735d74f6da634ea7a2138c640.pdf")
OUT = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_hist\山东_2020_第1批.csv"
JSONL = os.path.join(os.path.dirname(D.PDF), "sd2020b1_decoded.json")

recs = json.load(open(JSONL, encoding="utf-8"))
recs.sort(key=lambda r: r["seq"])

with open(OUT, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"])
    for r in recs:
        w.writerow([r["name"], r["cert"], "", "", "2020", "第1批", SRC_URL])

print("wrote", len(recs), "->", OUT)

# validation summary
certs = [r["cert"] for r in recs]
print("prefix set:", sorted({c[:8] for c in certs}))
nums = [int(c[8:]) for c in certs]
print("num range:", min(nums), max(nums), "count:", len(nums), "unique:", len(set(nums)))
gaps = [(a, b) for a, b in zip(nums, nums[1:]) if b - a != 1]
print("gaps:", gaps)
print("fmt ok:", all(re.fullmatch(r"GR202037\d{6}", c) for c in certs))
