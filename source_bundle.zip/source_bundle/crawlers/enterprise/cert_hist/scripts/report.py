# -*- coding: utf-8 -*-
"""Final report table: 地区 | 年度 | 入口URL | 附件类型 | 行数 | 有编号行数 | 城市是否可得 | 备注"""
import os
import re
import csv
import json
import collections

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(HERE, "_raw")
YEARS = ("2016", "2017", "2018", "2019", "2020")
LBL = {".pdf": "PDF", ".doc": "DOC", ".docx": "DOCX", ".xls": "XLS",
       ".xlsx": "XLSX", ".wps": "WPS", ".zip": "ZIP", ".rar": "RAR"}
ORDER = ["北京", "天津", "河北", "山西", "内蒙古", "辽宁", "吉林", "黑龙江", "上海",
         "江苏", "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南",
         "广东", "广西", "海南", "重庆", "四川", "贵州", "云南", "西藏", "陕西",
         "甘肃", "青海", "宁夏", "新疆", "大连", "宁波", "厦门", "青岛", "深圳"]


def prov_meta(prov):
    p = os.path.join(RAW, prov, f"{prov}_meta.json")
    if not os.path.exists(p):
        return None
    return json.load(open(p, encoding="utf-8"))


def build_index():
    """prov -> (col, {(year): {exts}})
    col 取 meta items 详情页 URL 里出现最多的 c101xxx"""
    idx = {}
    for prov in ORDER:
        m = prov_meta(prov)
        if not m:
            continue
        chs = collections.Counter()
        exts = collections.defaultdict(set)
        for it in m.get("items") or []:
            y = str(it.get("year"))
            if y not in YEARS:
                continue
            mm = re.search(r"/gqrdw/(c\d+)/", it.get("url") or "")
            if mm:
                chs[mm.group(1)] += 1
            for a in it.get("atts") or []:
                exts[y].add(LBL.get(os.path.splitext(a.lower())[1], ""))
        idx[prov] = (chs.most_common(1)[0][0] if chs else None, exts)
    return idx


def main():
    idx = build_index()
    out = []
    for f in sorted(os.listdir(HERE)):
        if not f.endswith(".csv") or "_第" in f:
            continue
        prov, y = f[:-4].rsplit("_", 1)
        if y not in YEARS:
            continue
        rows = list(csv.DictReader(open(os.path.join(HERE, f), encoding="utf-8-sig")))
        if not rows:
            continue
        certs = sum(1 for r in rows if r["证书编号"])
        city = sum(1 for r in rows if r["城市"])
        batches = sorted({r["批次"] for r in rows if r["批次"]})
        col, exts = idx.get(prov, (None, {}))
        entry = (f"http://www.innocom.gov.cn/gqrdw/{col}/list_gsgg_l3.shtml"
                 if col else "")
        al = [e for e in exts.get(y, set()) if e]
        atype = "+".join(sorted(al)) if al else "—"
        citytxt = "否" if city == 0 else ("是" if city == len(rows) else f"部分 {city}/{len(rows)}")
        note = "批:" + "/".join(batches) if batches else "批:—"
        if not certs:
            note += "；**无编号（仅公示名单）**"
        out.append([prov, y, entry, atype, len(rows), certs, citytxt, note])

    def key(r):
        return (ORDER.index(r[0]) if r[0] in ORDER else 99, r[0], r[1])

    out.sort(key=key)
    lines = ["| 地区 | 年度 | 入口URL | 附件类型 | 行数 | 有编号行数 | 城市是否可得 | 备注 |",
             "|---|---|---|---|---:|---:|---|---|"]
    for r in out:
        lines.append("| " + " | ".join(str(x) for x in r) + " |")
    tot = sum(r[4] for r in out)
    tc = sum(r[5] for r in out)
    tail = f"\n合计 {len(out)} 个 省×年 文件，{tot} 行，{tc} 行带证书编号\n"
    txt = "\n".join(lines) + "\n" + tail
    open(os.path.join(RAW, "_report.md"), "w", encoding="utf-8").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
