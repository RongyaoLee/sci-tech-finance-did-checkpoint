# -*- coding: utf-8 -*-
"""List a column's pages directly: python list_deep.py <ch> <page_from> <page_to> [l2|l3]"""
import os
import re
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))), "cert_lists"))
import fetch_common as fc  # noqa: E402
from bs4 import BeautifulSoup  # noqa: E402

ch = sys.argv[1]
a = int(sys.argv[2]) if len(sys.argv) > 2 else 1
b = int(sys.argv[3]) if len(sys.argv) > 3 else a
kind = sys.argv[4] if len(sys.argv) > 4 else "l3"

n = 0
for p in range(a, b + 1):
    url = f"http://www.innocom.gov.cn/gqrdw/{ch}/list_gsgg_{kind}{'' if p == 1 else f'_{p}'}.shtml"
    try:
        r = fc.get(url)
    except Exception as e:
        print(f"p{p} ERR {e}")
        break
    if isinstance(r, tuple):
        r = r[0]
    if r is None or r.status_code != 200:
        print(f"p{p} HTTP {getattr(r, 'status_code', 'None')}")
        break
    soup = BeautifulSoup(fc.text(r), "lxml")
    items = soup.select("a[href*='/gqrdw/']")
    got = 0
    for a_ in items:
        t = (a_.get("title") or a_.get_text() or "").strip()
        h = a_.get("href") or ""
        if "/c" not in h or not re.search(r"/\d{6}/", h):
            continue
        m = re.search(r"<span>\s*(\d{4}-\d{2}-\d{2})\s*</span>", str(a_.parent))
        print(f"p{p}\t{m.group(1) if m else ''}\t{t[:70]}\t{h}")
        got += 1
    n += got
    print(f"-- page {p}: {got} items (total {n})")
    if got == 0:
        break
