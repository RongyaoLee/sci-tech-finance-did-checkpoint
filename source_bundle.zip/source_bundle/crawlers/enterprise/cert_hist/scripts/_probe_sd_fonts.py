# -*- coding: utf-8 -*-
import re, io, json
import pymupdf
from fontTools.ttLib import TTFont

PDF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_hist\_raw\山东\关于山东省2020年第一批高新技术企业备案的复函_aa73c8b735.pdf"
doc = pymupdf.open(PDF)
page = doc[3]
for f in page.get_fonts(full=True):
    xref, ext, typ, basefont = f[0], f[1], f[2], f[3]
    obj = doc.xref_object(xref)
    print("=== ", basefont, "type", typ, "ext", ext)
    print(obj.replace("\n", " ")[:600])
    m = re.search(r"/Encoding (\d+) 0 R", obj)
    if m:
        print(" ENC:", doc.xref_object(int(m.group(1))).replace("\n", " ")[:800])
    nb, bext, ntyp, buf = doc.extract_font(xref)
    if buf:
        print(" font stream:", len(buf), bext)
        try:
            tt = TTFont(io.BytesIO(buf), fontNumber=0, lazy=True)
            print(" tables:", sorted(tt.keys()))
            go = tt.getGlyphOrder()
            print(" glyphs:", len(go), go[:12])
            if "cmap" in tt:
                print(" cmap tables:", len(tt["cmap"].tables))
        except Exception as e:
            print(" TTFont err", e)
