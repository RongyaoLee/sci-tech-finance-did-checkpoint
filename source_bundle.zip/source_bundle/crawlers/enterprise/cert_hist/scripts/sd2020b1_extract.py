# -*- coding: utf-8 -*-
"""Extract 山东 2020 第1批 名单 from the decoded 复函 PDF -> validated rows + CSV."""
import os, re, sys, json
import pymupdf

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd2020b1_decode as D

SRC_URL = ("http://www.innocom.gov.cn/gqrdw/c101460/202012/963012c3b2054bba84bd02ee883694b5"
           "/files/aa73c8b735d74f6da634ea7a2138c640.pdf")
OUT = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_hist\山东_2020_第1批.csv"

CERT_RE = re.compile(r"GR202037\d{6}")
SEQ_RE = re.compile(r"^(\d{1,4})(.*)$")

doc = pymupdf.open(D.PDF)
recs = []
noise = []
for pno in range(len(doc)):
    page = doc[pno]
    chars = D.decode_page(doc, page)
    if not chars:
        continue
    for y, cells in D.rows_of(chars):
        line = "".join(cells)
        m = CERT_RE.search(line)
        if not m:
            noise.append((pno + 1, line))
            continue
        head = line[:m.start()]
        cert = m.group(0)
        tail = line[m.end():]
        ms = SEQ_RE.match(head)
        if not ms:
            noise.append((pno + 1, line))
            continue
        seq = int(ms.group(1))
        name = ms.group(2).strip()
        recs.append({"page": pno + 1, "seq": seq, "name": name, "cert": cert, "tail": tail})

print("raw cert rows:", len(recs))
print("noise lines:", len(noise))
for n in noise[:10]:
    print("  noise", n)

# ---- integrity checks ----
seqs = [r["seq"] for r in recs]
print("seq min/max:", min(seqs), max(seqs), "unique:", len(set(seqs)))
dups = [s for s in set(seqs) if seqs.count(s) > 1]
print("dup seqs:", dups[:10])
missing = [s for s in range(1, max(seqs) + 1) if s not in set(seqs)]
print("missing seqs:", missing[:20], "count", len(missing))

bad_cert, bad_name = [], []
for r in recs:
    exp = "GR202037%06d" % r["seq"]
    if r["cert"] != exp:
        bad_cert.append((r["seq"], r["cer"]) if False else (r["seq"], r["cert"], exp))
    if not re.search(r"(公司|集团|研究院|研究所|研究中心|中心|学院|大学|医院|厂|合作社|事务所|工作室|商行|经营部|分院|学校|社)$", r["name"]):
        bad_name.append((r["seq"], r["name"]))
print("cert != zero-padded seq:", len(bad_cert), bad_cert[:10])
print("name tail suspicious:", len(bad_name), bad_name[:10])

# name char sanity: no replacement chars, no latin-only junk
badchars = [(r["seq"], r["name"]) for r in recs if "\ufffd" in r["name"] or len(r["name"]) < 4]
print("bad names:", len(badchars), badchars[:10])

json.dump(recs, open(os.path.join(os.path.dirname(D.PDF), "sd2020b1_decoded.json"), "w",
                     encoding="utf-8"), ensure_ascii=False, indent=0)
print("\nsample:", recs[:3])
print("tail:", recs[-3:])
