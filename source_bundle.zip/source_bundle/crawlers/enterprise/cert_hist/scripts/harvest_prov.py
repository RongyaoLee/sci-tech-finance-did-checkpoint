# -*- coding: utf-8 -*-
"""Harvest one province from innocom 备案公告(c101443-478) + 公示(c101407-442),
then split rows by 认定年度 into ../<地区>_<年份>.csv

Usage: python harvest_prov.py 江苏 [pages]
Outputs:
  cert_hist/_raw/<prov>/<prov>_rows.json   (all rows + stats)
  cert_hist/<prov>_<year>.csv
"""
import os, sys, json, csv, re, collections

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # cert_hist
WORK = os.path.dirname(HERE)                                        # work
sys.path.insert(0, os.path.join(WORK, "cert_lists"))
sys.path.insert(0, WORK)
import fetch_common as fc

fc.RAW = os.path.join(HERE, "_raw")   # never touch cert_lists/_raw
HDR = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]


def run(prov, pages=6, kinds=("gg", "gs")):
    raw_dir = os.path.join(HERE, "_raw", prov)
    os.makedirs(raw_dir, exist_ok=True)
    rows = fc.harvest(prov, pages=pages, kinds=kinds)
    js = os.path.join(raw_dir, f"{prov}_rows.json")
    json.dump(rows, open(js, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return rows


def split_write(prov, rows):
    """Dedupe by cert (keep first w/ city), fallback key (name,year)."""
    by_cert, by_name = {}, {}
    for r in rows:
        y = str(r.get("year") or "")
        if y not in ("2016", "2017", "2018", "2019", "2020"):
            continue
        c = r.get("cert") or ""
        if c:
            cur = by_cert.get(c)
            if cur is None:
                by_cert[c] = dict(r)
            else:
                for f in ("city", "county", "name", "src"):
                    if not cur.get(f) and r.get(f):
                        cur[f] = r[f]
        else:
            k = (re.sub(r"\s+", "", r.get("name") or ""), y)
            if k not in by_name:
                by_name[k] = dict(r)
    # name-only rows that already have a cert row for same (name,year) are dropped
    cert_names = {(re.sub(r"\s+", "", v.get("name") or ""), str(v.get("year"))) for v in by_cert.values()}
    kept = list(by_cert.values()) + [v for k, v in by_name.items() if k not in cert_names]
    out = {}
    for y in ("2016", "2017", "2018", "2019", "2020"):
        rs = [r for r in kept if str(r.get("year")) == y]
        if not rs:
            continue
        def key(r):
            return (r.get("batch") or "", str(r.get("cert") or "zzz"), r.get("name") or "")
        rs.sort(key=key)
        p = os.path.join(HERE, f"{prov}_{y}.csv")
        with open(p, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(HDR)
            for r in rs:
                w.writerow([r.get("name", ""), r.get("cert", ""), r.get("city", ""),
                            r.get("county", ""), y, r.get("batch", ""), r.get("src", "")])
        out[y] = (len(rs), sum(1 for r in rs if r.get("cert")))
    return out


if __name__ == "__main__":
    prov = sys.argv[1]
    pages = int(sys.argv[2]) if len(sys.argv) > 2 else 6
    rows = run(prov, pages)
    stats = split_write(prov, rows)
    print(f"== {prov}: raw={len(rows)}")
    for y, (n, c) in sorted(stats.items()):
        print(f"   {y}: rows={n} cert={c}")
    print(json.dumps({"prov": prov, "stats": stats}, ensure_ascii=False))
