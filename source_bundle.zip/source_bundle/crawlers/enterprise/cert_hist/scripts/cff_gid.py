# -*- coding: utf-8 -*-
"""Generic decoder for innocom 备案复函 PDFs whose embedded Type1/CFF subset uses
SimSun original GIDs as glyph names (gNNNN) with a custom /Differences encoding.

Public API:
    pdf_rows(path) -> dict(pages, chars, lines, rows, mode)
        rows: list of dict(seq, name, cert, page)
    text_lines(path) -> list[(page, y, text)]
"""
import os
import re
import sys

import pymupdf
from fontTools.ttLib import TTFont

_SIMSUN = r"C:\Windows\Fonts\simsun.ttc"


def _gid2ch():
    f = TTFont(_SIMSUN, fontNumber=0)
    order = f.getGlyphOrder()
    rev = {}
    for cp, gn in f.getBestCmap().items():
        rev.setdefault(gn, chr(cp))
    return {i: rev[gn] for i, gn in enumerate(order) if gn in rev}


GID2CH = _gid2ch()

CERT_RE = re.compile(r"GR\s*(\d{12})")
CJK_RE = re.compile(r"[\u4e00-\u9fff]")


def _plausible_name(s):
    return bool(s) and len(s) >= 4 and bool(CJK_RE.search(s)) and "GR" not in s


def parse_diffs(s):
    if "[" not in s or "]" not in s:
        return {}
    seg = s[s.index("["): s.index("]") + 1]
    toks = re.findall(r"\d+|/[^\s/\[\]]+", seg)
    m = {}
    cur = 0
    for t in toks:
        if t.startswith("/"):
            m[cur] = t[1:]
            cur += 1
        else:
            cur = int(t)
    return m


def font_info(doc, xref):
    obj = doc.xref_object(xref)
    if "/Type0" in obj or "/Identity-H" in obj:
        return None, None  # not our broken-SimSun case
    m = re.search(r"/Encoding (\d+) 0 R", obj)
    diffs, widths = {}, {}
    if m:
        try:
            diffs = parse_diffs(doc.xref_object(int(m.group(1))))
        except Exception:
            diffs = {}
    fc = re.search(r"/FirstChar (\d+)", obj)
    fc = int(fc.group(1)) if fc else 0
    wm = re.search(r"/Widths \[(.*?)\]", obj, re.S)
    if wm:
        ws = [int(float(x)) for x in wm.group(1).split()]
        widths = {fc + i: w for i, w in enumerate(ws)}
    return diffs, widths


def tokens(s):
    i, n = 0, len(s)
    while i < n:
        c = s[i:i + 1]
        if c in b" \t\r\n\x00\x0c":
            i += 1
            continue
        if c == b"%":
            j = s.find(b"\n", i)
            i = n if j < 0 else j + 1
            continue
        if c == b"(":
            depth, j = 1, i + 1
            buf = bytearray()
            while j < n and depth:
                ch = s[j:j + 1]
                if ch == b"\\":
                    nx = s[j + 1:j + 2]
                    esc = {b"n": b"\n", b"r": b"\r", b"t": b"\t", b"b": b"\b",
                           b"f": b"\f", b"(": b"(", b")": b")", b"\\": b"\\"}
                    if nx in esc:
                        buf += esc[nx]
                        j += 2
                        continue
                    if nx.isdigit():
                        k = 0
                        while k < 3 and s[j + 1 + k:j + 2 + k].isdigit():
                            k += 1
                        buf.append(int(s[j + 1:j + 1 + k], 8) & 0xFF)
                        j += 1 + k
                        continue
                    if nx in (b"\n", b"\r"):
                        j += 2
                        continue
                    buf += nx
                    j += 2
                    continue
                if ch == b"(":
                    depth += 1
                elif ch == b")":
                    depth -= 1
                    if depth == 0:
                        j += 1
                        break
                buf += ch
                j += 1
            yield ("str", bytes(buf))
            i = j
            continue
        if c == b"<" and s[i + 1:i + 2] != b"<":
            j = s.find(b">", i)
            if j < 0:
                i = n
                continue
            hx = re.sub(rb"\s", b"", s[i + 1:j])
            try:
                yield ("str", bytes.fromhex(hx.decode()))
            except Exception:
                pass
            i = j + 1
            continue
        if c == b"[":
            yield ("[", None)
            i += 1
            continue
        if c == b"]":
            yield ("]", None)
            i += 1
            continue
        if c == b"/":
            j = i + 1
            while j < n and s[j:j + 1] not in b" \t\r\n\x00\x0c/[]<>(){}%":
                j += 1
            yield ("name", s[i + 1:j].decode("latin1"))
            i = j
            continue
        j = i
        while j < n and s[j:j + 1] not in b" \t\r\n\x00\x0c/[]<>()%":
            j += 1
        w = s[i:j].decode("latin1")
        try:
            yield ("num", float(w))
        except Exception:
            yield ("op", w)
        i = j


def page_chars(doc, page):
    fonts = {}
    for fn in page.get_fonts(full=True):
        try:
            fonts[fn[4]] = font_info(doc, fn[0])
        except Exception:
            pass
    out = []
    tm = [1, 0, 0, 1, 0, 0]
    tlm = tm[:]
    fname = None
    adv = 0.0

    def show(bs, size):
        nonlocal adv
        fi = fonts.get(fname)
        for code in bs:
            ch = None
            if fi and fi[0] and code in fi[0]:
                nm = fi[0][code]
                if nm.startswith("g") and nm[1:].isdigit():
                    ch = GID2CH.get(int(nm[1:]))
            if ch is None:
                ch = "\ufffd"
            out.append((tm[0] * adv + tm[4], tm[1] * adv + tm[5], ch, size))
            w = fi[1].get(code, 1000) if (fi and fi[1]) else 1000
            adv += w / 1000.0

    try:
        cs = b"".join(doc.xref_stream(x) for x in page.get_contents())
    except Exception:
        return out
    if len(cs) > 4_000_000:  # guard against pathological streams
        cs = cs[:4_000_000]
    toks = []
    for t in tokens(cs):
        toks.append(t)
        if len(toks) >= 400_000:
            toks.append(("op", "ET"))
            break
    size = 10.0
    i = 0
    while i < len(toks):
        k, v = toks[i]
        if k == "op":
            if v == "BT":
                tm = [1, 0, 0, 1, 0, 0]
                tlm = tm[:]
                adv = 0.0
            elif v == "Tf":
                if i >= 2 and toks[i - 1][0] == "num":
                    size = toks[i - 1][1]
                if i >= 2 and toks[i - 2][0] == "name":
                    fname = toks[i - 2][1]
            elif v == "Tm" and i >= 6:
                nums = [toks[i - 6 + j][1] for j in range(6)]
                tm = list(nums)
                tlm = list(nums)
                adv = 0.0
            elif v in ("Td", "TD") and i >= 2:
                tx, ty = toks[i - 2][1], toks[i - 1][1]
                tlm = [tlm[0], tlm[1], tlm[2], tlm[3],
                       tlm[0] * tx + tlm[2] * ty + tlm[4],
                       tlm[1] * tx + tlm[3] * ty + tlm[5]]
                tm = tlm[:]
                adv = 0.0
            elif v in ("Tj", "'", '"') and i >= 1 and toks[i - 1][0] == "str":
                show(toks[i - 1][1], size)
            elif v == "TJ":
                j = i - 1
                while j >= 0 and toks[j][0] != "[":
                    j -= 1
                for kk, vv in toks[j + 1:i - 1]:
                    if kk == "str":
                        show(vv, size)
                    elif kk == "num":
                        adv -= vv / 1000.0
        i += 1
    return out


def text_lines(doc, tol=3.0):
    res = []
    for pno in range(len(doc)):
        chs = page_chars(doc, doc[pno])
        if not chs:
            continue
        chs.sort(key=lambda t: (-round(t[1], 1), t[0]))
        lines = []
        for x, y, c, sz in chs:
            if lines and abs(lines[-1]["y"] - y) <= tol:
                lines[-1]["chars"].append((x, c))
            else:
                lines.append({"y": y, "chars": [(x, c)]})
        for ln in lines:
            seg = sorted(ln["chars"])
            # split into cells on gaps > 3 * font size estimate
            cells, cur, lastx = [], [], None
            for x, c in seg:
                if lastx is not None and x - lastx > 18 and c.strip():
                    if "".join(ch for _, ch in cur).strip():
                        cells.append("".join(ch for _, ch in cur).strip())
                    cur = []
                cur.append((x, c))
                lastx = x
            if cur:
                cells.append("".join(ch for _, ch in cur).strip())
            cells = [c for c in cells if c]
            if cells:
                res.append((pno, round(ln["y"], 1), cells))
    return res


def pdf_rows(path, max_pages=None):
    doc = pymupdf.open(path)
    if max_pages:
        pass
    lines = text_lines(doc)
    rows = []
    for li, (pno, y, cells) in enumerate(lines):
        joined = "".join(cells)
        m = CERT_RE.search(joined)
        if not m:
            continue
        cert = "GR" + m.group(1)
        name = None
        seq = None
        # name = cell immediately preceding the cell containing the cert
        for idx, cell in enumerate(cells):
            if CERT_RE.search(cell):
                if idx >= 1:
                    name = cells[idx - 1]
                if idx >= 2 and re.fullmatch(r"\d{1,4}", cells[idx - 2]):
                    seq = cells[idx - 2]
                break
        if name is None:
            pre = joined[:m.start()]
            pre = re.sub(r"^\s*\d{1,4}\s*", "", pre).strip()
            name = pre or None
        if name and re.fullmatch(r"\d{1,4}", name) and len(cells) >= 3:
            name = cells[-2]
        # overlong names are drawn ~8pt above the cert line as their own line
        if not _plausible_name(name):
            for j in range(li - 1, max(li - 5, -1), -1):
                pp, py, pc = lines[j]
                if pp != pno or y - py > 16:
                    break
                if len(pc) == 1 and _plausible_name(pc[0]) and not re.search(r"\d{6}", pc[0]):
                    name = pc[0]
                    break
        rows.append({"seq": seq, "name": name, "cert": cert, "page": pno})
    nchars = sum(1 for _ in lines)
    return {"pages": len(doc), "lines": len(lines), "rows": rows, "nchars": nchars}


if __name__ == "__main__":
    for p in sys.argv[1:]:
        try:
            r = pdf_rows(p)
            print(f"{os.path.basename(p)[:60]:<62} pages={r['pages']:<4} lines={r['lines']:<5} rows={len(r['rows'])}")
            for row in r["rows"][:2]:
                print("     ", row)
        except Exception as e:
            print(f"{os.path.basename(p)[:60]:<62} ERR {e}")
