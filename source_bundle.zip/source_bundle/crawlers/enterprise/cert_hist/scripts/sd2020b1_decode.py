# -*- coding: utf-8 -*-
"""Decode 山东 2020 第1批 备案复函 PDF (Type1/CFF subset, glyph names /g<GID>, no ToUnicode).

Approach: parse the page content stream ourselves, resolve each byte code through the
font's /Encoding /Differences array to the glyph name /g<GID>, then map GID -> Unicode
using the *original* Windows font's cmap (SimSun / Times New Roman ...), inverted.
No OCR, no guessing: every character is recovered from the embedded font's own glyph ids.
"""
import os, re, io, json, sys
import pymupdf
from fontTools.ttLib import TTFont

PDF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_hist\_raw\山东\关于山东省2020年第一批高新技术企业备案的复函_aa73c8b735.pdf"
FONTDIR = r"C:\Windows\Fonts"

FAMILY_FILES = [
    ("SimSun", [("simsun.ttc", 0), ("simsun.ttc", 1)]),
    ("SimHei", [("simhei.ttf", None)]),
    ("FangSong", [("simfang.ttf", None)]),
    ("KaiTi", [("simkai.ttf", None)]),
    ("MicrosoftYaHei", [("msyh.ttc", 0)]),
    ("TimesNewRoman", [("times.ttf", None)]),
    ("Arial", [("arial.ttf", None)]),
    ("Calibri", [("calibri.ttf", None)]),
]

_cache = {}


def load_map(fname, num):
    key = (fname, num)
    if key in _cache:
        return _cache[key]
    path = os.path.join(FONTDIR, fname)
    m = {}
    if os.path.exists(path):
        try:
            f = TTFont(path, fontNumber=(num or 0), lazy=True)
            rev = {}
            for cp, gn in f.getBestCmap().items():
                rev.setdefault(gn, cp)
            for gid, gn in enumerate(f.getGlyphOrder()):
                if gn in rev:
                    m[gid] = chr(rev[gn])
        except Exception as e:
            print("  ! font load fail", fname, e, file=sys.stderr)
    _cache[key] = m
    return m


def family_maps(basefont):
    """All candidate gid->unicode maps for a font family (first that has the gid wins)."""
    fam = basefont.split("+")[-1]
    for name, files in FAMILY_FILES:
        if name.lower() in fam.lower():
            return [load_map(fn, num) for fn, num in files]
    return []


def parse_diffs(obj):
    """Parse a /Differences-containing object string -> {code: glyphname}."""
    if "[" not in obj:
        return {}
    seg = obj[obj.index("["): obj.index("]") + 1]
    toks = re.findall(r"\d+|/[^\s/\[\]]+", seg)
    out = {}
    cur = 0
    for t in toks:
        if t.startswith("/"):
            out[cur] = t[1:]
            cur += 1
        else:
            cur = int(t)
    return out


def font_info(doc, xref):
    obj = doc.xref_object(xref)
    m = re.search(r"/Encoding (\d+) 0 R", obj)
    diffs = {}
    if m:
        diffs = parse_diffs(doc.xref_object(int(m.group(1))))
    else:
        m2 = re.search(r"/Encoding\s*<<(.*?)>>", obj, re.S)
        if m2:
            diffs = parse_diffs(m2.group(0))
    fc = re.search(r"/FirstChar (\d+)", obj)
    fc = int(fc.group(1)) if fc else 0
    wm = re.search(r"/Widths \[(.*?)\]", obj, re.S)
    widths = {}
    if wm:
        ws = [float(x) for x in wm.group(1).split()]
        for i, w in enumerate(ws):
            widths[fc + i] = w
    return diffs, widths


# ---------------- minimal content-stream tokenizer ----------------

def tokens(s):
    i, n = 0, len(s)
    while i < n:
        c = s[i:i+1]
        if c in b" \t\r\n\x00\x0c":
            i += 1
            continue
        if c == b"%":
            j = s.find(b"\n", i)
            i = n if j < 0 else j + 1
            continue
        if c == b"(":
            depth, j, buf = 1, i + 1, bytearray()
            while j < n and depth:
                ch = s[j:j+1]
                if ch == b"\\":
                    nx = s[j+1:j+2]
                    esc = {b"n": b"\n", b"r": b"\r", b"t": b"\t", b"b": b"\b",
                           b"f": b"\f", b"(": b"(", b")": b")", b"\\": b"\\"}
                    if nx in esc:
                        buf += esc[nx]
                        j += 2
                        continue
                    if nx.isdigit():
                        k = 0
                        while k < 3 and s[j+1+k:j+2+k].isdigit():
                            k += 1
                        buf.append(int(s[j+1:j+1+k], 8) & 0xFF)
                        j += 1 + k
                        continue
                    if nx in (b"\n", b"\r"):
                        j += 2
                        continue
                    buf += nx
                    j += 2
                    continue
                if ch == b"(":
                    depth += 1
                elif ch == b")":
                    depth -= 1
                    if depth == 0:
                        j += 1
                        break
                buf += ch
                j += 1
            yield ("str", bytes(buf))
            i = j
            continue
        if c == b"<" and s[i+1:i+2] != b"<":
            j = s.find(b">", i)
            hx = re.sub(rb"\s", b"", s[i+1:j])
            if len(hx) % 2:
                hx += b"0"
            yield ("str", bytes.fromhex(hx.decode("latin1")))
            i = j + 1
            continue
        if c == b"[":
            yield ("[", None)
            i += 1
            continue
        if c == b"]":
            yield ("]", None)
            i += 1
            continue
        if c == b"/":
            j = i + 1
            while j < n and s[j:j+1] not in b" \t\r\n\x00\x0c/[]<>(){}%":
                j += 1
            yield ("name", s[i+1:j].decode("latin1"))
            i = j
            continue
        j = i
        while j < n and s[j:j+1] not in b" \t\r\n\x00\x0c/[]<>()%{}":
            j += 1
        if j == i:                      # stray delimiter byte: consume and ignore
            i += 1
            continue
        w = s[i:j].decode("latin1")
        try:
            yield ("num", float(w))
        except ValueError:
            yield ("op", w)
        i = j


def decode_page(doc, page):
    """-> list of (x, y, char) with each char resolved through the font's glyph ids."""
    fonts = {}
    for fn in page.get_fonts(full=True):
        xref, basefont = fn[0], fn[3]
        diffs, widths = font_info(doc, xref)
        fonts[fn[4]] = {"diffs": diffs, "widths": widths,
                        "maps": family_maps(basefont), "base": basefont}
    out = []
    tm = [1, 0, 0, 1, 0, 0]
    tlm = tm[:]
    cur = None
    adv = 0.0
    cs = b"".join(doc.xref_stream(x) or b"" for x in page.get_contents())
    toks = list(tokens(cs))
    missing = {}

    def show(bs):
        nonlocal adv
        f = fonts.get(cur) if cur else None
        for code in bs:
            ch = None
            if f:
                gn = f["diffs"].get(code)
                if gn and gn[:1] == "g" and gn[1:].isdigit():
                    gid = int(gn[1:])
                    for mp in f["maps"]:
                        if gid in mp:
                            ch = mp[gid]
                            break
            if ch is None:
                missing[f["base"] if f else "?"] = missing.get(f["base"] if f else "?", 0) + 1
                ch = "\ufffd"
            out.append((tm[4] + adv * tm[0], tm[5] + adv * tm[1], ch))
            w = f["widths"].get(code, 1000) if f else 1000
            adv += w / 1000.0

    i = 0
    while i < len(toks):
        k, v = toks[i]
        if k == "op":
            if v == "BT":
                tm = [1, 0, 0, 1, 0, 0]
                tlm = tm[:]
                adv = 0.0
            elif v == "Tf":
                if i >= 2 and toks[i-2][0] == "name":
                    cur = toks[i-2][1]
            elif v == "Tm":
                try:
                    nums = [toks[i-6+j][1] for j in range(6)]
                    tm = [float(x) for x in nums]
                    tlm = tm[:]
                    adv = 0.0
                except Exception:
                    pass
            elif v in ("Td", "TD"):
                tx, ty = toks[i-2][1], toks[i-1][1]
                tlm = [tlm[0], tlm[1], tlm[2], tlm[3],
                       tlm[0]*tx + tlm[2]*ty + tlm[4],
                       tlm[1]*tx + tlm[3]*ty + tlm[5]]
                tm = tlm[:]
                adv = 0.0
            elif v == "T*":
                tlm = [tlm[0], tlm[1], tlm[2], tlm[3], tlm[4], tlm[5]]
                tm = tlm[:]
                adv = 0.0
            elif v in ("Tj", "'", '"'):
                if toks[i-1][0] == "str":
                    show(toks[i-1][1])
            elif v == "TJ":
                j = i - 1
                while j >= 0 and toks[j][0] != "[":
                    j -= 1
                for kk, vv in toks[j+1:i-1]:
                    if kk == "str":
                        show(vv)
                    elif kk == "num":
                        adv -= vv / 1000.0
        i += 1
    if missing:
        print("   missing glyphs:", missing, file=sys.stderr)
    return out


def rows_of(chars, ytol=2.5, xgap=6.0):
    chars = sorted(chars, key=lambda t: (-t[1], t[0]))
    lines = []
    for x, y, c in chars:
        if lines and abs(lines[-1]["y"] - y) <= ytol:
            lines[-1]["chars"].append((x, c))
        else:
            lines.append({"y": y, "chars": [(x, c)]})
    res = []
    for ln in lines:
        seg = sorted(ln["chars"], key=lambda t: t[0])
        cells, buf, prev = [], "", None
        for x, c in seg:
            if prev is not None and x - prev > xgap:
                cells.append(buf.strip())
                buf = ""
            buf += c
            prev = x
        if buf.strip():
            cells.append(buf.strip())
        res.append((round(ln["y"], 1), [c for c in cells if c]))
    return res


if __name__ == "__main__":
    doc = pymupdf.open(PDF)
    allrows = []
    for pno in range(len(doc)):
        rows = rows_of(decode_page(doc, doc[pno]))
        for y, cells in rows:
            allrows.append({"page": pno + 1, "y": y, "cells": cells})
    json.dump(allrows, open(os.path.join(os.path.dirname(PDF), "sd2020b1_rows.json"), "w",
                            encoding="utf-8"), ensure_ascii=False, indent=0)
    print("rows:", len(allrows))
    for r in allrows[:12]:
        print(r["page"], r["cells"])
    print("...")
    for r in allrows[-8:]:
        print(r["page"], r["cells"])
