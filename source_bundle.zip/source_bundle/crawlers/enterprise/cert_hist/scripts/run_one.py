# -*- coding: utf-8 -*-
"""Decode one PDF in its own process: python run_one.py <pdf> <out.json> <prov> <year> <batch> <src>"""
import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cff_gid  # noqa: E402


def main():
    pdf, out, prov, year, batch, src = sys.argv[1:7]
    r = cff_gid.pdf_rows(pdf)
    json.dump({"prov": prov, "year": year, "batch": batch, "src": src,
               "file": os.path.basename(pdf), "pages": r["pages"], "rows": r["rows"]},
              open(out, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"{prov}\t{year}\t{batch:<10}rows={len(r['rows']):>6}\t{os.path.basename(pdf)[:50]}")


if __name__ == "__main__":
    main()
