# -*- coding: utf-8 -*-
"""Rebuild cert_hist/<prov>_<year>.csv from
     1) _raw/<prov>/<prov>_rows.json   (upstream sweep output, foreign rows filtered out)
     2) _raw/_decoded/*.json           (cff_gid decoded 备案复函, esp. 2020 batch 1)
Dedup: by 证书编号 first, then by (企业名称, 认定年度).
QC: flags rows whose cert province-code disagrees with the province's modal code.
"""
import os
import re
import sys
import csv
import json
import glob
import collections

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(HERE, "_raw")
DEC = os.path.join(RAW, "_decoded")
EXTRA = os.path.join(RAW, "_extra")
YEARS = ("2016", "2017", "2018", "2019", "2020")
HDR = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]

PROVS = ["北京", "天津", "河北", "山西", "内蒙古", "辽宁", "吉林", "黑龙江", "上海", "江苏",
         "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南", "广东", "广西",
         "海南", "重庆", "四川", "贵州", "云南", "陕西", "甘肃", "青海", "宁夏", "新疆",
         "深圳", "宁波", "青岛", "厦门", "大连", "西藏"]

CITY_PROV = {"北京", "天津", "上海", "重庆", "深圳", "宁波", "青岛", "厦门", "大连"}

CERT_RE = re.compile(r"^GR\d{12}$")


def norm(s):
    return re.sub(r"[\s\u3000]+", "", s or "")


HDR_RE = re.compile(r"^(?:序号|企业名称|名称|证书编号|证书号)+")


def clean_name(s):
    """strip table-header prefix accidentally merged into a name cell"""
    s = norm(s)
    if not s:
        return ""
    for _ in range(3):
        t = HDR_RE.sub("", s)
        if t == s:
            break
        s = t
    return s


def same_prov(title, prov):
    if not title:
        return True
    if prov in title:
        return True
    for other in PROVS:
        if other != prov and other in title:
            return False
    return True


def url2title():
    m = {}
    for p in glob.glob(os.path.join(RAW, "*", "*_meta.json")):
        try:
            meta = json.load(open(p, encoding="utf-8"))
        except Exception:
            continue
        for it in meta.get("items") or []:
            if it.get("url"):
                m.setdefault(it["url"], it.get("title") or "")
        for it in meta.get("skipped") or []:
            if it.get("url"):
                m.setdefault(it["url"], it.get("title") or "")
    return m


def main():
    U2T = url2title()
    summary = {}
    qc = []
    for prov in PROVS:
        rows = []
        rp = os.path.join(RAW, prov, f"{prov}_rows.json")
        if os.path.exists(rp):
            try:
                for r in json.load(open(rp, encoding="utf-8")):
                    r = dict(r)
                    r["prov"] = prov
                    if not same_prov(U2T.get(r.get("src", "")), prov):
                        continue
                    rows.append(r)
            except Exception as e:
                print("ERR", prov, e)
        # decoded 复函 + subagent-supplied provincial sources
        for _d in (DEC, EXTRA):
            for p in sorted(glob.glob(os.path.join(_d, f"{prov}__*.json"))):
                try:
                    d = json.load(open(p, encoding="utf-8"))
                except Exception:
                    continue
                y = str(d.get("year") or "")
                if y not in YEARS:
                    continue
                if not same_prov(d.get("file", ""), prov):
                    continue
                for r in d["rows"]:
                    if not CERT_RE.match(r.get("cert") or ""):
                        continue
                    rows.append({"name": r.get("name", ""), "cert": r["cert"],
                                 "city": r.get("city", ""), "county": r.get("county", ""),
                                 "prov": prov, "year": y, "batch": d.get("batch", ""),
                                 "src": d.get("src", "")})
        # dedup
        by_cert, by_name = {}, {}
        for r in rows:
            y = str(r.get("year") or "")
            if y not in YEARS:
                continue
            c = r.get("cert") or ""
            if c and CERT_RE.match(c):
                cur = by_cert.get(c)
                if cur is None:
                    by_cert[c] = dict(r)
                else:
                    for f in ("city", "county", "name", "src", "batch"):
                        if not cur.get(f) and r.get(f):
                            cur[f] = r[f]
            else:
                k = (norm(r.get("name")), y)
                if not k[0]:
                    continue
                by_name.setdefault(k, dict(r))
        with_cert_names = {(norm(v.get("name")), str(v.get("year"))) for v in by_cert.values()}
        kept = list(by_cert.values()) + [v for k, v in by_name.items() if k not in with_cert_names]
        # drop name-only rows in any prov-year that already has cert-bearing rows:
        # those rows come from 公示 lists (names of companies that mostly did NOT pass 备案)
        years_with_cert = {str(v.get("year")) for v in by_cert.values()}
        kept = [r for r in kept if r.get("cert") or str(r.get("year")) not in years_with_cert]
        for r in kept:
            r["name"] = clean_name(r.get("name"))
            if r.get("prov") in CITY_PROV and not r.get("city"):
                r["city"] = r["prov"]
        stats = {}
        for y in YEARS:
            rs = [r for r in kept if str(r.get("year")) == y]
            if not rs:
                continue
            # QC: modal province code among certs
            cnt = collections.Counter(r["cert"][6:8] for r in rs if r.get("cert"))
            modal = cnt.most_common(1)[0][0] if cnt else None
            if cnt and len(cnt) > 1:
                qc.append((prov, y, modal, dict(cnt)))
            rs.sort(key=lambda r: (r.get("batch") or "", r.get("cert") or "zzz", r.get("name") or ""))
            p = os.path.join(HERE, f"{prov}_{y}.csv")
            with open(p, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f)
                w.writerow(HDR)
                for r in rs:
                    w.writerow([r.get("name", ""), r.get("cert", ""), r.get("city", ""),
                                r.get("county", ""), y, r.get("batch", ""), r.get("src", "")])
            stats[y] = {"rows": len(rs), "cert": sum(1 for r in rs if r.get("cert")),
                        "city": sum(1 for r in rs if r.get("city"))}
        if stats:
            summary[prov] = stats
            print(f"{prov:<6} " + "  ".join(f"{y}:{v['rows']}/{v['cert']}" for y, v in stats.items()),
                  flush=True)
    json.dump(summary, open(os.path.join(RAW, "_summary2.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    json.dump([list(x) for x in qc], open(os.path.join(RAW, "_qc_prefix.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("\n-- cert prefix anomalies (prov, year, modal, counts) --")
    for q in qc:
        print(q)
    tot = sum(v["rows"] for s in summary.values() for v in s.values())
    tc = sum(v["cert"] for s in summary.values() for v in s.values())
    print(f"\nTOTAL rows={tot} with-cert={tc}")


if __name__ == "__main__":
    main()
