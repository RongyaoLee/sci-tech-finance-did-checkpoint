# -*- coding: utf-8 -*-
"""多引擎中文搜索：360 / 搜狗 / Mojeek。返回 (引擎, 标题, 链接, 摘要)。"""
import re, sys, time, urllib.parse
import requests
from bs4 import BeautifulSoup

requests.packages.urllib3.disable_warnings()
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36')
H = {'User-Agent': UA, 'Accept-Language': 'zh-CN,zh;q=0.9'}
S = requests.Session()
S.headers.update(H)
S.verify = False

_last = {}
def _throttle(host, gap=0.6):
    t = _last.get(host, 0)
    d = time.time() - t
    if d < gap:
        time.sleep(gap - d)
    _last[host] = time.time()

def get(url, **kw):
    host = urllib.parse.urlsplit(url).netloc
    _throttle(host)
    kw.setdefault('timeout', 25)
    kw.setdefault('verify', False)
    r = S.get(url, **kw)
    r.encoding = r.apparent_encoding or 'utf-8'
    return r

def so360(q, pn=1):
    out = []
    url = 'https://www.so.com/s?q=%s&pn=%d' % (urllib.parse.quote(q), pn)
    r = get(url)
    sp = BeautifulSoup(r.text, 'lxml')
    for li in sp.select('li.res-list'):
        a = li.select_one('h3 a')
        if not a:
            continue
        href = a.get('href') or ''
        dataurl = a.get('data-mdurl') or li.get('data-mdurl') or ''
        ttl = a.get_text(' ', strip=True)
        sn = li.select_one('.res-desc, .res-comm-con, p')
        out.append(('360', ttl, dataurl or href, sn.get_text(' ', strip=True) if sn else ''))
    return out

def sogou(q, page=1):
    out = []
    url = 'https://www.sogou.com/web?query=%s&page=%d' % (urllib.parse.quote(q), page)
    r = get(url)
    sp = BeautifulSoup(r.text, 'lxml')
    for d in sp.select('div.vrwrap, div.rb'):
        a = d.select_one('h3 a')
        if not a:
            continue
        out.append(('sogou', a.get_text(' ', strip=True), a.get('href') or '',
                    d.get_text(' ', strip=True)[:300]))
    return out

def mojeek(q):
    out = []
    r = get('https://www.mojeek.com/search?q=%s' % urllib.parse.quote(q))
    sp = BeautifulSoup(r.text, 'lxml')
    for li in sp.select('ul.results-standard li'):
        a = li.select_one('a.title')
        if not a:
            continue
        out.append(('mojeek', a.get_text(' ', strip=True), a.get('href') or '',
                    li.get_text(' ', strip=True)[:300]))
    return out

def baidu(q, pn=0):
    out = []
    r = get('https://www.baidu.com/s?wd=%s&pn=%d' % (urllib.parse.quote(q), pn))
    if '百度安全验证' in r.text:
        return [('baidu', 'BLOCKED', '', '')]
    sp = BeautifulSoup(r.text, 'lxml')
    for h in sp.select('h3'):
        a = h.select_one('a')
        if a:
            out.append(('baidu', a.get_text(' ', strip=True), a.get('href') or '', ''))
    return out

def search(q, engines=('360', 'sogou', 'mojeek')):
    res = []
    for e in engines:
        try:
            if e == '360':
                res += so360(q)
            elif e == 'sogou':
                res += sogou(q)
            elif e == 'mojeek':
                res += mojeek(q)
            elif e == 'baidu':
                res += baidu(q)
        except Exception as ex:
            res.append((e, 'ERR', '', str(ex)[:120]))
    return res

if __name__ == '__main__':
    for q in sys.argv[1:]:
        print('=== %s' % q)
        for e, t, u, s in search(q, ('360', 'sogou')):
            print('[%s] %s\n    %s\n    %s' % (e, t[:110], u[:160], s[:160]))
