# -*- coding: utf-8 -*-
"""Crawl 国家高企认定网 list columns (all pages) -> items json."""
import os, re, json, sys
from urllib.parse import urljoin
from lxml import html as LH
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work")
import cert_fetch as F

RAW = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "_raw", "_lists")
os.makedirs(RAW, exist_ok=True)

COLS = {"c101333": "公示", "c101334": "公告", "c101481": "认定备案公告"}
HOST = "http://www.innocom.gov.cn/gqrdw/"


def page_url(col, n):
    base = f"{HOST}{col}/list_gsgg_l2"
    return base + (".shtml" if n == 1 else f"_{n}.shtml")


def parse(t, base_url):
    doc = LH.fromstring(t)
    out = []
    for li in doc.xpath("//li | //tr | //p"):
        a = li.xpath(".//a[@href]")
        if not a:
            continue
        a = a[0]
        href = urljoin(base_url, a.get("href") or "")
        if not re.search(r"/gqrdw/c\d{6}/20\d{4}/", href):
            continue
        title = (a.get("title") or "").strip() or " ".join(a.text_content().split())
        txt = " ".join(li.text_content().split())
        m = re.search(r"(20\d{2}-\d{2}-\d{2})", txt)
        out.append({"title": title, "url": href, "date": m.group(1) if m else ""})
    return out


def main():
    cols = sys.argv[1].split(",") if len(sys.argv) > 1 else list(COLS)
    for col in cols:
        items, seen = [], set()
        for n in range(1, 61):
            fp = os.path.join(RAW, f"{col}_p{n}.html")
            u = page_url(col, n)
            try:
                if os.path.exists(fp) and os.path.getsize(fp) > 3000:
                    t = open(fp, encoding="utf-8", errors="replace").read()
                else:
                    r = F.get(u)
                    t = F.text(r)
                    open(fp, "w", encoding="utf-8").write(t)
            except Exception as e:
                print(f"  [{col}] p{n} ERR {type(e).__name__} {str(e)[:60]}")
                if n > 3:
                    break
                continue
            got = parse(t, u)
            new = 0
            for it in got:
                if it["url"] in seen:
                    continue
                seen.add(it["url"]); items.append(it); new += 1
            dates = [it["date"] for it in got if it["date"]]
            print(f"  [{col}] p{n}: +{new} (total {len(items)}) dates {dates[-1] if dates else '?'} .. {dates[0] if dates else '?'}")
            if new == 0 and n > 2:
                print(f"  [{col}] stop at p{n}")
                break
        json.dump(items, open(os.path.join(RAW, f"{col}_items.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"[done] {col} items={len(items)}")


if __name__ == "__main__":
    main()
