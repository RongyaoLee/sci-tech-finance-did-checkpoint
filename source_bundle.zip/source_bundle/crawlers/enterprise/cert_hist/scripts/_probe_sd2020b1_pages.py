# -*- coding: utf-8 -*-
import os, re, io, sys, json
import pymupdf
from fontTools.ttLib import TTFont

PDF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_hist\_raw\山东\关于山东省2020年第一批高新技术企业备案的复函_aa73c8b735.pdf"
doc = pymupdf.open(PDF)
print("pages:", len(doc))
for pno in range(len(doc)):
    page = doc[pno]
    t = page.get_text()
    fs = page.get_fonts(full=True)
    imgs = page.get_images(full=True)
    print(pno, "len", len(t), "fonts", len(fs), "imgs", len(imgs), repr(t[:60]))
