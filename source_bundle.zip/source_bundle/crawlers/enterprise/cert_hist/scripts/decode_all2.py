# -*- coding: utf-8 -*-
"""Driver: decode every upstream-failed (\"0 rows\") 备案复函 PDF, one subprocess per file
with a hard timeout so a pathological PDF cannot stall the batch.

    python scripts/decode_all2.py [timeout_sec=240] [only_prov_substr]
"""
import os
import re
import sys
import json
import glob
import subprocess

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(HERE, "_raw")
DEC = os.path.join(RAW, "_decoded")
SCRIPTS = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
YEARS = ("2016", "2017", "2018", "2019", "2020")


def basename(u):
    return (u or "").rsplit("/", 1)[-1]


def local_for(prov, item):
    d = os.path.join(RAW, prov)
    t = re.sub(r'[\\/:*?"<>|]', "_", (item.get("title") or "")[:60])
    a = item.get("atts") or []
    if not a:
        return None
    cand = os.path.join(d, t + "_" + basename(a[0])[:10] + ".pdf")
    if os.path.exists(cand):
        return cand
    suf = "_" + basename(a[0])[:10]
    for p in glob.glob(os.path.join(d, "*" + suf + "*")):
        return p
    return None


def main():
    timeout = int(sys.argv[1]) if len(sys.argv) > 1 else 240
    only = sys.argv[2] if len(sys.argv) > 2 else None
    os.makedirs(DEC, exist_ok=True)
    jobs = []
    for mp in sorted(glob.glob(os.path.join(RAW, "*", "*_meta.json"))):
        prov = os.path.basename(os.path.dirname(mp))
        if only and only not in prov:
            continue
        meta = json.load(open(mp, encoding="utf-8"))
        by_url = {it["url"]: it for it in meta.get("items") or []}
        for sk in meta.get("skipped") or []:
            y = str(sk.get("year") or "")
            if y not in YEARS or not str(sk.get("why", "")).startswith("0 rows"):
                continue
            u = sk.get("url") or ""
            if not u.lower().endswith(".pdf"):
                continue
            out = os.path.join(DEC, f"{prov}__{y}__{sk.get('batch')}.json")
            if os.path.exists(out):
                continue
            item = by_url.get(u) or {"title": sk.get("title"), "atts": [u]}
            jobs.append((prov, y, sk.get("batch"), u, local_for(prov, item), out))

    print(f"pending {len(jobs)}", flush=True)
    for prov, y, batch, u, f, out in jobs:
        if not f:
            print(f"{prov}\t{y}\t{batch}\tNOFILE\t{basename(u)}", flush=True)
            continue
        try:
            p = subprocess.run([PY, "-X", "utf8", os.path.join(SCRIPTS, "run_one.py"),
                                f, out, prov, y, str(batch), u],
                               capture_output=True, timeout=timeout)
            msg = (p.stdout or b"").decode("utf-8", "replace").strip()
            if msg:
                print(msg, flush=True)
            if p.returncode != 0:
                print(f"{prov}\t{y}\t{batch}\tRC={p.returncode}\t{(p.stderr or b'').decode('utf-8','replace')[-200:]}", flush=True)
        except subprocess.TimeoutExpired:
            print(f"{prov}\t{y}\t{batch}\tTIMEOUT {timeout}s\t{os.path.basename(f)[:50]}", flush=True)


if __name__ == "__main__":
    main()
