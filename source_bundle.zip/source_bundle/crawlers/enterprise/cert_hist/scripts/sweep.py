# -*- coding: utf-8 -*-
"""Sweep innocom 认定备案公告(gg) + 公示(gs) for 2016-2020, per province.

Writes:
  cert_hist/_raw/<prov>/<prov>_rows.json     all rows (with year/batch/src)
  cert_hist/_raw/<prov>/harvest.log          per-attachment stats
  cert_hist/<prov>_<year>.csv
  cert_hist/_raw/_summary.json               aggregated stats
"""
import os, sys, json, re, csv, collections, traceback

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(WORK, "cert_lists"))
sys.path.insert(0, os.path.join(HERE, "scripts"))
sys.path.insert(0, WORK)
import fetch_common as fc
import doc97

fc.RAW = os.path.join(HERE, "_raw")
YEARS = ("2016", "2017", "2018", "2019", "2020")
HDR = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]

_orig_extract = fc.extract

FOREIGN = [n for n in list(fc.PROV_GG) + list(fc.PROV_CH)]


def same_prov(title, prov):
    """Reject items that clearly belong to another province/计划单列市
    (list pages carry sidebar links to other provinces' announcements)."""
    if prov in title:
        return True
    for other in FOREIGN:
        if other != prov and other in title:
            return False
    return True


def extract2(path):
    """Use own .doc parser first (Word 97 piece table), then upstream."""
    if path.lower().endswith(".doc"):
        try:
            rs = doc97.cert_rows(path)
        except Exception:
            rs = []
        if rs:
            out = []
            for r in rs:
                c = fc.norm_cert(r["cert"])
                if c:
                    out.append({"name": r["name"], "cert": c, "city": "", "county": ""})
            if out:
                return out
    return _orig_extract(path)


fc.extract = extract2


def split_write(prov, rows):
    by_cert, by_name = {}, {}
    for r in rows:
        y = str(r.get("year") or "")
        if y not in YEARS:
            continue
        c = r.get("cert") or ""
        if c:
            cur = by_cert.get(c)
            if cur is None:
                by_cert[c] = dict(r)
            else:
                for f in ("city", "county", "name", "src"):
                    if not cur.get(f) and r.get(f):
                        cur[f] = r[f]
        else:
            k = (re.sub(r"\s+", "", r.get("name") or ""), y)
            by_name.setdefault(k, dict(r))
    cert_names = {(re.sub(r"\s+", "", v.get("name") or ""), str(v.get("year"))) for v in by_cert.values()}
    kept = list(by_cert.values()) + [v for k, v in by_name.items() if k not in cert_names]
    stats = {}
    for y in YEARS:
        rs = [r for r in kept if str(r.get("year")) == y]
        if not rs:
            continue
        rs.sort(key=lambda r: (r.get("batch") or "", str(r.get("cert") or "zzzzzz"), r.get("name") or ""))
        p = os.path.join(HERE, f"{prov}_{y}.csv")
        with open(p, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(HDR)
            for r in rs:
                w.writerow([r.get("name", ""), r.get("cert", ""), r.get("city", ""), r.get("county", ""),
                            y, r.get("batch", ""), r.get("src", "")])
        stats[y] = {"rows": len(rs), "cert": sum(1 for r in rs if r.get("cert")),
                    "city": sum(1 for r in rs if r.get("city"))}
    return stats


def sweep(prov, pages=8):
    logdir = os.path.join(HERE, "_raw", prov)
    os.makedirs(logdir, exist_ok=True)
    log = open(os.path.join(logdir, "harvest.log"), "w", encoding="utf-8")

    def p(*a):
        s = " ".join(str(x) for x in a)
        print(s, flush=True)
        log.write(s + "\n")
        log.flush()

    rows_all, skipped, items_meta = [], [], []
    for kind in ("gg", "gs"):
        try:
            items = fc.list_items(prov, pages, kind)
        except Exception as e:
            p(f"[{prov}/{kind}] list error {e}")
            items = []
        sel, foreign = [], 0
        for it in items:
            y, b = fc.parse_meta(it["title"])
            if y not in YEARS:
                continue
            if not same_prov(it["title"], prov):
                foreign += 1
                continue
            sel.append((it, y, b))
        if foreign:
            p(f"[{prov}/{kind}] dropped {foreign} foreign-province items (sidebar pollution)")
        p(f"[{prov}/{kind}] items={len(items)} in2016-20={len(sel)}")
        for it, y, b in sel:
            atts = fc.attachments(it["url"])
            if not atts:
                skipped.append({"year": y, "batch": b, "title": it["title"], "why": "no attachment",
                                "url": it["url"]})
                p(f"   - {y}/{b or '-':10s} no-att  {it['title'][:46]}")
                continue
            items_meta.append({"kind": kind, "year": y, "batch": b, "title": it["title"], "url": it["url"],
                               "atts": [u for _, u in atts]})
            for atitle, aurl in atts:
                p_ = fc.download(aurl, prov, it["title"][:60] + "_" + os.path.basename(aurl)[:10])
                if not p_:
                    skipped.append({"year": y, "batch": b, "title": it["title"], "why": "download fail",
                                    "url": aurl})
                    continue
                try:
                    rs = extract2(p_)
                except Exception as e:
                    p("   ! parse err", os.path.basename(p_), e)
                    skipped.append({"year": y, "batch": b, "title": it["title"], "why": f"parse err {e}",
                                    "url": aurl})
                    continue
                ncert = sum(1 for r in rs if r.get("cert"))
                p(f"   [{kind}] {y}/{b or '-':10s} rows={len(rs):5d} cert={ncert:5d} {os.path.basename(p_)[:44]}")
                if not rs:
                    skipped.append({"year": y, "batch": b, "title": it["title"], "why": "0 rows (scanned/empty)",
                                    "url": aurl})
                    continue
                for r in rs:
                    r.update(prov=prov, year=y, batch=b, src=it["url"])
                    rows_all.append(r)

    json.dump(rows_all, open(os.path.join(logdir, f"{prov}_rows.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    stats = split_write(prov, rows_all)
    meta = {"prov": prov, "stats": stats, "skipped": skipped, "items": items_meta}
    json.dump(meta, open(os.path.join(logdir, f"{prov}_meta.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    p(f"== {prov} raw={len(rows_all)} stats={json.dumps(stats, ensure_ascii=False)}")
    log.close()
    return meta


if __name__ == "__main__":
    provs = sys.argv[1].split(",")
    pages = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    summ_path = os.path.join(HERE, "_raw", "_summary.json")
    summ = json.load(open(summ_path, encoding="utf-8")) if os.path.exists(summ_path) else {}
    for prov in provs:
        try:
            m = sweep(prov, pages)
            summ[prov] = {"stats": m["stats"], "n_skipped": len(m["skipped"]),
                          "skipped": m["skipped"]}
        except Exception:
            traceback.print_exc()
            summ[prov] = {"error": traceback.format_exc()[-800:]}
        json.dump(summ, open(summ_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
