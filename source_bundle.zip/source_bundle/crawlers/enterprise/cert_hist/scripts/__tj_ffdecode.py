﻿import pymupdf, os, re, json, sys
from fontTools.ttLib import TTFont

base = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_hist\_raw\天津"
PDF = os.path.join(base, "关于天津市2020年第一批高新技术企业备案的复函_285ddb0c9b.pdf")

# gid -> char from simsun.ttc
f = TTFont(r"C:\Windows\Fonts\simsun.ttc", fontNumber=0)
order = f.getGlyphOrder()
rev = {}
for cp, gn in f.getBestCmap().items():
    rev.setdefault(gn, chr(cp))
gid2ch = {}
for i, gn in enumerate(order):
    c = rev.get(gn)
    if c: gid2ch[i] = c
print("gid map size", len(gid2ch), file=sys.stderr)

doc = pymupdf.open(PDF)

def parse_diffs(s):
    # s: "<< /Differences [ 2 /g5311 ... ] ... >>"
    seg = s[s.index("["): s.index("]")+1]
    toks = re.findall(r"\d+|/[^\s/\[\]]+", seg)
    m = {}; cur = None
    for t in toks:
        if t.startswith("/"):
            m[cur] = t[1:]; cur += 1
        else:
            cur = int(t)
    return m

def font_info(xref):
    obj = doc.xref_object(xref)
    enc = int(re.search(r"/Encoding (\d+) 0 R", obj).group(1))
    diffs = parse_diffs(doc.xref_object(enc))
    fc = int(re.search(r"/FirstChar (\d+)", obj).group(1))
    wm = re.search(r"/Widths \[(.*?)\]", obj, re.S)
    ws = [int(float(x)) for x in wm.group(1).split()] if wm else []
    widths = {fc+i: w for i, w in enumerate(ws)}
    return diffs, widths

def code2ch(fi, code):
    name = fi[0].get(code)
    if name and name.startswith("g") and name[1:].isdigit():
        return gid2ch.get(int(name[1:]))
    return None

# tokenizer for content stream
def tokens(s):
    i = 0; n = len(s)
    while i < n:
        c = s[i:i+1]
        if c in b" \t\r\n\x00\x0c":
            i += 1; continue
        if c == b"%":
            j = s.find(b"\n", i); i = n if j < 0 else j+1; continue
        if c == b"(":
            depth = 1; j = i+1; buf = bytearray()
            while j < n and depth:
                ch = s[j:j+1]
                if ch == b"\\":
                    nx = s[j+1:j+2]
                    esc = {b"n":b"\n",b"r":b"\r",b"t":b"\t",b"b":b"\b",b"f":b"\f",b"(":b"(",b")":b")",b"\\":b"\\"}
                    if nx in esc: buf += esc[nx]; j += 2; continue
                    if nx.isdigit():
                        oct_ = s[j+1:j+4]
                        k = 0
                        while k < 3 and oct_[k:k+1].isdigit(): k += 1
                        buf.append(int(oct_[:k], 8) & 0xFF); j += 1+k; continue
                    if nx in (b"\n", b"\r"):
                        j += 2; continue
                    buf += nx; j += 2; continue
                if ch == b"(": depth += 1
                elif ch == b")":
                    depth -= 1
                    if depth == 0: j += 1; break
                buf += ch; j += 1
            yield ("str", bytes(buf)); i = j; continue
        if c == b"<" and s[i+1:i+2] != b"<":
            j = s.find(b">", i)
            hx = re.sub(rb"\s", b"", s[i+1:j])
            yield ("str", bytes.fromhex(hx.decode())); i = j+1; continue
        if c == b"[":
            yield ("[", None); i += 1; continue
        if c == b"]":
            yield ("]", None); i += 1; continue
        if c == b"/":
            j = i+1
            while j < n and s[j:j+1] not in b" \t\r\n\x00\x0c/[]<>(){}%": j += 1
            yield ("name", s[i+1:j].decode("latin1")); i = j; continue
        j = i
        while j < n and s[j:j+1] not in b" \t\r\n\x00\x0c/[]<>()%": j += 1
        w = s[i:j].decode("latin1")
        try: yield ("num", float(w))
        except: yield ("op", w)
        i = j

def page_chars(page):
    """return list of (x, y, char) decoded"""
    fonts = {}
    for fn in page.get_fonts(full=True):
        fonts[fn[4]] = font_info(fn[0])
    out = []
    tm = [1,0,0,1,0,0]; tlm = tm[:]
    fname = None; fsize = 1.0; adv = 0.0
    cs = b"".join(doc.xref_stream(x) for x in page.get_contents())
    toks = list(tokens(cs))
    stack = []
    def show(bs):
        nonlocal adv
        fi = fonts.get(fname)
        for code in bs:
            ch = None
            if fi and code in fi[0]:
                ch = code2ch(fi, code)
            if ch is None:
                ch = chr(code)
            x = tm[0]*adv + tm[2]*0 + tm[4]
            y = tm[1]*adv + tm[3]*0 + tm[5]
            out.append((x, y, ch))
            w = fi[1].get(code, 1000) if fi else 1000
            adv += w/1000.0
    i = 0
    while i < len(toks):
        k, v = toks[i]
        if k == "op":
            if v == "BT": tm = [1,0,0,1,0,0]; tlm = tm[:]; adv = 0.0
            elif v == "Tf":
                # previous token name, before that size
                fname = toks[i-2][1] if toks[i-2][0]=="name" else fname
                try: fsize = toks[i-1][1]
                except: pass
            elif v == "Tm":
                nums = [toks[i-6+j][1] for j in range(6)]
                tm = nums[:]; tlm = nums[:]; adv = 0.0
            elif v in ("Td","TD"):
                tx, ty = toks[i-2][1], toks[i-1][1]
                tlm = [tlm[0],tlm[1],tlm[2],tlm[3], tlm[0]*tx+tlm[2]*ty+tlm[4], tlm[1]*tx+tlm[3]*ty+tlm[5]]
                tm = tlm[:]; adv = 0.0
            elif v == "Tj":
                show(toks[i-1][1])
            elif v in ("'", '"'):
                show(toks[i-1][1])
            elif v == "TJ":
                j = i-1; arr = []
                while not (toks[j][0]=="["):
                    j -= 1
                arr = toks[j+1:i-1]
                for kk, vv in arr:
                    if kk == "str": show(vv)
                    elif kk == "num": adv -= vv/1000.0
        i += 1
    return out

for pno in (1,2):
    chs = page_chars(doc[pno])
    lines = {}
    for x,y,c in chs:
        lines.setdefault(round(y,0), []).append((x,c))
    print("=== page", pno, "chars", len(chs), "lines", len(lines))
    for y in sorted(lines, reverse=True)[:6]:
        seg = sorted(lines[y])
        print(y, "|", "".join(c for _,c in seg)[:120])
