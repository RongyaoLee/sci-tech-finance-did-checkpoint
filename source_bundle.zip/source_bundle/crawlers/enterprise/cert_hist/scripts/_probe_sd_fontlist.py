# -*- coding: utf-8 -*-
import re, collections
import pymupdf
PDF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_hist\_raw\山东\关于山东省2020年第一批高新技术企业备案的复函_aa73c8b735.pdf"
doc = pymupdf.open(PDF)
c = collections.Counter()
for pno in range(len(doc)):
    for f in doc[pno].get_fonts(full=True):
        c[(f[3], f[2], f[1])] += 1
for k, v in c.items():
    print(v, k)
