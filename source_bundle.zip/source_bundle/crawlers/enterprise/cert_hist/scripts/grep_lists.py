# -*- coding: utf-8 -*-
"""Grep the crawled national-ish list dumps (_raw/_lists/*_items.json) for keywords.

    python scripts/grep_lists.py 安徽 江西 [more words...]
Prints: source column, date, title, url
"""
import os
import sys
import json
import glob

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LISTS = os.path.join(HERE, "_raw", "_lists")

words = sys.argv[1:]
for p in sorted(glob.glob(os.path.join(LISTS, "*_items.json"))):
    col = os.path.basename(p).replace("_items.json", "")
    try:
        items = json.load(open(p, encoding="utf-8"))
    except Exception:
        continue
    for it in items:
        t = it.get("title") or ""
        if any(w in t for w in words):
            print(f"{col}\t{it.get('date')}\t{t[:64]}\t{it.get('url')}")
