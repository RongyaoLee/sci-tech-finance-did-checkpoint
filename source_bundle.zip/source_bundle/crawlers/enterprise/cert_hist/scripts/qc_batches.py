# -*- coding: utf-8 -*-
"""Per (prov, year, batch) cert coverage from the rebuilt year CSVs."""
import os
import csv
import collections

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
YEARS = ("2016", "2017", "2018", "2019", "2020")

bad = []
for f in sorted(os.listdir(HERE)):
    if not f.endswith(".csv") or "_第" in f:
        continue
    prov, y = f[:-4].rsplit("_", 1)
    if y not in YEARS:
        continue
    agg = collections.OrderedDict()
    with open(os.path.join(HERE, f), encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            b = r["批次"] or "(空)"
            a = agg.setdefault(b, [0, 0])
            a[0] += 1
            if r["证书编号"]:
                a[1] += 1
    for b, (n, c) in agg.items():
        if c < n:
            bad.append((prov, y, b, n, c))

print(f"{'省':<6}{'年':<6}{'批次':<12}{'行':>7}{'带号':>7}{'缺':>7}")
for prov, y, b, n, c in bad:
    print(f"{prov:<6}{y:<6}{b:<12}{n:>7}{c:>7}{n-c:>7}")
print(f"\n{len(bad)} prov-year-batch with missing certs")
