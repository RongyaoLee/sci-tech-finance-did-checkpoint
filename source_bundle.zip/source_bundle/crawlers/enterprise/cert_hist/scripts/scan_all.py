# -*- coding: utf-8 -*-
"""Scan innocom per-province columns (备案公告=gg, 公示=gs) -> inventory of 2016-2020 items."""
import os, sys, json, re, collections

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(WORK, "cert_lists"))
sys.path.insert(0, WORK)
import fetch_common as fc

fc.RAW = os.path.join(HERE, "_raw")


def one(prov, kind, pages=6):
    ch = fc.PROV_GG.get(prov) if kind == "gg" else fc.PROV_CH.get(prov)
    if not ch:
        return [], ch
    items, empty = [], 0
    for p in range(1, pages + 1):
        suffix = "" if p == 1 else f"_{p}"
        url = f"{fc.BASE}/gqrdw/{ch}/list_gsgg_l3{suffix}.shtml"
        html, _ = fc.get(url)
        if not html:
            empty += 1
            if empty >= 2:
                break
            continue
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, "lxml")
        n = 0
        for a in soup.find_all("a", href=True):
            t = a.get_text(strip=True)
            h = a["href"]
            if not re.search(r"/gqrdw/", h) or not t:
                continue
            if "高新技术企业" not in t:
                continue
            full = h if h.startswith("http") else fc.BASE + (h if h.startswith("/") else "/" + h)
            items.append({"prov": prov, "ch": ch, "kind": kind, "title": t, "url": full})
            n += 1
        if n == 0:
            empty += 1
            if empty >= 1:
                break
        else:
            empty = 0
    seen, out = set(), []
    for it in items:
        if it["url"] in seen:
            continue
        seen.add(it["url"])
        y, b = fc.parse_meta(it["title"])
        it["year"], it["batch"] = y, b
        out.append(it)
    return out, ch


def main():
    provs = sys.argv[1].split(",") if len(sys.argv) > 1 else list(fc.PROV_GG)
    inv = {}
    for prov in provs:
        for kind in ("gg", "gs"):
            items, ch = one(prov, kind)
            inv[f"{prov}|{kind}"] = {"ch": ch, "items": items}
            yrs = collections.Counter(i["year"] for i in items if i["year"] in ("2016", "2017", "2018", "2019", "2020"))
            print(f"{prov} {kind} ch={ch} n={len(items):3d} 2016-20={dict(sorted(yrs.items()))}", flush=True)
    p = os.path.join(HERE, "_raw", "_lists", "inventory.json")
    json.dump(inv, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("saved", p)


if __name__ == "__main__":
    main()
