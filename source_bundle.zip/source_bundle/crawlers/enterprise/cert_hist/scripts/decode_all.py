# -*- coding: utf-8 -*-
"""Decode ONLY the 备案复函 PDFs that upstream failed on ("0 rows"), via cff_gid.

Cache: cert_hist/_raw/_decoded/<prov>__<year>__<batch>.json
"""
import os
import re
import sys
import json
import glob

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(HERE, "_raw")
DEC = os.path.join(RAW, "_decoded")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cff_gid  # noqa: E402

YEARS = ("2016", "2017", "2018", "2019", "2020")


def basename(u):
    return (u or "").rsplit("/", 1)[-1]


def local_for(prov, item):
    """replicate fetch_common download naming: title[:60] + '_' + basename(aurl)[:10]"""
    d = os.path.join(RAW, prov)
    t = re.sub(r'[\\/:*?"<>|]', "_", (item.get("title") or "")[:60])
    a = item.get("atts") or []
    if not a:
        return None
    cand = os.path.join(d, t + "_" + basename(a[0])[:10] + ".pdf")
    if os.path.exists(cand):
        return cand
    # fallback: suffix match
    suf = "_" + basename(a[0])[:10]
    for p in glob.glob(os.path.join(d, "*" + suf + "*")):
        return p
    return None


def main():
    os.makedirs(DEC, exist_ok=True)
    jobs = []
    for mp in sorted(glob.glob(os.path.join(RAW, "*", "*_meta.json"))):
        prov = os.path.basename(os.path.dirname(mp))
        meta = json.load(open(mp, encoding="utf-8"))
        by_url = {it["url"]: it for it in meta.get("items") or []}
        for sk in meta.get("skipped") or []:
            y = str(sk.get("year") or "")
            if y not in YEARS:
                continue
            if not str(sk.get("why", "")).startswith("0 rows"):
                continue
            u = sk.get("url") or ""
            if not u.lower().endswith(".pdf"):
                continue
            out = os.path.join(DEC, f"{prov}__{y}__{sk.get('batch')}.json")
            if os.path.exists(out):
                continue
            item = by_url.get(sk.get("url") or "") or {"title": sk.get("title"), "atts": [u]}
            f = local_for(prov, item)
            jobs.append((prov, y, sk.get("batch"), sk.get("title"), u, f, out))

    print(f"pending {len(jobs)} pdfs", flush=True)
    ok = 0
    for prov, y, batch, title, u, f, out in jobs:
        if not f:
            print(f"{prov}\t{y}\t{batch}\tNOFILE\t{basename(u)}", flush=True)
            continue
        try:
            r = cff_gid.pdf_rows(f)
        except Exception as e:
            print(f"{prov}\t{y}\t{batch}\tERR {e}\t{basename(f)}", flush=True)
            continue
        rec = {"prov": prov, "year": y, "batch": batch, "src": u, "file": os.path.basename(f),
               "pages": r["pages"], "rows": r["rows"]}
        json.dump(rec, open(out, "w", encoding="utf-8"), ensure_ascii=False)
        if r["rows"]:
            ok += 1
        print(f"{prov}\t{y}\t{batch:<8}rows={len(r['rows']):>6}  {os.path.basename(f)[:52]}", flush=True)
    print(f"\nfiles with rows: {ok}/{len(jobs)}", flush=True)


if __name__ == "__main__":
    main()
