# -*- coding: utf-8 -*-
"""Minimal Word 97-2003 (.doc) text extractor: OLE + FIB piece table (no external binaries).

text(path) -> str with Word cell marks (\x07) and paragraph marks (\r) preserved.
rows(path)  -> list[list[str]] table cells, using \x07 as delimiter.
"""
import re, struct
import olefile


def _fib_info(wd):
    flags = struct.unpack_from("<H", wd, 0x0A)[0]
    which = (flags >> 9) & 1
    fcClx, lcbClx = struct.unpack_from("<II", wd, 0x01A2)
    return which, fcClx, lcbClx


def text(path):
    ole = olefile.OleFileIO(path)
    try:
        wd = ole.openstream("WordDocument").read()
        which, fcClx, lcbClx = _fib_info(wd)
        tname = "1Table" if which else "0Table"
        if not ole.exists(tname):
            tname = "0Table" if ole.exists("0Table") else "1Table"
        tbl = ole.openstream(tname).read()
    finally:
        ole.close()

    clx = tbl[fcClx:fcClx + lcbClx]
    i, pcdt = 0, None
    while i < len(clx):
        t = clx[i]
        if t == 0x01:                      # Prc
            cb = struct.unpack_from("<h", clx, i + 1)[0]
            i += 3 + cb
        elif t == 0x02:                    # Pcdt
            lcb = struct.unpack_from("<I", clx, i + 1)[0]
            pcdt = clx[i + 5:i + 5 + lcb]
            break
        else:
            break
    if pcdt is None:
        return ""

    n = (len(pcdt) - 4) // 12
    cps = [struct.unpack_from("<I", pcdt, k * 4)[0] for k in range(n + 1)]
    out = []
    for k in range(n):
        fc = struct.unpack_from("<I", pcdt, (n + 1) * 4 + k * 8 + 2)[0]
        cch = cps[k + 1] - cps[k]
        if cch <= 0 or cch > 10_000_000:
            continue
        compressed = bool(fc & 0x40000000)
        off = (fc & 0x3FFFFFFF) // 2 if compressed else (fc & 0x3FFFFFFF)
        if compressed:
            raw = wd[off:off + cch]
            try:
                out.append(raw.decode("cp936"))
            except UnicodeDecodeError:
                out.append(raw.decode("cp1252", "replace"))
        else:
            raw = wd[off:off + cch * 2]
            out.append(raw.decode("utf-16-le", "replace"))
    return "".join(out)


CERT = re.compile(r"^GR\s*\d{10,14}$")


def rows(path):
    """Split extracted text into table rows (list of cell strings)."""
    t = text(path)
    lines = re.split(r"[\r\x0b\x0c]", t)
    out = []
    for ln in lines:
        if "\x07" not in ln:
            continue
        cells = [c.strip() for c in ln.split("\x07")]
        cells = [c for c in cells if c]
        if cells:
            out.append(cells)
    return out


def cert_rows(path):
    """-> [{seq,name,cert}] scanning cells linearly (table may be one long line)."""
    t = text(path)
    cells = [c.strip() for c in re.split(r"[\x07\r\x0b\x0c]", t)]
    res = []
    for j, c in enumerate(cells):
        c2 = c.replace(" ", "")
        if not CERT.match(c2):
            continue
        if j == 0:
            continue
        name = cells[j - 1]
        if len(name) < 3 or re.fullmatch(r"[\d\W_]+", name):
            # sometimes 名称 and 编号 in same cell order differs; skip junk
            continue
        seq = cells[j - 2] if j >= 2 and re.fullmatch(r"\d{1,5}", cells[j - 2]) else ""
        res.append({"seq": seq, "name": name, "cert": c2})
    return res


if __name__ == "__main__":
    import sys, json
    p = sys.argv[1]
    rs = cert_rows(p)
    print(len(rs), "cert rows")
    for r in rs[:5]:
        print(json.dumps(r, ensure_ascii=False))
    if not rs:
        print(text(p)[:800])
