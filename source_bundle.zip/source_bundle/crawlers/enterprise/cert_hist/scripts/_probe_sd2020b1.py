# -*- coding: utf-8 -*-
"""Probe the broken-font Shandong 2020 batch-1 filing-reply PDF."""
import os, re, io, sys, json
import pymupdf
from fontTools.ttLib import TTFont

PDF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_hist\_raw\山东\关于山东省2020年第一批高新技术企业备案的复函_aa73c8b735.pdf"
doc = pymupdf.open(PDF)
print("pages:", len(doc))
for pno in range(min(2, len(doc))):
    page = doc[pno]
    print("--- page", pno, "text:", repr(page.get_text()[:120]))
    for f in page.get_fonts(full=True):
        xref, ext, typ, basefont, name, enc = f[0], f[1], f[2], f[3], f[4], f[5]
        obj = doc.xref_object(xref)
        has_tu = "/ToUnicode" in obj
        m = re.search(r"/Encoding (\d+) 0 R", obj)
        encobj = doc.xref_object(int(m.group(1)))[:300] if m else "(inline/none)"
        nb, bext, ntyp, buf = doc.extract_font(xref)
        gids = -1
        if buf:
            try:
                tt = TTFont(io.BytesIO(buf), fontNumber=0, lazy=True)
                gids = len(tt.getGlyphOrder())
            except Exception as e:
                gids = "ERR:" + type(e).__name__
        print(f"  font xref={xref} base={basefont} type={typ} ext={ext} enc={enc} ToUnicode={has_tu} glyphs={gids} buflen={len(buf) if buf else 0}")
        print("    encobj:", encobj.replace("\n", " ")[:250])
