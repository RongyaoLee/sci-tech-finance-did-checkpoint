# -*- coding: utf-8 -*-
"""Dump per-province meta: items (year/batch/title/atts) + skipped, for gap analysis."""
import os
import sys
import json
import glob

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(HERE, "_raw")

for prov in sys.argv[1:]:
    p = os.path.join(RAW, prov, f"{prov}_meta.json")
    if not os.path.exists(p):
        print(f"== {prov}: NO META")
        continue
    m = json.load(open(p, encoding="utf-8"))
    print(f"\n== {prov}  items={len(m.get('items') or [])} skipped={len(m.get('skipped') or [])}")
    for it in m.get("items") or []:
        print(f"  [{it.get('kind')}] {it.get('year')} {it.get('batch')} atts={len(it.get('atts') or [])}  {it.get('title')[:56]}")
    for sk in m.get("skipped") or []:
        print(f"  SKIP {sk.get('year')} {sk.get('batch')} why={sk.get('why')}  {str(sk.get('title'))[:50]}")
