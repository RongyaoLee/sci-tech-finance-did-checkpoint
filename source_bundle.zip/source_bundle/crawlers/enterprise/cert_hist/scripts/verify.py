# -*- coding: utf-8 -*-
"""Verify 2016-2020 CSVs: cert format, year consistency, region code distribution."""
import os, re, csv, sys, collections, json

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
YEARS = ("2016", "2017", "2018", "2019", "2020")
CERT = re.compile(r"^GR(\d{4})(\d{2})(\d{6})$")


def main():
    rows = collections.defaultdict(lambda: {"n": 0, "cert": 0, "bad": [], "regions": collections.Counter(),
                                            "city": 0})
    for fn in sorted(os.listdir(HERE)):
        m = re.match(r"^(.+)_(201[6-9]|2020)\.csv$", fn)
        if not m:
            continue
        prov, year = m.group(1), m.group(2)
        with open(os.path.join(HERE, fn), encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                d = rows[(prov, year)]
                d["n"] += 1
                c = (r.get("证书编号") or "").strip()
                if not c:
                    continue
                mm = CERT.match(c)
                if not mm:
                    d["bad"].append(c)
                    continue
                if mm.group(1) != year:
                    d["bad"].append(f"{c}(year)")
                    continue
                d["cert"] += 1
                d["regions"][mm.group(2)] += 1
                if (r.get("城市") or "").strip():
                    d["city"] += 1
    tot = totc = 0
    print(f"{'省':6s} {'年':5s} {'行':>7s} {'有编号':>7s} {'城市':>6s}  区间码")
    for (p, y), d in sorted(rows.items()):
        tot += d["n"]
        totc += d["cert"]
        regs = ",".join(f"{k}:{v}" for k, v in d["regions"].most_common(4))
        bad = f" BAD={len(d['bad'])} {d['bad'][:3]}" if d["bad"] else ""
        print(f"{p:6s} {y:5s} {d['n']:7d} {d['cert']:7d} {d['city']:6d}  {regs}{bad}")
    print(f"TOTAL rows={tot} cert={totc}")


if __name__ == "__main__":
    main()
