# -*- coding: utf-8 -*-
"""把 innocom 复函 PDF（字体编码损坏）确定性还原为文本：glyph 名 g<GID> -> simsun/simhei GID -> unicode。无 OCR。"""
import io, re, sys
import pymupdf
from fontTools.ttLib import TTCollection, TTFont
from fontTools.cffLib import CFFFontSet

FONTS = [r'C:\Windows\Fonts\simsun.ttc', r'C:\Windows\Fonts\simhei.ttf',
         r'C:\Windows\Fonts\simfang.ttf', r'C:\Windows\Fonts\msyh.ttc',
         r'C:\Windows\Fonts\times.ttf', r'C:\Windows\Fonts\timesbd.ttf',
         r'C:\Windows\Fonts\arial.ttf']

def load_maps():
    maps = {}
    for p in FONTS:
        try:
            fonts = TTCollection(p).fonts if p.lower().endswith('.ttc') else [TTFont(p)]
        except Exception:
            continue
        for f in fonts:
            order = f.getGlyphOrder()
            cm = f.getBestCmap() or {}
            n2u = {}
            for u, n in cm.items():
                if n not in n2u:
                    n2u[n] = u
            q = []
            for gid, n in enumerate(order):
                q.append(chr(n2u[n]) if n in n2u else None)
            maps[f['name'].getDebugName(4)] = q
    return maps

MAPS = load_maps()

def resolve(maps, gid, base):
    """在若干候选字体里按 gid 取字；优先同名族。"""
    keys = [k for k in maps if base and base.split('+')[-1] in k] or list(maps)
    for k in keys:
        q = maps[k]
        if gid < len(q) and q[gid]:
            return q[gid]
    return None

def cff_charset(doc, xref, cache):
    if xref not in cache:
        info = doc.extract_font(xref)
        if not info or not info[3]:
            cache[xref] = []
        else:
            cff = CFFFontSet()
            cff.decompile(io.BytesIO(info[3]), None)
            cache[xref] = cff[cff.fontNames[0]].charset
    return cache[xref]

def decode_pages(pdf, only=None):
    doc = pymupdf.open(pdf)
    cache = {}
    out = []
    for pno, pg in enumerate(doc):
        if only is not None and pno not in only:
            continue
        res = {}
        for f in pg.get_fonts(full=True):
            xref, ext, typ, base, name, enc = f[:6]
            for k in (name, base, base.split('+')[-1]):
                res[k] = (xref, base)
        chars = []
        for sp in pg.get_texttrace():
            xr, base = res.get(sp['font'], (None, sp['font']))
            cs = cff_charset(doc, xr, cache) if xr is not None else []
            for ch in sp['chars']:
                u, gid, orig, bbox = ch
                nm = cs[gid] if gid < len(cs) else ''
                c = None
                m = re.match(r'^g(\d+)$', nm or '')
                if m:
                    c = resolve(MAPS, int(m.group(1)), base)
                elif nm:
                    try:
                        from fontTools import agl
                        t = agl.toUnicode(nm)
                        if t and len(t) == 1:
                            c = t
                    except Exception:
                        pass
                if c is None and u < 128:
                    c = chr(u)
                if c is None:
                    c = '\uFFFD'
                if c == '\uFFFD' and bbox and bbox[2] - bbox[0] > 40:
                    continue
                chars.append((round((bbox[1] + bbox[3]) / 2, 1), round(bbox[0], 1),
                              round(bbox[2], 1), c))
        out.append(chars)
    return out

def lines_of(chars, tol=4.0):
    chars = sorted(chars)
    rows = []
    for y, x0, x1, c in chars:
        if rows and abs(rows[-1][0] - y) <= tol:
            rows[-1][1].append((x0, x1, c))
        else:
            rows.append([y, [(x0, x1, c)]])
    res = []
    for y, items in rows:
        items.sort()
        s = ''
        prev = None
        for x0, x1, c in items:
            if prev is not None and x0 - prev > 2.0 and c.strip():
                s += ' '
            s += c
            prev = x1
        res.append((y, items[0][0], s))
    return res

if __name__ == '__main__':
    pdf = sys.argv[1]
    pno = int(sys.argv[2]) if len(sys.argv) > 2 else 6
    pages = decode_pages(pdf, only={pno})
    for y, x, s in lines_of(pages[0]):
        print('%7.1f %6.1f | %s' % (y, x, s))
