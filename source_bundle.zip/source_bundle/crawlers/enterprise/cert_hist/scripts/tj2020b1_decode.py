﻿# -*- coding: utf-8 -*-
"""Decode Tianjin 2020 batch-1 filing reply PDF (broken font subset encoding)."""
import pymupdf, os, re, json, sys
from fontTools.ttLib import TTFont

base = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_hist\_raw\天津"
PDF = os.path.join(base, "关于天津市2020年第一批高新技术企业备案的复函_285ddb0c9b.pdf")

_f = TTFont(r"C:\Windows\Fonts\simsun.ttc", fontNumber=0)
_order = _f.getGlyphOrder()
_rev = {}
for cp, gn in _f.getBestCmap().items():
    _rev.setdefault(gn, chr(cp))
GID2CH = {i: _rev[gn] for i, gn in enumerate(_order) if gn in _rev}

doc = pymupdf.open(PDF)

def parse_diffs(s):
    seg = s[s.index("["): s.index("]")+1]
    toks = re.findall(r"\d+|/[^\s/\[\]]+", seg)
    m = {}; cur = None
    for t in toks:
        if t.startswith("/"):
            m[cur] = t[1:]; cur += 1
        else:
            cur = int(t)
    return m

def font_info(xref):
    obj = doc.xref_object(xref)
    m = re.search(r"/Encoding (\d+) 0 R", obj)
    diffs, widths = {}, {}
    if m:
        diffs = parse_diffs(doc.xref_object(int(m.group(1))))
    fc = re.search(r"/FirstChar (\d+)", obj)
    fc = int(fc.group(1)) if fc else 0
    wm = re.search(r"/Widths \[(.*?)\]", obj, re.S)
    if wm:
        ws = [int(float(x)) for x in wm.group(1).split()]
        widths = {fc+i: w for i, w in enumerate(ws)}
    return diffs, widths

def tokens(s):
    i = 0; n = len(s)
    while i < n:
        c = s[i:i+1]
        if c in b" \t\r\n\x00\x0c":
            i += 1; continue
        if c == b"%":
            j = s.find(b"\n", i); i = n if j < 0 else j+1; continue
        if c == b"(":
            depth = 1; j = i+1; buf = bytearray()
            while j < n and depth:
                ch = s[j:j+1]
                if ch == b"\\":
                    nx = s[j+1:j+2]
                    esc = {b"n":b"\n",b"r":b"\r",b"t":b"\t",b"b":b"\b",b"f":b"\f",b"(":b"(",b")":b")",b"\\":b"\\"}
                    if nx in esc: buf += esc[nx]; j += 2; continue
                    if nx.isdigit():
                        k = 0
                        while k < 3 and s[j+1+k:j+2+k].isdigit(): k += 1
                        buf.append(int(s[j+1:j+1+k], 8) & 0xFF); j += 1+k; continue
                    if nx in (b"\n", b"\r"):
                        j += 2; continue
                    buf += nx; j += 2; continue
                if ch == b"(": depth += 1
                elif ch == b")":
                    depth -= 1
                    if depth == 0: j += 1; break
                buf += ch; j += 1
            yield ("str", bytes(buf)); i = j; continue
        if c == b"<" and s[i+1:i+2] != b"<":
            j = s.find(b">", i)
            hx = re.sub(rb"\s", b"", s[i+1:j])
            yield ("str", bytes.fromhex(hx.decode())); i = j+1; continue
        if c == b"[": yield ("[", None); i += 1; continue
        if c == b"]": yield ("]", None); i += 1; continue
        if c == b"/":
            j = i+1
            while j < n and s[j:j+1] not in b" \t\r\n\x00\x0c/[]<>(){}%": j += 1
            yield ("name", s[i+1:j].decode("latin1")); i = j; continue
        j = i
        while j < n and s[j:j+1] not in b" \t\r\n\x00\x0c/[]<>()%": j += 1
        w = s[i:j].decode("latin1")
        try: yield ("num", float(w))
        except: yield ("op", w)
        i = j

def page_chars(page):
    fonts = {}
    for fn in page.get_fonts(full=True):
        fonts[fn[4]] = font_info(fn[0])
    out = []
    tm = [1,0,0,1,0,0]; tlm = tm[:]
    fname = None; adv = 0.0
    cs = b"".join(doc.xref_stream(x) for x in page.get_contents())
    toks = list(tokens(cs))
    def show(bs):
        nonlocal adv
        fi = fonts.get(fname)
        for code in bs:
            ch = None
            if fi and code in fi[0]:
                nm = fi[0][code]
                if nm.startswith("g") and nm[1:].isdigit():
                    ch = GID2CH.get(int(nm[1:]))
            if ch is None:
                ch = "\ufffd"
            out.append((tm[0]*adv + tm[4], tm[1]*adv + tm[5], ch))
            w = fi[1].get(code, 1000) if fi else 1000
            adv += w/1000.0
    i = 0
    while i < len(toks):
        k, v = toks[i]
        if k == "op":
            if v == "BT": tm = [1,0,0,1,0,0]; tlm = tm[:]; adv = 0.0
            elif v == "Tf":
                if i >= 2 and toks[i-2][0] == "name": fname = toks[i-2][1]
            elif v == "Tm":
                nums = [toks[i-6+j][1] for j in range(6)]
                tm = nums[:]; tlm = nums[:]; adv = 0.0
            elif v in ("Td","TD"):
                tx, ty = toks[i-2][1], toks[i-1][1]
                tlm = [tlm[0],tlm[1],tlm[2],tlm[3],
                       tlm[0]*tx+tlm[2]*ty+tlm[4], tlm[1]*tx+tlm[3]*ty+tlm[5]]
                tm = tlm[:]; adv = 0.0
            elif v == "Tj": show(toks[i-1][1])
            elif v in ("'", '"'): show(toks[i-1][1])
            elif v == "TJ":
                j = i-1
                while toks[j][0] != "[": j -= 1
                for kk, vv in toks[j+1:i-1]:
                    if kk == "str": show(vv)
                    elif kk == "num": adv -= vv/1000.0
        i += 1
    return out

def lines_of(page, tol=2.0):
    chs = page_chars(page)
    chs.sort(key=lambda t: -t[1])
    lines = []
    for x,y,c in chs:
        if lines and abs(lines[-1]["y"] - y) <= tol:
            lines[-1]["chars"].append((x,c))
        else:
            lines.append({"y": y, "chars": [(x,c)]})
    res = []
    for ln in lines:
        seg = sorted(ln["chars"])
        res.append((ln["y"], "".join(c for _,c in seg)))
    return res

if __name__ == "__main__":
    allrows = []
    raw_lines = []
    for pno in range(len(doc)):
        for y, txt in lines_of(doc[pno]):
            raw_lines.append({"page": pno, "y": round(y,1), "text": txt})
    json.dump(raw_lines, open(os.path.join(base, "tj2020b1_rawlines.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=0)
    print("lines:", len(raw_lines))
    print("sample tail:", json.dumps(raw_lines[-6:], ensure_ascii=False))
