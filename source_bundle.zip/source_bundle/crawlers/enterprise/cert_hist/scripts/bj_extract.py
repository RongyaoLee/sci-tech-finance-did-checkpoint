# -*- coding: utf-8 -*-
"""从 innocom 复函 PDF（字体编码损坏）确定性还原 (序号, 企业名称, 证书编号) 并写 CSV。"""
import csv, re, sys, collections
from pdf_dec2 import decode_pages, lines_of

ROW = re.compile(r'^(\d{1,5})\s+(.+?)\s+(GR\d{12})$')
ROW_NO_CERT = re.compile(r'^(\d{1,5})\s+(\D{4,})$')


def extract(pdf):
    pages = decode_pages(pdf)
    rows, bad = [], []
    for pno, chars in enumerate(pages):
        for y, x, s in lines_of(chars):
            s = s.replace('\u3000', ' ').strip()
            if not s:
                continue
            m = ROW.match(s)
            if m:
                rows.append((pno, int(m.group(1)), m.group(2).strip(), m.group(3)))
            elif ROW_NO_CERT.match(s) and len(s) > 8:
                bad.append((pno, s[:80]))
    return rows, bad


def main():
    pdf, out, year, batch, url = sys.argv[1:6]
    rows, bad = extract(pdf)
    rows.sort(key=lambda r: r[1])
    seen = {}
    dup = []
    for pno, seq, name, cert in rows:
        k = cert
        if k in seen:
            dup.append((k, seen[k], name))
        seen[k] = name
    seqs = [r[1] for r in rows]
    certs = [int(r[3][6:]) for r in rows]
    # 顺序号 = 末 6 位
    gaps_c = [(a, b) for a, b in zip(certs, certs[1:]) if b != a + 1]
    gaps_s = [(a, b) for a, b in zip(seqs, seqs[1:]) if b != a + 1]
    pre_bad = [r for r in rows if not (r[3][:6] == 'GR' + year and r[3][6:8] == '11')]
    lens = collections.Counter(len(r[3]) for r in rows)
    print('rows=%d seq %d..%d  cert %d..%d  dups=%d' % (
        len(rows), min(seqs), max(seqs), min(certs), max(certs), len(dup)))
    print('len(证书编号)=', dict(lens), ' prefix_bad=', len(pre_bad), ' cert_gaps=', gaps_c[:5], ' seq_gaps=', gaps_s[:5])
    print('bad_lines(no cert)=%d' % len(bad), bad[:6])
    print('dup samples', dup[:5])
    if len(sys.argv) > 6 and sys.argv[6] == '--write':
        with open(out, 'w', newline='', encoding='utf-8-sig') as f:
            w = csv.writer(f)
            w.writerow(['企业名称', '证书编号', '城市', '区县', '认定年度', '批次', '来源URL'])
            for pno, seq, name, cert in rows:
                w.writerow([name, cert, '北京', '', year, batch, url])
        print('WROTE', out, len(rows))
    else:
        for r in rows[:3] + rows[-3:]:
            print(r)


if __name__ == '__main__':
    main()
