# -*- coding: utf-8 -*-
"""docx → rows for 高企 lists (tables)."""
import re
from docx import Document


def parse_docx(path, region_hint=None):
    doc = Document(path)
    rows = []
    for tbl in doc.tables:
        grid = [[c.text.strip() for c in r.cells] for r in tbl.rows]
        if not grid:
            continue
        hdr_i = None
        for i, g in enumerate(grid[:4]):
            joined = "".join(g)
            if "证书编号" in joined or ("序号" in joined and "企业名称" in joined):
                hdr_i = i
                break
        if hdr_i is None:
            continue
        hdr = grid[hdr_i]
        def col(*keys):
            for j, h in enumerate(hdr):
                for k in keys:
                    if k in h:
                        return j
            return None
        c_name = col("企业名称", "单位名称")
        c_cert = col("证书编号", "证书号")
        c_reg = col("行政区域", "所属区域", "地区", "所在市", "地市")
        c_seq = col("序号")
        for g in grid[hdr_i + 1:]:
            if not g:
                continue
            cert = re.sub(r"\s", "", g[c_cert]) if c_cert is not None and c_cert < len(g) else ""
            cert = cert.replace("Ｒ", "R")
            if not re.fullmatch(r"G[R]\d{10,14}", cert):
                cert = ""
            name = g[c_name].strip() if c_name is not None and c_name < len(g) else ""
            reg = g[c_reg].strip() if c_reg is not None and c_reg < len(g) else ""
            seq = g[c_seq].strip() if c_seq is not None and c_seq < len(g) else ""
            if not name and not cert:
                continue
            rows.append({"seq": seq, "cert": cert, "name": name,
                         "region": reg or (region_hint or ""), "page": 0})
    # dedupe
    seen, out = set(), []
    for r in rows:
        k = r["cert"] or r["name"]
        if k in seen:
            continue
        seen.add(k); out.append(r)
    return out


if __name__ == "__main__":
    import sys
    rows = parse_docx(sys.argv[1])
    print("rows", len(rows), "cert", sum(1 for r in rows if r["cert"]), "region", sum(1 for r in rows if r["region"]))
    for r in rows[:3]:
        print(r)
