# -*- coding: utf-8 -*-
"""Download a file and dump first lines / table preview."""
import io, os, re, sys, requests
import pymupdf, openpyxl

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
H = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9"}
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_probe")
os.makedirs(OUT, exist_ok=True)


def dl(url):
    r = requests.get(url, headers=H, timeout=60, verify=False)
    r.raise_for_status()
    name = url.split("/")[-1]
    p = os.path.join(OUT, name)
    open(p, "wb").write(r.content)
    return p


def pdf_preview(p, pages=2):
    d = pymupdf.open(p)
    print("PAGES", d.page_count)
    for i in range(min(pages, d.page_count)):
        t = d[i].get_text()
        print(f"--- page {i+1} textlen={len(t)}")
        print(t[:1200])


def xlsx_preview(p):
    wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
    for ws in wb.worksheets:
        print("SHEET", ws.title, ws.max_row, ws.max_column)
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i > 6:
                break
            print("  ", row)


if __name__ == "__main__":
    for u in sys.argv[1:]:
        p = dl(u)
        print("FILE", p, os.path.getsize(p))
        if p.lower().endswith(".pdf"):
            pdf_preview(p)
        elif p.lower().endswith((".xlsx", ".xls")):
            xlsx_preview(p)
