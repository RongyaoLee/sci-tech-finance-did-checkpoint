# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

for u in ["http://kjj.changsha.gov.cn/",
          "https://cstexun.com/article/2219.html",
          "http://kjj.zhuzhou.gov.cn/",
          "http://kjj.xiangtan.gov.cn/",
          "http://kjj.hengyang.gov.cn/"]:
    html, final = cf.get(u, tries=1)
    if not html:
        print("%-40s FAIL" % u)
        continue
    soup = BeautifulSoup(html, "lxml")
    t = soup.title.get_text(strip=True) if soup.title else ""
    atts = cf.attachments(u, html)
    print("%-40s len=%-7d %s | atts=%s" % (u, len(html), t[:40], [a[1][-60:] for a in atts][:4]))
