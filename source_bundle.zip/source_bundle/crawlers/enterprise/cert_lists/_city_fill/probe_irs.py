# -*- coding: utf-8 -*-
import requests, urllib3, re, json, urllib.parse
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
HOST = 'https://kjt.shaanxi.gov.cn'
kw = '拟认定高新技术企业'
qv = urllib.parse.quote(kw)
cands = [
    f'/irs-c-web/search?code=191b76850fb&dataTypeId=20770&searchWord={qv}&page=1&pageSize=10',
    f'/irs-c-web/search.do?code=191b76850fb&dataTypeId=20770&searchWord={qv}&page=1&pageSize=10',
    f'/irs-c-web/api/search?code=191b76850fb&dataTypeId=20770&searchWord={qv}&page=1&pageSize=10',
    f'/irs-c-web/front/search?code=191b76850fb&dataTypeId=20770&searchWord={qv}',
    f'/irs-c-web/search/list?code=191b76850fb&dataTypeId=20770&searchWord={qv}',
]
for c in cands:
    try:
        r = requests.get(HOST + c, headers=H, timeout=30, verify=False)
        body = r.content[:220]
        print(r.status_code, len(r.content), c[:80], body[:160])
    except Exception as e:
        print('ERR', c[:60], str(e)[:60])
print('--- js from search html ---')
t = open(r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw\_sxsearch.html', encoding='utf-8').read()
for x in re.findall(r'src=[\'"]([^\'"]+\.js)[\'"]', t):
    print('  ', x)
