﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
sys.path.insert(0,r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists")
import cf
out=open("_hn_dump.txt","w",encoding="utf-8")
for u in ["http://csmls.changsha.gov.cn/zwgk/xxgk/czxx/202308/t20230822_11198490.html",
          "http://www.hnyx.gov.cn/c5636/20201208/i1628402.html"]:
    h,f=cf.get(u)
    out.write("===== %s %d\n"%(f,len(h) if h else 0))
    if not h: continue
    body=re.sub(r"<(script|style)[^>]*>.*?</\1>","",h,flags=re.S|re.I)
    txt=re.sub(r"<[^>]+>","\n",body); txt=re.sub(r"&nbsp;"," ",txt).replace("&amp;","&")
    for x in txt.split("\n"):
        x=x.strip()
        if x: out.write(x+"\n")
out.close()
print("ok")
