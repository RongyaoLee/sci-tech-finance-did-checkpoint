# -*- coding: utf-8 -*-
"""山东各市高企名单抓取：栏目翻页 -> 文章 -> 附件 -> 表格 -> parts/*.jsonl
用法: python sd_crawl.py 威海 泰安 ...
"""
import os, re, sys, time, json, io
from urllib.parse import urljoin, urlparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_lib as S, sd_city_parser as P, sd_store as ST

LOG = []
BASE = S.BASE


def log(*a):
    msg = " ".join(str(x) for x in a)
    LOG.append(msg)
    print(msg, flush=True)


# city -> list of (column_url, max_pages)
COLS = {
    "威海": [("https://kjj.weihai.gov.cn/col/col23341/index.html", 30)],
    "泰安": [("https://kjj.taian.gov.cn/col/col45670/index.html", 30)],
    "淄博": [("https://www.zibo.gov.cn/col/col2067/index.html", 40)],
    "东营": [("http://www.dongying.gov.cn/col/col38799/index.html", 40)],
    "济宁": [("http://jnkj.jining.gov.cn/col/col34419/index.html", 25),
             ("https://www.jining.gov.cn/col/col61575/index.html", 25)],
    "潍坊": [("http://kjj.weifang.gov.cn/kjjgd/?id=10", 20)],
    "烟台": [("https://kjj.yantai.gov.cn/col/col16248/index.html", 40)],
    "临沂": [("https://kjj.linyi.gov.cn/info/1177/1.htm", 20)],
    "聊城": [("http://kjj.liaocheng.gov.cn/col/col28061/index.html", 30)],
    "德州": [("http://kjj.dezhou.gov.cn/col/col2355/index.html", 30)],
    "滨州": [("http://kjj.binzhou.gov.cn/col/col1233/index.html", 30)],
    "日照": [("http://kjj.rizhao.gov.cn/col/col2388/index.html", 30)],
    "枣庄": [("http://kjj.zaozhuang.gov.cn/col/col12596/index.html", 30)],
    "菏泽": [("http://kjj.heze.gov.cn/col/col17953/index.html", 30)],
    "济南": [("http://kjj.jinan.gov.cn/col/col26153/index.html", 30)],
}

ART_RE = re.compile(r'(?:href|src)="([^"]*?(?:/art/\d{4}/|art_\d+_\d+\.html|/\d{4}/\d{2}/t\d{8}_\d+\.html|\?id=\d+&[a-z]+=art|/\d{15,}\.html|/info/\d+/\d+\.htm)[^"]*)"', re.I)
LINK_RE = re.compile(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', re.S | re.I)
DOC_RE = re.compile(r'(attach/0/|downfile\.jsp|\.pdf|\.xlsx?|\.docx?|\.et\b|\.wps\b)', re.I)
TITLE_HIT = re.compile(r"高新|高企|科技型|创新型企业")
TITLE_LIST = re.compile(r"名单|公布|认定|公示|备案|证书|通知|结果")


def pages(col, maxp):
    """generate candidate list-page urls"""
    yield col
    u = col
    if "?" in col:
        head, qs = col.split("?", 1)
        for i in range(1, maxp):
            yield "%s?%s&page=%d" % (head, qs, i + 1)
            yield "%s?%s&pageNo=%d" % (head, qs, i + 1)
        return
    head = col.replace("index.html", "")
    for i in range(1, maxp):
        yield "%sindex_%d.html" % (head, i)


def crawl_col(city, col, maxp):
    seen_arts = set()
    got = 0
    empty = 0
    for u in pages(col, maxp):
        try:
            sc, h, fin = S.get(u, tries=1, timeout=30)
        except Exception:
            empty += 1
            continue
        if not isinstance(h, str) or sc != 200 or len(h) < 500:
            empty += 1
            if empty >= 6:
                break
            continue
        # 收集文章链接 + 标题
        found = []
        for href, txt in LINK_RE.findall(h):
            t = re.sub(r"<[^>]+>", "", txt)
            t = re.sub(r"\s+", "", t)
            if not t or len(t) < 4:
                continue
            if not (TITLE_HIT.search(t) and TITLE_LIST.search(t)):
                continue
            full = urljoin(fin or u, href)
            if not full.startswith("http"):
                continue
            found.append((t, full))
        new = 0
        for t, full in found:
            if full in seen_arts:
                continue
            seen_arts.add(full)
            new += 1
            try:
                got += handle_article(city, t, full)
            except Exception as e:
                log("  art ERR %s %r" % (full, e))
        log("  page %s arts=%d new=%d" % (u, len(found), new))
        empty = 0 if new else empty + 1
        if empty >= 3:
            break
        if not found and "index_" in u:
            break
    return got, len(seen_arts)


def html_tables(h):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(h, "html.parser")
    tabs = []
    for t in soup.find_all("table"):
        rows = []
        for tr in t.find_all("tr"):
            cells = [re.sub(r"\s+", "", td.get_text(" ")) for td in tr.find_all(["td", "th"])]
            if cells:
                rows.append(cells)
        if len(rows) >= 2:
            tabs.append(rows)
    return tabs


def handle_article(city, title, url):
    try:
        sc, h, fin = S.get(url, tries=1, timeout=30)
    except Exception:
        return 0
    if not isinstance(h, str) or sc != 200:
        return 0
    year = ""
    m = re.search(r"(20\d\d)\s*年", title) or re.search(r"/(20\d\d)/", url)
    if m:
        year = m.group(1)
    n = 0
    # 1) 正文内联表格
    tabs = html_tables(h)
    if tabs:
        rows = [(a, b, d) for a, b, c, d in P.rows_from_tables(tabs, city + "市") if (c == city or not c)]
        if len(rows) >= 5:
            n += ST.append_rows(city, rows, url, year, "")
            log("    inline-table rows=%d -> %d  %s" % (len(rows), n, title[:40]))
    # 2) 附件
    docs = []
    for href, txt in LINK_RE.findall(h):
        full = urljoin(fin or url, href)
        if DOC_RE.search(href) or DOC_RE.search(full):
            docs.append(full)
    for full in dict.fromkeys(docs)[:12] if isinstance(docs, list) else []:
        if len(full) > 400:
            continue
        try:
            sc2, data, fin2 = S.get(full, tries=1, timeout=45, binary=True)
        except Exception:
            continue
        if not isinstance(data, bytes) or len(data) < 800:
            continue
        if data[:5] not in (b"%PDF-",) and data[:2] != b"PK" and data[:4] != b"\xd0\xcf\x11\xe0":
            continue
        rows = P.rows_from_doc(full, data, city + "市")
        rows = [(a, b, d) for a, b, c, d in rows if (c == city or not c)]
        if rows:
            add = ST.append_rows(city, rows, full, year, "")
            n += add
            log("    doc rows=%d add=%d %s" % (len(rows), add, os.path.basename(urlparse(full).path)[:50]))
    return n


def main(cities):
    tot = {}
    for city in cities:
        cols = COLS.get(city)
        if not cols:
            log("SKIP %s (no col)" % city)
            continue
        c = 0
        for col, maxp in cols:
            log("== %s %s" % (city, col))
            try:
                g, na = crawl_col(city, col, maxp)
                log("  -> %s arts=%d rows=%d" % (city, na, g))
                c += g
            except Exception as e:
                log("  COL ERR %s %r" % (col, e))
        tot[city] = c
        log("TOTAL %s = %d" % (city, c))
    with open(os.path.join(BASE, "_crawl_%s.json" % "_".join(cities)), "w", encoding="utf-8") as f:
        json.dump(tot, f, ensure_ascii=False)


if __name__ == "__main__":
    main(sys.argv[1:] or list(COLS))
