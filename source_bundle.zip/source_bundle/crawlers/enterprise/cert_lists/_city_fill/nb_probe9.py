# -*- coding: utf-8 -*-
import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

tests = [
    "http://www.innocom.gov.cn/gqrdw/c101455/201612/79e3a2a0addc4ed4beb98e5c69da7b6d.shtml",  # 2016 一批复函
    "http://www.innocom.gov.cn/gqrdw/c101455/202512/d2d6a87ea5fa440a8681ed746ae1e84c.shtml",  # 2025 备案公告
    "http://www.innocom.gov.cn/gqrdw/c101455/202001/e137af4a069445c4a4db93da8971ea26.shtml",  # 2019 一批复函
]
for u in tests:
    sc, html, final = H.get(u, timeout=25, tries=2)
    print("===", u.split("/")[-1], sc, len(html or ""))
    if sc != 200:
        continue
    H.save_raw("nb_art", u, html.encode("utf-8", "ignore"))
    docs = []
    for href, t in H.img_links(html, final):
        low = href.lower()
        if any(e in low for e in (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".zip", ".rar")) or "files/" in low:
            docs.append((href, t))
    print("  docs:", len(docs))
    for href, t in docs:
        sc2, data, f2 = H.get(href, binary=True)
        txt = H.doc_text(href, data) if sc2 == 200 else ""
        n = len(H.certs_in_text(txt))
        print("   DL", sc2, len(data or b""), "certs", n, "|", t[:40], "|", href)
        if n:
            p = H.save_raw("nb", href, data)
            open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_test_%s.txt" % n, "w", encoding="utf-8").write(txt[:6000])
            print("     sample:", txt[:200].replace("\n", " / "))
