# -*- coding: utf-8 -*-
"""Find the endpoint constants V and H used by the Hubei 高新技术企业查询 page (flid=008001)."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

p = os.path.join(cf.HERE, "_hb_ConvenientQuery.js")
t = open(p, encoding="utf-8").read()

print("== assignments to V/H ==")
for m in re.finditer(r"(?:[,;{ ])([VH])=([^,;{}]{0,140})", t):
    print(repr(m.group(0))[:180])

print("== backtick strings ==")
for s in sorted(set(re.findall(r"`([^`]{4,90})`", t))):
    print("  ", repr(s))

print("== axios instance ==")
for m in re.finditer(r"\$=([A-Za-z_$\.]+\([^)]{0,200}\))", t):
    print(repr(m.group(0))[:240])

print("== any string ending in /query or /list ==")
for s in sorted(set(re.findall(r"['\"]([^'\"]*(?:/query|/list|/page|/search|bm/)[^'\"]*)['\"]", t))):
    print("  ", repr(s))

# fall back: dump the whole main bundle hits for likely endpoint names
main = open(os.path.join(cf.HERE, "_hb_ywt.js"), encoding="utf-8").read()
print("== main bundle: quoted paths with ywt/bm/api ==")
for s in sorted(set(re.findall(r"['\"]([^'\"]{6,90}(?:bm|api|query|list)[^'\"]{0,40})['\"]", main))):
    if "/" in s:
        print("  ", repr(s))
