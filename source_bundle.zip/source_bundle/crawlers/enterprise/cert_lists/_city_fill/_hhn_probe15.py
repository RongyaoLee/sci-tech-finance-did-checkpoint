# -*- coding: utf-8 -*-
import io, sys, json, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import requests

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
S = requests.Session()
S.headers.update({'User-Agent': UA, 'Referer': 'https://fuwu.most.gov.cn/html/fwcx/gxjsqybacx/',
                  'X-Requested-With': 'XMLHttpRequest'})
u = 'https://fuwu.most.gov.cn/dataService/WebService.asmx/getGxqData'
for code in ['0000', '1234']:
    for only_name in (False,):
        d = {'appName': 'gxjs', 'from': 'pc', 'name': '唐山非晶科技有限公司',
             'Certificate_num': 'GR202413000299', 'code': code}
        try:
            r = S.post(u, data=d, timeout=30, verify=False)
            print('code=%s status=%s' % (code, r.status_code))
            print((r.text or '')[:800])
        except Exception as e:
            print('code=%s ERR %r' % (code, e))

# 验证码图片端点
try:
    r = S.get('https://fuwu.most.gov.cn/dataService/WebService.asmx/getVerifyCode', timeout=20, verify=False)
    print('verify endpoint', r.status_code, r.headers.get('Content-Type'), len(r.content))
except Exception as e:
    print('verify ERR', repr(e))
