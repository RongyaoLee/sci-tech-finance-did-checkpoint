# -*- coding: utf-8 -*-
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

docs = {
 'hn2024p4': 'https://oss.henan.gov.cn/typtfile/20241203/0072e952d015453aae4848536008292f.doc',
 'hn2025p2': 'https://oss.henan.gov.cn/typtfile/20251128/3f8f31b1299f4b809669eac7b90d1f75.wps',
}
for k, u in docs.items():
    st, data, fu = H.get(u, timeout=90, binary=True)
    print('==', k, st, len(data))
    if st != 200:
        continue
    open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_%s.bin' % k), 'wb').write(data)
    t = H.doc_text(u, data)
    print(' chars', len(t))
    print(' head:', re.sub(r'\s+', ' ', t[:500]))
    print(' has 所属地市:', '所属地市' in t, '所在地域:', '所在地域' in t, 'certs', len(H.certs_in_text(t)))

print('### innocom /file links')
for u in ['http://www.innocom.gov.cn/gxjsqyrdw/2018henan/201811/d23f689ad7844a3bae31ef8a738d8a3b/file']:
    st, data, fu = H.get(u, timeout=60, binary=True)
    print(' ', u[-40:], st, len(data or b''), (data or b'')[:8])
