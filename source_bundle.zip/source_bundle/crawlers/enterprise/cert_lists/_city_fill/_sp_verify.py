# -*- coding: utf-8 -*-
"""交付前校验：9 省 _city_fill CSV 的行数/城市填充/城市合法性/样本"""
import os, csv, sys, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S

HERE = os.path.dirname(os.path.abspath(__file__))
HDR = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
PROVS = ["辽宁省", "吉林省", "黑龙江省", "广西壮族自治区", "甘肃省", "贵州省",
         "内蒙古自治区", "海南省", "宁夏回族自治区"]

for p in PROVS:
    f = os.path.join(HERE, p + "_city.csv")
    if not os.path.exists(f):
        print(p, "MISSING")
        continue
    rd = list(csv.DictReader(open(f, encoding="utf-8-sig")))
    assert list(rd[0].keys()) == HDR, (p, list(rd[0].keys()))
    filled = [r for r in rd if (r["城市"] or "").strip()]
    al = S.allowed_cities(p)
    bad = collections.Counter(r["城市"] for r in filled
                              if S._core(r["城市"]) not in al and r["城市"] not in al)
    print("%-12s rows=%5d 有城市=%5d %5.1f%% 区县=%4d 城市种类=%2d 非法=%s"
          % (p, len(rd), len(filled), 100.0 * len(filled) / max(1, len(rd)),
             sum(1 for r in filled if (r["区县"] or "").strip()),
             len(set(r["城市"] for r in filled)), dict(bad.most_common(3)) or "-"))
    for r in filled[:2]:
        print("    ", r["企业名称"][:26], "|", r["城市"], "|", r["区县"], "|", r["认定年度"], r["批次"])
