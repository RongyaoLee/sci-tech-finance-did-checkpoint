﻿# -*- coding: utf-8 -*-
import os,sys,re,json,urllib.parse
sys.path.insert(0,os.getcwd())
import cf
def cols(base):
    h,fin=cf.get(base)
    if not h: return []
    out=set()
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',h,re.S|re.I):
        u=urllib.parse.urljoin(fin,m.group(1)); t=re.sub(r"<[^>]+>","",m.group(2)); t=re.sub(r"\s+","",t).strip()
        if re.search(r"通知公告|公示公告|公告|政务公开",t) and len(t)<=8: out.add(u)
    return sorted(out)[:8]
for base in ["http://www.zzgx.gov.cn/","http://www.czgxq.gov.cn/"]:
    print("==",base)
    for c in cols(base): print("   COL",c)
