# -*- coding: utf-8 -*-
"""Build <省>_城市.csv (only rows we could resolve a 地级市 for) from harvested sources.

Sources
  湖北省 : _city_fill/hubei_api_rows.jsonl   (湖北科技一网通 便民查询 API, field areaname)
  湖南省 : _city_fill/rows_湖南*.jsonl        (市州科技局/政务公开公布件)
  陕西省 : _city_fill/rows_陕西*.jsonl

Two passes
  pass1 直接命中：patch 记录能对上主表行（name+cert → cert → name 唯一）
  pass2 同名扩展：主表里没命中、但企业全名与某条已解析记录完全一致（该名字在 patch 里唯一）的行，
        把同一城市写成该行自己的补丁行（同企业旧年度证书），来源 URL 保持不变，
        明细另存 _city_fill/_namejoin_<省>.jsonl 供审计。

输出列 == HEADER。认定年度/批次 取自主表行（权威），来源URL 取自官方文件/接口。
"""
import os, sys, collections, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import city_common as cc

HB_API = "https://kjt.hubei.gov.cn/ywt/services/portal/search/commonSearch?flid=008001"


def hb_records():
    out = []
    for r in cc.load_jsonl(["hubei_api_rows.jsonl"]):
        out.append({"name": r.get("name", ""), "cert": r.get("data_no", "") or r.get("id", ""),
                    "city": r.get("areaname", ""), "county": "", "year": str(r.get("nd", "") or ""),
                    "batch": "", "source_url": HB_API, "note": "hubei-api"})
    return out


def sub_records(prov):
    fn = os.path.join(cc.FILL, "rows_%s.jsonl" % prov.replace("省", ""))
    base = "rows_%s" % prov.replace("省", "")
    files = sorted(f for f in os.listdir(cc.FILL)
                   if f.startswith(base) and f.endswith(".jsonl"))
    return cc.load_jsonl(files)


SOURCES = {"湖北省": hb_records, "湖南省": lambda: sub_records("湖南省"),
           "陕西省": lambda: sub_records("陕西省")}


def build(prov):
    rows, nl = cc.read_prov(prov)
    by_key, by_cert, by_name = {}, collections.defaultdict(list), collections.defaultdict(list)
    for r in rows:
        k = (cc.norm_name(r["企业名称"]), (r["证书编号"] or "").strip())
        by_key[k] = r
        if k[1]:
            by_cert[k[1]].append(r)
        by_name[k[0]].append(r)

    out, seen, resolved, stat = [], set(), {}, collections.Counter()
    for rec in SOURCES[prov]():
        name = cc.norm_name(rec.get("name"))
        cert = (rec.get("cert") or "").strip()
        city = cc.norm_city(prov, rec.get("city"))
        if not name or not city:
            stat["drop_no_city"] += 1
            continue
        how, row = "", by_key.get((name, cert))
        if row is not None:
            how = "name+cert"
        elif cert and len(by_cert.get(cert, [])) == 1:
            row, how = by_cert[cert][0], "cert"
        else:
            cand = by_name.get(name, [])
            if len(cand) == 1:
                row, how = cand[0], "name"
            elif cand:
                how = "ambiguous"
        if row is None:
            stat["miss_" + (how or "none")] += 1
            continue
        stat[how] += 1
        rk = (cc.norm_name(row["企业名称"]), (row["证书编号"] or "").strip())
        resolved[rk] = (city, (rec.get("county") or "").strip(),
                        (rec.get("source_url") or row["来源URL"] or "").strip())
        key = (rk[0], rk[1], city)
        if key in seen:
            continue
        seen.add(key)
        out.append({"企业名称": row["企业名称"], "证书编号": row["证书编号"], "城市": city,
                    "区县": resolved[rk][1], "认定年度": row["认定年度"] or str(rec.get("year", "") or ""),
                    "批次": row["批次"], "来源URL": resolved[rk][2]})

    # pass2: 同名（企业全名一致）跨年度扩展
    name2city = {}
    for (nm, ct), v in resolved.items():
        name2city.setdefault(nm, set()).add((v[0], v[1], v[2]))
    sidecar = []
    for r in rows:
        nm = cc.norm_name(r["企业名称"])
        cert = (r["证书编号"] or "").strip()
        if (nm, cert) in resolved:
            continue
        hits = name2city.get(nm)
        if not hits or len({h[0] for h in hits}) != 1:
            continue
        city, county, url = sorted(hits)[0]
        key = (nm, cert, city)
        if key in seen:
            continue
        seen.add(key)
        out.append({"企业名称": r["企业名称"], "证书编号": r["证书编号"], "城市": city,
                    "区县": county, "认定年度": r["认定年度"], "批次": r["批次"], "来源URL": url})
        sidecar.append({"name": r["企业名称"], "cert": cert, "city": city, "year": r["认定年度"],
                        "via": "same-name", "source_url": url})
        stat["name_join"] += 1

    path = os.path.join(cc.FILL, prov + "_城市.csv")
    cc.write_rows(path, out, nl)
    if sidecar:
        with open(os.path.join(cc.FILL, "_namejoin_%s.jsonl" % prov), "w", encoding="utf-8") as f:
            for s in sidecar:
                f.write(json.dumps(s, ensure_ascii=False) + "\n")
    cities = sorted({r["城市"] for r in out})
    years = sorted({r["认定年度"] for r in out if r["认定年度"]})
    print("[%s] patch_rows=%d cities=%d years=%s..%s stat=%s"
          % (prov, len(out), len(cities), years[0] if years else "-", years[-1] if years else "-",
             dict(stat)))
    print("   cities:", " ".join(cities))
    return len(out)


if __name__ == "__main__":
    tot = 0
    for p in (sys.argv[1:] or cc.PROVS):
        tot += build(p)
    print("TOTAL", tot)
