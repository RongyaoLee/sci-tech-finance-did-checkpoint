# -*- coding: utf-8 -*-
"""Fetch Footer chunk (holds request instance + endpoint constants) and grep."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

u = "https://kjt.hubei.gov.cn/ywt/static/js/vendor/Footer.CgcxWRQb.js"
t, f = cf.get(u)
print("ok" if t else f, len(t or ""))
if t:
    open(os.path.join(cf.HERE, "_hb_Footer.js"), "w", encoding="utf-8").write(t)
    print("== quoted paths ==")
    for s in sorted(set(re.findall(r"['\"]([^'\"]{3,90})['\"]", t))):
        if "/" in s or "http" in s:
            print("  ", repr(s))
    print("== exports ==")
    m = re.search(r"export\{[^}]{0,600}", t)
    print(m.group(0) if m else "none")
