# -*- coding: utf-8 -*-
"""栏目翻页 -> 标题列表（过滤关键词）。用法: _sp_col.py COLURL KEY [maxpages]"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
from urllib.parse import urljoin, urlparse

col = sys.argv[1]
key = sys.argv[2]
maxp = int(sys.argv[3]) if len(sys.argv) > 3 else 12

sc, d, f = S.H.get(col, timeout=25, tries=2, binary=True)
if sc != 200:
    print("FAIL", sc, col)
    sys.exit(1)
t = d.decode("utf-8", "ignore")
if t.count("\ufffd") > 20:
    t = d.decode("gb18030", "ignore")
base = f or col
m = re.search(r"共\s*(\d+)\s*页", t) or re.search(r"totalpage[\"']?\s*[:=]\s*[\"']?(\d+)", t)
total = int(m.group(1)) if m else maxp
print("pages", total, "col", base)


def links(html, base):
    out = []
    for a in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html, re.S):
        u = a.group(1)
        n = re.sub(r"<[^>]+>", "", a.group(2))
        n = re.sub(r"\s", "", n)
        if len(n) < 6:
            continue
        if u.startswith("/") or not u.startswith("http"):
            u = urljoin(base, u)
        if key in n:
            out.append((n, u))
    return out


rows = []
p = urlparse(base)
dirpart = base.rsplit("/", 1)[0]
seen = set()
for i in range(1, min(total, maxp) + 1):
    u = base if i == 1 else None
    for pat in ("list_%d.shtml" % (i - 1), "index_%d.shtml" % (i - 1),
                "%s-%d.shtml" % (p.path.rstrip("/").split("/")[-2] if False else "", i)):
        pass
    if i > 1:
        cands = ["%s/list_%d.shtml" % (dirpart, i - 1), "%s/index_%d.shtml" % (dirpart, i - 1),
                 "%s/index_%d.html" % (dirpart, i - 1), "%s/list_%d.html" % (dirpart, i - 1)]
        mm = re.search(r"onclick=\"queryArticleByCondition\(this,'([^']+-%d\.shtml)'\)" % i, t)
        if mm:
            cands.insert(0, urljoin(base, mm.group(1)))
        for cu in cands:
            sc2, d2, f2 = S.H.get(cu, timeout=25, tries=1, binary=True)
            if sc2 == 200 and d2 and len(d2) > 3000:
                u = f2 or cu
                tt = d2.decode("utf-8", "ignore")
                if tt.count("\ufffd") > 20:
                    tt = d2.decode("gb18030", "ignore")
                for n, uu in links(tt, f2 or cu):
                    if uu not in seen:
                        seen.add(uu)
                        rows.append((n, uu))
                break
        if u is None:
            continue
    else:
        for n, uu in links(t, base):
            if uu not in seen:
                seen.add(uu)
                rows.append((n, uu))
for n, u in rows:
    print(n[:78], "|", u)
print("total", len(rows))
