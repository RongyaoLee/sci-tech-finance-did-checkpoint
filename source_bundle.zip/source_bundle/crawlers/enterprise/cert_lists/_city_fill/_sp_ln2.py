# -*- coding: utf-8 -*-
"""辽宁 zfxxgk/ptzc 栏目全量 -> 找 认定...高新技术企业 通知"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
from urllib.parse import urljoin

HOST = "https://kjt.ln.gov.cn"
COL = "/kjt/zfxxgk/fdzdgknr/ghxx/ptzc/index.shtml"
sc, d, f = S.H.get(HOST + COL, timeout=25, tries=2, binary=True)
t = d.decode("utf-8", "ignore")
navs = sorted(set(re.findall(r"this,'([^']+-\d+\.shtml)'", t)))
print("navs", navs)
rows = []


def grab_links(html, base):
    for mm in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html, re.S):
        n = re.sub(r"<[^>]+>|\s", "", mm.group(2))
        u = mm.group(1)
        if u.startswith("/"):
            u = urljoin(base, u)
        if len(n) >= 8:
            rows.append((n, u))


grab_links(t, f or HOST + COL)
for nv in navs:
    u = HOST + nv
    sc2, d2, f2 = S.H.get(u, timeout=25, tries=2, binary=True)
    if sc2 == 200 and d2:
        grab_links(d2.decode("utf-8", "ignore"), f2 or u)
seen = set()
for n, u in rows:
    if "高新技术企业" in n and u not in seen:
        seen.add(u)
        print(n[:80], "|", u)
print("total links", len(rows), "hits", len(seen))
