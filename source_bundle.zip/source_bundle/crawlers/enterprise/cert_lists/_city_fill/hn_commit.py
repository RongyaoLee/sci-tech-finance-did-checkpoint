﻿# -*- coding: utf-8 -*-
import os,sys,re,json
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,HERE); sys.path.insert(0,os.path.dirname(HERE))
import fetch_common as F
ROWS=os.path.join(HERE,"rows_湖南.jsonl"); PROG=os.path.join(HERE,"_progress_湖南.log")
SKIP_URLS={"http://ylgxq.changsha.gov.cn/xxgk/fdxxgknr/jsrd/qydt/202111/t20211104_10320699.html"}
seen=set()
if os.path.exists(ROWS):
    for l in open(ROWS,encoding="utf-8"):
        d=json.loads(l); seen.add((d["name"],d.get("cert",""),d["city"]))
def yr(t):
    m=re.search(r"(20\d{2})",t); return m.group(1) if m else ""
def ba(t):
    m=re.search(r"第([一二三四五六七八九十])批",t); return ("第"+m.group(1)+"批") if m else ""
tot=0
for l in open(os.path.join(HERE,"_hn_parsed.jsonl"),encoding="utf-8"):
    d=json.loads(l)
    if d["url"] in SKIP_URLS or not d["names"]: continue
    n=0
    with open(ROWS,"a",encoding="utf-8") as f:
        for r in d["names"]:
            nm=F.clean(r["name"]); cert=(r.get("cert") or "").strip()
            if not F.looks_like_name(nm): continue
            k=(nm,cert,d["city"])
            if k in seen: continue
            seen.add(k)
            f.write(json.dumps({"name":nm,"cert":cert,"city":d["city"],"county":"","year":yr(d["title"]),
                "batch":ba(d["title"]),"source_url":d["url"],"note":d["title"][:50]},ensure_ascii=False)+"\n")
            n+=1
    tot+=n
    with open(PROG,"a",encoding="utf-8") as f:
        f.write("%s\t%d\t%s\t%s\n"%(d["city"],n,d["url"],d["title"][:60]))
    print(d["city"],n,d["url"][:80])
print("TOTAL",tot)
