# -*- coding: utf-8 -*-
"""重试抓取广西 .doc 培育库名单（站点间歇性拒连），落 raw 后解析。"""
import sys, os, re, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
import harvest as H

BASE = "http://kjt.gxzf.gov.cn/xxgk/gxkjgk/gxjsqy/gxgxjsqy/"
P = "广西壮族自治区"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "parts", P + ".jsonl")

JOBS = [
    ("P020210512674266627262.doc", "2021", "培育库第一批"),
    ("P020221215659441721435.doc", "2022", "培育库"),
    ("P020230330587986285315.doc", "2023", "培育库"),
    ("P020250811675887139594.doc", "2024", "培育库"),
    ("W020200323786329738931.doc", "2019", "培育库第一批"),
    ("W020200323786395067401.doc", "2019", "培育库第二批"),
]

tot = 0
for fn, y, b in JOBS:
    u = BASE + fn
    data = None
    for i in range(6):
        for host in ("http://", "https://"):
            uu = host + u.split("://", 1)[1]
            sc, d, f = H.get(uu, timeout=45, tries=1, binary=True)
            if sc == 200 and d and len(d) > 10000:
                data, u = d, uu
                break
        if data:
            break
        time.sleep(2 + i * 3)
    if not data:
        print("FAIL", fn)
        continue
    H.save_raw("gx_py", u, data)
    recs = []
    if data[:4] == b"PK\x03\x04":
        recs = S.extract_from_tables(S.doc_tables(u, data), P, src=u, year=y, batch=b, require_city=True)
    elif data[:4] == b"%PDF":
        recs = S.extract_from_tables(S.doc_tables(u, data), P, src=u, year=y, batch=b, require_city=True)
    else:
        from _sp_doc import doc_pairs
        for name, code, city in doc_pairs(data):
            c = S.norm_city(P, city)
            if c:
                recs.append({"name": name, "cert": code, "city": c, "county": "",
                             "year": y, "batch": b, "src": u})
    n = S.append(OUT, recs)
    tot += n
    print("%-40s %d bytes -> %d rows" % (fn, len(data), n), flush=True)
print("total", tot)
