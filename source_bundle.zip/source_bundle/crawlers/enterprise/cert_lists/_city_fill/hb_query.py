# -*- coding: utf-8 -*-
"""Test the Hubei ywt /portal/search/commonSearch API for 高企查询 (flid=008001)."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

BASE = "https://kjt.hubei.gov.cn/ywt"

def post(path, payload):
    u = BASE + path
    r = cf.S.post(u, json=payload, timeout=30,
                  headers={"Content-Type": "application/json;charset=utf-8",
                           "Referer": "https://kjt.hubei.gov.cn/ywt/",
                           "Origin": "https://kjt.hubei.gov.cn"})
    return r.status_code, r.text[:1200]


for body in ({"cpage": 1, "pageSize": 5, "flid": "008001"},
             {"cpage": 1, "pageSize": 5, "flid": "008001", "name": "", "unit": ""},
             {"cpage": 1, "pageSize": 5, "flid": "008001", "ssqd_name": ""}):
    code, txt = post("/portal/search/commonSearch", body)
    print("BODY", body, "->", code)
    print(txt[:900])
    print("-" * 60)
