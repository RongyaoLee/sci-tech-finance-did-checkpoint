# -*- coding: utf-8 -*-
import sys, re, os
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H
from urllib.parse import urljoin

for u in ["http://www.innocom.gov.cn/gqrdw/index.shtml",
          "http://www.innocom.gov.cn/gqrdw/c1014xx/list_gsgg_l2.shtml",
          "http://www.innocom.gov.cn/"]:
    sc, html, final = H.get(u, timeout=25, tries=2)
    print("===", u, "->", sc, len(html or ""), final)
    if sc != 200:
        continue
    H.save_raw("nb_probe1", u, html.encode("utf-8", "ignore"))
    for href, txt in H.img_links(html, final):
        if any(k in txt for k in ("宁波", "青岛", "深圳", "厦门", "大连", "计划单列", "认定机构")):
            print("   ", txt[:60], "|", href)
