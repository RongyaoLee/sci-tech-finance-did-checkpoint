# -*- coding: utf-8 -*-
import sys, os, glob, re
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

p = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw\nb_doc\106f137f_4b9f4ddbe56b4afdb281fa11981573e6.pdf"
txt = H.doc_text(p, open(p, "rb").read())
lines = [l.strip() for l in txt.split("\n")]
print("lines", len(lines))
print("\n".join("%3d|%s" % (i, l) for i, l in enumerate(lines[:30])))
