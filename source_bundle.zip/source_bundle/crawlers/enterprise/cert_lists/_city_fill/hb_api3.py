# -*- coding: utf-8 -*-
"""Fetch the app-core chunk(s) of the Hubei ywt SPA and grep for endpoints."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

CAND = ["index.BK_DE7OD.js", "url.BGdZ929U.js", "Z.js", "SearchResult.qNxIaldB.js"]
for name in CAND:
    for base in ("https://kjt.hubei.gov.cn/ywt/static/js/vendor/", "https://kjt.hubei.gov.cn/ywt/static/js/"):
        u = base + name
        t, f = cf.get(u)
        if t:
            print("== OK", u, len(t))
            open(os.path.join(cf.HERE, "_hb_" + name.replace(".", "_")), "w", encoding="utf-8").write(t)
            hits = sorted(set(re.findall(r"['\"]([^'\"]{4,80}(?:/bm|/api|query|flid|portal/list)[^'\"]{0,40})['\"]", t)))
            print("   hits:", hits[:30])
            for kw in ("baseURL", "flid=", "cpage", "pageSize"):
                m = re.search(re.escape(kw), t)
                if m:
                    print("   [%s]" % kw, repr(t[max(0, m.start() - 150):m.start() + 150]))
            break
