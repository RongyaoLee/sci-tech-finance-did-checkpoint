# -*- coding: utf-8 -*-
"""河北：现有带城市行的来源URL分布，找可复制的模式。"""
import io, sys, os, csv, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
ROOT = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists'
rows = list(csv.DictReader(open(os.path.join(ROOT, '河北省.csv'), encoding='utf-8-sig', newline='')))
c = collections.Counter((x['来源URL'], x['城市'], x['认定年度']) for x in rows if (x['城市'] or '').strip())
for (u, city, y), n in c.most_common(20):
    print(n, y, city, u[:110])
print('---- 河南同型 ----')
rows = list(csv.DictReader(open(os.path.join(ROOT, '河南省.csv'), encoding='utf-8-sig', newline='')))
c = collections.Counter((x['来源URL'], x['认定年度']) for x in rows if (x['城市'] or '').strip())
for (u, y), n in c.most_common(12):
    print(n, y, u[:110])
