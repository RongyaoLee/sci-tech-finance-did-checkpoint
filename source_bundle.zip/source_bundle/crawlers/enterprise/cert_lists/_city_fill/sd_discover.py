# -*- coding: utf-8 -*-
"""Bing 检索发现各市高企名单 -> 附件/正文 -> parts
用法: python sd_discover.py 潍坊 淄博 ...
"""
import os, re, sys, json, time, html
from urllib.parse import urljoin, urlparse, quote
import requests, urllib3
urllib3.disable_warnings()
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_lib as S, sd_run as R, sd_store as ST

BASE = S.BASE
LOG = []


def log(*a):
    m = " ".join(str(x) for x in a)
    LOG.append(m)
    print(m, flush=True)


DOMAINS = {
    "济南": ["jnsti.jinan.gov.cn", "kjj.jinan.gov.cn", "jinan.gov.cn"],
    "淄博": ["zibo.gov.cn", "kjj.zibo.gov.cn"],
    "枣庄": ["zaozhuang.gov.cn", "zzst.zaozhuang.gov.cn"],
    "东营": ["dongying.gov.cn", "dysti.dongying.gov.cn"],
    "烟台": ["kjj.yantai.gov.cn", "yantai.gov.cn"],
    "潍坊": ["kjj.weifang.gov.cn", "weifang.gov.cn"],
    "济宁": ["jnkj.jining.gov.cn", "jining.gov.cn"],
    "泰安": ["kjj.taian.gov.cn", "taian.gov.cn"],
    "威海": ["kjj.weihai.gov.cn", "weihai.gov.cn", "whcxcy.com"],
    "日照": ["stc.rizhao.gov.cn", "rizhao.gov.cn"],
    "临沂": ["kjj.linyi.gov.cn", "linyi.gov.cn"],
    "德州": ["kjj.dezhou.gov.cn", "dezhou.gov.cn"],
    "聊城": ["kjj.liaocheng.gov.cn", "liaocheng.gov.cn"],
    "滨州": ["kj.binzhou.gov.cn", "binzhou.gov.cn"],
    "菏泽": ["kjj.heze.gov.cn", "heze.gov.cn"],
}


def bing(q, pages=2):
    out = []
    for p in range(pages):
        u = "https://cn.bing.com/search?q=%s&first=%d" % (quote(q), 1 + 10 * p)
        try:
            r = requests.get(u, headers={"User-Agent": R.UA, "Accept-Language": "zh-CN,zh;q=0.9"},
                             timeout=25, verify=False)
        except Exception:
            continue
        t = r.text
        blocks = re.findall(r'<li class="b_algo".*?</li>', t, re.S)
        if not blocks:
            blocks = re.findall(r'<div class="b_algo".*?</div>\s*</div>', t, re.S)
        for b in blocks:
            m = re.search(r'href="(http[^"]+)"', b)
            if not m:
                continue
            href = html.unescape(m.group(1))
            tt = re.sub(r"<[^>]+>", "", b)
            tt = re.sub(r"\s+", " ", html.unescape(tt)).strip()[:60]
            if "bing.com" in href or "microsoft" in href:
                continue
            out.append((tt, href))
        time.sleep(0.6)
    return out


def discover(city):
    kws = []
    for y in (2021, 2022, 2023, 2024, 2025):
        kws.append("%d年%s市高新技术企业名单" % (y, city))
    kws.append("%s市高新技术企业名单 所属区市" % city)
    cands = []
    for q in kws:
        for t, u in bing(q, 2):
            if not t:
                continue
            if not re.search(r"高新", t):
                continue
            cands.append((t, u))
    # 去重
    seen, res = set(), []
    for t, u in cands:
        k = re.sub(r"[?#].*", "", u)
        if k in seen:
            continue
        seen.add(k)
        res.append((t, u))
    log("  %s cands=%d" % (city, len(res)))
    return res


def score(city, t, u):
    s = 0
    if re.search(r"名单", t):
        s += 3
    if re.search(r"(20\d\d)", t):
        s += 1
    host = urlparse(u).netloc
    for d in DOMAINS.get(city, []):
        if host.endswith(d):
            s += 3
            break
    if R.DOC.search(u):
        s += 2
    return s


def main(cities):
    for city in cities:
        log("== %s" % city)
        cands = discover(city)
        cands.sort(key=lambda x: -score(city, *x))
        n = 0
        for t, u in cands[:24]:
            if score(city, t, u) <= 0:
                continue
            log("  try(%d) %s %s" % (score(city, t, u), t[:40], u[:90]))
            try:
                if R.DOC.search(u):
                    data, fin = R.f(u, binary=True, timeout=90)
                    if data and (data[:5] == b"%PDF-" or data[:2] == b"PK" or data[:4] == b"\xd0\xcf\x11\xe0"):
                        import sd_city_parser as P
                        rows = P.rows_from_doc(fin or u, data, city + "市")
                        rows = [(a, b, d) for a, b, c, d in rows if (c == city or not c)]
                        if rows:
                            y = re.search(r"(20\d\d)", t)
                            add = ST.append_rows(city, rows, fin or u, y.group(1) if y else "", "")
                            n += add
                            log("    doc +%d/%d" % (add, len(rows)))
                else:
                    n += R.grab_article(city, t, u)
            except Exception as e:
                log("    ERR %r" % (e,))
        log("TOTAL %s=%d" % (city, n))


if __name__ == "__main__":
    main(sys.argv[1:] or list(DOMAINS))
