# -*- coding: utf-8 -*-
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

cands = [
    'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/index.html',
    'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/index_1.html',
    'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/index.html',
]
for u in cands:
    st, txt, fu = H.get(u, timeout=30)
    print('==', u, '->', st, len(txt or ''))
    if st != 200:
        continue
    links = H.img_links(txt, fu)
    gq = [(a, b) for a, b in links if '高新' in b or '高企' in b]
    print('  total links', len(links), 'gaoxin', len(gq))
    for a, b in gq[:15]:
        print('   ', b[:80], '|', a)
    # also show arbitrary 10 links to learn id pattern
    for a, b in links[:8]:
        print('   ?', b[:60], '|', a)
