# -*- coding: utf-8 -*-
"""Shared fetch/parse helpers for the city backfill (陕西/湖北/湖南).

Design notes:
- http first, https fallback (proxy often breaks TLS); UA + 30s timeout; <=2 req/s.
- cache every response under _city_fill/_cache so re-runs cost nothing.
"""
import os, re, time, hashlib, json, urllib.parse

import requests
from bs4 import BeautifulSoup
import urllib3

urllib3.disable_warnings()

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "_cache")
os.makedirs(CACHE, exist_ok=True)

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
H = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9",
     "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}

S = requests.Session()
S.headers.update(H)
S.verify = False

_LAST = [0.0]


def _pace():
    dt = time.time() - _LAST[0]
    if dt < 0.5:
        time.sleep(0.5 - dt)
    _LAST[0] = time.time()


def _key(url, suff):
    return hashlib.md5(url.encode("utf-8")).hexdigest()[:16] + suff


def get(url, binary=False, tries=2, use_cache=True, timeout=30):
    """Return (content, final_url) or (None, err)."""
    ext = ".bin" if binary else ".html"
    cp = os.path.join(CACHE, _key(url, ext))
    meta = cp + ".json"
    if use_cache and os.path.exists(cp) and os.path.exists(meta):
        try:
            m = json.load(open(meta, encoding="utf-8"))
            data = open(cp, "rb").read()
            return (data if binary else data.decode("utf-8", "replace")), m["final"]
        except Exception:
            pass
    urls = [url]
    if url.startswith("https://"):
        urls.append("http://" + url[8:])
    elif url.startswith("http://"):
        urls.append("https://" + url[7:])
    last = "?"
    for u in urls:
        for _ in range(tries):
            _pace()
            try:
                r = S.get(u, timeout=timeout)
                if r.status_code == 200 and len(r.content) > 120:
                    if binary:
                        data = r.content
                    else:
                        raw = r.content
                        enc = None
                        m = re.search(rb'charset=["\']?([\w\-]+)', raw[:3000], re.I)
                        if m:
                            enc = m.group(1).decode("ascii", "ignore")
                        if not enc:
                            enc = r.apparent_encoding or "utf-8"
                        try:
                            data = raw.decode(enc, "replace")
                        except LookupError:
                            data = raw.decode("utf-8", "replace")
                    open(cp, "wb").write(data if binary else data.encode("utf-8"))
                    json.dump({"url": url, "final": r.url}, open(meta, "w", encoding="utf-8"))
                    return data, r.url
                last = "HTTP %s" % r.status_code
            except Exception as e:
                last = type(e).__name__ + ":" + str(e)[:70]
            time.sleep(0.6)
    return None, last


def soup_of(html):
    return BeautifulSoup(html, "lxml")


ATT_RE = re.compile(r"\.(pdf|xlsx?|docx?|wps|et|zip|rar)(\?|$)", re.I)


def attachments(page_url, html):
    """All attachment links on a page as [(text, abs_url)]."""
    soup = soup_of(html)
    out = []
    for a in soup.find_all("a", href=True):
        h = a["href"].strip()
        if not ATT_RE.search(h):
            continue
        full = urllib.parse.urljoin(page_url, h)
        out.append((a.get_text(" ", strip=True), full))
    if not out:
        for m in re.findall(r"""["']([^"']+\.(?:pdf|xlsx?|docx?|wps|et))["']""", html, re.I):
            out.append(("", urllib.parse.urljoin(page_url, m)))
    seen, res = set(), []
    for t, u in out:
        if u in seen:
            continue
        seen.add(u)
        res.append((t, u))
    return res


def download(url, tag):
    """Cache a binary attachment; returns local path or None."""
    ext = os.path.splitext(urllib.parse.urlparse(url).path)[1].lower()
    if ext not in (".pdf", ".xlsx", ".xls", ".doc", ".docx", ".wps", ".et"):
        return None
    d = os.path.join(CACHE, "att")
    os.makedirs(d, exist_ok=True)
    fn = re.sub(r"[^\w\.\-]", "_", tag)[:70] + "_" + _key(url, "") + ext
    p = os.path.join(d, fn)
    if os.path.exists(p) and os.path.getsize(p) > 300:
        return p
    data, _ = get(url, binary=True)
    if not data or len(data) < 200:
        return None
    open(p, "wb").write(data)
    return p
