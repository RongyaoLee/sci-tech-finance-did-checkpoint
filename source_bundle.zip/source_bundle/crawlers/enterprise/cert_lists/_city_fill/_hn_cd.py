﻿# -*- coding: utf-8 -*-
import os,sys,re,urllib.parse
sys.path.insert(0,os.getcwd())
import cf
u="https://kjj.changde.gov.cn/kjdt/tzgg/content_907153"
h,f=cf.get(u)
out=open("_hn_cd.txt","w",encoding="utf-8")
if not h: out.write("FAIL")
else:
    out.write("LEN %d FINAL %s\n"%(len(h),f))
    for m in re.finditer(r'href=["\']([^"\']+)["\']',h,re.I):
        uu=m.group(1)
        if re.search(r"\.(xls|xlsx|doc|docx|pdf|wps|et)$",uu,re.I) or "attach" in uu.lower() or "files/" in uu.lower():
            out.write("LINK %s\n"%urllib.parse.urljoin(f,uu))
    body=re.sub(r"<(script|style)[^>]*>.*?</\1>","",h,flags=re.S|re.I)
    txt=re.sub(r"<[^>]+>","\n",body).replace("&nbsp;"," ")
    ls=[re.sub(r"\s+","",x) for x in txt.split("\n")]
    ls=[x for x in ls if x]
    out.write("---TEXT---\n")
    out.write("\n".join(ls[:120]))
out.close(); print("ok")
