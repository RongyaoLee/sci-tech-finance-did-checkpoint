# -*- coding: utf-8 -*-
"""v2：用 nb_names.extract 稳健抽名称，全部附件重跑，含 2020 补充备案扫描件人工转写记录。"""
import sys, json, re, os
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H
import nb_docparse
import nb_names
from collections import Counter

CF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill"


def year_batch(title):
    ys = re.findall(r"(20\d{2})", title)
    year = int(ys[0]) if ys else None
    if "第二批补充备案" in title:
        batch = "第二批补充备案"
    elif "第一批补充备案" in title:
        batch = "第一批补充备案"
    elif "补充备案" in title:
        batch = "补充备案"
    elif "第二批" in title:
        batch = "第二批"
    elif "第一批" in title:
        batch = "第一批"
    elif "复审" in title:
        batch = "复审"
    else:
        batch = "备案"
    return year, batch


# 人工转写：扫描件《关于2020年高新技术企业补充备案的复函》(国科火字〔2021〕69号) 附件"宁波市2020年高新技术企业补充备案名单"
# 该 pdf 为纯图片（2 页，0 文本层），用 fitz 渲染 200dpi 后人工核对：1 行 = 宁波璞锐科技有限公司 / GR202033101668 / 发证 2020-12-01
_log2 = json.load(open(os.path.join(CF, "_nb_log2.json"), encoding="utf-8"))
_src2020 = [l["url"] for l in _log2 if "2020年高新技术企业补充备案的复函" in l.get("title", "")][0]
MANUAL = [{
    "cert": "GR202033101668", "name": "宁波璞锐科技有限公司",
    "city": "宁波市", "county": "", "year": 2020, "batch": "补充备案", "src": _src2020,
}]


def main():
    arts = json.load(open(os.path.join(CF, "_nb_cols2.json"), encoding="utf-8"))
    rows, log = [], []
    for col in ("c101455", "c101419"):
        for a in arts.get(col, []):
            u, t = a["u"], a["t"]
            y, b = year_batch(t)
            if not y or y < 2016 or y > 2025 or "更名" in t:
                continue
            sc, html, final = H.get(u, timeout=25, tries=2)
            if sc != 200:
                log.append({"title": t, "err": "page %s" % sc})
                continue
            for href, tt in H.img_links(html, final):
                low = href.lower().split("?")[0]
                if not any(low.endswith(e) for e in (".pdf", ".doc", ".docx", ".xls", ".xlsx")):
                    continue
                sc2, data, f2 = H.get(href, binary=True, timeout=60)
                if sc2 != 200 or not data:
                    log.append({"title": t, "doc": tt, "err": "dl %s" % sc2})
                    continue
                p = H.save_raw("nb_doc", href, data)
                if low.endswith(".doc") or data[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
                    try:
                        txt = nb_docparse.doc_text(p)
                    except Exception:
                        txt = ""
                else:
                    txt = H.doc_text(href, data)
                pairs = nb_names.extract(txt)
                for c, nm in pairs:
                    rows.append({"cert": c, "name": nm, "city": "宁波市", "county": "",
                                 "src": href, "year": int(c[2:6]), "batch": b})
                log.append({"title": t, "doc": tt, "size": len(data), "chars": len(txt),
                            "pairs": len(pairs), "named": sum(1 for _, n in pairs if n), "url": href})
    rows.extend(MANUAL)
    best = {}
    for r in rows:
        c = r["cert"]
        if c not in best or (not best[c]["name"] and r["name"]) or \
                (best[c]["name"] and r["name"] and len(r["name"]) > len(best[c]["name"])):
            best[c] = r
    recs = sorted(best.values(), key=lambda r: (r["year"], r["cert"]))
    out = os.path.join(CF, "parts", "浙江省_宁波市.jsonl")
    with open(out, "w", encoding="utf-8") as f:
        for r in recs:
            f.write(json.dumps({k: r[k] for k in ("cert", "name", "city", "county", "src", "year", "batch")},
                               ensure_ascii=False) + "\n")
    json.dump(log, open(os.path.join(CF, "_nb_log3.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("TOTAL", len(recs), "| empty", sum(1 for r in recs if not r["name"]),
          "| uniq", len({r["cert"] for r in recs}))
    print("year", sorted(Counter(r["year"] for r in recs).items()))
    print("batch", sorted(Counter((r["year"], r["batch"]) for r in recs).items()))
    bad = [r for r in recs if "GR" in r["name"] or len(r["name"]) > 34]
    print("suspect", len(bad), [r["name"] for r in bad[:5]])
    for l in log:
        if l.get("pairs") is not None and l["named"] < l["pairs"]:
            print("MISS", l["named"], "/", l["pairs"], "|", l["title"][:40], "|", (l.get("doc") or "")[:30])


if __name__ == "__main__":
    main()
