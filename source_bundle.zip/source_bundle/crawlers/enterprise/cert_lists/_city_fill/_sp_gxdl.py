# -*- coding: utf-8 -*-
"""广西 .doc 名单：固定 UA 下载到 raw/gx_py（避免 UA 轮换触发风控），随后离线解析。"""
import sys, os, re, time, urllib.request, ssl, json

RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), "raw", "gx_py")
os.makedirs(RAW, exist_ok=True)
BASE = "http://kjt.gxzf.gov.cn/xxgk/gxkjgk/gxjsqy/gxgxjsqy/"
FILES = [
    "P020210512674266627262.doc",
    "P020221215659441721435.doc",
    "P020230330587986285315.doc",
    "P020250811675887139594.doc",
    "W020200323786329738931.doc",
    "W020200323786395067401.doc",
]
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE


def fetch(u, timeout=30):
    req = urllib.request.Request(u, headers={
        "User-Agent": UA,
        "Accept": "*/*",
        "Referer": BASE,
    })
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.status, r.read()


for fn in FILES:
    out = os.path.join(RAW, fn)
    if os.path.exists(out) and os.path.getsize(out) > 10000:
        print("cached", fn, os.path.getsize(out), flush=True)
        continue
    for host in ("http://", "https://"):
        u = host + (BASE + fn).split("://", 1)[1]
        try:
            sc, d = fetch(u)
            if sc == 200 and len(d) > 10000:
                open(out, "wb").write(d)
                print("ok", fn, len(d), flush=True)
                break
            print("bad", sc, len(d), u, flush=True)
        except Exception as e:
            print("err", fn, host, type(e).__name__, str(e)[:80], flush=True)
        time.sleep(2)
    time.sleep(3)
print("done")
