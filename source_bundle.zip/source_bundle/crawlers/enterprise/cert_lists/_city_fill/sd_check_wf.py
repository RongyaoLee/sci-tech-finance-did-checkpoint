# -*- coding: utf-8 -*-
"""Inspect Weifang-hosted docs: do they carry a 市/区县 column?"""
import os, sys, io, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_baidu as B
import sd_city_parser as P

DOCS = [
    "http://kjj.weifang.gov.cn/xxgk/upload-service/162/55333/WY2022474096813674496.xls",
    "http://kjj.weifang.gov.cn/xxgk/upload-service/162/55333/WY2008808162433568768.pdf",
    "http://kjj.weifang.gov.cn/xxgk/upload-service/162/55333/WY2008808164178399232.pdf",
]
out = []
for u in DOCS:
    st, data, _ = B.f(u, binary=True, timeout=60)
    rec = {"url": u, "status": st, "len": len(data or b"")}
    if st == 200 and data:
        base = u.split("/")[-1]
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "raw_so", base)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, "wb").write(data)
        rec["file"] = p
        try:
            low = u.lower()
            if data[:4] == b"%PDF":
                tabs = P.pdf_tables(data)
            elif data[:4] == b"\xd0\xcf\x11\xe0":
                import xlrd
                bk = xlrd.open_workbook(file_contents=data)
                tabs = [[[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(min(sh.nrows, 2600))] for sh in bk.sheets()]
            else:
                tabs = P.xlsx_tables(data)
            rec["n_tables"] = len(tabs)
            rec["sizes"] = [len(t) for t in tabs][:5]
            rec["head"] = [[P.norm_cell(c) for c in row] for row in (tabs[0][:6] if tabs else [])]
            norows = P.rows_from_tables(tabs, "")
            rec["rows_nocity"] = len(norows)
            rec["rows_withcity"] = sum(1 for r in norows if r[2])
            rec["cities"] = sorted({r[2] for r in norows if r[2]})[:20]
        except Exception as e:
            rec["err"] = repr(e)[:200]
    out.append(rec)
    print(u.split("/")[-1], st, rec.get("rows_withcity"), rec.get("cities"), flush=True)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_wf_docs.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
