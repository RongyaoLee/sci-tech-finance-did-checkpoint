# -*- coding: utf-8 -*-
import requests, urllib3, re
urllib3.disable_warnings()
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})
for u in ['https://kjt.shaanxi.gov.cn/', 'https://kjt.shaanxi.gov.cn/kjdt/ztzl/lszt/gqrd/index.html']:
    r = s.get(u, timeout=40, verify=False)
    r.encoding = r.apparent_encoding or 'utf-8'
    t = r.text
    print('=====', u, r.status_code, len(t))
    for m in re.finditer(r'<(?:form|input|div|a)[^>]*(?:search|sousuo|Search)[^>]*>', t):
        print('   ', m.group(0)[:180])
    for m in re.finditer(r'href=[\'"]([^\'"]*(?:search|sousuo)[^\'"]*)[\'"]', t, re.I):
        print('   link', m.group(1)[:150])
    # nav columns of 专题
    for m in re.finditer(r'href=[\'"]([^\'"]*gqrd[^\'"]*)[\'"]', t):
        print('   gqrd', m.group(1)[:120])
