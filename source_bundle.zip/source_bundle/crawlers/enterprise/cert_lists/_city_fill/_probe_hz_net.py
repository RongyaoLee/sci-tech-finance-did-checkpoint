﻿import sys, json
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H
hosts = ["https://www.hangzhou.gov.cn/","http://www.hangzhou.gov.cn/",
         "https://kjj.hangzhou.gov.cn/","http://kjj.hangzhou.gov.cn/",
         "https://stbrain.hangzhou.gov.cn/","http://stbrain.hangzhou.gov.cn/",
         "https://kjt.zj.gov.cn/","http://kjt.zj.gov.cn/"]
for u in hosts:
    try:
        st, c, fu = H.get(u, timeout=20, tries=1)
        print(u, "->", st, len(c) if c else 0, fu)
    except Exception as e:
        print(u, "ERR", type(e).__name__, str(e)[:120])
