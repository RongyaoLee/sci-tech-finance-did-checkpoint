﻿# -*- coding: utf-8 -*-
import os,sys,re,json,time
sys.path.insert(0,os.getcwd())
import cf
U="http://searching.hunan.gov.cn/hunan/001000000/all"
QS=["高新技术企业 认定 名单","高新技术企业 公示 名单","高企 认定 名单",
    "高新技术企业 奖补 公示","高新技术企业 认定 推荐 名单","高新技术企业 备案 名单",
    "高新技术企业 认定 通过 名单","高新技术企业 名单 通知","高企 名单 公示"]
out={}
for q in QS:
    for p in range(1,7):
        try:
            r=cf.S.get(U,params={"q":q,"iszq":"1","p":p},timeout=30); r.encoding="utf-8"
        except Exception as e:
            print("ERR",q,p,type(e).__name__); break
        h=r.text
        items=re.findall(r'<a[^>]+href="(https?://[^"]+\.(?:html|shtml|htm|do|jsp)[^"]*)"[^>]*>(.*?)</a>',h,re.S)
        n=0
        for url,t in items:
            t=re.sub(r"<[^>]+>","",t); t=re.sub(r"\s+"," ",t).strip()
            if not t or len(t)<6: continue
            if "searching.hunan.gov.cn" in url: continue
            if url in out: continue
            out[url]={"t":t,"q":q,"p":p}; n+=1
        print(q,p,"new",n,"total",len(out),flush=True)
        if n==0 and p>1: break
json.dump(out,open("_hn_hits.json","w",encoding="utf-8"),ensure_ascii=False)
print("SAVED",len(out))
