# -*- coding: utf-8 -*-
import sys, os, re, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

out = {}
h, u = cf.get("https://kjt.shaanxi.gov.cn/")
out["home_len"] = len(h) if h else h
out["final"] = u
if h:
    s = cf.soup_of(h)
    links = []
    for a in s.find_all("a", href=True):
        tx = a.get_text(" ", strip=True)
        if any(k in tx for k in ["高新", "查询", "认定", "服务"]):
            links.append((tx[:40], a["href"][:200]))
    out["links"] = links[:60]
json.dump(out, open(os.path.join(HERE, "_sx_probe1.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("done", out["home_len"])
