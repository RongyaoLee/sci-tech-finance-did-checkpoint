﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
import cf
for u in ["http://www.cshtz.gov.cn/","https://www.cshtz.gov.cn/","http://cshtz.changsha.gov.cn/"]:
    h,fin=cf.get(u)
    print(u,"->",fin, len(h) if h else None)
    if h:
        t=re.search(r"<title>(.*?)</title>",h,re.S); print("  title",t.group(1).strip()[:50] if t else "?")
        open("_cshtz.html","w",encoding="utf-8").write(h)
        break
