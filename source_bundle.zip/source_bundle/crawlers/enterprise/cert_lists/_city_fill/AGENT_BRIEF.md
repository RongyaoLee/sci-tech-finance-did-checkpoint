# 子智能体作业简报：高企名单「地级市」字段补齐（浙江 / 山东）

> 你是被派出的子智能体。**先读本文件全文**，再动手。本文件包含已验证的工具、已验证的死路、输出契约。

## 0. 硬约束

- 工作目录：`C:\Users\rongy\Documents\Codex\2026-11-07\xie\work`
- 解释器：`C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\.venv\Scripts\python.exe`
  （这是重定向器，一个逻辑进程会显示两个进程；杀进程按 PID 且排除 `$PID`，模式串要拼接构造，否则会误杀工具自己的 shell）
- **禁止**修改：`work\hn_enterprise.sqlite`、`work\cert_lists\*.csv`（主表与补丁表都只能由父 agent 的回填脚本动）、其它 agent 的脚本。
- 你**只能**写：`work\cert_lists\_city_fill\parts\<省>_<市>.jsonl`、`work\cert_lists\_city_fill\raw\<任意>`、你自己新建的脚本（放 `_city_fill\` 下，文件名带 `_<市>` 后缀避免撞车）。
- 网络：http 优先（https 常被本机代理拦，SSLError 就换 http 重试）；带 UA；单站 ≤2 req/s；超时 30s。
- 语言：中文回报。

## 1. 任务本质

主表 `work\cert_lists\浙江省.csv`（83,686 行）、`山东省.csv`（41,495 行），表头
`企业名称,证书编号,城市,区县,认定年度,批次,来源URL`，城市/区县全空。
证书编号 = `GR` + 年度4位 + 省码2位 + 顺序号6位。

**严禁**用证书编号第 7–10 位反推城市（已实测证伪）。
城市只能来自**官方公布件自带的地区列**，或**官方公布件本身的发布主体**（例：宁波市认定机构在 innocom 公示的全部企业，城市即宁波市）。

## 2. 已验证的死路（别浪费时间去试）

1. **省级/国家级名单附件只有 3 列：序号 / 企业名称 / 证书编号，没有城市列**。已实测这些都不带城市：
   - 山东科技厅 2021 / 2023 / 2025、2024 一批二批（`_raw\sd2024_*.pdf`、`kjt_sd_2021_*.pdf`）
   - 浙江 2021 一批、浙江 2019 公示
   - innocom 各省公告（3 列）
   → 只有**计划单列市**（宁波、青岛、深圳、厦门、大连）在 innocom 有独立栏目，其全部证书号即该市企业，可直接用。
2. 省级栏目翻页不按 `index_N.html` 走（`kjt.zj.gov.cn/col/col1229225203`、`kjt.shandong.gov.cn/col/col13360` 的 `index_1.html` 都是 status=0）。
3. **百度被图形验证码拦；搜狗已上 anti-captcha**（返回 3.8KB 拦截页）。本地 `requests` 抓 Bing 只能拿到泛结果，`site:` 无效。
   → **必须用 `web_search` 工具（Firecrawl 后端，可用！）** 做检索，再用本地 requests 抓具体页面/附件。
4. 宁波「高新技术企业查询」`kjj.ningbo.gov.cn/col/col1229589555/index.html` 只是跳转页，落到 `stbrain.kjj.ningbo.gov.cn` 的 JS 应用。
5. 浙江科技大脑名录清单 `https://stbrain.kjt.zj.gov.cn/CarrierList.aspx?Code=HT` 有 `序号/名称/**所在地**/地址/联系人/电话` 六列，但**只显示 20 行、无翻页、无 postback**；页内 `名单目录` 指向 `/CSV/HT.csv` → **404**（https 404 / http 403）。不要指望它批量导出，但 20 行可抄（杭州市 17 条等），价值低。
6. 湖州这类站点（`kjj.huzhou.gov.cn`）列表是 API 渲染：`/api-gateway/jpaas-publish-server/front/page/build/unit?parseType=bulidstatic&webId=..&tplSetId=..&pageType=column&tagId=最新信息&editType=null&pageId=..`（GET 返回 JSON 里 `data.html` 即列表 HTML）。**但 `currentPage/pageNo/pageNum/page/pageIndex` 参数全部被忽略**，只能拿到第一页（约 40 条最新）。价值有限。

## 3. 已验证可用的工具（直接 import，别重写）

`sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")`

- `harvest.py`
  - `H.get(url, timeout=30, tries=3, binary=False) -> (status, content, final_url)`：UA 轮换 + 每站限速 0.55s + http/https 自动互换。
  - `H.img_links(html, base) -> [(abs_url, anchor_text)]`
  - `H.doc_links(items)`：按扩展名（pdf/xls/xlsx/doc/docx/zip/rar/et/wps）过滤
  - `H.certs_in_text(text) -> set("GR############")`，正则 `GR\s?(\d{4})\s?(\d{2})\s?(\d{6})`
  - `H.doc_text(url, data) -> text`：pdf(fitz) / docx(python-docx) / doc(olefile UTF-16LE+GB18030 粗糙解码) / xlsx(openpyxl) / xls(xlrd)
  - `H.save_raw(tag, url, data) -> path`（落 `_city_fill\raw\<tag>\`）
  - `H.fetch_certs(url, tag) -> (cert_set, path, note)`
- `jcms.py`：`list_articles(index_url, max_pages)`（针对真的服务端渲染的 `/col/col../art/YYYY/art_hash.html` 列表有效）、`docs_of(article_url)`（能抽 `downfile.jsp?classid=0&filename=..pdf`、`/attach/0/..pdf`、`/cms_files/..`）、`grab(url, tag)`
- `search.py`：本地 Bing/搜狗封装（**已知效果差，优先用 `web_search` 工具**）
- `colfind.py <homepage...>`：打印首页里「通知公告/政务公开/公示」类栏目链接

## 4. 高效套路（按优先级）

**套路 A：省级附件里的「带地市列」名单**（成本最低）
- 山东科技厅的「取消高新技术企业资格名单」「更名名单」附件**带 `地市` 列**，已确认两个：
  - `http://kjt.shandong.gov.cn/attach/0/da7db68431974c4b94ead4d058b98604.pdf`（61 家，列：企业名称/高企证书编号/地市/取消起始年份）
  - `http://kjt.shandong.gov.cn/attach/0/1776752ffe7c47c5b76c1ec8b98b94dc.pdf`（471 家，同列）
  - 还有 `kjt.shandong.gov.cn/module/download/downfile.jsp?classid=0&filename=c99c95ed67834a2daf1765c71f0f9c66.pdf`（取消资格名单，含「济南市」「潍坊市」）
- 搜索关键词：`取消高新技术企业资格 名单 地市 附件`、`更名高新技术企业 名单 地市`

**套路 B：市科技局/市政府门户的「XX市高新技术企业名单」公布件**
- 用 `web_search` 检索：`<市名> 高新技术企业名单 附件`、`<市名> 高新技术企业认定 奖励 公示 名单`、`<市名> 科技局 关于公布 高新技术企业名单 通知`
- 命中后：本地 `requests` 抓页面 → 找附件（`.pdf/.xlsx/.xls/.doc`，或 `downfile.jsp`/`/attach/` 链接）→ `H.doc_text` 取文本 → `H.certs_in_text` 抽证书号
- **城市归属判定**：发布主体是 XX市 科技局/市政府 ⇒ 该附件里所有证书号城市 = XX市。附件里若有「区县/所属区县/所在地」列，顺便填 `county`。
- 若附件只有企业名称没有证书号：也收，`cert` 留空、填 `name`，记 `src`。

**套路 C：计划单列市（宁波）走 innocom 独立栏目**
- `http://www.innocom.gov.cn/gqrdw/c1014xx/list_gsgg_l2.shtml` 这类栏目，找「宁波市认定机构」的公示/公告，附件 3 列也够——因为**整个栏目就是宁波市**。
- 浙江文件里 33 省码内宁波企业的证书号会全部命中。

**套路 D：市政务公开平台的「建议提案答复/年度报告」里附的高企名单**（兜底，命中率低）

## 5. 输出契约（严格）

文件：`_city_fill\parts\<省>_<市>.jsonl`（UTF-8，一行一个 JSON，**追加写**，不要重复写同一 cert）

```json
{"cert":"GR202537000001","name":"山东蓝色时光新材料有限公司","city":"潍坊市","county":"","src":"http://...","year":2025,"batch":"第一批"}
```

- `cert`：14 位 `GR` + 12 数字；拿不到就 `""`
- `name`：官方件里的企业全名；拿不到就 `""`（但 cert 与 name 至少要有一个）
- `city`：必须写成 `XX市`（如 `潍坊市`、`杭州市`）
- `county`：有就填（如 `诸暨市`、`余杭区`），没有留 `""`
- `src`：**能直接打开的官方页面或附件 URL**（不是搜索结果页）
- 去重键：`cert`（cert 为空时用 `name+city`）

写完自检：`python -c` 统计行数、去重后行数、城市分布，确认 JSON 可解析。

## 6. 回报格式（发给派你的 agent）

| 城市 | 入口URL | 附件类型 | 行数 | 覆盖年度 | 备注 |
结尾附：JSONL 绝对路径、总行数、失败原因（若为 0 行）。

**行数为 0 也要如实回报并说明卡在哪**（例如「站点 DNS 不通」「只有汇总数字无企业名」），不要编造。
