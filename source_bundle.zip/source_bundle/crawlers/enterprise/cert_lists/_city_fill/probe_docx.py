# -*- coding: utf-8 -*-
import requests, urllib3, io
urllib3.disable_warnings()
s = requests.Session()
s.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'})
u = 'https://kjt.shaanxi.gov.cn/kjdt/tzgg/202311/P020250118836682342465.docx'
r = s.get(u, timeout=60, verify=False)
print('docx', r.status_code, len(r.content))
open(r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw\_sx2023b5.docx', 'wb').write(r.content)
try:
    from docx import Document
    d = Document(io.BytesIO(r.content))
    print('tables', len(d.tables))
    for ti, tb in enumerate(d.tables[:2]):
        print('table', ti, 'rows', len(tb.rows), 'cols', len(tb.columns))
        for row in tb.rows[:4]:
            print('   ', [c.text.strip()[:40] for c in row.cells])
    print('paras', [p.text.strip()[:80] for p in d.paragraphs if p.text.strip()][:8])
except Exception as e:
    print('ERR', e)
