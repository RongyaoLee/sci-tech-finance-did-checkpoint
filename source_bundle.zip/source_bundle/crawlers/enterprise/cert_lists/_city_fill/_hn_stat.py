﻿# -*- coding: utf-8 -*-
import json,collections
rows=[json.loads(l) for l in open("rows_湖南.jsonl",encoding="utf-8") if l.strip()]
print("total",len(rows))
c=collections.Counter(r["city"] for r in rows); print(dict(c))
y=collections.Counter(str(r.get("year") or "") for r in rows); print(dict(sorted(y.items())))
s=collections.Counter((r["city"],r["source_url"]) for r in rows)
for (ct,u),n in s.items(): print(ct,n,u)
