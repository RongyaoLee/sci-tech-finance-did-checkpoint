# -*- coding: utf-8 -*-
"""套路A：山东省科技厅「取消高新技术企业资格名单」附件（自带地市列）。
抽 烟台市 / 潍坊市 行 -> parts jsonl
"""
import sys, os, re, json
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

PDFS = [
    "http://kjt.shandong.gov.cn/attach/0/da7db68431974c4b94ead4d058b98604.pdf",
    "http://kjt.shandong.gov.cn/attach/0/1776752ffe7c47c5b76c1ec8b98b94dc.pdf",
    "http://kjt.shandong.gov.cn/module/download/downfile.jsp?classid=0&filename=c99c95ed67834a2daf1765c71f0f9c66.pdf",
]
OUT = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_yt_wf_cancel_dump.txt"

def main():
    buf = []
    for u in PDFS:
        sc, data, final = H.get(u, binary=True)
        print(u, "->", sc, len(data) if data else 0, final if final != u else "")
        if sc != 200 or not data:
            continue
        p = H.save_raw("sd_cancel", u, data)
        try:
            txt = H.text_of_pdf(data)
        except Exception as e:
            print("  pdf err", e); continue
        buf.append("\n\n========== %s\n%s" % (u, txt))
        print("  text len", len(txt), "certs", len(H.certs_in_text(txt)))
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(buf))
    print("dump ->", OUT)

if __name__ == "__main__":
    main()
