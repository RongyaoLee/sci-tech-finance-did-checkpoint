# -*- coding: utf-8 -*-
import requests, urllib3, re
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
r = requests.get('https://kjj.taiyuan.gov.cn/', headers=H, timeout=40, verify=False)
r.encoding = r.apparent_encoding or 'utf-8'
t = r.text
print(r.status_code, len(t))
anch = re.findall(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', t, re.S)
print('anchors', len(anch))
for href, txt in anch[:80]:
    txt = re.sub(r'<[^>]+>', '', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    print(f'  {href[:60]:60s} | {txt[:36]}')
