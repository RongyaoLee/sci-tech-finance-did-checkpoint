# -*- coding: utf-8 -*-
"""爬浙江科技大脑 /Public/CarrierList.aspx?code=RC（省级高新技术企业研究开发中心名录）。

表头：序号 | 名称(研发中心名) | 依托单位(企业名) | 地址 | 联系人 | 电话
地址首段即「市 + 县(市/区)」，无市名时用县名反查所属地级市（行政区划事实表，非猜测）。
产出 JSONL: parts/浙江省_stbrain_rc.jsonl
中断可续跑：已存在的 page 跳过。
"""
import sys, os, re, json, html

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H

CODE = os.environ.get("STB_CODE", "RC")
BASE = "https://stbrain.kjt.zj.gov.cn/Public/CarrierList.aspx?code=" + CODE
OUT = os.path.join(HERE, "parts", "浙江省_stbrain_%s.jsonl" % CODE)
CITIES = ["杭州市", "宁波市", "温州市", "嘉兴市", "湖州市", "绍兴市", "金华市",
          "衢州市", "舟山市", "台州市", "丽水市"]
# 县(县级市/区) → 地级市，属于确定性的行政区划事实
COUNTY2CITY = {}
for c, arr in {
    "杭州市": "上城区 拱墅区 西湖区 滨江区 萧山区 余杭区 临平区 钱塘区 富阳区 临安区 桐庐县 淳安县 建德市",
    "宁波市": "海曙区 江北区 北仑区 镇海区 鄞州区 奉化区 象山县 宁海县 余姚市 慈溪市",
    "温州市": "鹿城区 龙湾区 瓯海区 洞头区 永嘉县 平阳县 苍南县 文成县 泰顺县 瑞安市 乐清市 龙港市",
    "嘉兴市": "南湖区 秀洲区 嘉善县 海盐县 海宁市 平湖市 桐乡市",
    "湖州市": "吴兴区 南浔区 德清县 长兴县 安吉县",
    "绍兴市": "越城区 柯桥区 上虞区 新昌县 诸暨市 嵊州市",
    "金华市": "婺城区 金东区 武义县 浦江县 磐安县 兰溪市 义乌市 东阳市 永康市",
    "衢州市": "柯城区 衢江区 常山县 开化县 龙游县 江山市",
    "舟山市": "定海区 普陀区 岱山县 嵊泗县",
    "台州市": "椒江区 黄岩区 路桥区 三门县 天台县 仙居县 温岭市 临海市 玉环市",
    "丽水市": "莲都区 青田县 缙云县 遂昌县 松阳县 云和县 庆元县 景宁畲族自治县 龙泉市",
}.items():
    for x in arr.split():
        COUNTY2CITY[x] = c


def clean(s):
    s = html.unescape(s or "")
    s = re.sub(r"<[^>]+>", "", s)
    s = s.replace("\u3000", " ").replace("\xa0", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s.lstrip("|｜").strip()


def parse_rows(t):
    out = []
    for r in re.findall(r"(?is)<tr[^>]*>(.*?)</tr>", t):
        c = [clean(x) for x in re.findall(r"(?is)<t[dh][^>]*>(.*?)</t[dh]>", r)]
        if len(c) == 6 and re.fullmatch(r"\d+", c[0] or ""):
            out.append(c)
    return out


CN = r"\u4e00-\u9fff"
UNIT = r"([%s]{1,7}?(?:新区|区|县|市))" % CN


def city_of_county(co):
    """县(市/区)名 → 地级市。支持「慈溪高新技术产业开发区」这类前缀形态。"""
    if not co:
        return ""
    if co in COUNTY2CITY:
        return COUNTY2CITY[co]
    for k in sorted(COUNTY2CITY, key=len, reverse=True):
        if co.startswith(k):
            return COUNTY2CITY[k]
    for c in CITIES:
        if co.startswith(c[:2]):
            return c
    return ""


def area_from_addr(addr):
    """从地址首段取 (city, county)。只做字面解析 + 县→市 事实查表。"""
    a = clean(addr)
    a = re.sub(r"^(浙江省|浙江|中国)", "", a).strip()
    a = re.sub(r"^[（(][^）)]*[）)]", "", a).strip()
    # 「杭州湾上虞经济技术开发区」是绍兴上虞（杭州湾是海湾名，不是杭州），
    # 「杭州湾新区/杭州湾慈溪」属宁波慈溪。不能按「杭州」前缀判杭州。
    if a.startswith("杭州湾"):
        if "上虞" in a:
            return "绍兴市", "上虞区"
        for stem, city, full in (("慈溪", "宁波市", "慈溪市"), ("余姚", "宁波市", "余姚市"),
                                 ("镇海", "宁波市", "镇海区"), ("北仑", "宁波市", "北仑区"),
                                 ("海盐", "嘉兴市", "海盐县"), ("海宁", "嘉兴市", "海宁市")):
            if stem in a:
                return city, full
        return "", ""
    for c in CITIES:
        if a.startswith(c):
            m = re.match(UNIT, a[len(c):])
            return c, (m.group(1) if m else "")
    m = re.match(UNIT, a)
    if m:
        co = m.group(1)
        return city_of_county(co), co
    for co in sorted(COUNTY2CITY, key=len, reverse=True):   # 地址中间出现县名
        if co in a:
            return COUNTY2CITY[co], co
    for c in CITIES:                                        # 「杭州经济技术开发区」这类省略「市」
        if a.startswith(c[:2]):
            return c, ""
    for full in sorted(COUNTY2CITY, key=len, reverse=True):  # 「慈溪高新技术产业开发区」这类无后缀
        stem = full[:-1]
        if len(stem) >= 2 and stem in a:
            return COUNTY2CITY[full], full
    for c in CITIES:
        if c in a:
            return c, ""
    return "", ""


def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    done = set()
    if os.path.exists(OUT):
        with open(OUT, encoding="utf-8") as fh:
            for line in fh:
                try:
                    done.add(json.loads(line)["page"])
                except Exception:
                    pass
    print("resume pages done:", len(done), flush=True)
    # 先探 maxpage
    st, b, _ = H.get(BASE, timeout=30, tries=3, binary=True)
    t = (b or b"").decode("utf-8", "replace") if b else ""
    m = re.search(r"maxpage\s*=\s*(\d+)", t)
    maxpage = int(m.group(1)) if m else 470
    print("maxpage", maxpage, flush=True)
    fout = open(OUT, "a", encoding="utf-8")
    nrow = 0
    for p in range(0, maxpage + 1):
        if p in done:
            continue
        st, b, fu = H.get("%s&filter=&city=&page=%d" % (BASE, p), timeout=30, tries=3, binary=True)
        if st != 200 or not b:
            print("FAIL page", p, st, flush=True)
            continue
        rr = parse_rows(b.decode("utf-8", "replace"))
        if not rr:
            print("EMPTY page", p, flush=True)
            continue
        for c in rr:
            city, county = area_from_addr(c[3])
            rec = {"seq": c[0], "center": c[1], "name": c[2], "raw_area": c[3],
                   "city": city, "county": county, "src": BASE, "page": p}
            fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
            nrow += 1
        fout.flush()
        if p % 25 == 0:
            print("page", p, "rows", len(rr), "cum", nrow, flush=True)
    fout.close()
    print("DONE new rows", nrow, flush=True)


if __name__ == "__main__":
    main()
