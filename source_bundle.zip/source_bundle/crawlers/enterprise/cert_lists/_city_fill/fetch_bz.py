# -*- coding: utf-8 -*-
"""Fetch 山西 研发费补助名单公示 page, list attachments, download, inspect."""
import requests, urllib3, re, os, io, json
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})

urls = [
    ('bz2024', 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202607/t20260724_10183727.shtml'),
    ('bz2022', 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202407/t20240719_9612952.shtml'),
    ('bz2021', 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202208/t20220802_6840752.shtml'),
]
for tag, u in urls:
    try:
        r = s.get(u, timeout=45, verify=False)
        r.encoding = r.apparent_encoding or 'utf-8'
    except Exception as e:
        print(tag, 'ERR', str(e)[:80]); continue
    print('==', tag, r.status_code, len(r.text))
    open(os.path.join(RAW, f'_{tag}.html'), 'w', encoding='utf-8').write(r.text)
    body = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', r.text))
    i = body.find('附件')
    print('   TXT:', body[max(0, i - 400):i + 300] if i > 0 else body[:400])
    for m in re.finditer(r'href=[\'"]([^\'"]+\.(?:xls|xlsx|doc|docx|pdf|zip|rar|et))[\'"]', r.text, re.I):
        print('   ATT', m.group(1))
