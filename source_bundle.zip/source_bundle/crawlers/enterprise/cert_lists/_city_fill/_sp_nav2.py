# -*- coding: utf-8 -*-
"""首页 -> 打印所有栏目链接（关键词过滤）。用法: _sp_nav2.py HOST [kw1,kw2]"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
from urllib.parse import urljoin

host = sys.argv[1]
kws = (sys.argv[2] if len(sys.argv) > 2 else "通知,公告,公示,高新").split(",")
sc, d, f = S.H.get(host, timeout=25, tries=2, binary=True)
print(host, sc, len(d or b""))
t = d.decode("utf-8", "ignore")
if t.count("\ufffd") > 20:
    t = d.decode("gb18030", "ignore")
seen = set()
for a in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>([^<]{2,26})</a>', t):
    u, n = a.group(1), re.sub(r"\s", "", a.group(2))
    if u.startswith("/"):
        u = urljoin(f or host, u)
    if not u.startswith("http") or u in seen:
        continue
    if any(k in n for k in kws):
        seen.add(u)
        print("  ", n, "|", u)
