# -*- coding: utf-8 -*-
"""河南：抓科技厅公示/认定通知附件，解析自带「所属地市 / 所在地域」列的名单。v2"""
import io, sys, os, re, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, '_hn_region_rows.jsonl')

CITIES = ['郑州市', '开封市', '洛阳市', '平顶山市', '安阳市', '鹤壁市', '新乡市', '焦作市', '濮阳市',
          '许昌市', '漯河市', '三门峡市', '南阳市', '商丘市', '信阳市', '周口市', '驻马店市',
          '济源市', '郑州航空港区', '济源示范区', '航空港区']
CITY_SET = set(CITIES)

PAGES = [
    ('http://kjt.henan.gov.cn/2024/12-03/3094227.html', 2024, '第四批'),
    ('http://kjt.henan.gov.cn/2025/11-28/3268844.html', 2025, '第二批'),
]

KEEP = re.compile(r'[\u4e00-\u9fff0-9A-Za-z（）()％%．\.\-—_·、,，:：;；]')


def doc_text_heur(data):
    """OLE/未知容器：按 UTF-16LE 解，抽可读片段。"""
    t = data.decode('utf-16-le', 'ignore')
    out, buf = [], []
    for ch in t:
        if KEEP.match(ch):
            buf.append(ch)
        else:
            if len(buf) >= 2:
                out.append(''.join(buf))
            buf = []
    if len(buf) >= 2:
        out.append(''.join(buf))
    return '\n'.join(out)


def parse_rows(text):
    toks = [t for t in re.split(r'[\s\u3000]+', text or '') if t]
    out = []
    for i, tok in enumerate(toks):
        if tok not in CITY_SET:
            continue
        # 期望: city | region | name | code
        if i + 3 < len(toks) and re.fullmatch(r'[0-9A-Z]{18}', toks[i + 3]) and len(toks[i + 2]) >= 4:
            out.append((toks[i + 1], toks[i + 2], toks[i + 3]))
        elif i + 2 < len(toks) and re.fullmatch(r'[0-9A-Z]{18}', toks[i + 2]) and len(toks[i + 1]) >= 4:
            out.append(('', toks[i + 1], toks[i + 2]))
    return out


def main():
    have = set()
    if os.path.exists(OUT):
        for line in open(OUT, encoding='utf-8'):
            try:
                d = json.loads(line)
                have.add((d['name'], d['city']))
            except Exception:
                pass
    fh = open(OUT, 'a', encoding='utf-8')
    grand = 0
    for url, year, batch in PAGES:
        st, txt, fu = H.get(url, timeout=30)
        if st != 200:
            print('PAGE FAIL', url, st); continue
        docs = H.doc_links(H.img_links(txt, fu), fu)
        print('PAGE %s %s docs=%d' % (year, batch, len(docs)))
        for d, tt in docs:
            st2, data, _ = H.get(d, timeout=120, binary=True)
            if st2 != 200 or not data:
                print('   doc fail', st2, d[:100]); continue
            dt = H.doc_text(d, data)
            rows = parse_rows(dt)
            if not rows and data[:8] == b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1':
                dt = doc_text_heur(data)
                rows = parse_rows(dt)
                print('   [heur] chars=%d rows=%d' % (len(dt), len(rows)))
            print('   n=%-5d chars=%-7d %s' % (len(rows), len(dt), d.split('/')[-1][:46]))
            toks = [t for t in re.split(r'[\s\u3000]+', dt) if t]
            for i, tok in enumerate(toks):
                if tok not in CITY_SET:
                    continue
                if i + 3 < len(toks) and re.fullmatch(r'[0-9A-Z]{18}', toks[i + 3]) and len(toks[i + 2]) >= 4:
                    city, region, name, code = tok, toks[i + 1], toks[i + 2], toks[i + 3]
                elif i + 2 < len(toks) and re.fullmatch(r'[0-9A-Z]{18}', toks[i + 2]) and len(toks[i + 1]) >= 4:
                    city, region, name, code = tok, '', toks[i + 1], toks[i + 2]
                else:
                    continue
                if (name, city) in have:
                    continue
                have.add((name, city))
                fh.write(json.dumps({'city': city, 'county': region, 'name': name, 'uscc': code,
                                     'year': year, 'batch': batch, 'src': d}, ensure_ascii=False) + '\n')
                grand += 1
            fh.flush()
    fh.close()
    print('TOTAL new rows', grand)


if __name__ == '__main__':
    main()
