# -*- coding: utf-8 -*-
import csv, collections, os, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
base = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists'
for fn in ['河北省.csv', '河南省.csv']:
    p = os.path.join(base, fn)
    with open(p, encoding='utf-8-sig', newline='') as f:
        r = csv.DictReader(f)
        rows = list(r)
    print('==', fn, 'rows', len(rows), 'fields', r.fieldnames)
    cc = collections.Counter(x['城市'] for x in rows)
    print(' city nonempty', sum(v for k, v in cc.items() if k), 'distinct', len([k for k in cc if k]))
    print(' top city', cc.most_common(10))
    yr = collections.Counter(x['认定年度'] for x in rows)
    print(' years', sorted(yr.items()))
    src = collections.Counter()
    for x in rows:
        u = x['来源URL']
        src[u.split('/')[2] if '://' in u else u] += 1
    print(' src hosts', src.most_common(8))
    de = sum(1 for x in rows if x['区县'])
    print(' county nonempty', de)
    print(' sample', rows[0])
    for x in rows[:3]:
        print('   ', x)
    # per-year city fill
    py = collections.defaultdict(lambda: [0, 0])
    for x in rows:
        py[x['认定年度']][0] += 1
        if x['城市']:
            py[x['认定年度']][1] += 1
    print(' per-year (total,city)', {k: tuple(v) for k, v in sorted(py.items())})
