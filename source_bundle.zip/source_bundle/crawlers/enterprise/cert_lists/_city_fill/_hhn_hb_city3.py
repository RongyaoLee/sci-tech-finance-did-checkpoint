# -*- coding: utf-8 -*-
"""河北各市科技局：找「高新技术企业」名单页 → 抽取 企业名称+证书号（城市=本市）。"""
import io, sys, os, re, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, '_hb_city_rows.jsonl')

EP = {
 '秦皇岛市': ['http://kjj.qhd.gov.cn/', 'http://kjj.qhd.gov.cn/col/col3178/index.html'],
 '邢台市': ['http://kjj.xingtai.gov.cn/class/88', 'http://kjj.xingtai.gov.cn/class/79'],
 '张家口市': ['http://kjj.zjk.gov.cn/xxgk/list.thtml?classId=14', 'http://kjj.zjk.gov.cn/list.thtml?classId=169'],
 '廊坊市': ['https://kjj.lf.gov.cn/tongzhigonggao/'],
 '衡水市': ['http://kjj.hengshui.gov.cn/col/col2786/index.html'],
}


def art_links(html, base):
    out = []
    for href, label in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', html, re.S):
        lab = re.sub(r'\s+', '', re.sub(r'<[^>]+>', '', label))
        if not lab:
            continue
        if any(k in lab for k in ('高新技术企业', '高企', '高新企业')):
            if href.startswith('http'):
                out.append((href, lab))
            elif href.startswith('/'):
                out.append((base.split('/')[0] + '//' + base.split('/')[2] + href, lab))
    return out


CERT_RE = re.compile(r'GR\s?\d{4}\s?\d{2}\s?\d{6}')


def parse_pairs(text):
    """返回 [(name, cert)]：按证书号附近取名称。"""
    pairs = []
    toks = [t for t in re.split(r'[\s\u3000]+', text) if t]
    for i, t in enumerate(toks):
        for m in CERT_RE.finditer(t):
            cert = re.sub(r'\s', '', m.group(0))
            pre = t[:m.start()].strip(' \t:：、,，|')
            if not pre and i > 0:
                pre = toks[i - 1]
            pre = re.sub(r'^[0-9]+[.、]?', '', pre).strip()
            if len(pre) >= 4 and not CERT_RE.search(pre):
                pairs.append((pre, cert))
    return pairs


def main():
    have = set()
    if os.path.exists(OUT):
        for line in open(OUT, encoding='utf-8'):
            try:
                d = json.loads(line); have.add((d['name'], d['city']))
            except Exception:
                pass
    fh = open(OUT, 'a', encoding='utf-8')
    for city, eps in EP.items():
        print('==', city)
        arts = {}
        for ep in eps:
            st, txt, fu = H.get(ep, timeout=30)
            print('   ep', st, len(txt or ''), ep[:60])
            if st != 200:
                continue
            for u, lab in art_links(txt, fu):
                arts.setdefault(u, lab)
        print('   arts', len(arts))
        for u, lab in list(arts.items())[:14]:
            st, txt, fu = H.get(u, timeout=30)
            if st != 200:
                continue
            docs = H.doc_links(H.img_links(txt, fu), fu)
            n = 0
            for d, tt in docs:
                st2, data, _ = H.get(d, timeout=120, binary=True)
                if st2 != 200 or not data:
                    continue
                dt = H.doc_text(d, data)
                for name, cert in parse_pairs(dt):
                    if (name, city) in have:
                        continue
                    have.add((name, city)); n += 1
                    fh.write(json.dumps({'city': city, 'county': '', 'name': name, 'cert': cert,
                                         'src': d}, ensure_ascii=False) + '\n')
            if n:
                print('    +', n, lab[:40], '|', u[-40:])
            fh.flush()
    fh.close()
    print('done')


if __name__ == '__main__':
    main()
