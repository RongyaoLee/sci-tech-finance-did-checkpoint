# -*- coding: utf-8 -*-
"""Probe URLs: status, size, title, sample links."""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

for url in sys.argv[1:]:
    sc, html, final = H.get(url, timeout=25, tries=2)
    title = ""
    m = re.search(r"<title[^>]*>(.*?)</title>", html or "", re.S | re.I)
    if m:
        title = re.sub(r"\s+", " ", m.group(1)).strip()
    print("=" * 70)
    print("URL:", url)
    print("status:", sc, "len:", len(html or ""), "final:", final)
    print("title:", title[:120])
    if sc == 200 and html:
        links = H.img_links(html, final)
        docs = H.doc_links(links)
        print("links:", len(links), "docs:", len(docs))
        for u, t in links[:25]:
            print("   L", t[:50], "|", u[:120])
        for u, t in docs[:10]:
            print("   D", t[:50], "|", u[:120])
