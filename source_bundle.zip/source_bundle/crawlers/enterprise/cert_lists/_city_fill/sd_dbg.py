# -*- coding: utf-8 -*-
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_baidu as B

U = "https://www.so.com/link?m=b2S1z20%2FnEck%2FS0%2FJxzj57HN2DAPuhF8TO%2B0OASjPQ7erxA22O%2Bz%2FDCDUiyVXg37MT5qJFgA"
st, h, fin = B.f(U, timeout=25, referer="https://www.so.com/")
print("status", st, "len", len(h or ""), "final", fin[:120])
h = h or ""
for pat in [r"URL=.{0,200}", r"location\.(?:href|replace).{0,200}", r"https?://[\w.\-]*gov\.cn[^\"' <>]{0,140}", r"<meta[^>]+refresh[^>]*>", r"data-mdurl=\"[^\"]+\""]:
    m = re.findall(pat, h, re.I)[:6]
    print("PAT", pat[:24], len(m))
    for x in m[:4]:
        print("    ", x[:160])
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "raw_baidu", "so_link.html"), "w", encoding="utf-8").write(h)
