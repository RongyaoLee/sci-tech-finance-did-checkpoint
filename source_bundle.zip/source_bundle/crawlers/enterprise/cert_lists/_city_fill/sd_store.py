# -*- coding: utf-8 -*-
"""带区县的追加存储：parts/山东省_<city>.jsonl"""
import os, json, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_lib as S

PARTS = os.environ.get("SD_PARTS") or S.PARTS


def _seen(city):
    p = os.path.join(PARTS, "山东省_%s.jsonl" % city)
    seen = set()
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            try:
                o = json.loads(line)
            except Exception:
                continue
            k = o.get("cert") or ("N:" + o.get("name", ""))
            seen.add(k)
    return seen


def append_rows(city, rows, src, year="", batch=""):
    """rows: [(name, cert, county)] 追加去重，返回新增条数。"""
    p = os.path.join(PARTS, "山东省_%s.jsonl" % city)
    seen = _seen(city)
    n = 0
    with open(p, "a", encoding="utf-8") as f:
        for r in rows:
            nm, ct, county = (list(r) + ["", "", ""])[:3]
            nm = (nm or "").strip()
            ct = (ct or "").strip()
            if not ct and not nm:
                continue
            k = ct or ("N:" + nm)
            if k in seen:
                continue
            seen.add(k)
            f.write(json.dumps({"cert": ct, "name": nm, "city": city,
                                "county": county or "", "src": src,
                                "year": year, "batch": batch}, ensure_ascii=False) + "\n")
            n += 1
    return n
