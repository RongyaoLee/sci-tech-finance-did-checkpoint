# -*- coding: utf-8 -*-
"""Crawl 山西 综合前沿科技处 zhqykjc column; list 高企 titles; also try attachment harvest on 认定结果 notices."""
import requests, urllib3, re, time, json, os
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})


def get(u, binary=False):
    for attempt in range(2):
        try:
            r = s.get(u, timeout=45, verify=False)
        except Exception as e:
            return 0, str(e)[:90], u
        if r.status_code == 200:
            if binary:
                return 200, r.content, r.url
            r.encoding = r.apparent_encoding or 'utf-8'
            return 200, r.text, r.url
        alt = u.replace('https://', 'http://', 1) if u.startswith('https://') else u.replace('http://', 'https://', 1)
        if attempt == 0 and alt != u:
            u = alt
            continue
        return r.status_code, '', u
    return 0, '', u


base = 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/'
items = []
for p in range(0, 40):
    pats = ['', 'index.shtml'] if p == 0 else ['index_{p}.shtml']
    st = 0
    for pat in pats:
        u = base + (pat.format(p=p) if p else pat)
        st, t, fu = get(u)
        if st == 200 and len(t) > 3000:
            break
    if st != 200:
        print('stop', p, u, st)
        break
    n = 0
    for m in re.finditer(r'<li>(.*?)</li>', t, re.S):
        blk = m.group(1)
        hm = re.search(r'href="\s*([^"\s]+\.shtml)\s*"', blk)
        if not hm:
            continue
        tm = re.search(r'target="_blank"[^>]*>(.*?)</a>', blk, re.S)
        title = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', tm.group(1))).strip() if tm else ''
        if title:
            items.append((title, hm.group(1).strip()))
            n += 1
    print('page', p, 'len', len(t), 'items', n)
    time.sleep(0.35)
uniq = {}
for ti, href in items:
    if ti not in uniq:
        uniq[ti] = href
json.dump(uniq, open(os.path.join(RAW, '_sxkj_zhqy_titles.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('TOTAL', len(uniq))
hits = {k: v for k, v in uniq.items() if re.search(r'高新', k)}
for k, v in sorted(hits.items()):
    print('  ', k[:120], '|', v)
