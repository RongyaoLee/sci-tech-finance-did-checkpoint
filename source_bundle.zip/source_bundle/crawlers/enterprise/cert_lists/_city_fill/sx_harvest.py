# -*- coding: utf-8 -*-
"""Harvest city-scoped enterprise name lists from city gov pages; append to rows_陕西.jsonl."""
import sys, os, re, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))   # cert_lists -> for fetch_common
import cf

OUT = os.path.join(HERE, "rows_陕西.jsonl")
LOG = os.path.join(HERE, "_progress_陕西.log")

NAME_RE = re.compile(r"[\u4e00-\u9fa5A-Za-z0-9（）()·\-]{2,40}?(?:股份有限公司|有限责任公司|有限公司|集团)")

def write_rows(rows, city, year, batch, src, note):
    n = 0
    with open(OUT, "a", encoding="utf-8") as f:
        for nm in rows:
            f.write(json.dumps({"name": nm, "cert": "", "city": city, "county": "",
                                "year": year, "batch": batch, "source_url": src,
                                "note": note}, ensure_ascii=False) + "\n")
            n += 1
    with open(LOG, "a", encoding="utf-8") as f:
        f.write("%s\t%d\t%s\n" % (city, n, src))
    return n

def names_from_html(url):
    h, f = cf.get(url)
    if not h:
        return [], []
    s = cf.soup_of(h)
    for t in s(["script", "style"]):
        t.decompose()
    txt = s.get_text("\n", strip=True)
    names = []
    for m in NAME_RE.finditer(txt):
        nm = m.group(0).strip("（）()·-")
        if len(nm) >= 4:
            names.append(nm)
    # dedupe keep order
    seen, out = set(), []
    for nm in names:
        if nm in seen:
            continue
        seen.add(nm)
        out.append(nm)
    return out, cf.attachments(url, h)

if __name__ == "__main__":
    targets = json.loads(sys.argv[1])
    for t in targets:
        names, atts = names_from_html(t["url"])
        print("==", t["city"], t["url"])
        print("   names", len(names), "atts", len(atts))
        print("   sample", names[:6])
        for a in atts[:6]:
            print("   ATT", a[0][:40], a[1])
        if t.get("write") and names:
            n = write_rows(names, t["city"], t.get("year", ""), t.get("batch", ""),
                           t["url"], t.get("note", ""))
            print("   WROTE", n)
