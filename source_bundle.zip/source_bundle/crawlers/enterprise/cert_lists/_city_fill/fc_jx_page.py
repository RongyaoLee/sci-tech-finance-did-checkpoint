# -*- coding: utf-8 -*-
"""Parse Jiangxi col list listData JSON + detect pagination."""
import os, sys, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

BASE = "http://kjt.jiangxi.gov.cn/jxskxjst/col/col27029/index.html"


def listdata(html):
    m = re.search(r"var\s+listData\s*=\s*(\{.*?\})\s*;?\s*\n", html, re.S)
    if not m:
        m = re.search(r"var\s+listData\s*=\s*(\{.*\})\s*;", html, re.S)
    if not m:
        return None
    raw = m.group(1)
    try:
        return json.loads(raw)
    except Exception:
        # trim trailing junk
        for end in range(len(raw), 0, -1):
            try:
                return json.loads(raw[:end])
            except Exception:
                continue
    return None


if __name__ == "__main__":
    for pg in [0, 1, 2]:
        u = BASE if pg == 0 else BASE.replace("index.html", "index_%d.html" % pg)
        h, f = cf.get(u)
        if not h:
            print(pg, "FAIL", u)
            continue
        d = listdata(h)
        if not d:
            print(pg, "no listData", u, len(h))
            continue
        arts = d.get("articleList") or []
        print("=" * 60)
        print("page", pg, "articles", len(arts), "keys", list(d.keys()))
        for a in arts[:5]:
            print("   ", a.get("pubDate"), a.get("title")[:50], a.get("urls"))
        # pagination hints
        for k, v in d.items():
            if k != "articleList":
                print("   ", k, "=", str(v)[:200])
