# -*- coding: utf-8 -*-
"""Rowspan/colspan aware HTML table grid + PDF column-model helpers."""

import re


def clean(v):
    if v is None:
        return ""
    s = str(v).replace("\u00a0", " ").replace("\u3000", " ")
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def grid_of(table):
    """Expand a BS4 <table> into a rectangular list-of-lists (rowspan/colspan applied)."""
    rows = table.find_all("tr")
    grid = []
    pending = {}  # col -> (text, remaining_rows)
    for tr in rows:
        cells = tr.find_all(["td", "th"], recursive=False)
        if not cells:
            cells = tr.find_all(["td", "th"])
        out = []
        col = 0
        it = iter(cells)
        cur = list(cells)
        idx = 0
        while idx < len(cur) or col in pending:
            if col in pending:
                text, left = pending[col]
                out.append(text)
                if left <= 1:
                    del pending[col]
                else:
                    pending[col] = (text, left - 1)
                col += 1
                continue
            if idx >= len(cur):
                break
            c = cur[idx]
            idx += 1
            text = clean(c.get_text(" ", strip=True))
            try:
                cs = int(c.get("colspan", 1) or 1)
            except ValueError:
                cs = 1
            try:
                rs = int(c.get("rowspan", 1) or 1)
            except ValueError:
                rs = 1
            for k in range(cs):
                out.append(text)
                if rs > 1:
                    pending[col] = (text, rs - 1)
                col += 1
        grid.append(out)
    # fill tail of pending
    while pending:
        out = []
        for col in sorted(set(list(range(max(pending) + 1)))):
            if col in pending:
                text, left = pending[col]
                out.append(text)
                if left <= 1:
                    del pending[col]
                else:
                    pending[col] = (text, left - 1)
            else:
                out.append("")
        grid.append(out)
        if len(grid) > 5000:
            break
    return grid
