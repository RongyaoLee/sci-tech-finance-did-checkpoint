# -*- coding: utf-8 -*-
import sys, os, re, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pymupdf

p = sorted(glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_cache", "att", "*")),
           key=os.path.getmtime)[-1]
print(p, os.path.getsize(p))
d = pymupdf.open(p)
pg = d[0]
words = pg.get_text("words")
lines = {}
for w in words:
    lines.setdefault(round(w[1] / 4), []).append(w)
for k in sorted(lines)[:14]:
    ws = sorted(lines[k], key=lambda x: x[0])
    print(" | ".join("%s@%.0f" % (w[4], w[0]) for w in ws))
