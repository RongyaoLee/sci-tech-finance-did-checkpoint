# -*- coding: utf-8 -*-
"""探测河北 11 市科技局站点存活与通知公告栏目。"""
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

SITES = {
    '石家庄': ['http://kjj.sjz.gov.cn/', 'http://kjj.sjz.gov.cn/col/1585277824508/index.html'],
    '唐山': ['http://kejiju.tangshan.gov.cn/', 'http://kejiju.tangshan.gov.cn/tsskjj/tzgg/index.html'],
    '秦皇岛': ['http://kjj.qhd.gov.cn/', 'http://www.qhdkjj.gov.cn/'],
    '邯郸': ['http://kjj.hd.gov.cn/', 'http://kjj.hd.gov.cn/col/1585277824508/index.html'],
    '邢台': ['http://kjj.xingtai.gov.cn/', 'http://kjj.xt.gov.cn/'],
    '保定': ['http://kjj.bd.gov.cn/', 'http://kjj.baoding.gov.cn/'],
    '张家口': ['http://kjj.zjk.gov.cn/', 'http://kjj.zjk.gov.cn/col/1585277824508/index.html'],
    '承德': ['http://kjj.chengde.gov.cn/', 'http://kjj.cd.gov.cn/'],
    '沧州': ['http://kjj.cangzhou.gov.cn/', 'http://kjj.cz.gov.cn/'],
    '廊坊': ['https://kjj.lf.gov.cn/', 'https://kjj.lf.gov.cn/tongzhigonggao/'],
    '衡水': ['http://kjj.hengshui.gov.cn/', 'http://kjj.hs.gov.cn/'],
}
for city, urls in SITES.items():
    for u in urls:
        st, txt, fu = H.get(u, timeout=25)
        if st != 200 or not txt:
            print('%-5s %-45s FAIL %s' % (city, u, st)); continue
        t = re.search(r'<title>(.*?)</title>', txt, re.S)
        t = re.sub(r'\s+', ' ', t.group(1)).strip() if t else ''
        n_gx = txt.count('高新技术企业')
        links = re.findall(r'<a[^>]+href="([^"]+)"[^>]*>([^<]{2,30})</a>', txt)
        cols = [(h, x.strip()) for h, x in links if re.search(r'(通知|公告|公示|动态|新闻|文件)', x)]
        print('%-5s %-45s OK %d chars title=%s gx=%d' % (city, u, len(txt), t[:40], n_gx))
        for h, x in cols[:6]:
            print('      ', x, '->', h[:80])
        break
