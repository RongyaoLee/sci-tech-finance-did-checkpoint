# -*- coding: utf-8 -*-
import io, sys, os, re, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from urllib.parse import quote

def api(kw, begin='', end='', page=1, size=50):
    u = ('https://searchapi.henan.gov.cn/open/api/external-new?keywords=%s&siteId=4500000004'
         '&searchRange=-1000&sortType=150&pageNumber=%d&pageSize=%d' % (quote(kw), page, size))
    if begin:
        u += '&beginTime=%s&endTime=%s' % (begin, end)
    st, txt, fu = H.get(u, timeout=30)
    try:
        return json.loads(txt)
    except Exception:
        return None

print('### 河南 2020-2023 公示（按时间窗）')
seen = {}
for kw in ['公示', '拟认定高新技术企业']:
    for page in range(1, 9):
        j = api(kw, '2020-01-01', '2023-12-31', page, 50)
        if not j or j.get('code') not in (1,):
            print(' stop', kw, page); break
        d = j.get('data') or {}
        ds = d.get('datas') or []
        if not ds: break
        for it in ds:
            t = (it.get('title') or '').strip()
            d0 = (it.get('pubDate') or '')[:10]
            if '高新' in t and ('公示' in t or '认定' in t) and '更名' not in t and '搬迁' not in t:
                seen[str(it.get('id'))] = d0 + ' ' + t + ' ' + (it.get('selfUrl') or '')
        if page * 50 >= int(d.get('totalRow') or 0): break
for k in sorted(seen, key=lambda x: seen[x]):
    print('  ', k, seen[k][:130])

print('### 2017-2019 备用 id 的附件')
for u in ['http://kjt.henan.gov.cn/2017/08-29/1524026.html',
          'http://kjt.henan.gov.cn/2017/12-01/1524028.html',
          'http://kjt.henan.gov.cn/2018/09-12/1523966.html',
          'http://kjt.henan.gov.cn/2019/12-09/1528778.html']:
    st, txt, fu = H.get(u, timeout=30)
    if st != 200:
        print(' ', u[-24:], 'FAIL', st); continue
    docs = H.doc_links(H.img_links(txt, fu), fu)
    print(' ', u[-24:], 'docs', [(t[:34], d[:100]) for d, t in docs[:3]])
