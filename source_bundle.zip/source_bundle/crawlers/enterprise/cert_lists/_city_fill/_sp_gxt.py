# -*- coding: utf-8 -*-
"""省工信厅名单采集器：创新型中小企业 / 专精特新 中小企业 名单（自带「所属市州」列）
   用途：name -> 城市 映射，与高企名单按企业名称 join。
用法: python _sp_gxt.py <省> <host1,host2,...> [关键词]
"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
import harvest as H
from urllib.parse import urljoin, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
KW = ("创新型中小企业", "专精特新", "小巨人")


def txt(d):
    t = d.decode("utf-8", "ignore")
    if t.count("\ufffd") > 30:
        t = d.decode("gb18030", "ignore")
    return t


def anchors(t, base):
    out = []
    for m in re.finditer(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', t, re.S):
        n = re.sub(r"<[^>]+>|[\s\u200b]+", "", m.group(2))
        if n:
            out.append((n, urljoin(base, m.group(1))))
    return out


def pager(base, t, limit=8):
    urls = [base]
    stem = re.search(r"(index|list)\.(s?html?)$", base)
    d = base if base.endswith("/") else base.rsplit("/", 1)[0] + "/"
    cand = set()
    for n, u in anchors(t, base):
        if re.search(r"(index|list)_\d+\.(s?html?)$", u):
            cand.add(u)
    for i in range(1, limit + 1):
        if stem:
            cand.add(d + "%s_%d.%s" % (stem.group(1), i, stem.group(2)))
        else:
            cand.add(d + "index_%d.html" % i)
            cand.add(d + "index_%d.shtml" % i)
    return urls + sorted(cand)


def main():
    prov = sys.argv[1]
    hosts = sys.argv[2].split(",")
    extra = sys.argv[3] if len(sys.argv) > 3 else ""
    kws = KW + ((extra,) if extra else ())
    OUT = os.path.join(HERE, "parts", prov + ".jsonl")

    home = html = None
    for h in hosts:
        for sc0 in ("http://", "https://"):
            u = sc0 + h.strip("/") + "/"
            sc, d, f = H.get(u, timeout=15, tries=1, binary=True)
            if sc == 200 and d and len(d) > 3000:
                home, html = u, txt(d)
                print("HOME", u, len(d), flush=True)
                break
        if home:
            break
    if not home:
        print("NO HOME for", prov)
        return

    cols = {}
    for n, u in anchors(html, home):
        if re.search(r"(通知|公告|公示|公开|文件|政策|中小企业|企业)", n) and re.search(r"\.(s?html?)$|/$", u):
            cols.setdefault(u, n)
    print("cand", len(cols), flush=True)

    arts = {}
    for u in list(cols)[:30]:
        sc, d, f = H.get(u, timeout=15, tries=1, binary=True)
        if sc != 200 or not d:
            continue
        t = txt(d)
        if not any(k in t for k in kws):
            continue
        for pu in pager(f or u, t)[:9]:
            sc2, d2, f2 = H.get(pu, timeout=15, tries=1, binary=True)
            if sc2 != 200 or not d2:
                continue
            t2 = txt(d2)
            if not any(k in t2 for k in kws):
                continue
            for nm, au in anchors(t2, f2 or pu):
                if any(k in nm for k in kws) and ("名单" in nm or "公布" in nm):
                    arts.setdefault(au, nm)
        if len(arts) > 30:
            break
    print("articles", len(arts), flush=True)

    tot = 0
    for au, nm in sorted(arts.items(), key=lambda x: x[1]):
        ym = re.search(r"(20\d\d)", nm)
        year = ym.group(1) if ym else ""
        recs = S.grab(au, prov, "gxt_" + prov[:2], year=year, batch="工信名单",
                      require_city=True, carry=True, min_name=4)
        # 文章页本身无表 -> 跟随附件（doc/docx/xls/xlsx/pdf）
        if not recs:
            sc, d, f = H.get(au, timeout=25, tries=2, binary=True)
            if sc == 200 and d:
                t = txt(d)
                links = []
                for m in re.finditer(r'href=[\'"]([^\'"]+\.(?:docx?|xlsx?|pdf))[\'"]', t, re.I):
                    links.append(urljoin(f or au, m.group(1)))
                for lu in list(dict.fromkeys(links))[:6]:
                    r2 = S.grab(lu, prov, "gxt_" + prov[:2], year=year, batch="工信名单",
                                require_city=True, carry=True, min_name=4)
                    recs += r2
        S.append(OUT, recs)
        n1 = len(recs)
        tot += n1
        print("  %-58s %d" % (nm[:58], n1), flush=True)
    print("TOTAL", prov, tot, flush=True)


if __name__ == "__main__":
    main()
