# -*- coding: utf-8 -*-
"""Audit the Hubei JSONL: nd distribution, cert-year distribution, duplicates, area coverage."""
import os, sys, json, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

path = os.path.join(cf.HERE, "hubei_api_rows.jsonl")
rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
print("rows", len(rows))
print("nd:", collections.Counter(str(r.get("nd")) for r in rows))
print("cert year:", collections.Counter((r.get("data_no") or "")[2:6] for r in rows).most_common())
ids = collections.Counter(r.get("id") for r in rows)
print("distinct ids", len(ids), "dup ids", sum(1 for v in ids.values() if v > 1))
names = collections.Counter(r.get("name") for r in rows)
print("distinct names", len(names), "dup names", sum(1 for v in names.values() if v > 1))
print("fl_name:", collections.Counter(r.get("fl_name") for r in rows).most_common(5))
print("lb:", collections.Counter(r.get("lb") for r in rows).most_common(5))
# sample rows for a missing area's year: query with year filter directly
print("sample row:", json.dumps(rows[0], ensure_ascii=False))
