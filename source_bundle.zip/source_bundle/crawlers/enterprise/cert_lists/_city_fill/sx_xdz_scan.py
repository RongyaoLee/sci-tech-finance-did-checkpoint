# -*- coding: utf-8 -*-
import json, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "_sx_list_xdz.json"), encoding="utf-8"))
print("total", len(d))
for r in d:
    if re.search(r"证书|高企|高新技术企业|认定名单|名单", r["t"]):
        print(r["d"], "|", r["t"][:70], "|", r["u"])
print("--- date range ---")
ds = sorted([r["d"] for r in d if r["d"]])
print(ds[0] if ds else "", ds[-1] if ds else "")
