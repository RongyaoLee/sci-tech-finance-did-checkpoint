﻿# -*- coding: utf-8 -*-
import os,sys,re,json,urllib.parse,time
sys.path.insert(0,os.getcwd())
import cf
Q=["高新技术企业名单","高企名单"]
seen={}
for q in Q:
    for p in range(1,5):
        u="http://searching.hunan.gov.cn/hunan/001000000/all?q=%s&iszq=1&p=%d"%(urllib.parse.quote(q),p)
        h,f=cf.get(u)
        if not h: break
        n0=len(seen)
        for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',h,re.S|re.I):
            uu=urllib.parse.urljoin(f,m.group(1)); tt=re.sub(r"<[^>]+>","",m.group(2)); tt=re.sub(r"\s+","",tt).strip()
            if "searching.hunan.gov.cn" in uu or not tt or len(tt)<8: continue
            if not re.search(r"高新|高企",tt): continue
            seen.setdefault(uu,tt)
        print(q,p,"tot",len(seen))
        time.sleep(0.4)
json.dump(seen,open("_hn_hits4.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
o=["## %s | %s"%(t,u) for u,t in seen.items()]
open("_hn_hits4.txt","w",encoding="utf-8").write("\n".join(o))
