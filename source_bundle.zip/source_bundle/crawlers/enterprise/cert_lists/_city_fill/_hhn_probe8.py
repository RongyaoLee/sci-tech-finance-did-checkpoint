# -*- coding: utf-8 -*-
import io, sys, os, re, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from urllib.parse import quote

BASE = os.path.dirname(os.path.abspath(__file__))
u = 'https://kjt.henan.gov.cn/wzjs/?keywords=' + quote('高新技术企业名单')
st, txt, fu = H.get(u, timeout=30)
print('==', st, len(txt or ''), fu)
open(os.path.join(BASE, '_hn_search.html'), 'w', encoding='utf-8').write(txt or '')
if st == 200:
    links = H.img_links(txt, fu)
    print('links', len(links))
    hits = [(a, b) for a, b in links if re.match(r'https?://kjt\.henan\.gov\.cn/\d{4}/\d{2}-\d{2}/\d+\.html', a)]
    print('article links', len(hits))
    for a, b in hits[:30]:
        print('  ', b[:70], '|', a)
    # pagination hints
    for m in re.finditer(r'page|页码|总数|共\s*\d+', txt, re.I):
        s = max(0, m.start()-100); print('  pgn:', re.sub(r'\s+',' ', txt[s:m.end()+120])[:200]); break
