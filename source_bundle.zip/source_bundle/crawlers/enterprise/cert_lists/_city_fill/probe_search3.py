# -*- coding: utf-8 -*-
import requests, urllib3, re, urllib.parse
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
kw = urllib.parse.quote('拟认定高新技术企业')
u = f'https://kjt.shaanxi.gov.cn/sxsearch-a/search.shtml?code=191b76850fb&dataTypeId=20770&searchWord={kw}'
r = requests.get(u, headers=H, timeout=40, verify=False)
r.encoding = r.apparent_encoding or 'utf-8'
t = r.text
print(r.status_code, len(t))
open(r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw\_sxsearch.html', 'w', encoding='utf-8').write(t)
for ln in t.split('\n'):
    if re.search(r'(ajax|url|api|search|\.shtml|http)', ln, re.I) and len(ln) < 400:
        print(ln.strip()[:300])
