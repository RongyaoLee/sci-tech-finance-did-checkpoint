# -*- coding: utf-8 -*-
import sys, os, re, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

BASE = "https://kjt.shaanxi.gov.cn/kjdt/tzgg/"
seen, items = set(), []
for i in range(0, 160):
    u = BASE + ("index.html" if i == 0 else "index_%d.html" % i)
    h, f = cf.get(u, tries=1, timeout=20)
    if not h:
        print("miss", i, f); break
    n0 = len(items)
    for m in re.finditer(r'href="\.?/?(\d{6}/t\d{8}_\d+\.html)"[^>]*>(.*?)</a>', h, re.S):
        rel, tx = m.group(1), re.sub(r"<[^>]+>", "", m.group(2)).strip()
        url = "https://kjt.shaanxi.gov.cn/kjdt/tzgg/" + rel
        if url in seen:
            continue
        seen.add(url)
        items.append({"t": tx, "u": url})
    if len(items) == n0:
        print("no new at page", i); break
    if i % 20 == 0:
        print("page", i, "items", len(items))

json.dump(items, open(os.path.join(HERE, "_sx_kjt_tzgg.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print("TOTAL", len(items))
KW = re.compile(r"(高新技术企业|高企).*(名单|证书|公示|公告)|(名单|证书|公示|公告).*(高新技术企业|高企)")
for it in items:
    if KW.search(it["t"]):
        print(it["u"], "|", it["t"][:80])
