# -*- coding: utf-8 -*-
"""Find candidate 通知公告/政务公开 column entry links on a gov homepage."""
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

PAT = re.compile(r"通知公告|公示公告|公告公示|政务公开|信息公开|工作动态|科技动态|通知|公告|公开目录")


def cols(url):
    sc, html, final = H.get(url, tries=2, timeout=25)
    res = []
    if sc != 200 or not html:
        return sc, final, res
    seen = set()
    for a, t in H.img_links(html, final):
        t = t.strip()
        if not t or a in seen:
            continue
        if PAT.search(t) and len(t) <= 20:
            seen.add(a)
            res.append((t, a))
    return sc, final, res


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for u in sys.argv[1:]:
        sc, final, res = cols(u)
        print("##### %s sc=%s final=%s" % (u, sc, final))
        for t, a in res[:14]:
            print("   %s | %s" % (t, a))
