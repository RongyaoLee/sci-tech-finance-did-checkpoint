# -*- coding: utf-8 -*-
"""Scan a gov site for 高企名单 pages/attachments.

Usage:
  python cityscan.py START_URL [MAXPAGES] [KEYPATTERN]

BFS within the same host, following only "list-like" URLs, printing every
anchor whose text matches the keyword pattern.
"""
import re
import sys
import io
import os
from urllib.parse import urljoin, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

DEFAULT_KEY = r"高新技术企业|高企"
FOLLOW_RE = re.compile(r"(/col/col|/art/|/xwzx|/tzgg|/zwgk|/xxgk|/gkml|/index|/list|\.s?html?)", re.I)
SKIP_RE = re.compile(r"\.(jpg|jpeg|png|gif|css|js|ico|woff2?|ttf|mp4|mp3)(\?|$)", re.I)


def scan(start, max_pages=60, key=DEFAULT_KEY, same_prefix=True):
    key_re = re.compile(key)
    host = urlparse(start).netloc
    seen = set()
    queue = [start]
    hits = []
    docs = []
    n = 0
    while queue and n < max_pages:
        u = queue.pop(0)
        if u in seen:
            continue
        seen.add(u)
        sc, html, final = H.get(u, tries=2, timeout=25)
        n += 1
        if sc != 200 or not html:
            continue
        for a, t in H.img_links(html, final):
            if SKIP_RE.search(a):
                continue
            if key_re.search(t):
                hits.append((t.strip()[:110], a))
        for a, t in H.img_links(html, final):
            if SKIP_RE.search(a):
                continue
            p = urlparse(a)
            if p.netloc != host:
                continue
            if not FOLLOW_RE.search(a):
                continue
            if a in seen or a in queue:
                continue
            depth_ok = True
            if same_prefix:
                # stay within the same top-level directory subtree
                sp = urlparse(start).path
                depth_ok = p.path.startswith(sp.rsplit("/", 1)[0] + "/") or p.path.count("/") <= 2
            if depth_ok:
                queue.append(a)
    return hits, n, seen


def docs_of(url):
    sc, html, final = H.get(url, tries=2)
    if sc != 200 or not html:
        return []
    return H.doc_links(H.img_links(html, final))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    start = sys.argv[1]
    mp = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    key = sys.argv[3] if len(sys.argv) > 3 else DEFAULT_KEY
    hits, n, seen = scan(start, mp, key)
    print("pages_fetched=%d visited=%d hits=%d" % (n, len(seen), len(hits)))
    for t, u in hits:
        print("  %s | %s" % (t, u))
