﻿# -*- coding: utf-8 -*-
"""Generic Hunan pipeline: 站群 search -> page -> attachments/inline tables -> rows jsonl."""
import os,sys,re,json
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,HERE); sys.path.insert(0,os.path.dirname(HERE))
import cf, fetch_common as F

CITIES=["长沙市","株洲市","湘潭市","衡阳市","邵阳市","岳阳市","常德市","张家界市","益阳市","郴州市","永州市","怀化市","娄底市","湘西土家族苗族自治州"]
DOM={"changsha":"长沙市","zhuzhou":"株洲市","xiangtan":"湘潭市","hengyang":"衡阳市","hygx":"衡阳市",
"shaoyang":"邵阳市","yueyang":"岳阳市","changde":"常德市","zjj":"张家界市","yiyang":"益阳市",
"chenzhou":"郴州市","czs":"郴州市","yzcity":"永州市","huaihua":"怀化市","loudi":"娄底市","xxz":"湘西土家族苗族自治州",
"cshtz":"长沙市","ylgxq":"长沙市"}
ROWS=os.path.join(HERE,"rows_湖南.jsonl")
PROG=os.path.join(HERE,"_progress_湖南.log")
SEARCH=os.path.join(HERE,"_hn_parsed.jsonl")

def city_of(u):
    h=re.match(r"https?://([a-z0-9\.\-]+)",u).group(1).lower()
    for k,v in DOM.items():
        if re.search(r"(^|\.)"+re.escape(k)+r"\.",h): return v
    return ""

def load_done():
    s=set()
    if os.path.exists(SEARCH):
        for l in open(SEARCH,encoding="utf-8"):
            try: s.add(json.loads(l)["url"])
            except: pass
    return s

def have_rows():
    s=set()
    if os.path.exists(ROWS):
        for l in open(ROWS,encoding="utf-8"):
            try:
                d=json.loads(l); s.add((d["name"],d.get("cert",""),d["city"]))
            except: pass
    return s

def emit(city,url,title,year,batch,rows,note=""):
    seen=have_rows(); n=0
    with open(ROWS,"a",encoding="utf-8") as f:
        for nm,cert in rows:
            nm=F.clean(nm)
            if not F.looks_like_name(nm): continue
            k=(nm,cert or "",city)
            if k in seen: continue
            seen.add(k)
            f.write(json.dumps({"name":nm,"cert":cert or "","city":city,"county":"",
                                "year":year,"batch":batch,"source_url":url,"note":note},ensure_ascii=False)+"\n")
            n+=1
    with open(PROG,"a",encoding="utf-8") as f:
        f.write("%s\t%d\t%s\t%s\n"%(city,n,url,title[:60]))
    return n

def parse_page(url,city):
    h,fin=cf.get(url)
    if not h: return None
    txt=re.sub(r"<[^>]+>"," ",h)
    hits=[c for c in CITIES if c in txt]
    prov = len(hits)>2
    names=[]
    atts=cf.attachments(url,h)
    for t,au in atts:
        p=cf.download(au,"hn_"+city)
        if not p: continue
        try:
            for r in F.extract(p):
                if F.looks_like_name(r["name"]): names.append((r["name"],r["cert"]))
        except Exception: pass
    if len(names)<5:
        soup=cf.soup_of(h)
        for tb in soup.find_all("table"):
            for tr in tb.find_all("tr"):
                cells=[c.get_text(" ",strip=True) for c in tr.find_all(["td","th"])]
                if not cells: continue
                nm=""
                for c in cells:
                    cc=F.clean(c)
                    if F.looks_like_name(cc): nm=cc; break
                if nm: names.append((nm,F.norm_cert(" ".join(cells))))
    seen={}; out=[]
    for n,c in names:
        n=F.clean(n)
        if n in seen: continue
        seen[n]=1; out.append((n,re.sub(r"^GR.*","",c) if False else c))
    return {"prov":prov,"names":out,"atts":len(atts),"hits":hits}

if __name__=="__main__":
    q=sys.argv[1] if len(sys.argv)>1 else "高新区 高新技术企业 证书"
    U="http://searching.hunan.gov.cn/hunan/001000000/all"
    hits={}
    for p in range(1,6):
        try:
            r=cf.S.get(U,params={"q":q,"iszq":"1","p":p},timeout=30); r.encoding="utf-8"
        except Exception: break
        n=0
        for url,t in re.findall(r'<a[^>]+href="(https?://[^"]+\.(?:html|shtml|htm|do|jsp)[^"]*)"[^>]*>(.*?)</a>',r.text,re.S):
            t=re.sub(r"<[^>]+>","",t); t=re.sub(r"\s+"," ",t).strip()
            if not t or len(t)<6 or "searching.hunan" in url or url in hits: continue
            hits[url]=t; n+=1
        if n==0: break
    print("hits",len(hits),flush=True)
    done=load_done()
    tot=0
    for url,t in hits.items():
        if url in done: continue
        if "高新" not in t and "高企" not in t: continue
        if not re.search(r"名单|公示|公布|认定|证书|备案|推荐|领取",t): continue
        c=city_of(url)
        if not c: continue
        try:
            res=parse_page(url,c)
        except Exception as e:
            print("ERR",url,type(e).__name__,flush=True); continue
        with open(SEARCH,"a",encoding="utf-8") as fo:
            fo.write(json.dumps({"url":url,"city":c,"title":t,"atts":res["atts"] if res else 0,
                                 "names":[]} if not res else
                                {"url":url,"city":c,"title":t,"atts":res["atts"],
                                 "names":[{"name":a,"cert":b} for a,b in res["names"]]},ensure_ascii=False)+"\n")
        if not res or res["prov"] and len(res["names"])>1500: 
            print("skip",("prov" if res and res["prov"] else "none"),c,t[:30],flush=True); continue
        cnt=len(res["names"])
        print(("PROV?" if res["prov"] else "OK"),c,cnt,"atts",res["atts"],"|",t[:34],flush=True)
    print("done")
