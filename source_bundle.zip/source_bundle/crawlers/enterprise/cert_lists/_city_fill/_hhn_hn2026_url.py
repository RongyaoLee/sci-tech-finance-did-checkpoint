# -*- coding: utf-8 -*-
import io, sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

st, txt, fu = H.get('http://kjt.henan.gov.cn/2026/11-06/3445327.html', timeout=30)
print(st, len(txt))
for m in set(re.findall(r'(?:href|src)="([^"]*(?:pdf|doc|docx|xls|xlsx|wps)[^"]*)"', txt, re.I)):
    print('A', m)
for m in set(re.findall(r'oss\.henan\.gov\.cn[^"\x27 )<]+', txt))    :
    print('B', m)
print('DOCS', H.doc_links(H.img_links(txt, fu), fu))
