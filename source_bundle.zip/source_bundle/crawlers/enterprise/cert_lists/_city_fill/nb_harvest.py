# -*- coding: utf-8 -*-
"""宁波市 高企名单采集：innocom 宁波市认定机构 公示(c101419) + 备案公告(c101455)。"""
import sys, json, re, os, csv
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H

WORK = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work"
CF = os.path.join(WORK, "cert_lists", "_city_fill")
COLS = {"c101455": "_nb_cols2.json", "c101419": "_nb_cols2.json"}

# 1) cert -> name from provincial CSV (read only)
cert2name = {}
with open(os.path.join(WORK, "cert_lists", "浙江省.csv"), encoding="utf-8-sig", newline="") as f:
    rd = csv.reader(f)
    next(rd)
    for row in rd:
        if len(row) >= 2 and row[1].startswith("GR"):
            cert2name[row[1].strip()] = row[0].strip()
print("csv certs", len(cert2name))

arts = json.load(open(os.path.join(CF, "_nb_cols2.json"), encoding="utf-8"))

def year_batch(title):
    ys = re.findall(r"(20\d{2})", title)
    year = int(ys[0]) if ys else None
    if "第二批补充备案" in title:
        batch = "第二批补充备案"
    elif "第一批补充备案" in title:
        batch = "第一批补充备案"
    elif "补充备案" in title:
        batch = "补充备案"
    elif "第二批" in title:
        batch = "第二批"
    elif "第一批" in title:
        batch = "第一批"
    elif "复审" in title:
        batch = "复审"
    else:
        batch = "备案"
    return year, batch

rows = []
log = []
for col in ("c101455", "c101419"):
    for a in arts.get(col, []):
        u, t = a["u"], a["t"]
        y, b = year_batch(t)
        if not y or y < 2016 or y > 2025:
            log.append({"col": col, "title": t, "skip": "year %s" % y})
            continue
        if "更名" in t:
            log.append({"col": col, "title": t, "skip": "更名"})
            continue
        sc, html, final = H.get(u, timeout=25, tries=2)
        if sc != 200:
            log.append({"col": col, "title": t, "err": "page %s" % sc})
            continue
        H.save_raw("nb_html", u, html.encode("utf-8", "ignore"))
        docs = []
        for href, tt in H.img_links(html, final):
            low = href.lower().split("?")[0]
            if any(low.endswith(e) for e in (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".et", ".zip", ".rar")):
                docs.append((href, tt))
        if not docs:
            # 正文里可能直接给名单
            txt = re.sub(r"(?is)<script.*?</script>", " ", html)
            txt = re.sub(r"<[^>]+>", "\n", txt)
            cs = H.certs_in_text(txt)
            log.append({"col": col, "title": t, "note": "no-attach", "inline_certs": len(cs)})
            for c in cs:
                rows.append({"cert": c, "name": cert2name.get(c, ""), "city": "宁波市", "county": "",
                             "src": u, "year": int(c[2:6]), "batch": b, "col": col})
            continue
        got = 0
        for href, tt in docs:
            sc2, data, f2 = H.get(href, binary=True, timeout=40)
            if sc2 != 200 or not data:
                log.append({"col": col, "title": t, "err": "dl %s" % sc2, "url": href})
                continue
            H.save_raw("nb_doc", href, data)
            txt = H.doc_text(href, data)
            if txt.startswith("##ERR"):
                log.append({"col": col, "title": t, "err": txt[:60], "url": href})
                continue
            cs = H.certs_in_text(txt)
            for c in cs:
                rows.append({"cert": c, "name": cert2name.get(c, ""), "city": "宁波市", "county": "",
                             "src": href, "year": int(c[2:6]), "batch": b, "col": col})
            got += len(cs)
        log.append({"col": col, "title": t, "year": y, "batch": b, "docs": len(docs), "certs": got})

# dedupe by cert
best = {}
for r in rows:
    c = r["cert"]
    if c not in best:
        best[c] = r
    else:
        # 优先 备案公告(col c101455)，其次有名
        if not best[c]["name"] and r["name"]:
            best[c]["name"] = r["name"]

recs = list(best.values())
recs.sort(key=lambda r: (r["year"], r["batch"], r["cert"]))
out = os.path.join(CF, "parts", "浙江省_宁波市.jsonl")
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, "w", encoding="utf-8") as f:
    for r in recs:
        f.write(json.dumps({k: r[k] for k in ("cert", "name", "city", "county", "src", "year", "batch")},
                           ensure_ascii=False) + "\n")
json.dump(log, open(os.path.join(CF, "_nb_log.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

print("TOTAL certs", len(recs))
from collections import Counter
print("by year", sorted(Counter(r["year"] for r in recs).items()))
print("no name:", sum(1 for r in recs if not r["name"]))
print("--- article log ---")
for l in log:
    print(l.get("year"), l.get("batch"), l.get("certs"), "|", l["title"][:60], "|", l.get("skip") or l.get("err") or l.get("note") or "")
