# -*- coding: utf-8 -*-
"""宁波市高企名单：从 innocom 宁波市认定机构 备案公告(c101455)/公示(c101419) 附件抽 (证书编号, 企业名称)。"""
import sys, json, re, os, csv, glob
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H
import nb_docparse

WORK = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work"
CF = os.path.join(WORK, "cert_lists", "_city_fill")
CERT = re.compile(r"GR\d{12}")
NUMONLY = re.compile(r"^\d{1,5}$")
HDR = ("序号", "企业名称", "证书编号", "附件", "名单", "备案", "公示", "公告", "复函")


def parse_pdf_rows(txt):
    """PDF 文本按 序号/企业名称/证书编号 顺序逐行输出。"""
    lines = [re.sub(r"\s+", " ", l).strip() for l in txt.split("\n")]
    lines = [l for l in lines if l]
    pairs = []
    for i, l in enumerate(lines):
        if CERT.fullmatch(l):
            buf = []
            j = i - 1
            while j >= 0 and not NUMONLY.match(lines[j]) and lines[j] not in HDR and len(buf) < 3:
                buf.append(lines[j])
                j -= 1
            name = "".join(reversed(buf)).strip()
            pairs.append((l, name))
    return pairs


def parse_doc_rows(txt):
    """Word97 单元格以 \\x07 分隔：序号\\x07名称\\x07证书编号。"""
    pairs = []
    for m in CERT.finditer(txt):
        c = m.group(0)
        prev = txt[max(0, m.start() - 200):m.start()]
        prev = prev.split("\x07")
        # 形如 [... '1', '宁波力劲机械有限公司', ''] -> 名称在倒数第2段
        cand = [p.strip() for p in prev if p.strip()]
        name = ""
        for p in reversed(cand):
            if NUMONLY.match(p):
                break
            name = p + name
            if len(name) >= 4:
                break
        name = re.sub(r"[\x00-\x1f]", "", name)
        pairs.append((c, name))
    return pairs


def parse_sheet_rows(txt):
    pairs = []
    for line in txt.split("\n"):
        c = CERT.search(line)
        if not c:
            continue
        cells = [x.strip() for x in line.split("\t")]
        nm = ""
        for x in cells:
            if CERT.fullmatch(x.replace(" ", "")):
                continue
            if not x or NUMONLY.match(x):
                continue
            nm = x
        pairs.append((c.group(0), nm))
    return pairs


def year_batch(title):
    ys = re.findall(r"(20\d{2})", title)
    year = int(ys[0]) if ys else None
    if "第二批补充备案" in title:
        batch = "第二批补充备案"
    elif "第一批补充备案" in title:
        batch = "第一批补充备案"
    elif "补充备案" in title:
        batch = "补充备案"
    elif "第二批" in title:
        batch = "第二批"
    elif "第一批" in title:
        batch = "第一批"
    elif "复审" in title:
        batch = "复审"
    else:
        batch = "备案"
    return year, batch


def main():
    arts = json.load(open(os.path.join(CF, "_nb_cols2.json"), encoding="utf-8"))
    rows, log = [], []
    for col in ("c101455", "c101419"):
        for a in arts.get(col, []):
            u, t = a["u"], a["t"]
            y, b = year_batch(t)
            if not y or y < 2016 or y > 2025 or "更名" in t:
                continue
            sc, html, final = H.get(u, timeout=25, tries=2)
            if sc != 200:
                log.append({"title": t, "err": "page %s" % sc})
                continue
            docs = []
            for href, tt in H.img_links(html, final):
                low = href.lower().split("?")[0]
                if any(low.endswith(e) for e in (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".et", ".zip", ".rar")):
                    docs.append((href, tt))
            for href, tt in docs:
                sc2, data, f2 = H.get(href, binary=True, timeout=60)
                if sc2 != 200 or not data:
                    log.append({"title": t, "doc": tt, "err": "dl %s" % sc2})
                    continue
                p = H.save_raw("nb_doc", href, data)
                low = href.lower()
                if low.endswith(".doc") or data[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
                    try:
                        txt = nb_docparse.doc_text(p)
                    except Exception as e:
                        txt = ""
                        log.append({"title": t, "doc": tt, "err": "docparse %s" % type(e).__name__})
                    pairs = parse_doc_rows(txt)
                elif low.endswith(".pdf") or data[:4] == b"%PDF":
                    txt = H.doc_text(href, data)
                    pairs = parse_pdf_rows(txt)
                else:
                    txt = H.doc_text(href, data)
                    pairs = parse_sheet_rows(txt)
                for c, nm in pairs:
                    rows.append({"cert": c, "name": nm, "city": "宁波市", "county": "",
                                 "src": href, "year": int(c[2:6]), "batch": b})
                log.append({"title": t, "doc": tt, "size": len(data), "chars": len(txt),
                            "pairs": len(pairs), "url": href})

    best = {}
    for r in rows:
        c = r["cert"]
        if c not in best or (not best[c]["name"] and r["name"]):
            best[c] = r
    recs = sorted(best.values(), key=lambda r: (r["year"], r["batch"], r["cert"]))
    out = os.path.join(CF, "parts", "浙江省_宁波市.jsonl")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        for r in recs:
            f.write(json.dumps({k: r[k] for k in ("cert", "name", "city", "county", "src", "year", "batch")},
                               ensure_ascii=False) + "\n")
    json.dump(log, open(os.path.join(CF, "_nb_log2.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    from collections import Counter
    print("TOTAL", len(recs), "| empty name:", sum(1 for r in recs if not r["name"]))
    print("by year", sorted(Counter(r["year"] for r in recs).items()))
    print("by batch", sorted(Counter((r["year"], r["batch"]) for r in recs).items()))
    print("--- docs ---")
    for l in log:
        print(l.get("size"), l.get("chars"), l.get("pairs"), "|", (l.get("doc") or "")[:36], "|", l["title"][:44], "|", l.get("err", ""))


if __name__ == "__main__":
    main()
