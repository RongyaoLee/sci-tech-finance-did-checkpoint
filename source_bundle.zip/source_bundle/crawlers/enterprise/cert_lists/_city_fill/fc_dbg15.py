# -*- coding: utf-8 -*-
import sys, os, glob, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from docparse import doc_text, cells_of

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_cache", "att")


def sniff(path):
    t = doc_text(path)
    cells = cells_of(t)
    gr = [c for c in cells if re.fullmatch(r"GR\d{9,}", c.strip())]
    hdr = [c for c in cells if "企业名称" in c]
    return len(t), len(cells), len(gr), hdr[:2], cells[:6]


for p in glob.glob(os.path.join(D, "*.doc")):
    try:
        n, c, g, h, head = sniff(p)
    except Exception as e:
        print(os.path.basename(p), "ERR", e); continue
    if g or h:
        print("%-28s text=%-6d cells=%-5d GR=%-4d hdr=%s" % (os.path.basename(p), n, c, g, h))
