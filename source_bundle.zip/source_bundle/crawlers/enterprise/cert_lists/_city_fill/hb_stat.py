# -*- coding: utf-8 -*-
"""Hubei: pull per-city-per-year expected counts, then diff against the harvested JSONL."""
import os, sys, json, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

BASE = "https://kjt.hubei.gov.cn/ywt/services"
HDR = {"Content-Type": "application/json;charset=utf-8",
       "Referer": "https://kjt.hubei.gov.cn/ywt/",
       "Origin": "https://kjt.hubei.gov.cn"}

r = cf.S.post(BASE + "/portal/search/dataStatByYear", params={"flid": "008001"},
              json={}, headers=HDR, timeout=30)
stat = r.json()
rows = stat.get("rows") or []
print("stat rows:", len(rows), "sample:", rows[:3])
json.dump(rows, open(os.path.join(cf.HERE, "_hb_stat.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)

exp = collections.Counter()
for x in rows:
    exp[(x.get("地区"), str(x.get("年度")))] += int(x.get("数量") or 0)

got = collections.Counter()
path = os.path.join(cf.HERE, "hubei_api_rows.jsonl")
n = 0
for line in open(path, encoding="utf-8"):
    if not line.strip():
        continue
    d = json.loads(line)
    n += 1
    got[(d.get("areaname"), str(d.get("nd")))] += 1
print("jsonl rows:", n)

areas_exp = sorted({k[0] for k in exp})
areas_got = sorted({k[0] for k in got})
print("areas expected:", len(areas_exp), areas_exp)
print("areas got     :", len(areas_got), areas_got)
print("MISSING areas:", [a for a in areas_exp if a not in areas_got])
print("EXTRA areas  :", [a for a in areas_got if a not in areas_exp])
print("\nper (area,year) diffs where got != exp:")
bad = 0
for k in sorted(exp, key=lambda x: (str(x[0]), str(x[1]))):
    g, e = got.get(k, 0), exp[k]
    if g != e:
        bad += 1
        print("  %-24s %-6s exp=%-5d got=%-5d" % (k[0], k[1], e, g))
print("diff cells:", bad, "| total exp", sum(exp.values()), "total got", sum(got.values()))
