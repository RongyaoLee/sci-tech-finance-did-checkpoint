# -*- coding: utf-8 -*-
"""爬浙江科技大脑 /Public/CarrierList.aspx?code=HT 全量名录（458页 x 20 行，含 所在地/地址）。
产出 JSONL: parts/浙江省_stbrain.jsonl  {"name","raw_area","city","county","addr","src","page","seq"}
中断可续跑：已存在的 page 跳过。"""
import sys, os, re, json, time, html

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H

BASE = "https://stbrain.kjt.zj.gov.cn/Public/CarrierList.aspx?code=HT"
OUT = os.path.join(HERE, "parts", "浙江省_stbrain.jsonl")
CITIES = ["杭州市", "宁波市", "温州市", "嘉兴市", "湖州市", "绍兴市", "金华市",
          "衢州市", "舟山市", "台州市", "丽水市"]
BADCOUNTY = {"", "市辖区", "市本级", "市区", "县", "本级"}


def clean(s):
    s = html.unescape(s or "")
    s = re.sub(r"<[^>]+>", "", s)
    s = s.replace("\u3000", " ").replace("\xa0", " ")
    s = re.sub(r"\s+", " ", s).strip()
    s = s.lstrip("|｜").strip()
    return s


def parse_rows(t):
    out = []
    for r in re.findall(r"(?is)<tr[^>]*>(.*?)</tr>", t):
        c = [clean(x) for x in re.findall(r"(?is)<t[dh][^>]*>(.*?)</t[dh]>", r)]
        if len(c) == 6 and re.fullmatch(r"\d+", c[0] or ""):
            out.append(c)
    return out


def split_area(raw):
    """'台州市温岭市' -> ('台州市','温岭市')；'杭州市' -> ('杭州市','')"""
    raw = (raw or "").strip()
    for c in CITIES:
        if raw.startswith(c):
            rest = raw[len(c):].strip()
            return c, ("" if rest in BADCOUNTY else rest)
    for c in CITIES:
        if c in raw:
            return c, ""
    return "", ""


def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    done = set()
    if os.path.exists(OUT):
        with open(OUT, encoding="utf-8") as fh:
            for line in fh:
                try:
                    done.add(json.loads(line)["page"])
                except Exception:
                    pass
    print("resume pages done:", len(done), flush=True)
    pages = list(range(0, 458))
    fout = open(OUT, "a", encoding="utf-8")
    nrow = 0
    for p in pages:
        if p in done:
            continue
        st, b, fu = H.get(f"{BASE}&filter=&city=&page={p}", timeout=30, tries=3, binary=True)
        if st != 200 or not b:
            print("FAIL page", p, st, flush=True)
            continue
        t = b.decode("utf-8", "replace")
        rr = parse_rows(t)
        if not rr:
            print("EMPTY page", p, flush=True)
            continue
        for c in rr:
            city, county = split_area(c[2])
            rec = {"seq": c[0], "name": c[1], "raw_area": c[2], "city": city,
                   "county": county, "addr": c[3], "src": BASE, "page": p}
            fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
            nrow += 1
        fout.flush()
        if p % 25 == 0:
            print("page", p, "rows", len(rr), "cum", nrow, flush=True)
    fout.close()
    print("DONE new rows", nrow, flush=True)


if __name__ == "__main__":
    main()
