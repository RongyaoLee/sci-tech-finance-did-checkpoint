# -*- coding: utf-8 -*-
"""将官方公示件中的 企业名称 -> 城市(地级)/区县 回填到主表，产出 <省>_city.csv。

规则:
- 城市只能来自官方名单自带的地区列（含县级值向设区市归并）。
- 名称匹配：先 (名称) 唯一，再 (名称+认证年度) 唯一；冲突留空。
"""
import os, sys, csv, io, json, re, collections

FILL = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.dirname(os.path.dirname(FILL))  # ...\xie\work
LISTS = os.path.dirname(FILL)                  # ...\xie\work\cert_lists

HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]


def norm_name(s):
    s = (s or "").strip()
    s = s.replace("\u3000", "").replace(" ", "")
    s = s.replace("（", "(").replace("）", ")")
    s = s.replace("．", ".").replace("·", "")
    return s.upper()


JX_CITY = {
    "南昌市": "南昌市", "南昌高新区": "南昌市", "南昌经开区": "南昌市",
    "景德镇市": "景德镇市", "景德镇高新区": "景德镇市",
    "萍乡市": "萍乡市",
    "九江市": "九江市", "共青城市": "九江市", "共青城高新区": "九江市", "九江经开区": "九江市",
    "新余市": "新余市", "新余高新区": "新余市",
    "鹰潭市": "鹰潭市", "鹰潭高新区": "鹰潭市",
    "赣州市": "赣州市", "瑞金市": "赣州市", "赣州高新区": "赣州市", "赣州经开区": "赣州市",
    "吉安市": "吉安市", "安福县": "吉安市", "吉安高新区": "吉安市",
    "宜春市": "宜春市", "丰城市": "宜春市", "丰城高新区": "宜春市", "樟树市": "宜春市", "高安市": "宜春市",
    "抚州市": "抚州市", "南城县": "抚州市", "抚州高新区": "抚州市",
    "上饶市": "上饶市", "鄱阳县": "上饶市", "上饶经开区": "上饶市",
    # 赣江新区 跨南昌/九江 -> 不判定
}

JX_CITY_LEVEL = {"南昌市", "景德镇市", "萍乡市", "九江市", "新余市", "鹰潭市",
                 "赣州市", "吉安市", "宜春市", "抚州市", "上饶市"}


def build(prov, rows_jsonl, out_csv, city_map, city_level, use_year=True):
    main = os.path.join(LISTS, prov + ".csv")
    with io.open(main, encoding="utf-8-sig", newline="") as f:
        rd = list(csv.reader(f))
    hdr, body = rd[0], rd[1:]
    print(prov, "main rows", len(body), "hdr", hdr)

    patches = collections.defaultdict(list)
    n_rows = 0
    for line in io.open(rows_jsonl, encoding="utf-8"):
        line = line.strip()
        if not line:
            continue
        r = json.loads(line)
        raw = (r.get("city") or "").strip()
        city = city_map.get(raw)
        if not city:
            continue
        county = "" if raw in city_level else raw
        year = str(r.get("year") or "").strip()
        patches[norm_name(r["name"])].append((city, county, year))
        n_rows += 1
    print(" patch rows", n_rows, "unique names", len(patches))

    # uniqueness check
    name_city = {}
    conflict = 0
    for k, v in patches.items():
        cs = {c for c, _, _ in v}
        if len(cs) == 1:
            name_city[k] = v[0][:2]
        else:
            conflict += 1
    print(" name-unique city", len(name_city), "conflicts", conflict)

    name_year = collections.defaultdict(set)
    for k, v in patches.items():
        for c, cnt, y in v:
            if y:
                name_year[(k, y)].add((c, cnt))

    filled = 0
    filled_names = set()
    rows_out = []
    for row in body:
        row = (row + [""] * 7)[:7]
        name = row[0]
        k = norm_name(name)
        city = county = ""
        if k in name_city:
            city, county = name_city[k]
        elif use_year:
            y = (row[4] or "").strip()
            hit = name_year.get((k, y))
            if hit and len(hit) == 1:
                city, county = list(hit)[0]
        if city:
            row[2], row[3] = city, county
            filled += 1
            filled_names.add(k)
        rows_out.append(row)

    os.makedirs(os.path.dirname(out_csv), exist_ok=True)
    with io.open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(HEADER)
        w.writerows(rows_out)
    print(" wrote", out_csv, "rows", len(rows_out), "with city", filled,
          "distinct firms", len(filled_names))
    cc = collections.Counter(r[2] for r in rows_out if r[2])
    print(" city dist", cc.most_common())


if __name__ == "__main__":
    build("江西省", os.path.join(FILL, "rows_江西_gongshi.jsonl"),
          os.path.join(FILL, "江西省_city.csv"), JX_CITY, JX_CITY_LEVEL)
