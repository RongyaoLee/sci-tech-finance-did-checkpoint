# -*- coding: utf-8 -*-
"""缺口画像：两省剩余无城市行按年度分布。"""
import io, sys, os, csv, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
ROOT = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists'

for prov, p in (('河北', os.path.join(ROOT, '河北省.csv')), ('河南', os.path.join(ROOT, '河南省.csv'))):
    rows = list(csv.DictReader(open(p, encoding='utf-8-sig', newline='')))
    empty = [x for x in rows if not (x['城市'] or '').strip()]
    print('==', prov, 'rows', len(rows), 'city', len(rows) - len(empty), 'empty', len(empty))
    c = collections.Counter(x['认定年度'] for x in empty)
    print('  empty by year', sorted(c.items()))
    c2 = collections.Counter(x['认定年度'] for x in rows)
    print('  all by year  ', sorted(c2.items()))
