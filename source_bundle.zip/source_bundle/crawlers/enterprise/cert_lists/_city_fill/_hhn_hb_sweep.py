# -*- coding: utf-8 -*-
"""扫河北省级 151 条目录里的「公布/公示名单」页，下载所有附件，检测是否含地区列。"""
import io, sys, os, re, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
enum = json.load(open(os.path.join(BASE, '_hb_enum.json'), encoding='utf-8'))
CITYWORDS = ['石家庄', '唐山', '秦皇岛', '邯郸', '邢台', '保定', '张家口', '承德', '沧州', '廊坊', '衡水', '定州', '辛集']
SKIP = ('更名', '搬迁', '取消', '专家', '申报认定工作', '培训', '遴选', '审计', '博览会', '杨凌')
cands = [e for e in enum if not any(s in e['title'] for s in SKIP)]
print('candidates', len(cands))

rep = []
for e in cands:
    st, txt, fu = H.get(e['url'], timeout=30)
    if st != 200:
        print('FAIL', st, e['title'][:40]); continue
    docs = H.doc_links(H.img_links(txt, fu), fu)
    line = ['PAGE', e['title'][:46], 'docs=%d' % len(docs)]
    rep.append({'title': e['title'], 'url': e['url'], 'docs': [d for d, t in docs]})
    for d, t in docs:
        st2, data, _ = H.get(d, timeout=120, binary=True)
        if st2 != 200 or not data:
            line.append('  fail %s' % d.split('/')[-1][:40]); continue
        dt = H.doc_text(d, data)
        certs = H.certs_in_text(dt)
        cityhit = [c for c in CITYWORDS if c in dt]
        line.append('  %-42s chars=%-7d certs=%-5d cityhit=%d %s' % (
            d.split('/')[-1][:42], len(dt), len(certs), len(cityhit), ','.join(cityhit[:4])))
        if cityhit:
            fn = os.path.join(BASE, 'raw', 'hb_hit_%s' % re.sub(r'[^\w.]', '_', d.split('/')[-1])[:60])
            open(fn, 'wb').write(data)
    print('\n'.join(line))
json.dump(rep, open(os.path.join(BASE, '_hb_docs.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
