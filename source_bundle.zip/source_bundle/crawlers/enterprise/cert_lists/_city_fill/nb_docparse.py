# -*- coding: utf-8 -*-
"""Word97(.doc) 文本抽取：解析 FIB -> CLX piece table，还原正文字符流（含中文）。"""
import struct


def _read_stream(path, name="WordDocument"):
    import olefile
    ole = olefile.OleFileIO(path)
    data = ole.openstream(name).read()
    table_name = "1Table"
    wd = ole.openstream("WordDocument").read()
    flags = struct.unpack("<H", wd[0x0A:0x0C])[0]
    if not (flags & 0x0200):
        table_name = "0Table"
    try:
        table = ole.openstream(table_name).read()
    except Exception:
        table = b""
    ole.close()
    return wd, table


def doc_text(path):
    wd, table = _read_stream(path)
    if len(wd) < 0x01AA:
        return ""
    fcClx, lcbClx = struct.unpack("<II", wd[0x01A2:0x01AA])
    clx = table[fcClx:fcClx + lcbClx]
    # 跳过 Prc
    i = 0
    while i < len(clx) and clx[i] == 0x01:
        cb = struct.unpack("<H", clx[i + 1:i + 3])[0]
        i += 3 + cb
    if i >= len(clx) or clx[i] != 0x02:
        return ""
    lcb = struct.unpack("<I", clx[i + 1:i + 5])[0]
    pcd = clx[i + 5:i + 5 + lcb]
    n = (lcb - 4) // 12
    cps = [struct.unpack("<I", pcd[j * 4:j * 4 + 4])[0] for j in range(n + 1)]
    out = []
    for k in range(n):
        off = (n + 1) * 4 + k * 8
        fc = struct.unpack("<I", pcd[off + 2:off + 6])[0]
        cch = cps[k + 1] - cps[k]
        if fc & 0x40000000:
            real = (fc & 0x3FFFFFFF) // 2
            raw = wd[real:real + cch]
            out.append(raw.decode("gbk", "ignore"))
        else:
            raw = wd[fc:fc + cch * 2]
            out.append(raw.decode("utf-16-le", "ignore"))
    return "\n".join(out)


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    p = sys.argv[1]
    t = doc_text(p)
    print(len(t))
    print(t[:2000])
