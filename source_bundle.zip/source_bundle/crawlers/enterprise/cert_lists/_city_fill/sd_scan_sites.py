# -*- coding: utf-8 -*-
"""扫山东各市科技局/门户：找『高新技术企业名单』类文章与附件。仅探查，产出报告。"""
import sys, re, os, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_lib as S

HOSTS = {
    "淄博": ["kjj.zibo.gov.cn", "www.zibo.gov.cn"],
    "枣庄": ["kjj.zaozhuang.gov.cn", "www.zaozhuang.gov.cn"],
    "东营": ["kjj.dongying.gov.cn", "www.dongying.gov.cn"],
    "烟台": ["kjj.yantai.gov.cn", "www.yantai.gov.cn"],
    "潍坊": ["kjj.weifang.gov.cn", "www.weifang.gov.cn"],
    "济宁": ["jnkj.jining.gov.cn", "www.jining.gov.cn"],
    "泰安": ["kjj.taian.gov.cn", "www.taian.gov.cn"],
    "威海": ["kjj.weihai.gov.cn", "www.weihai.gov.cn"],
    "日照": ["kjj.rizhao.gov.cn", "www.rizhao.gov.cn"],
    "临沂": ["kjj.linyi.gov.cn", "www.linyi.gov.cn"],
    "德州": ["kjj.dezhou.gov.cn", "www.dezhou.gov.cn"],
    "聊城": ["kjj.liaocheng.gov.cn", "www.liaocheng.gov.cn"],
    "滨州": ["kjj.binzhou.gov.cn", "www.binzhou.gov.cn"],
    "菏泽": ["kjj.heze.gov.cn", "www.heze.gov.cn"],
}

COL_PAT = re.compile(r"通知公告|公示公告|公告公示|通知|公告|公示|政务公开|信息公开|科技动态|工作动态|政策文件|申报")
ART_PAT = re.compile(r"/\d{5,}/\d{12,}\.html|/art/\d{4}/\d{1,2}/\d{1,2}/art_\d+_\d+\.html|/art/\d{4}/\d+/\d+/art_\d+_\d+\.html|t\d{8}_\d+\.html")
GX_ART = re.compile(r"高新")
NAMEISH = re.compile(r"名单|公示|公布|认定|备案|奖励|补助|资助")


def col_links(html, base):
    out, seen = [], set()
    for u, t in S.H.img_links(html, base):
        t = t.strip()
        if not t or len(t) > 24:
            continue
        if COL_PAT.search(t) and S.urlparse(u).netloc and u not in seen:
            if re.search(r"\.(pdf|xls|xlsx|doc|docx|zip)$", u.lower()):
                continue
            seen.add(u)
            out.append((u, t))
    return out[:14]


def arts_of(html, base):
    out = []
    for u, t in S.H.img_links(html, base):
        t = t.strip()
        if len(t) < 8:
            continue
        if ART_PAT.search(u) and GX_ART.search(t):
            out.append((u, t))
    return out


def main(cities):
    rep = {}
    for city, hosts in HOSTS.items():
        if cities and city not in cities:
            continue
        info = {"cols": [], "arts": [], "notes": []}
        for h in hosts:
            sc, html, fin = S.get("http://%s/" % h, tries=2, timeout=25)
            if sc != 200 or len(html) < 500:
                info["notes"].append("home %s -> %s" % (h, sc))
                continue
            info["notes"].append("home %s ok len=%d" % (h, len(html)))
            for cu, ct in col_links(html, fin):
                info["cols"].append([ct, cu])
                sc2, h2, f2 = S.get(cu, tries=1, timeout=25)
                if sc2 != 200:
                    continue
                a = arts_of(h2, f2)
                for au, at in a:
                    info["arts"].append([at, au])
            break
        rep[city] = info
        print(city, "cols", len(info["cols"]), "arts", len(info["arts"]), flush=True)
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_sd_scan.json")
    json.dump(rep, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("saved", p)


if __name__ == "__main__":
    main(sys.argv[1:])
