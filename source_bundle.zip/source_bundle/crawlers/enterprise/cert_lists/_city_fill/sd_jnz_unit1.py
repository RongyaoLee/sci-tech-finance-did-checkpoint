# -*- coding: utf-8 -*-
"""破解 jpaas unitbuild 列表接口（济南市科技局）。"""
import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import sd_jnz_lib as L
import requests, time, random

BASEURL = "http://jnsti.jinan.gov.cn/api-gateway/jpaas-publish-server/front/page/build/unit"
D = {"parseType": "bulidstatic", "webId": "10", "tplSetId": "GbnFskR3C7PD0nABf9KzT",
     "pageType": "column", "tagId": "信息列表", "editType": "null", "pageId": "13061"}

def show(tag, st, body):
    n = len(body or "")
    arts = re.findall(r"art_[0-9a-f]+\.html", body or "")
    print("%-28s st=%s len=%d arts=%d" % (tag, st, n, len(set(arts))))
    return body

res = {}
# 1) GET query
for pg in ["1", "2"]:
    p = dict(D); p["pageNo"] = pg
    u = BASEURL + "?" + "&".join("%s=%s" % (k, requests.utils.quote(str(v))) for k, v in p.items())
    st, body, final = L.get(u)
    res["GET_pageNo_" + pg] = (st, body)
    show("GET pageNo=" + pg, st, body)

# 2) POST form
for pgkey in ["pageNo", "currentPage", "pageNum", "page"]:
    for pg in ["1", "2"]:
        p = dict(D); p[pgkey] = pg
        try:
            r = requests.post(BASEURL, data=p, timeout=25,
                              headers={"User-Agent": random.choice(L.UAS), "Referer": "http://jnsti.jinan.gov.cn/col/col13061/index.html"})
            res["POST_%s_%s" % (pgkey, pg)] = (r.status_code, r.text)
            show("POST %s=%s" % (pgkey, pg), r.status_code, r.text)
        except Exception as e:
            print("POST", pgkey, pg, "ERR", type(e).__name__, str(e)[:60])
        time.sleep(0.6)

out = {}
for k, (st, b) in res.items():
    out[k] = {"st": st, "len": len(b or ""), "head": (b or "")[:1500]}
json.dump(out, open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_unit1.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
