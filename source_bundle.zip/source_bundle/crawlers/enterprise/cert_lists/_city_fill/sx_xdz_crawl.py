# -*- coding: utf-8 -*-
import sys, os, re, json, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf
sys.path.insert(0, HERE)
from sx_chan import items_of

def crawl(tpl, n):
    seen, res = set(), []
    for i in range(1, n + 1):
        url = tpl.format(i)
        h, f = cf.get(url, tries=1, timeout=20)
        if not h or len(h) < 2000:
            break
        got = 0
        for tx, u, d in items_of(h, f):
            if u in seen:
                continue
            seen.add(u)
            res.append({"t": tx, "u": u, "d": d})
            got += 1
        if got == 0:
            break
    return res

res = crawl("http://xdz.xa.gov.cn/xwzx/tzgg/{0}.html", 120)
json.dump(res, open(os.path.join(HERE, "_sx_list_xdz.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
hit = [r for r in res if re.search(r"高新|高企|认定|证书", r["t"])]
print("total", len(res), "hit", len(hit))
for r in hit:
    print(r["d"], "|", r["t"][:70], "|", r["u"])
