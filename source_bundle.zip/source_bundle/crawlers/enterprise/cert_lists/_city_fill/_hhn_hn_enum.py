# -*- coding: utf-8 -*-
"""枚举河南/河北科技厅「高新技术企业」公示页（search API）。"""
import io, sys, os, re, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from urllib.parse import quote

BASE = os.path.dirname(os.path.abspath(__file__))

def api(host, site, kw, page=1, size=50):
    u = ('https://%s/open/api/external-new?keywords=%s&siteId=%s'
         '&searchRange=-1000&sortType=150&pageNumber=%d&pageSize=%d' % (host, quote(kw), site, page, size))
    st, txt, fu = H.get(u, timeout=30)
    if st != 200:
        return st, None
    try:
        return st, json.loads(txt)
    except Exception:
        return st, None

def enum(host, site, kws, tag):
    seen = {}
    for kw in kws:
        for page in range(1, 12):
            st, j = api(host, site, kw, page, 50)
            if not j or j.get('code') not in (1, 200, '200', '1'):
                print('  stop', kw, page, st, (j or {}).get('message'))
                break
            d = j.get('data') or {}
            datas = d.get('datas') or []
            total = d.get('totalRow')
            print('  %s p%d got %d total=%s' % (kw, page, len(datas), total))
            if not datas:
                break
            for it in datas:
                t = (it.get('title') or '').strip()
                if '高新技术企业' not in t:
                    continue
                seen[str(it.get('id'))] = {'id': str(it.get('id')), 'title': t,
                                            'url': it.get('selfUrl') or it.get('outUrl'),
                                            'date': (it.get('pubDate') or '')[:10],
                                            'summary': (it.get('summary') or '')[:120]}
            if total and page * 50 >= int(total):
                break
    out = os.path.join(BASE, '_%s_enum.json' % tag)
    json.dump(sorted(seen.values(), key=lambda x: x['date']), open(out, 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    print('== %s: %d pages saved -> %s' % (tag, len(seen), out))
    for v in sorted(seen.values(), key=lambda x: x['date']):
        print('   ', v['date'], v['title'][:60], v['url'])
    return seen

print('#### HENAN')
enum('searchapi.henan.gov.cn', '4500000004',
     ['拟认定高新技术企业', '高新技术企业名单', '高新技术企业备案'], 'hn')
