# -*- coding: utf-8 -*-
"""江西: download every 拟申请备案 公示 attachment, parse (企业名称, 信用代码, 所在地)."""
import os, sys, re, json, io, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf, requests
requests.packages.urllib3.disable_warnings()

FILL = os.path.dirname(os.path.abspath(__file__))
ROWS = os.path.join(FILL, "rows_江西_gongshi.jsonl")
LOG = os.path.join(FILL, "_jx_rows.log")
BASE = "https://kjt.jiangxi.gov.cn"
SKIP = re.compile(r"众创空间|孵化器|新型研发机构|文化和科技融合|示范基地")

NAME_H = ("企业名称", "企业 名称")
CITY_H = ("所在地", "区域名称", "所在市", "设区市", "所属市", "地市", "所在地区")
CODE_H = ("统一社会信用代码", "信用代码")


def log(m):
    line = time.strftime("%H:%M:%S ") + str(m)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line, flush=True)


def clean(v):
    if v is None:
        return ""
    s = str(v).replace("\u3000", " ").replace("\n", " ").strip()
    return re.sub(r"\s+", " ", s)


def parse_table(rows2d):
    """rows2d: list of list[str]; returns list of dict(name, code, city)."""
    hdr_i, cmap = None, {}
    for i, r in enumerate(rows2d[:12]):
        cells = [clean(c) for c in r]
        joined = "|".join(cells)
        if any(h in joined for h in NAME_H):
            nm = next((j for j, c in enumerate(cells) if any(h in c for h in NAME_H)), None)
            ct = next((j for j, c in enumerate(cells) if any(h in c for h in CITY_H)), None)
            cd = next((j for j, c in enumerate(cells) if any(h in c for h in CODE_H)), None)
            if nm is not None and ct is not None:
                hdr_i, cmap = i, {"name": nm, "city": ct, "code": cd}
                break
    if hdr_i is None:
        return []
    out = []
    for r in rows2d[hdr_i + 1:]:
        cells = [clean(c) for c in r]
        if len(cells) <= max(cmap["name"], cmap["city"]):
            continue
        name = cells[cmap["name"]]
        city = cells[cmap["city"]]
        code = cells[cmap["code"]] if cmap["code"] is not None and cmap["code"] < len(cells) else ""
        if not name or name in ("企业名称",) or len(name) < 3:
            continue
        if not city:
            continue
        out.append({"name": name, "city": city, "code": code})
    return out


def xlsx_rows(path):
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    allout = []
    for ws in wb.worksheets:
        rows2d = []
        for row in ws.iter_rows(values_only=True):
            rows2d.append([clean(v) for v in row])
        got = parse_table(rows2d)
        if got:
            allout.extend(got)
    return allout


def xls_rows(path):
    import xlrd
    wb = xlrd.open_workbook(path)
    allout = []
    for sh in wb.sheets():
        rows2d = [[clean(sh.cell_value(r, c)) for c in range(sh.ncols)] for r in range(sh.nrows)]
        got = parse_table(rows2d)
        if got:
            allout.extend(got)
    return allout


CITYSET = ("南昌市", "景德镇市", "萍乡市", "九江市", "新余市", "鹰潭市", "赣州市",
           "吉安市", "宜春市", "抚州市", "上饶市", "赣江新区")


def pdf_rows(path):
    import pymupdf
    d = pymupdf.open(path)
    out = []
    buf = []
    for pno in range(d.page_count):
        txt = d[pno].get_text("text")
        for ln in txt.splitlines():
            L = clean(ln)
            if L:
                buf.append(L)
    # rows appear as: 序号, 企业名称, [信用代码], 所在地 — newline separated
    i = 0
    while i < len(buf) - 2:
        if re.fullmatch(r"\d{1,5}", buf[i]):
            name = buf[i + 1]
            # look ahead up to 3 cells for a city
            for k in (i + 2, i + 3):
                if k < len(buf) and buf[k] in CITYSET and len(name) >= 3 and not name.isdigit():
                    out.append({"name": name, "city": buf[k], "code": ""})
                    i = k
                    break
        i += 1
    return out


def docx_rows(path):
    import docx
    d = docx.Document(path)
    out = []
    for tb in d.tables:
        rows2d = [[clean(c.text) for c in r.cells] for r in tb.rows]
        out.extend(parse_table(rows2d))
    return out


def handle(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in (".xlsx", ".xlsm"):
            return xlsx_rows(path)
        if ext == ".xls":
            return xls_rows(path)
        if ext == ".pdf":
            return pdf_rows(path)
        if ext == ".docx":
            return docx_rows(path)
    except Exception as e:
        log("   parse ERR %s %s" % (os.path.basename(path), e))
    return []


def main():
    open(LOG, "w", encoding="utf-8").close()
    arts = json.load(io.open(os.path.join(FILL, "_jx_gongshi.json"), encoding="utf-8"))
    arts = [a for a in arts if a["title"] and not SKIP.search(a["title"])]
    log("pages to process: %d" % len(arts))
    tot = 0
    with io.open(ROWS, "w", encoding="utf-8") as fout:
        for a in arts:
            url = BASE + a["url"] if a["url"].startswith("/") else a["url"]
            ym = re.search(r"(\d{4})年", a["title"])
            year = ym.group(1) if ym else ""
            pc = ""
            m = re.search(r"第([一二三四五六七八九十]+)批", a["title"])
            if m:
                pc = "第%s批" % m.group(1)
            elif "补充" in a["title"]:
                pc = "补充"
            log("%s | %s" % (a["pubDate"], a["title"][:58]))
            html, final = cf.get(url)
            if not html:
                log("   page FAIL")
                continue
            atts = cf.attachments(url, html)
            if not atts:
                # some 公示 put the list inline
                log("   no attachment")
                continue
            got_any = 0
            for text, u in atts:
                p = cf.download(u, "jx")
                if not p:
                    log("   dl FAIL", u)
                    continue
                rows = handle(p)
                got_any += len(rows)
                log("   %-40s %-6s %d rows" % (text[:40], os.path.splitext(p)[1], len(rows)))
                for r in rows:
                    rec = dict(r, year=year, batch=pc, src=url,
                               att=os.path.basename(u), pubdate=a["pubDate"])
                    fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
                fout.flush()
            tot += got_any
            log("   subtotal %d (accum %d)" % (got_any, tot))
    log("DONE total rows %d -> %s" % (tot, ROWS))


if __name__ == "__main__":
    main()
