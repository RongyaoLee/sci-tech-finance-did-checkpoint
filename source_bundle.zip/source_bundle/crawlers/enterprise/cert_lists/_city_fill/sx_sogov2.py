# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

h, _ = cf.get("https://p.so-gov.cn/web/api/query.js")
print("len", len(h) if h else h)
if h:
    for line in h.split("\n"):
        if re.search(r"basic\s*\+|\.basic|url\s*[:=]\s*['\"]|/api|path\s*[:=]", line):
            print("Q>", line.strip()[:200])
h2, _ = cf.get("https://p.so-gov.cn/web/api/api.js")
print("api.js len", len(h2) if h2 else h2)
if h2:
    for line in h2.split("\n"):
        if re.search(r"/api|url\s*[:=]", line):
            print("A>", line.strip()[:200])
