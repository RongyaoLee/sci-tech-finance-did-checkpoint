# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

URLS = [
    "https://kjt.shaanxi.gov.cn/kjdt/tzgg/202401/t20240119_3382989.html",
    "https://kjt.shaanxi.gov.cn/kjdt/tzgg/202401/t20240105_3382974.html",
    "https://kjt.shaanxi.gov.cn/kjdt/tzgg/202302/t20230201_3382541.html",
]
for u in URLS:
    h, f = cf.get(u, tries=1, timeout=25)
    print("=====", u, "len", len(h) if h else 0)
    if not h:
        continue
    s = cf.soup_of(h)
    for t in s(["script", "style"]):
        t.decompose()
    txt = re.sub(r"\n{2,}", "\n", s.get_text("\n", strip=True))
    i = txt.find("关于领取")
    print(txt[i:i + 1400] if i >= 0 else txt[:1200])
    for a in cf.attachments(u, h):
        print("   ATT", a[0][:60], "|", a[1])
