# -*- coding: utf-8 -*-
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sx_harvest as H

T = [
    {"city": "咸阳市", "year": "2024", "batch": "",
     "url": "https://kjj.xianyang.gov.cn/kjxw/tztg/202410/t20241018_1823764.html",
     "note": "咸阳市科技局新闻《咸阳29家企业成功认定！》，标题明确本市"},
    {"city": "榆林市", "year": "2019", "batch": "第一批",
     "url": "https://kjj.yl.gov.cn/kjdt/tzgg/201910/t20191028_774874.html",
     "note": "榆林市科技局《我市18家企业进入2019年第一批高新技术企业认定公示名单》"},
]
for t in T:
    names, atts = H.names_from_html(t["url"])
    print("==", t["city"], len(names), "atts", len(atts))
    print("   ", names[:10])
    for a in atts[:8]:
        print("   ATT", a[0][:50], "|", a[1])
    if names:
        print("   WROTE", H.write_rows(names, t["city"], t["year"], t["batch"], t["url"], t["note"]))
