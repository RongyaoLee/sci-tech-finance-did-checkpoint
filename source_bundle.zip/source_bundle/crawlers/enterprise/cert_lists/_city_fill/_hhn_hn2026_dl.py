# -*- coding: utf-8 -*-
import io, sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from _hhn_hn_crawl2 import doc_text_heur, CITY_SET

U = 'https://xcoss.henan.gov.cn/typtfile/20261106/a13a50f6cb0543eda2e28af40d61436b.pdf'
for u in (U, U.replace('https://', 'http://')):
    st, data, fu = H.get(u, timeout=180, binary=True)
    print(u[:60], st, len(data or b''))
    if st == 200 and data and len(data) > 5000:
        open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_hn2026p1.pdf'), 'wb').write(data)
        t = H.doc_text(u, data)
        print('chars', len(t))
        print(re.sub(r'\n{2,}', '\n', t[:600]))
        break
