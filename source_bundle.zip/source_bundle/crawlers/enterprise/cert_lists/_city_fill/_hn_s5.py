﻿# -*- coding: utf-8 -*-
import os,sys,re
sys.path.insert(0,os.getcwd())
import cf
q="高新技术企业认定名单"
for u in ["http://searching.hunan.gov.cn/hunan/all/news","http://searching.hunan.gov.cn/hunan/all","http://searching.hunan.gov.cn/hunan/0/news"]:
    try:
        r=cf.S.get(u,params={"q":q},timeout=30); r.encoding="utf-8"
        print("==",u,r.status_code,len(r.text),"hits",r.text.count("高新技术企业"))
        doms=set(re.findall(r'https?://([a-z0-9\.\-]+\.gov\.cn)',r.text))
        print("  doms:",sorted(doms)[:15])
    except Exception as e:
        print(u,"ERR",type(e).__name__,str(e)[:80])
