# -*- coding: utf-8 -*-
"""Enumerate 陕西 高企 公示/公布 notices from 专题 list; extract (name, creditcode) tables."""
import requests, urllib3, re, os, io, json, time
urllib3.disable_warnings()
BASE = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill'
RAW = os.path.join(BASE, 'raw')
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})


def get(u, bin=False):
    try:
        r = s.get(u, timeout=60, verify=False)
    except Exception as e:
        return 0, (b'' if bin else ''), str(e)[:70]
    if r.status_code != 200:
        return r.status_code, (b'' if bin else ''), ''
    if bin:
        return 200, r.content, r.url
    r.encoding = r.apparent_encoding or 'utf-8'
    return 200, r.text, r.url


def page_tables(content, fn):
    low = fn.lower()
    out = []
    if low.endswith('.docx'):
        from docx import Document
        d = Document(io.BytesIO(content))
        for tb in d.tables:
            out.append([[c.text.strip() for c in row.cells] for row in tb.rows])
    elif low.endswith(('.xlsx', '.et')):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
        for ws in wb.worksheets:
            out.append([[('' if c is None else str(c).strip()) for c in row] for row in ws.iter_rows(values_only=True)])
    elif low.endswith('.xls'):
        import xlrd
        wb = xlrd.open_workbook(file_contents=content)
        for ws in wb.sheets():
            out.append([[str(ws.cell_value(i, j)).strip() for j in range(ws.ncols)] for i in range(ws.nrows)])
    elif low.endswith('.doc'):
        import olefile
        of = olefile.OleFileIO(io.BytesIO(content))
        dec = of.openstream('WordDocument').read().decode('utf-16-le', 'ignore')
        runs = re.findall(r'[\u4e00-\u9fa5A-Za-z0-9（）()]{2,}', dec)
        out.append([['RUNS'] + runs])
    elif low.endswith('.pdf'):
        import fitz
        doc = fitz.open(stream=content, filetype='pdf')
        txt = '\n'.join(pg.get_text() for pg in doc)
        out.append([['TXT'] + txt.split('\n')])
    return out


def norm_code(c):
    c = re.sub(r'\s', '', str(c)).upper()
    return c if re.fullmatch(r'[0-9A-Z]{18}', c) else ''


res = []
notices = json.load(open(os.path.join(RAW, '_sxgqrd.json'), encoding='utf-8'))
pairs = notices if isinstance(notices, list) else list(notices.items())
base = 'https://kjt.shaanxi.gov.cn/kjdt/ztzl/lszt/gqrd/'
import urllib.parse
todo = []
for item in pairs:
    title, href = (item[0], item[1]) if isinstance(item, (list, tuple)) else (item, notices[item])
    if not re.search(r'(拟认定|公布.*高新技术企业名单|高新技术企业名单)', title):
        continue
    url = urllib.parse.urljoin(base, href)
    if 'kjt.shaanxi.gov.cn' not in url:
        url = urllib.parse.urljoin('https://kjt.shaanxi.gov.cn/kjdt/tzgg/', href)
    todo.append((title, url))
print('notices to fetch', len(todo))
for title, url in todo:
    st, t, fu = get(url)
    print('==', title[:60], st, len(t))
    if st != 200:
        continue
    b = fu.rsplit('/', 1)[0] + '/'
    for m in re.finditer(r'href=[\'"]([^\'"]+\.(?:pdf|docx?|xlsx?|et))[\'"]', t, re.I):
        h = m.group(1)
        a = h if h.startswith('http') else (('https://kjt.shaanxi.gov.cn' + h) if h.startswith('/') else urllib.parse.urljoin(b, h))
        st2, c2, _ = get(a, bin=True)
        if st2 != 200:
            print('   skip', a, st2); continue
        fn = a.rsplit('/', 1)[-1]
        open(os.path.join(RAW, 'sx_' + fn), 'wb').write(c2)
        try:
            tbs = page_tables(c2, fn)
        except Exception as e:
            print('   parse ERR', fn, str(e)[:60]); continue
        for tb in tbs[:1]:
            if not tb:
                continue
            print('   ==', fn, 'rows', len(tb), 'hdr', [str(x)[:18] for x in tb[0]][:6])
            got = 0
            hdr = ' '.join(str(x) for x in tb[0])
            if 'RUNS' in hdr:
                continue
            for row in tb[1:]:
                cells = [str(x).strip() for x in row]
                code = next((norm_code(c) for c in cells if norm_code(c)), '')
                nm = next((c for c in cells if re.search(r'[\u4e00-\u9fa5]{4,}(公司|院|中心|厂|集团|研究所)', c)), '')
                if nm:
                    res.append({'name': nm, 'code': code, 'src': url, 'title': title})
                    got += 1
            print('      extracted', got)
    time.sleep(0.5)
json.dump(res, open(os.path.join(RAW, '_sx_gongshi_codes.json'), 'w', encoding='utf-8'), ensure_ascii=False)
print('TOTAL extracted', len(res), 'with code', sum(1 for r in res if r['code']))
