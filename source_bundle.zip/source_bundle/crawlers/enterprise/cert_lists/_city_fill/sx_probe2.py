# -*- coding: utf-8 -*-
import sys, os, re, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

out = {}

def probe(url, key):
    h, u = cf.get(url)
    d = {"len": len(h) if h else h, "final": u}
    if h:
        s = cf.soup_of(h)
        links = []
        for a in s.find_all("a", href=True):
            tx = a.get_text(" ", strip=True)
            if tx:
                links.append((tx[:40], a["href"][:200]))
        d["links"] = links[:80]
        d["scripts"] = re.findall(r'src=["\']([^"\']+\.js[^"\']*)["\']', h)[:30]
        d["text"] = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", h))[:1500]
    out[key] = d

probe("https://kjt.shaanxi.gov.cn/zwfw/", "zwfw")
probe("http://ywgl.sstrc.com/", "ywgl")
json.dump(out, open(os.path.join(HERE, "_sx_probe2.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("ok")
