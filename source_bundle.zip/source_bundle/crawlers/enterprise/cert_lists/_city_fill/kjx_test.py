# -*- coding: utf-8 -*-
"""Hit-rate test: 科小 (name -> 区划码) joins how many 湖南省.csv rows?"""
import os, sys, collections, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf, city_common as cc
from kjx_parse import parse_pdf

rows = []
for p in sorted(glob.glob(os.path.join(cf.CACHE, "att", "kjx_*.pdf"))):
    rows += parse_pdf(p)
kj = collections.defaultdict(set)
for name, code in rows:
    kj[name].add(code[:4])

prov, _ = cc.read_prov("湖南省")
hit = 0
by_year = collections.Counter()
for r in prov:
    nm = cc.norm_name(r["企业名称"])
    if nm in kj:
        hit += 1
        by_year[r["认定年度"]] += 1
print("科小 names", len(rows), "uniq", len(kj))
print("province rows", len(prov), "hit", hit, "%.1f%%" % (100.0 * hit / len(prov)))
print("hit by year", dict(sorted(by_year.items())))
miss = collections.Counter(r["认定年度"] for r in prov if cc.norm_name(r["企业名称"]) not in kj)
print("miss by year", dict(sorted(miss.items())))
