# -*- coding: utf-8 -*-
"""从 OLE .doc 里用启发式抽出表格文本（WordDocument 流按 UTF-16LE 解，保留 CJK/数字/常见标点）。"""
import io, sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

KEEP = re.compile(r'[\u4e00-\u9fff0-9A-Za-z（）()％%．\.\-—_·、,，:：;；]')

def doc_text_heuristic(path):
    import olefile
    ole = olefile.OleFileIO(path)
    raw = ole.openstream('WordDocument').read()
    ole.close()
    t = raw.decode('utf-16-le', 'ignore')
    # 只保留可读字符，其余当分隔
    out = []
    buf = []
    for ch in t:
        if KEEP.match(ch):
            buf.append(ch)
        else:
            if len(buf) >= 2:
                out.append(''.join(buf))
            buf = []
    if len(buf) >= 2:
        out.append(''.join(buf))
    return '\n'.join(out)

if __name__ == '__main__':
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_hn2024p4.bin')
    t = doc_text_heuristic(p)
    print('chars', len(t))
    print('has 所属地市', '所属地市' in t, '所在地域', '所在地域' in t)
    print(t[:1200])
    print('--- idx 序号', [m.start() for m in re.finditer('序号', t)][:5])
    i = t.find('所属地市')
    print('CTX:', t[max(0, i-200):i+900])
