# -*- coding: utf-8 -*-
"""通用：官方公布件（html/表格内嵌/pdf/doc/docx/xls/xlsx）-> (企业名称,证书编号,城市,区县)。

原则：城市只能来自公布件自带的地区列，或发布主体本身就是某市（default_city）。
解析不出就留空，绝不推断。
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.dirname(os.path.dirname(HERE))
CITYJSON = os.path.join(WORK, "cert_lists", "cities.json")
sys.path.insert(0, HERE)

import harvest as H  # noqa: E402

PROV_CODE = {
    "辽宁省": "21", "吉林省": "22", "黑龙江省": "23", "广西壮族自治区": "45",
    "甘肃省": "62", "贵州省": "52", "内蒙古自治区": "15", "海南省": "46",
    "宁夏回族自治区": "64", "福建省": "35", "云南省": "53",
    "新疆维吾尔自治区": "65", "西藏自治区": "54",
}

_CITY_CACHE = None


def _load_cities():
    global _CITY_CACHE
    if _CITY_CACHE is None:
        with open(CITYJSON, encoding="utf-8") as f:
            _CITY_CACHE = json.load(f)
    return _CITY_CACHE


EXTRA = {
    "海南省": ["五指山市", "琼海市", "文昌市", "万宁市", "东方市", "定安县", "屯昌县",
             "澄迈县", "临高县", "白沙黎族自治县", "昌江黎族自治县", "乐东黎族自治县",
             "陵水黎族自治县", "保亭黎族苗族自治县", "琼中黎族苗族自治县", "洋浦经济开发区"],
    "辽宁省": ["沈抚示范区", "沈抚新区"],
    "甘肃省": ["兰州新区"],
    "贵州省": ["贵安新区"],
    "新疆维吾尔自治区": ["石河子市", "阿拉尔市", "图木舒克市", "五家渠市", "北屯市",
                    "铁门关市", "双河市", "可克达拉市", "昆玉市", "胡杨河市", "新星市"],
}


def _core(name):
    n = name
    for s in ("特别行政区", "自治区", "自治州", "自治县", "自治旗"):
        if n.endswith(s):
            n = n[: -len(s)]
    for s in ("地区", "林区", "市", "盟", "县", "区", "旗"):
        if n.endswith(s) and len(n) > 2:
            n = n[: -len(s)]
            break
    return n


def allowed_cities(prov):
    code = PROV_CODE.get(prov)
    out = []
    for c in _load_cities():
        nm = c.get("name")
        if c.get("provinceCode") == code and nm not in (None, "", "市辖区", "县",
                                                        "省直辖县级行政区划", "自治区直辖县级行政区划"):
            out.append(nm)
    for e in EXTRA.get(prov, []):
        if e not in out:
            out.append(e)
    return out


_ALIAS_CACHE = {}


def _alias(prov):
    if prov in _ALIAS_CACHE:
        return _ALIAS_CACHE[prov]
    m = {}
    for name in allowed_cities(prov):
        m[name] = name
        m[_core(name)] = name
    _ALIAS_CACHE[prov] = m
    return m


def norm_city(prov, raw, strict=False):
    if not raw:
        return ""
    t = re.sub(r"\s|　", "", str(raw))
    t = t.replace("（", "(").replace("）", ")").strip(".。:：;；")
    if not t or t in ("-", "—", "/", "无", "合计", "小计", "其他", "其它"):
        return ""
    al = _alias(prov)
    if t in al:
        return al[t]
    c = _core(t)
    if c in al:
        return al[c]
    m = re.match(r"^([^\(\)]{2,12})\(([^\)]{2,20})\)$", t)
    if m:
        b = norm_city(prov, m.group(1))
        if b:
            return b
    for sep in ("/", "、", "|", "，", ","):
        if sep in t:
            b = norm_city(prov, t.split(sep)[0])
            if b:
                return b
    if not strict and re.search(r"(市|盟|自治州|地区|新区|示范区)$", t) and 2 <= len(t) <= 15:
        return t
    return ""


NAME_KEYS = ("企业名称", "单位名称", "公司名称", "企业名", "认定企业名称", "企 业 名 称")
CERT_KEYS = ("证书编号", "高企证书编号", "证书号", "证书编码", "证书 编号", "编号")
CITY_KEYS = ("所属市", "所属地市", "所在市", "所属地区", "所在地市", "地市", "盟市",
             "市(州)", "市（州）", "地区", "城市", "所在地", "区域", "行政区划",
             "所属盟市", "所属州市", "州市", "市地", "地州市", "市州", "市（州）",
             "所在盟市", "盟市名称", "市(地)", "市（地）")
COUNTY_KEYS = ("区县", "所属区县", "县(市、区)", "县（市、区）", "区(市)县", "所在区县",
               "县区", "所属县区", "区(县)", "所属区(县)", "县(市)", "县级")


def _find_col(header, keys, exclude=()):
    norm = [re.sub(r"\s", "", h or "") for h in header]
    ex = set(re.sub(r"\s", "", e) for e in exclude)
    for i, hs in enumerate(norm):
        if not hs or hs in ex:
            continue
        for k in keys:
            if hs == re.sub(r"\s", "", k):
                return i
    for i, hs in enumerate(norm):
        if not hs or hs in ex:
            continue
        for k in keys:
            kk = re.sub(r"\s", "", k)
            if kk in hs and len(hs) <= 14:
                return i
    return -1


def parse_html_tables(html):
    from lxml import html as LH
    try:
        doc = LH.fromstring(html)
    except Exception:
        return []
    out = []
    for tb in doc.iter("table"):
        rows = []
        for tr in tb.iter("tr"):
            cells = [re.sub(r"\s+", " ", ("".join(td.itertext()) or "").strip())
                     for td in tr.iter("td", "th")]
            if cells:
                rows.append(cells)
        if len(rows) >= 2:
            out.append(rows)
    return out


def doc_tables(url, data):
    """附件 -> [rows]。pdf 用 find_tables。"""
    low = url.lower().split("?")[0]
    tables = []
    try:
        if data[:4] == b"%PDF" or low.endswith(".pdf"):
            import pymupdf
            doc = pymupdf.open(stream=data, filetype="pdf")
            for page in doc:
                try:
                    tf = page.find_tables()
                except Exception:
                    continue
                for tb in tf.tables:
                    rows = [[(c or "").replace("\n", " ").strip() for c in r]
                            for r in tb.extract()]
                    rows = [r for r in rows if any(x for x in r)]
                    if len(rows) >= 2:
                        tables.append(rows)
            doc.close()
            return tables
        if low.endswith(".xlsx") or (data[:2] == b"PK" and b"xl/" in data[:4000]):
            import io
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(data), data_only=True, read_only=True)
            for ws in wb.worksheets:
                rows = []
                for r in ws.iter_rows(values_only=True):
                    cells = ["" if v is None else str(v).strip() for v in r]
                    if any(cells):
                        rows.append(cells)
                if len(rows) >= 2:
                    tables.append(rows)
            return tables
        if low.endswith(".xls") or low.endswith(".et"):
            import xlrd
            wb = xlrd.open_workbook(file_contents=data)
            for sh in wb.sheets():
                rows = []
                for r in range(sh.nrows):
                    cells = [str(sh.cell_value(r, c)).strip() for c in range(sh.ncols)]
                    if any(cells):
                        rows.append(cells)
                if len(rows) >= 2:
                    tables.append(rows)
            return tables
        if low.endswith(".docx") or (data[:2] == b"PK" and b"word/" in data[:4000]):
            import io
            import docx
            d = docx.Document(io.BytesIO(data))
            for tb in d.tables:
                rows = []
                for r in tb.rows:
                    rows.append([c.text.strip() for c in r.cells])
                if len(rows) >= 2:
                    tables.append(rows)
            if not tables:
                lines = [p.text.strip() for p in d.paragraphs if p.text.strip()]
                rows = [re.split(r"\t+|\s{2,}", ln) for ln in lines]
                rows = [r for r in rows if len(r) >= 2]
                if len(rows) >= 2:
                    tables.append(rows)
            return tables
        # .doc / 其它：退回纯文本
        txt = H.doc_text(url, data) or ""
        rows = [re.split(r"\t+", ln) for ln in txt.splitlines() if ln.strip()]
        rows = [r for r in rows if len(r) >= 2]
        if len(rows) >= 2:
            tables.append(rows)
    except Exception as e:
        print("   doc_tables ERR", type(e).__name__, e)
    return tables


CERT_RE = re.compile(r"^(GR\d{10,14})", re.I)
BAD_NAME = re.compile(r"^(序号|合计|小计|企业名称|单位名称|备注|附件)")


def _clean_cert(s):
    t = re.sub(r"[\s\-]", "", s or "").upper()
    m = re.search(r"(GR\d{10,14})", t)
    return m.group(1) if m else ""


def extract_from_tables(tables, prov, src="", year="", batch="", default_city="",
                        carry=False, min_name=4, require_city=False):
    recs = []
    last = None          # 上一张表解析出的列位（carry=True 时跨表复用）
    for rows in tables:
        hi = -1
        for i, r in enumerate(rows[:8]):
            if any(any(k in re.sub(r"\s", "", c) for k in NAME_KEYS) for c in r):
                hi = i
                break
        if hi < 0 and carry and last:
            ni, ct, ci, gi = last
            ncol = max(len(r) for r in rows) if rows else 0
            for r in rows:
                if len(r) <= ni:
                    continue
                nm = (r[ni] or "").strip()
                if not nm or BAD_NAME.match(nm) or len(nm) < min_name:
                    continue
                if any(k in nm.replace(" ", "") for k in NAME_KEYS):
                    continue
                cert = _clean_cert(r[gi]) if 0 <= gi < len(r) else ""
                raw_city = (r[ct] or "").strip() if 0 <= ct < len(r) else ""
                city = norm_city(prov, raw_city)
                county = (r[ci] or "").strip() if 0 <= ci < len(r) else ""
                if not city and raw_city and not county:
                    for cn in allowed_cities(prov):
                        if raw_city.startswith(cn) and len(raw_city) > len(cn):
                            city, county = cn, raw_city[len(cn):]
                            break
                if not city:
                    city = default_city
                recs.append(dict(name=nm, cert=cert, city=city or "", county=county,
                                 year=year, batch=batch, src=src))
            continue
        if hi < 0:
            for r in rows:
                nm = (r[0] or "").strip() if r else ""
                cert = _clean_cert(r[1]) if len(r) > 1 else ""
                if cert and len(nm) >= min_name and not BAD_NAME.match(nm):
                    recs.append(dict(name=nm, cert=cert, city=default_city, county="",
                                     year=year, batch=batch, src=src))
            continue
        header = rows[hi]
        ni = _find_col(header, NAME_KEYS)
        if ni < 0:
            continue
        ci = _find_col(header, COUNTY_KEYS)
        ct = _find_col(header, CITY_KEYS, exclude=COUNTY_KEYS)
        gi = _find_col(header, CERT_KEYS)
        if require_city and ct < 0:
            continue
        last = (ni, ct, ci, gi)
        ncol = len(header)
        prev_city = ""
        for r in rows[hi + 1:]:
            if len(r) <= ni:
                continue
            nm = (r[ni] or "").strip()
            if not nm or BAD_NAME.match(nm) or len(nm) < min_name:
                continue
            if any(k in nm.replace(" ", "") for k in NAME_KEYS):
                continue
            cert = _clean_cert(r[gi]) if 0 <= gi < len(r) else ""
            if not cert:
                for c in r:
                    cc = _clean_cert(c)
                    if cc:
                        cert = cc
                        break
            raw_city = (r[ct] or "").strip() if 0 <= ct < len(r) else ""
            city = norm_city(prov, raw_city)
            county = (r[ci] or "").strip() if 0 <= ci < len(r) else ""
            if not city and raw_city and not county:
                for cn in allowed_cities(prov):
                    if raw_city.startswith(cn) and len(raw_city) > len(cn):
                        city = cn
                        county = raw_city[len(cn):]
                        break
            if not city and carry and prev_city:
                city = prev_city
            if city:
                prev_city = city
            if not city:
                city = default_city
            recs.append(dict(name=nm, cert=cert, city=city or "", county=county,
                             year=year, batch=batch, src=src))
    return recs


def extract(html, prov, src="", **kw):
    return extract_from_tables(parse_html_tables(html), prov, src=src, **kw)


def grab(url, prov, tag, **kw):
    sc, data, fin = H.get(url, timeout=30, tries=3, binary=True)
    if sc != 200 or not data:
        print("  FAIL", sc, url)
        return []
    H.save_raw(tag, url, data)
    low = url.lower().split("?")[0]
    head = data[:4000].lower()
    if low.endswith((".pdf", ".doc", ".docx", ".xls", ".xlsx")) or data[:4] == b"%PDF":
        tables = doc_tables(url, data)
    else:
        t = data.decode("utf-8", "ignore")
        if t.count("\ufffd") > 20 or "<table" not in t.lower():
            t = data.decode("gb18030", "ignore")
        tables = parse_html_tables(t)
    out = extract_from_tables(tables, prov, src=url, **kw)
    print("  %-46s %s t=%d -> %d rows" % (url.split("/")[-1][:46], sc, len(tables), len(out)))
    return out


def append(path, recs):
    if not recs:
        return 0
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        for r in recs:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return len(recs)


def snifftables(url, n=4):
    sc, data, fin = H.get(url, timeout=30, tries=2, binary=True)
    if sc != 200 or not data:
        print("FAIL", sc, url)
        return
    low = url.lower().split("?")[0]
    if low.endswith((".pdf", ".doc", ".docx", ".xls", ".xlsx")):
        tables = doc_tables(url, data)
    else:
        t = data.decode("utf-8", "ignore")
        if "<table" not in t.lower():
            t = data.decode("gb18030", "ignore")
        tables = parse_html_tables(t)
    print("=" * 70)
    print(url, sc, len(data), "tables", len(tables))
    for i, rows in enumerate(tables[:n]):
        print(" T%d rows=%d" % (i, len(rows)))
        for r in rows[:4]:
            print("   ", r[:9])
