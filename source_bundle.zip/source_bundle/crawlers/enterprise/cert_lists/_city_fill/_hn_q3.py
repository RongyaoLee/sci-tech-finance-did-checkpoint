﻿# -*- coding: utf-8 -*-
import os,sys,re,json,urllib.parse,time
sys.path.insert(0,os.getcwd())
import cf
Q=["高新技术企业 奖励 名单","高企 奖补 名单","高新技术企业 认定 奖励 公示","高新技术企业 培育 名单"]
seen={}
for q in Q:
    for p in range(1,4):
        u="http://searching.hunan.gov.cn/hunan/001000000/all?q=%s&iszq=1&p=%d"%(urllib.parse.quote(q),p)
        h,f=cf.get(u)
        if not h: break
        n0=len(seen)
        for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',h,re.S|re.I):
            uu=urllib.parse.urljoin(f,m.group(1)); tt=re.sub(r"<[^>]+>","",m.group(2)); tt=re.sub(r"\s+","",tt).strip()
            if "searching.hunan.gov.cn" in uu or not tt or len(tt)<10: continue
            if not re.search(r"高新|高企",tt): continue
            seen.setdefault(uu,tt)
        print(q,p,"new",len(seen)-n0,"tot",len(seen))
        time.sleep(0.5)
json.dump(seen,open("_hn_hits3.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
