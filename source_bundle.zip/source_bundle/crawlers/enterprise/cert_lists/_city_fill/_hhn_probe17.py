# -*- coding: utf-8 -*-
"""MOST 高企查询探测：get 阶段存 cookie+验证码图；post 阶段用人工读码提交。"""
import io, sys, os, json, random, pickle
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import requests

BASE = os.path.dirname(os.path.abspath(__file__))
CK = os.path.join(BASE, '_most_cookies.pkl')
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
API = 'https://fuwu.most.gov.cn/dataService/WebService.asmx/getGxqData'


def new_session():
    s = requests.Session()
    s.headers.update({'User-Agent': UA, 'Referer': 'https://fuwu.most.gov.cn/html/fwcx/gxjsqybacx/',
                      'X-Requested-With': 'XMLHttpRequest'})
    return s


if sys.argv[1] == 'get':
    s = new_session()
    r = s.get('https://fuwu.most.gov.cn/dataService/WebService.asmx/getValidCode',
              params={'appName': 'gxjs', 'random': random.random()}, timeout=30, verify=False)
    open(os.path.join(BASE, '_cap_gx.png'), 'wb').write(r.content)
    pickle.dump(s.cookies, open(CK, 'wb'))
    print('captcha saved', len(r.content), dict(s.cookies))
else:
    code = sys.argv[2]
    name = sys.argv[3] if len(sys.argv) > 3 else ''
    cert = sys.argv[4] if len(sys.argv) > 4 else ''
    s = new_session()
    s.cookies.update(pickle.load(open(CK, 'rb')))
    r = s.post(API, data={'appName': 'gxjs', 'from': 'pc', 'name': name,
                          'Certificate_num': cert, 'code': code}, timeout=40, verify=False)
    print('status', r.status_code)
    print((r.text or '')[:1500])
