# -*- coding: utf-8 -*-
"""Direct-URL runner: parse inline tables + attachments of a known 高企 奖补/名单 page."""
import os, sys, re, json, io, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup
from fc_hn_rows import tables_of_html, parse_rows2d, doc_rows, log, ROWS, LOG

BAD = re.compile(r"(渔业|农业|专利|科技专家|专家库|创新平台|孵化器|众创|瞪羚|科学技术奖|提名)")

spec = json.load(io.open(sys.argv[1], encoding="utf-8"))
if not os.path.exists(LOG):
    open(LOG, "w", encoding="utf-8").close()
tot = 0
with io.open(ROWS, "a", encoding="utf-8") as fout:
    for it in spec:
        url, city = it["url"], it["city"]
        log("== %s | %s" % (city, url))
        html, final = cf.get(url)
        if not html:
            log("   FETCH FAIL")
            continue
        got = 0
        for ti, rows2d in enumerate(tables_of_html(html)):
            rows = parse_rows2d(rows2d, city)
            if rows:
                log("   inline table%d (%dx%d) -> %d rows" % (ti, len(rows2d), len(rows2d[0]), len(rows)))
                for r in rows:
                    fout.write(json.dumps(dict(r, src=url, tag=it.get("tag", "")), ensure_ascii=False) + "\n")
                got += len(rows)
        for text, u in cf.attachments(url, html):
            p = cf.download(u, "hn")
            if not p:
                log("   dl FAIL %s" % u)
                continue
            rows = doc_rows(p, city)
            log("   att %-46s %s -> %d" % (text[:46], os.path.splitext(p)[1], len(rows)))
            for r in rows:
                fout.write(json.dumps(dict(r, src=url, tag=it.get("tag", ""),
                                           att=os.path.basename(u)), ensure_ascii=False) + "\n")
            got += len(rows)
        fout.flush()
        tot += got
        log("   +%d (accum %d)" % (got, tot))
log("DONE %d rows" % tot)
