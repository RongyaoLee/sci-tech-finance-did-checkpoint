# -*- coding: utf-8 -*-
import sys, os, re, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

for u in ["http://xdz.xa.gov.cn/xwzx/tzgg/1.html",
          "http://xdz.xa.gov.cn/xwzx/tzgg/2.html",
          "http://xdz.xa.gov.cn/xwzx/tzgg/index_2.html",
          "http://xdz.xa.gov.cn/xwzx/tzgg/"]:
    h, f = cf.get(u, tries=1, timeout=15)
    if not h:
        print(u, "ERR", f)
        continue
    # paging hints
    pg = re.findall(r'(?:共\s*\d+\s*页|createPageHTML\([^)]*\)|pageCount|totalPage[^,;]{0,40})', h)
    links = re.findall(r'href="([^"]*(?:index_\d+|\d+)\.html)"', h)
    print(u, "len", len(h), "pg", pg[:3], "nlinks", len(links), "sample", links[:6])
