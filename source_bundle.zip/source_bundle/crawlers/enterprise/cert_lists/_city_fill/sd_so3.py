# -*- coding: utf-8 -*-
"""360 discovery sweep v3: mixed site:/free queries, per-city, reuse sd_so2.grab."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_so2 as S2

HOSTS = S2.HOSTS

SITE_Q = [
    "高新技术企业名单",
    "高新技术企业名单 所属区市",
    "高新技术企业名单 附件",
    "2022年度高新技术企业名单",
    "2023年度高新技术企业名单",
    "2024年度高新技术企业名单",
    "高新技术企业 区县 名单",
]

FREE_Q = [
    '"%(c)s市高新技术企业名单"',
    '%(c)s市 高新技术企业 名单 所属区县',
    '%(c)s市20%(y)d年高新技术企业名单 附件',
]


def run(cities, pages=1):
    rep = {}
    for city in cities:
        tot = 0
        arts = []
        for host in HOSTS.get(city, []):
            for q in SITE_Q:
                for pn in range(1, pages + 1):
                    ls = S2.so_links("site:%s %s" % (host, q), pn)
                    for t, u in ls:
                        if [t, u] in S2.SEEN.get("links", []):
                            continue
                        S2.SEEN.setdefault("links", []).append([t, u])
                        arts.append((t, u))
                    if not ls:
                        break
        for y in (22, 23, 24):
            for tpl in FREE_Q:
                q = tpl % {"c": city, "y": y}
                ls = S2.so_links(q, 1)
                for t, u in ls:
                    if [t, u] in S2.SEEN.get("links", []):
                        continue
                    S2.SEEN.setdefault("links", []).append([t, u])
                    # free query: only keep same-city government hosts
                    if city in u or "gov.cn" in u:
                        arts.append((t, u))
                if not ls:
                    break
        arts = list(dict.fromkeys(arts))
        for t, u in arts[:40]:
            n, det = S2.grab(u)
            if n:
                tot += n
                rep.setdefault(city, []).append({"url": u, "rows": n, "title": t})
        S2.save_seen()
        print("%s arts=%d rows=%d" % (city, len(arts), tot), flush=True)
        rep.setdefault(city, [])
        json.dump(rep, open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                         "_so3_%s.json" % "_".join(cities[:2])), "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)


if __name__ == "__main__":
    run(sys.argv[1:] or ["淄博"])
