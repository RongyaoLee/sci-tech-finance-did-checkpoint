﻿# -*- coding: utf-8 -*-
import json
d=json.load(open("_hn_hits3.json",encoding="utf-8"))
for u,t in d.items(): print(t[:60],"|",u[:110])
