﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
sys.path.insert(0,r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists")
import cf,fetch_common as fc
T=[("http://csmls.changsha.gov.cn/zwgk/xxgk/czxx/202308/t20230822_11198490.html","长沙市","2022"),
   ("http://kjt.hunan.gov.cn/kjt/xxgk/tzgg/tzgg_1/202210/t20221018_29072933.html","","2022"),
   ("http://www.hnyx.gov.cn/c5636/20201208/i1628402.html","株洲市","2020"),
   ("http://txjkq.changsha.gov.cn/jdhy/zcjd/202402/t20240207_11369658.html","长沙市","2024")]
for u,city,yr in T:
    h,f=cf.get(u)
    if not h: print("FAIL",u); continue
    t=re.search(r"<title>(.*?)</title>",h,re.S)
    print("=====",(t.group(1).strip()[:60] if t else ""),len(h))
    atts=cf.attachments(f,h)
    print("  atts:",[(a[0][:50],a[1][:90]) for a in atts][:6])
    for txt,au in atts:
        p=cf.download(au,"hnx")
        if not p: print("   dl fail",au[:80]); continue
        try: rr=fc.extract(p)
        except Exception as e: print("   extract err",e); continue
        print("   ATT",os.path.basename(p),len(rr),[x.get("name","")[:24] for x in rr[:4]])
