# -*- coding: utf-8 -*-
import sys, os, re, json, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

h, f = cf.get("http://www.xa.gov.cn/so/s?siteCode=6101000007&tab=all&qt=" + urllib.parse.quote("高新技术企业"))
print("len", len(h))
# dump inline scripts that mention api
for m in re.finditer(r"<script[^>]*>(.*?)</script>", h, re.S):
    js = m.group(1)
    if "api" in js or "search" in js.lower():
        for line in js.split("\n"):
            if re.search(r"api\.|https?://|/api/|url\s*[:=]", line):
                print("JS>", line.strip()[:220])
print("---- js srcs ----")
for m in re.finditer(r'<script[^>]+src=["\']([^"\']+)["\']', h):
    print("SRC", m.group(1)[:160])
