# -*- coding: utf-8 -*-
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

u = 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418344688721/2022012115434848730.docx'
st, data, fu = H.get(u, timeout=30, binary=True)
print('docx', st, len(data))
t = H.doc_text(u, data)
print('chars', len(t), 'certs', len(H.certs_in_text(t)))
print(t[:1500])
print('...TAIL...')
print(t[-800:])
