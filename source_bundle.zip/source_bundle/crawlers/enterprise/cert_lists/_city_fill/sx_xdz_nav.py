# -*- coding: utf-8 -*-
import sys, os, re, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

h, f = cf.get("http://xdz.xa.gov.cn/")
s = cf.soup_of(h)
print("final", f, len(h))
seen = set()
for a in s.find_all("a", href=True):
    tx = a.get_text(" ", strip=True)
    u = a["href"].strip()
    if not tx or u.startswith("javascript"):
        continue
    key = (tx[:20], u)
    if key in seen:
        continue
    seen.add(key)
    print(tx[:30], "|", u[:120])
