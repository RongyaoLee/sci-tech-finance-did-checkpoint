# -*- coding: utf-8 -*-
"""Download Shanxi subsidy xls/xlsx attachments, inspect columns and count."""
import requests, urllib3, re, os, io
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})

targets = [
    ('bz2024', 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202607/P020260727349202718457.xlsx'),
    ('bz2022', 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202407/P020240719616378598823.xls'),
    ('bz2021', 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202208/P020220802349440528026.xls'),
]
for tag, u in targets:
    r = s.get(u, timeout=60, verify=False)
    print('==', tag, r.status_code, len(r.content))
    if r.status_code != 200:
        continue
    path = os.path.join(RAW, f'_{tag}_list' + ('.xlsx' if u.endswith('xlsx') else '.xls'))
    open(path, 'wb').write(r.content)
    try:
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(r.content), data_only=True)
        for ws in wb.worksheets[:3]:
            print('  sheet', ws.title, ws.max_row, ws.max_column)
            for row in ws.iter_rows(min_row=1, max_row=4, values_only=True):
                print('    ', [str(c)[:36] if c is not None else '' for c in row][:9])
    except Exception as e:
        print('  xlsx fail', str(e)[:60])
        try:
            import xlrd
            wb = xlrd.open_workbook(file_contents=r.content)
            for ws in wb.sheets()[:3]:
                print('  sheet', ws.name, ws.nrows, ws.ncols)
                for ri in range(min(4, ws.nrows)):
                    print('    ', [str(ws.cell_value(ri, ci))[:36] for ci in range(min(9, ws.ncols))])
        except Exception as e2:
            print('  xls fail', str(e2)[:60])
