# -*- coding: utf-8 -*-
"""Find the 高企 公示 columns on the two 科技厅 sites."""
import os, sys, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

HOMES = ["http://kjt.jiangxi.gov.cn/", "http://kjt.hunan.gov.cn/"]
KEY = re.compile(r"高新|高企|认定|公示|通知公告|科技型")


def scan(home):
    html, final = cf.get(home)
    print("=" * 70)
    print(home, "->", final, "len", len(html) if html else None)
    if not html:
        return
    soup = BeautifulSoup(html, "lxml")
    seen = set()
    for a in soup.find_all("a", href=True):
        t = a.get_text(" ", strip=True)
        h = a["href"].strip()
        if not t or len(t) > 40:
            continue
        if not KEY.search(t):
            continue
        u = urllib.parse.urljoin(final or home, h)
        if u in seen:
            continue
        seen.add(u)
        print("  %-30s %s" % (t[:30], u))


for h in HOMES:
    scan(h)
