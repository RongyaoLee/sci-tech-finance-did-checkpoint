# -*- coding: utf-8 -*-
"""河南搜索 API：定向找 2019-2023 的「拟认定高新技术企业名单」公示页。"""
import io, sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

API = 'https://searchapi.henan.gov.cn/open/api/external-new'
found = {}
KWS = ['拟认定高新技术企业名单', '高新技术企业名单公示', '公示高新技术企业名单',
       '拟认定高新技术企业', '高新技术企业认定名单', '高企名单']
for kw in KWS:
    for pn in range(1, 6):
        st, txt, _ = H.get(API, timeout=30)
        # 用带参形式
        url = (API + '?keywords=' + kw + '&siteId=4500000004&searchRange=-1000&sortType=150'
               '&pageNumber=%d&pageSize=50' % pn)
        st, txt, _ = H.get(url, timeout=30)
        if st != 200:
            print('X', st, kw, pn); break
        try:
            d = json.loads(txt)
        except Exception:
            print('bad json', kw, pn); break
        datas = (d.get('data') or {}).get('datas') or []
        if not datas:
            break
        for x in datas:
            t = x.get('title', '')
            u = x.get('selfUrl', '')
            m = re.search(r'20(19|2\d)', t)
            if '公示' in t and ('拟认定' in t or '名单' in t) and m:
                found[u] = (t, x.get('pubDate', '')[:10])
print('found', len(found))
for u, (t, dt) in sorted(found.items(), key=lambda z: z[1][1]):
    print(dt, t[:56], '|', u[-26:])
json.dump([{'u': u, 't': t, 'd': d} for u, (t, d) in found.items()],
          open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_hn_enum2.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
