# -*- coding: utf-8 -*-
import io, sys, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

tests = [
    'https://kjt.henan.gov.cn/2024/10-17/3074891.html',
    'http://kjt.henan.gov.cn/2024/10-17/3074891.html',
]
for u in tests:
    st, txt, fu = H.get(u, timeout=30)
    print('GET', u, '->', st, len(txt) if txt else 0, fu)
    if st == 200:
        links = H.img_links(txt, fu)
        docs = H.doc_links(links, fu)
        print('  docs:', len(docs))
        for d, t in docs[:20]:
            print('   -', t[:60], '|', d[:120])
        # find tables: header row text
        for m in re.finditer(r'<table.*?</table>', txt, re.S | re.I):
            seg = m.group(0)
            rows = re.findall(r'<tr.*?</tr>', seg, re.S | re.I)
            head = re.sub(r'<[^>]+>', ' ', rows[0]) if rows else ''
            print('  TABLE rows=%d head=%s' % (len(rows), re.sub(r'\s+', ' ', head).strip()[:120]))
    if st == 200:
        break
