# -*- coding: utf-8 -*-
import csv, collections, os
BASE = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists'
for prov in ('陕西省', '山西省'):
    c = collections.Counter()
    yr = collections.defaultdict(set)
    for r in csv.DictReader(open(os.path.join(BASE, prov + '.csv'), encoding='utf-8-sig', newline='')):
        u = r['来源URL'].strip()
        c[u] += 1
        yr[u].add(r['认定年度'].strip())
    print('=====', prov, 'distinct', len(c))
    for u, n in c.most_common(40):
        print(f'{n:6d} {sorted(yr[u])} {u}')
