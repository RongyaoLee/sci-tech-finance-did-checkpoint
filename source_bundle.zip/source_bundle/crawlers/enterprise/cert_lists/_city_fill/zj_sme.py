﻿# -*- coding: utf-8 -*-
"""解析各设区市「省科技型中小企业认定名单」PDF/附件：序号|企业名称|区县市
城市由文件归属（发布机关）确定，区县必须能反证到该市，否则丢弃。
输出 _city_fill\parts\浙江省_sme.jsonl  {"name","city","county","src"}
"""
import os, re, sys, json, io, time
import urllib.request

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PARTS = os.path.join(HERE, "parts")
OUT = os.path.join(PARTS, "浙江省_sme.jsonl")
RAW = os.path.join(HERE, "raw")
os.makedirs(PARTS, exist_ok=True); os.makedirs(RAW, exist_ok=True)

sys.path.insert(0, HERE)
from zj_stbrain_rc import COUNTY2CITY, area_from_addr  # noqa

CN = r"\u4e00-\u9fff"
TYPE = ("有限公司", "股份公司", "有限责任公司", "厂", "中心", "研究院", "研究所", "合伙企业",
        "事务所", "工作室", "集团", "合作社", "场", "店", "部")
NAME_OK = re.compile(r"[%s（）()·A-Za-z0-9]{4,}$" % CN)
SEQ = re.compile(r"^\d{1,5}$")

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}


def fetch(url, tries=3):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            return urllib.request.urlopen(req, timeout=60).read()
        except Exception as e:  # noqa
            last = e
            time.sleep(1.5 + i)
    raise last


def doc_lines(data, url):
    low = url.lower()
    if low.endswith(".pdf") or data[:4] == b"%PDF":
        import pymupdf
        doc = pymupdf.open(stream=data, filetype="pdf")
        txt = "\n".join(p.get_text() for p in doc)
    elif low.endswith(".docx"):
        import docx
        d = docx.Document(io.BytesIO(data))
        txt = "\n".join(p.text for p in d.paragraphs)
        for t in d.tables:
            for r in t.rows:
                txt += "\n" + "\n".join(c.text for c in r.cells)
    elif low.endswith(".xlsx") or low.endswith(".xls"):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        out = []
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                out.append("\t".join("" if c is None else str(c).strip() for c in row))
        txt = "\n".join(out)
    else:  # .doc / .wps 走 antiword 不在，跳过
        return []
    return [l.strip() for l in txt.replace("\u3000", " ").splitlines() if l.strip()]


def parse_rows(lines, city):
    """从逐行文本里抓 序号|企业名称|区县 三元组。区县必须属于 city。"""
    got, bad = [], 0
    i, n = 0, len(lines)
    while i < n - 2:
        if SEQ.match(lines[i]):
            nm = lines[i + 1]
            cu = lines[i + 2]
            okco = COUNTY2CITY.get(cu) == city or cu == city or cu == city[:2] + "市本级"
            if okco and any(nm.endswith(t) or t in nm for t in TYPE) and 3 < len(nm) < 60:
                got.append((nm.strip(), cu.strip()))
                i += 3
                continue
            if SEQ.match(lines[i + 2]):
                i += 1
                continue
        i += 1
    return got, bad


def main():
    jobs = json.load(open(os.path.join(HERE, "sme_jobs.json"), encoding="utf-8"))
    have = set()
    if os.path.exists(OUT):
        for l in open(OUT, encoding="utf-8"):
            try:
                d = json.loads(l)
                have.add((d["name"], d["city"]))
            except Exception:
                pass
    with open(OUT, "a", encoding="utf-8") as fh:
        for j in jobs:
            url, city = j["url"], j["city"]
            tag = os.path.join(RAW, "_sme_" + j["tag"] + (".pdf" if url.lower().endswith(".pdf") else ".bin"))
            try:
                if os.path.exists(tag) and os.path.getsize(tag) > 2000:
                    data = open(tag, "rb").read()
                else:
                    data = fetch(url)
                    open(tag, "wb").write(data)
                    time.sleep(0.6)
                lines = doc_lines(data, url)
                rows, _ = parse_rows(lines, city)
                new = 0
                for nm, cu in rows:
                    if (nm, city) in have:
                        continue
                    have.add((nm, city))
                    fh.write(json.dumps({"name": nm, "city": city, "county": cu,
                                         "src": url, "tag": j["tag"]}, ensure_ascii=False) + "\n")
                    new += 1
                fh.flush()
                print(f"{j['tag']:28s} {city} lines={len(lines):6d} rows={len(rows):5d} new={new:5d}", flush=True)
            except Exception as e:  # noqa
                print(f"{j['tag']:28s} {city} FAIL {type(e).__name__}: {str(e)[:90]}", flush=True)


if __name__ == "__main__":
    main()

