# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

tests = [
    "https://kjt.shaanxi.gov.cn/kjdt/tzgg/202410/",
    "https://kjt.shaanxi.gov.cn/kjdt/tzgg/",
    "https://kjt.shaanxi.gov.cn/kjdt/tzgg/index.html",
    "https://kjt.shaanxi.gov.cn/kjdt/tzgg/index_1.html",
]
for u in tests:
    h, f = cf.get(u, tries=1, timeout=20)
    if not h:
        print(u, "->", f)
        continue
    links = re.findall(r'href="([^"]*t\d{8}_\d+\.html)"', h)
    print(u, "len", len(h), "itemlinks", len(links), links[:4])
