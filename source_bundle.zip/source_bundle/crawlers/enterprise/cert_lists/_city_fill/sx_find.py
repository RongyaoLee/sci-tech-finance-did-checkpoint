# -*- coding: utf-8 -*-
"""Discovery: bing search for Shaanxi city-level high-tech-enterprise lists."""
import sys, os, re, json, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

QUERIES = [
    "西安市 高新技术企业 认定 推荐名单 公示",
    "西安市科学技术局 高新技术企业 名单 公示 附件",
    "宝鸡市 高新技术企业 认定 名单 公示",
    "咸阳市 高新技术企业 名单 公示 科技局",
    "渭南市 高新技术企业 认定 名单 公示",
    "延安市 高新技术企业 名单 公示",
    "汉中市 高新技术企业 名单 公示",
    "榆林市 高新技术企业 名单 公示",
    "安康市 高新技术企业 名单 公示",
    "商洛市 高新技术企业 名单 公示",
    "铜川市 高新技术企业 名单 公示",
    "杨凌示范区 高新技术企业 名单 公示",
]

RES = {}
for q in QUERIES:
    got = []
    for host in ("https://cn.bing.com/search?q=", "https://www.bing.com/search?q="):
        url = host + urllib.parse.quote(q) + "&count=30&ensearch=0"
        h, u = cf.get(url)
        if not h or len(h) < 2000:
            continue
        # bing result anchors
        for m in re.finditer(r'<h2><a href="([^"]+)"[^>]*>(.*?)</a></h2>', h, re.S):
            link = m.group(1)
            title = re.sub(r"<[^>]+>", "", m.group(2))
            got.append((title.strip(), link))
        if not got:
            for m in re.finditer(r'<a[^>]+href="(https?://[^"]+)"[^>]*h="ID=SERP', h):
                got.append(("", m.group(1)))
        if got:
            break
    RES[q] = got[:25]
    print(q, len(got))

json.dump(RES, open(os.path.join(HERE, "_sx_bing.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("saved")
