# -*- coding: utf-8 -*-
import sys, os, re, json, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

out = {}

def probe(url, key, maxlinks=120):
    h, u = cf.get(url)
    d = {"len": len(h) if h else h, "final": u}
    if h:
        s = cf.soup_of(h)
        links = []
        for a in s.find_all("a", href=True):
            tx = a.get_text(" ", strip=True)
            links.append((tx[:50], a["href"][:200]))
        d["links"] = links[:maxlinks]
        d["scripts"] = re.findall(r'src=["\']([^"\']+\.js[^"\']*)["\']', h)[:20]
        d["text"] = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", h))[:2000]
    out[key] = d

probe("https://kjt.shaanxi.gov.cn/zwfw/jg/jgcx/", "jgcx")
sw = "高新技术企业"
probe("https://kjt.shaanxi.gov.cn/sxsearch-a/search.shtml?code=191b76850fb&dataTypeId=20770&searchWord=" + urllib.parse.quote(sw), "search", 200)
json.dump(out, open(os.path.join(HERE, "_sx_probe3.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("ok")
