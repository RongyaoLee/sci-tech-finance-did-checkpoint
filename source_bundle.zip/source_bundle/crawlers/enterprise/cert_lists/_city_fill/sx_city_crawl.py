# -*- coding: utf-8 -*-
"""Crawl several city S&T bureau notice channels; report titles matching hi-tech keywords."""
import sys, os, re, json, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf
from sx_chan import items_of

KW = re.compile(r"高新技术企业|高企")

SITES = {
    "宝鸡": ["https://kjj.baoji.gov.cn/col2190/col2194/index_{0}.html"],
    "渭南": ["https://kjj.weinan.gov.cn/xwzx/tzgg/{0}.html"],
    "延安": ["https://kjj.yanan.gov.cn/xwzx/tzgg/{0}.html"],
    "榆林": ["http://kjj.yl.gov.cn/kjdt/tzgg/{0}.html",
             "http://kjj.yl.gov.cn/kjdt/tzgg/index_{0}.html"],
    "安康": ["https://kjj.ankang.gov.cn/Node-3374-{0}.html",
             "https://kjj.ankang.gov.cn/Node-3374.html"],
}

def crawl(templates, maxp=45):
    seen, res, miss = set(), [], 0
    for i in range(1, maxp + 1):
        got = 0
        for tpl in templates:
            for cand in (tpl.format(i), tpl.format(i) if i > 1 else tpl.format(1)):
                pass
            url = tpl.format(i)
            h, f = cf.get(url, tries=1, timeout=15)
            if not h or len(h) < 1500:
                continue
            before = len(seen)
            for tx, u, d in items_of(h, f):
                if u in seen:
                    continue
                seen.add(u)
                res.append({"t": tx, "u": u, "d": d})
            got += len(seen) - before
            if got:
                break
        if got == 0:
            miss += 1
            if miss >= 3:
                break
    return res

alls = {}
for city, tpls in SITES.items():
    r = crawl(tpls)
    alls[city] = r
    hits = [x for x in r if KW.search(x["t"])]
    print("==", city, "total", len(r), "hits", len(hits))
    for x in hits:
        print("   ", x["d"], "|", x["t"][:70], "|", x["u"][:110])

json.dump(alls, open(os.path.join(HERE, "_sx_citylists.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
