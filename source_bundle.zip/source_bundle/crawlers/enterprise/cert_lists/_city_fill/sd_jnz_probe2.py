import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

TARGETS = [
    ("jinan", "http://www.jinan.gov.cn/"),
    ("zibo", "http://www.zibo.gov.cn/"),
    ("zaozhuang", "http://www.zaozhuang.gov.cn/"),
]
KW = re.compile(r"科技|通知|公告|公示|公开|高新|政策|文件")
res = {}
for tag, url in TARGETS:
    st, html, final = H.get(url, timeout=25, tries=1)
    print("==", tag, st, len(html), final)
    res[tag] = {"url": url, "status": st, "final": final, "len": len(html), "links": []}
    if not html:
        continue
    open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_%s_home.html" % tag, "w", encoding="utf-8").write(html)
    seen = set()
    for href, txt in H.img_links(html, final):
        if not txt or len(txt) > 40:
            continue
        if not KW.search(txt + href):
            continue
        if href in seen:
            continue
        seen.add(href)
        res[tag]["links"].append([href, txt])
    for l in res[tag]["links"][:40]:
        print("   ", l[1], "|", l[0])
json.dump(res, open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_jnz_probe2.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
