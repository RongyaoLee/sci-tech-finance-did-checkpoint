# -*- coding: utf-8 -*-
"""Test server-side keyword filtering on the Jiangxi /queryList endpoint."""
import time, json
import requests
requests.packages.urllib3.disable_warnings()

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36"
s = requests.Session()
s.headers.update({"User-Agent": UA,
                  "Referer": "http://kjt.jiangxi.gov.cn/jxskxjst/col/col27029/index.html",
                  "X-Requested-With": "XMLHttpRequest"})
BASE = {"unitid": "466678", "webSiteCode": "jxskxjst", "channelCode": "col27029",
        "perPage": "50", "pageSize": "50", "showMode": "full", "groupSize": "1",
        "titleMax": "120", "sort": "pubDate", "order": "desc", "current": "1", "page": "1"}

variants = [
    {"keyword": "高新技术企业"},
    {"searchWord": "高新技术企业"},
    {"title": "高新技术企业"},
    {"query": "高新技术企业"},
    {"keywords": "高新技术企业"},
]

for v in variants:
    t0 = time.time()
    try:
        r = s.post("http://kjt.jiangxi.gov.cn/queryList", data=dict(BASE, **v), timeout=60, verify=False)
        j = r.json()
        data = j.get("data") or {}
        res = data.get("results") or []
        titles = [(x.get("source") or {}).get("title", "")[:34] for x in res[:3]]
        print("%-22s %.1fs total=%s n=%d  %s" % (json.dumps(v, ensure_ascii=False),
              time.time() - t0, data.get("total"), len(res), titles), flush=True)
    except Exception as e:
        print("%-22s ERR %s" % (json.dumps(v, ensure_ascii=False), e), flush=True)
    time.sleep(1)
