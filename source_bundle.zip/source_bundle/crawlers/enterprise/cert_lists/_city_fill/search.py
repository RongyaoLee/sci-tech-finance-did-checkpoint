# -*- coding: utf-8 -*-
"""Web search helpers (Bing + Sogou) for locating city-level 高企名单 pages.

Usage:
    from search import se
    for title, url in se('潍坊市 高新技术企业名单 附件'):
        print(title, url)
"""
import re
import sys
import time
import random
from urllib.parse import quote

import requests

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
HDR = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Connection": "keep-alive",
}

_LAST = {}


def _throttle(host, gap=1.2):
    last = _LAST.get(host, 0)
    d = time.time() - last
    if d < gap:
        time.sleep(gap - d)
    _LAST[host] = time.time()


def _get(url, timeout=25):
    host = re.sub(r"^https?://([^/]+).*", r"\1", url)
    _throttle(host)
    try:
        r = requests.get(url, headers=HDR, timeout=timeout, allow_redirects=True)
        r.encoding = r.apparent_encoding or "utf-8"
        return r.text
    except Exception:
        return ""


def bing(q, pages=1, mkt="zh-CN"):
    out = []
    for p in range(pages):
        u = ("https://cn.bing.com/search?q=%s&first=%d&mkt=%s&setlang=zh-CN"
             % (quote(q), p * 10 + 1, mkt))
        h = _get(u)
        if not h:
            continue
        for m in re.finditer(r'<h2[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', h, re.S):
            url = m.group(1)
            title = re.sub(r"<[^>]+>", "", m.group(2))
            title = re.sub(r"\s+", " ", title).strip()
            if url.startswith("http"):
                out.append((title, url))
    return out


def sogou(q, pages=1):
    out = []
    for p in range(pages):
        u = "https://www.sogou.com/web?query=%s&page=%d" % (quote(q), p + 1)
        h = _get(u)
        if not h:
            continue
        # result blocks: <h3 ...><a href="/link?url=...">title</a>
        for m in re.finditer(r'<h3[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', h, re.S):
            href = m.group(1).replace("&amp;", "&")
            title = re.sub(r"<[^>]+>", "", m.group(2))
            title = re.sub(r"\s+", " ", title).strip()
            if href.startswith("/link"):
                href = "https://www.sogou.com" + href
            out.append((title, href))
    return out


def se(q, pages=1):
    res = []
    seen = set()
    for fn in (bing, sogou):
        try:
            for t, u in fn(q, pages=pages):
                k = (t, u)
                if k in seen:
                    continue
                seen.add(k)
                res.append((t, u))
        except Exception:
            pass
    return res


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for q in sys.argv[1:]:
        print("=" * 20, q)
        for t, u in se(q):
            print(" ", t[:70], "|", u[:120])
