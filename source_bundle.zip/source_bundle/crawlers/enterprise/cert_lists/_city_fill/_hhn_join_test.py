# -*- coding: utf-8 -*-
"""把已抓的地区行 join 回主表，统计覆盖。"""
import io, sys, os, re, json, csv, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

BASE = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists'
CF = os.path.join(BASE, '_city_fill')


def norm(s):
    s = (s or '').strip()
    s = s.replace('（', '(').replace('）', ')').replace('　', '').replace(' ', '')
    s = re.sub(r'\(', '(', s)
    return s.upper()


def load_rows(path):
    d = {}
    for line in open(path, encoding='utf-8'):
        try:
            r = json.loads(line)
        except Exception:
            continue
        k = norm(r['name'])
        if k and k not in d:
            d[k] = r
    return d


def main():
    idx = load_rows(os.path.join(CF, '_hn_region_rows.jsonl'))
    print('index names', len(idx))
    rows = list(csv.DictReader(open(os.path.join(BASE, '河南省.csv'), encoding='utf-8-sig', newline='')))
    filled = 0
    byyear = collections.Counter()
    tot = collections.Counter()
    miss_ex = []
    for x in rows:
        y = x['认定年度']
        tot[y] += 1
        if (x['城市'] or '').strip():
            continue
        k = norm(x['企业名称'])
        r = idx.get(k)
        if r:
            filled += 1
            byyear[y] += 1
        elif len(miss_ex) < 8:
            miss_ex.append(x['企业名称'])
    print('join filled', filled, 'of', len(rows))
    for y in sorted(tot):
        print('  %s gap=%d newfill=%d' % (y, tot[y] - sum(1 for x in rows if x['认定年度'] == y and (x['城市'] or '').strip()), byyear[y]))
    print('miss examples', miss_ex)


if __name__ == '__main__':
    main()
