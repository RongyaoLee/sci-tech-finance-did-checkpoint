# -*- coding: utf-8 -*-
"""Parse 山西 2024 补助 xlsx by city sections; and probe other years' attachments."""
import requests, urllib3, re, os, io, json
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
PARTS = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\parts'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})
os.makedirs(PARTS, exist_ok=True)

# ---------- 2024 ----------
import openpyxl
SRC24 = 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202607/t20260724_10183727.shtml'
wb = openpyxl.load_workbook(os.path.join(RAW, '_bz2024_list.xlsx'), data_only=True)
ws = wb.worksheets[0]
city = None
rows = []
sec = {}
for r in ws.iter_rows(min_row=1, values_only=True):
    cells = ['' if c is None else str(c).strip() for c in r]
    if len(cells) < 2:
        continue
    a, b = cells[0], cells[1]
    m = re.match(r'^[一二三四五六七八九十]+、\s*(.+)$', b or a)
    if m:
        city = m.group(1).strip()
        sec[city] = 0
        continue
    if b and re.match(r'^\d+$', a or '') and city:
        rows.append({'name': b, 'city': city, 'county': '', 'cert': '', 'year': '2024', 'batch': '', 'src': SRC24})
        sec[city] = sec.get(city, 0) + 1
print('2024 rows', len(rows))
print('sections', json.dumps(sec, ensure_ascii=False))
with open(os.path.join(PARTS, '山西省_补助2024.jsonl'), 'w', encoding='utf-8') as f:
    for x in rows:
        f.write(json.dumps(x, ensure_ascii=False) + '\n')

# ---------- other years: dump attachment names ----------
for tag, page, yr in [('bz2022', 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202407/t20240719_9612952.shtml', '2022-2023'),
                      ('bz2021', 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202208/t20220802_6840752.shtml', '2021')]:
    r = s.get(page, timeout=45, verify=False)
    r.encoding = r.apparent_encoding or 'utf-8'
    base = page.rsplit('/', 1)[0] + '/'
    print('==', tag, yr, r.status_code)
    for m in re.finditer(r'<a[^>]+href=[\'"](\./P\d+\.(?:xls|xlsx|doc|docx|pdf))[\'"]', r.text, re.I):
        print('   ', m.group(1))
    # also Cms.attachment JSON
    for m in re.finditer(r'附件[：:]\s*(.{0,60})', re.sub(r'<[^>]+>', ' ', r.text)):
        print('   att-label:', re.sub(r'\s+', ' ', m.group(1))[:60])
