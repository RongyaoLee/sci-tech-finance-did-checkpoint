# -*- coding: utf-8 -*-
"""河南 2017+ 拟认定公示 全量抓取（v3 解析：兼容 4 元组/USCC 与 3 元组 无 USCC 版式）。"""
import io, sys, os, re, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, '_hn_region_rows.jsonl')

CITY_KEYS = ['郑州', '开封', '洛阳', '平顶山', '安阳', '鹤壁', '新乡', '焦作', '濮阳', '许昌',
             '漯河', '三门峡', '南阳', '商丘', '信阳', '周口', '驻马店', '济源']
NAME_END = ('公司', '厂', '院', '所', '中心', '集团', '大学', '合作社', '研究院', '事务所', '银行', '学校', '医院')


def is_city(tok):
    if not tok or len(tok) > 10:
        return False
    for k in CITY_KEYS:
        if tok.startswith(k):
            rest = tok[len(k):]
            if rest in ('市', '区', '县', '新区', '示范区', '高新区') or rest == '' or '高新' in rest or '航空港' in rest:
                return k + '市'
    return None


def is_name(tok):
    return bool(tok) and len(tok) >= 4 and len(tok) <= 40 and tok.endswith(NAME_END) and not re.search(r'\d{4}', tok)


def parse(text):
    toks = [x for x in re.split(r'[\s\u3000]+', text) if x]
    rows = []
    for i, tok in enumerate(toks):
        city = is_city(tok)
        if not city:
            continue
        nxt = toks[i + 1] if i + 1 < len(toks) else ''
        nxt2 = toks[i + 2] if i + 2 < len(toks) else ''
        nxt3 = toks[i + 3] if i + 3 < len(toks) else ''
        if re.fullmatch(r'[0-9A-Z]{18}', nxt3) and is_name(nxt2):
            rows.append((city, nxt, nxt2))
        elif re.fullmatch(r'[0-9A-Z]{18}', nxt2) and is_name(nxt):
            rows.append((city, '', nxt))
        elif is_name(nxt2) and is_city(nxt):
            rows.append((city, nxt, nxt2))
        elif is_name(nxt):
            rows.append((city, '', nxt))
    return rows


def main():
    enum = json.load(open(os.path.join(BASE, '_hn_enum.json'), encoding='utf-8'))
    cands = []
    for x in enum:
        t = x.get('title', '')
        u = x.get('selfUrl') or x.get('url') or ''
        m = re.search(r'20(1[7-9]|2\d)', t)
        if not m or not u:
            continue
        if '拟认定' not in t or '更名' in t or '复审' in t:
            continue
        y = int('20' + m.group(1)) if len(m.group(0)) == 4 else 0
        y = int(re.search(r'20\d\d', t).group(0))
        bm = re.search(r'第([一二三四五六七八九十])批', t)
        cands.append((u, y, ('第' + bm.group(1) + '批') if bm else ''))
    seen_u = set(); uniq = []
    for c in cands:
        if c[0] in seen_u:
            continue
        seen_u.add(c[0]); uniq.append(c)
    print('candidates', len(uniq))

    have = set()
    if os.path.exists(OUT):
        for line in open(OUT, encoding='utf-8'):
            try:
                d = json.loads(line); have.add((d['name'], d['city']))
            except Exception:
                pass
    print('existing', len(have))
    fh = open(OUT, 'a', encoding='utf-8')
    total_new = 0
    for u, y, b in uniq:
        st, txt, fu = H.get(u, timeout=30)
        if st != 200:
            print('X', st, u[-24:]); continue
        docs = H.doc_links(H.img_links(txt, fu), fu)
        if not docs:
            print('-', y, b, 'nodocs', u[-24:]); continue
        got = 0
        for d, tt in docs:
            st2, data, _ = H.get(d, timeout=180, binary=True)
            if st2 != 200 or not data:
                print('   dl-fail', st2, d[-40:]); continue
            dt = H.doc_text(d, data)
            rows = parse(dt)
            for city, county, name in rows:
                if (name, city) in have:
                    continue
                have.add((name, city)); got += 1
                fh.write(json.dumps({'city': city, 'county': county, 'name': name,
                                     'year': y, 'batch': b, 'src': d}, ensure_ascii=False) + '\n')
        total_new += got
        print('+', y, b, got, tt[:26], u[-24:])
        fh.flush()
    fh.close()
    print('TOTAL_NEW', total_new)


if __name__ == '__main__':
    main()
