﻿# -*- coding: utf-8 -*-
import json,collections
rows=[json.loads(l) for l in open("rows_湖南.jsonl",encoding="utf-8") if l.strip()]
o=[]
o.append("total=%d"%len(rows))
for c,n in collections.Counter(r["city"] for r in rows).items(): o.append("CITY\t%s\t%d"%(c,n))
for c,n in collections.Counter(str(r.get("year") or "(空)") for r in rows).items(): o.append("YEAR\t%s\t%d"%(c,n))
for (c,u),n in collections.Counter((r["city"],r["source_url"]) for r in rows).items(): o.append("SRC\t%s\t%d\t%s"%(c,n,u))
o.append("cert_nonempty=%d"%sum(1 for r in rows if r.get("cert")))
open("_hn_stat.txt","w",encoding="utf-8").write("\n".join(o))
