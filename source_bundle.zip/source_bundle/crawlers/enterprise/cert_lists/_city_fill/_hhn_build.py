# -*- coding: utf-8 -*-
"""生成 河北省_city.csv / 河南省_city.csv。只填充，不改原值；来源URL 标官方附件。"""
import io, sys, os, re, json, csv, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

ROOT = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists'
CF = os.path.join(ROOT, '_city_fill')
OUTDIR = CF
HEADER = ['企业名称', '证书编号', '城市', '区县', '认定年度', '批次', '来源URL']


def norm(s):
    s = (s or '').strip().replace('　', '')
    s = s.replace('（', '(').replace('）', ')')
    s = re.sub(r'\s+', '', s)
    return s.upper()


GUIDE_MAP = [
    ('石家庄', '石家庄市'), ('唐山', '唐山市'), ('秦皇岛', '秦皇岛市'), ('邯郸', '邯郸市'),
    ('邢台', '邢台市'), ('保定', '保定市'), ('张家口', '张家口市'), ('承德', '承德市'),
    ('沧州', '沧州市'), ('廊坊', '廊坊市'), ('燕郊', '廊坊市'), ('衡水', '衡水市'),
    ('定州', '定州市'), ('辛集', '辛集市'), ('雄安', '雄安新区'), ('华油', '沧州市'),
    ('冀中', '沧州市'),
]


def guide_to_city(g):
    for k, v in GUIDE_MAP:
        if k in g:
            return v
    return ''


def build_hebei():
    idx = {}
    src_of = {}
    path = os.path.join(CF, '_hb_guikou.jsonl')
    for line in open(path, encoding='utf-8'):
        try:
            r = json.loads(line)
        except Exception:
            continue
        c = guide_to_city(r['guide'])
        if not c:
            continue
        k = norm(r['name'])
        if k and k not in idx:
            idx[k] = (c, r['guide'] if '高新' in r['guide'] or '新区' in r['guide'] else '')
            src_of[k] = r['src']
    print('河北 归口索引', len(idx))
    rows = list(csv.DictReader(open(os.path.join(ROOT, '河北省.csv'), encoding='utf-8-sig', newline='')))
    out = []
    filled = 0
    for x in rows:
        city = (x['城市'] or '').strip()
        county = (x['区县'] or '').strip()
        src = x['来源URL']
        if not city:
            k = norm(x['企业名称'])
            hit = idx.get(k)
            if hit:
                city, county = hit[0], (county or hit[1])
                src = 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/ (附件 %s)' % src_of[k]
                filled += 1
        out.append([x['企业名称'], x['证书编号'], city, county, x['认定年度'], x['批次'], src])
    return out, filled


def build_henan():
    idx = {}
    for line in open(os.path.join(CF, '_hn_region_rows.jsonl'), encoding='utf-8'):
        try:
            r = json.loads(line)
        except Exception:
            continue
        k = norm(r['name'])
        if k and k not in idx:
            idx[k] = r
    print('河南 地区索引', len(idx))
    HN_CITY = {'郑州航空港区': '郑州市', '航空港区': '郑州市', '济源示范区': '济源市'}

    def hn_norm(city, county):
        """把 高新区/航空港区/示范区 等标签归一到地级市，原标签落到区县。"""
        if not city:
            return city, county
        if city in HN_CITY:
            return HN_CITY[city], (county or ('' if city == '航空港区' else city))
        if city.endswith('高新区'):
            base = city[:-3]
            m = base if base.endswith('市') else base + '市'
            return m, (county or city)
        return city, county
    rows = list(csv.DictReader(open(os.path.join(ROOT, '河南省.csv'), encoding='utf-8-sig', newline='')))
    out = []
    filled = 0
    for x in rows:
        city = (x['城市'] or '').strip()
        county = (x['区县'] or '').strip()
        src = x['来源URL']
        if not city:
            r = idx.get(norm(x['企业名称']))
            if r:
                city = HN_CITY.get(r['city'], r['city'])
                county = county or r['county'] or ''
                src = r['src']
                filled += 1
        if city in HN_CITY or city.endswith('高新区'):
            city, county = hn_norm(city, county)
        out.append([x['企业名称'], x['证书编号'], city, county, x['认定年度'], x['批次'], src])
    return out, filled


def write(rows, name):
    p = os.path.join(OUTDIR, name)
    with open(p, 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(HEADER)
        w.writerows(rows)
    nonempty = sum(1 for r in rows if r[2])
    firms = len({(r[0], r[2]) for r in rows if r[2]})
    print('%s rows=%d city=%d firms=%d' % (name, len(rows), nonempty, firms))
    return nonempty, firms


def main():
    hb, hbf = build_hebei()
    hn, hnf = build_henan()
    a = write(hb, '河北省_city.csv')
    b = write(hn, '河南省_city.csv')
    print('河北 filled_now=%d 河南 filled_now=%d' % (hbf, hnf))
    json.dump({'hebei': {'rows': len(hb), 'city': a[0], 'firms': a[1], 'filled_now': hbf},
               'henan': {'rows': len(hn), 'city': b[0], 'firms': b[1], 'filled_now': hnf}},
              open(os.path.join(CF, '_hhn_stat.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
