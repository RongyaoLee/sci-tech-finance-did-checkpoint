# -*- coding: utf-8 -*-
import sys, os, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

url = "https://yiyang.gov.cn/yyskjj/1217/content_2062053.html"
html, final = cf.get(url)
soup = BeautifulSoup(html, "lxml")
print("anchors:")
for a in soup.find_all("a", href=True):
    print("  ", a.get_text(" ", strip=True)[:60], "->", a["href"][:140])
print("---- any .xlsx mention in raw html:")
for m in re.finditer(r"[\w./?=&%-]{0,80}\.xlsx?", html):
    print("  ", m.group(0))
print("---- iframes/embeds:")
for t in soup.find_all(["iframe", "embed", "script"]):
    src = t.get("src")
    if src:
        print("  ", t.name, src[:140])
