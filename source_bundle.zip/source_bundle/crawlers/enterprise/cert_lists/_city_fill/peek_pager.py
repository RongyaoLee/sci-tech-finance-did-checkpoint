# -*- coding: utf-8 -*-
"""Inspect 陕西 tzgg list page pagination markup."""
import requests, urllib3, re, os
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})
u = 'https://kjt.shaanxi.gov.cn/kjdt/tzgg/index.html'
r = s.get(u, timeout=45, verify=False); r.encoding = r.apparent_encoding or 'utf-8'
t = r.text
open(os.path.join(RAW, '_sx_tzgg_list2.html'), 'w', encoding='utf-8').write(t)
print('len', len(t))
for kw in ['index_', 'page', '总数', '下一页', 'createPageHTML', 'countPage', 'turnpage']:
    idxs = [m.start() for m in re.finditer(re.escape(kw), t)][:5]
    print(kw, idxs)
    for i in idxs[:2]:
        print('   ...', re.sub(r'\s+', ' ', t[max(0, i - 200):i + 260]))
