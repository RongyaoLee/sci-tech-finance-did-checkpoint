﻿# -*- coding: utf-8 -*-
import os,sys,re,urllib.parse
sys.path.insert(0,os.getcwd())
sys.path.insert(0,r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists")
import cf,fetch_common as fc
T=["http://czj.shaoyang.gov.cn//syczj/tzgg/202009/f87efa25b4594d4285572fb9e2fa24e7.shtml",
   "http://czj.shaoyang.gov.cn//syczj/tzgg/202304/68178c3033904316be51a0cd93fe7c10.shtml",
   "http://czj.shaoyang.gov.cn//syczj/tzgg/202103/70da06ff734e4463bb213e174aa99c6d.shtml"]
out=open("_hn_sy.txt","w",encoding="utf-8")
for u in T:
    h,f=cf.get(u)
    out.write("\n===== %s\n"%u)
    if not h: out.write("FAIL\n"); continue
    t=re.search(r"<title>(.*?)</title>",h,re.S); out.write("TITLE %s\n"%(t.group(1).strip()[:80] if t else "?"))
    atts=cf.attachments(f,h); out.write("ATTS %s\n"%[(a[0][:50],a[1][:95]) for a in atts][:5])
    body=re.sub(r"<(script|style)[^>]*>.*?</\1>","",h,flags=re.S|re.I)
    txt=re.sub(r"<[^>]+>","\n",body).replace("&nbsp;"," ")
    ls=[re.sub(r"\s+","",x) for x in txt.split("\n")]; ls=[x for x in ls if x]
    cand=[x for x in ls if re.search(r"(公司|厂|中心|研究院|集团)$",x) and 5<len(x)<40]
    out.write("NAMES %d\n"%len(cand))
    for x in cand[:12]: out.write("   - %s\n"%x)
    for at,au in atts[:3]:
        p=cf.download(au,"hnx")
        if not p: out.write("   DLFAIL\n"); continue
        try: rr=fc.extract(p)
        except Exception as e: out.write("   ERR %s\n"%e); continue
        out.write("   ATT %s %d %s\n"%(os.path.basename(p),len(rr),[x.get("name","")[:20] for x in rr[:4]]))
out.close(); print("ok")
