# -*- coding: utf-8 -*-
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

url = "https://yiyang.gov.cn/yyskjj/1217/content_2062053.html"
html, final = cf.get(url)
i = html.find("拟补助名单.xlsx")
print(html[max(0, i - 700):i + 120])
