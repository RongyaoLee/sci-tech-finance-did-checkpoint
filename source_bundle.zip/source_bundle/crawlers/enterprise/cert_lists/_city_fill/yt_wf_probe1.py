# -*- coding: utf-8 -*-
"""探测 烟台(kjj.yantai.gov.cn) / 潍坊(kjj.weifang.gov.cn) 站点结构与列表接口。"""
import sys, re, json, os
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

OUT = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_yt_wf_probe1.json"

def show(tag, url, pat=None, maxn=60):
    sc, html, final = H.get(url, timeout=25, tries=2)
    print("[%s] %s -> %s len=%s final=%s" % (tag, url, sc, len(html or ""), final), flush=True)
    rec = {"tag": tag, "url": url, "status": sc, "final": final, "len": len(html or "")}
    if sc != 200 or not html:
        return rec
    H.save_raw("probe_" + tag, url, html.encode("utf-8", "ignore"))
    links = H.img_links(html, final)
    if pat:
        links = [(u, t) for u, t in links if re.search(pat, t)]
    rec["links"] = links[:maxn]
    for u, t in links[:maxn]:
        print("   ", t[:40], "|", u[:130], flush=True)
    return rec

def main():
    res = []
    res.append(show("yt_home", "http://kjj.yantai.gov.cn/", r"高新|通知|公告|公示|名单|政策"))
    res.append(show("wf_home", "http://kjj.weifang.gov.cn/", r"高新|通知|公告|公示|名单"))
    res.append(show("wf_gd10", "http://kjj.weifang.gov.cn/kjjgd/?id=10", None, 80))
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    print("->", OUT)

if __name__ == "__main__":
    main()
