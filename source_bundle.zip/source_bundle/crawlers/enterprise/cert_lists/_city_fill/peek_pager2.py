# -*- coding: utf-8 -*-
"""Extract pager JS vars + city 科技局 URLs from 陕西 tzgg list page; test index_1 diff."""
import requests, urllib3, re, os, hashlib
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})
t = open(os.path.join(RAW, '_sx_tzgg_list2.html'), encoding='utf-8').read()
for v in ['_sPageName', '_sPageExt', '_nPageCount', '_nCurrIndex']:
    for m in re.finditer(v + r'\s*=\s*["\']?([^;"\']+)', t):
        print(v, '=', m.group(1)[:60])
print('--- city links')
for m in re.finditer(r'<option value="([^"]+)">([^<]+)</option>', t):
    print('  ', m.group(2), '|', m.group(1))
r1 = s.get('https://kjt.shaanxi.gov.cn/kjdt/tzgg/index_1.html', timeout=45, verify=False)
r2 = s.get('https://kjt.shaanxi.gov.cn/kjdt/tzgg/index_3.html', timeout=45, verify=False)
for nm, rr in (('p1', r1), ('p3', r2)):
    rr.encoding = rr.apparent_encoding or 'utf-8'
    ts = [x for x in re.findall(r't20\d{6}_\d+\.html', rr.text)][:6]
    print(nm, rr.status_code, len(rr.text), 'md5', hashlib.md5(rr.text.encode('utf-8', 'ignore')).hexdigest()[:8], ts)
