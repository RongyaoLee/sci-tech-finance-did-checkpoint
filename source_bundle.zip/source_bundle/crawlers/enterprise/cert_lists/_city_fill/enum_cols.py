# -*- coding: utf-8 -*-
"""Enumerate 陕西科技厅 tzgg + 山西科技厅 通知公告 columns; collect 高新 titles."""
import requests, urllib3, re, time, json, os, sys
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})


def get(u, binary=False):
    for attempt in range(2):
        try:
            r = s.get(u, timeout=30, verify=False)
        except Exception as e:
            return 0, str(e)[:90], u
        if r.status_code == 200:
            if binary:
                return 200, r.content, r.url
            r.encoding = r.apparent_encoding or 'utf-8'
            return 200, r.text, r.url
        # http/https swap
        alt = u.replace('https://', 'http://', 1) if u.startswith('https://') else u.replace('http://', 'https://', 1)
        if attempt == 0 and alt != u:
            u = alt
            continue
        return r.status_code, '', u
    return 0, '', u


def links(html):
    out = []
    for m in re.finditer(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', html, re.S):
        txt = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', m.group(2))).strip()
        if txt:
            out.append((txt, m.group(1)))
    return out


def crawl(base, patterns, maxpage, tag):
    found = {}
    for p in range(0, maxpage):
        got = False
        for pat in patterns:
            u = base + (pat.format(p=p) if p else '')
            st, t, fu = get(u)
            if st == 200 and len(t) > 3000:
                got = True
                break
        if not got:
            print(tag, 'stop at page', p, u, st)
            break
        n = 0
        for txt, href in links(t):
            if '高新' in txt and len(txt) < 90:
                key = txt
                if key not in found:
                    found[key] = href
                    n += 1
        print(tag, 'page', p, 'len', len(t), 'new', n)
        time.sleep(0.5)
    json.dump(found, open(os.path.join(RAW, f'_{tag}_gaoxin.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    for k, v in found.items():
        print('  ', k[:80], '|', v)
    return found


print('=== 陕西 tzgg')
crawl('https://kjt.shaanxi.gov.cn/kjdt/tzgg/', ['index.html', 'index_{p}.html'], 30, 'sx_tzgg')
print('=== 山西 tzgg')
crawl('https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/azt_11688/tzgg_11716/', ['', 'index.shtml', 'index_{p}.shtml'], 20, 'sxkj_tzgg')
