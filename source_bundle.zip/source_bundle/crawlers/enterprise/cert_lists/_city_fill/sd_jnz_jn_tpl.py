# -*- coding: utf-8 -*-
"""济南市科技局：枚举 工作通知/公告公示/政策法规 列表（unit API 分页）。"""
import sys, json, re, requests
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import sd_jnz_lib as L

BASEURL = "http://jnsti.jinan.gov.cn/api-gateway/jpaas-publish-server/front/page/build/unit"
WEBID = "10"
COLS = {
    "13061": "GbnFskR3C7PD0nABf9KzT",   # 工作通知
    "11650": None,                      # 公告公示（tplSetId 未知，先探）
}
# 先探 col11650 / col11651 的 tplSetId
probe = {}
for col in ["11650", "11651", "11652"]:
    st, html, final = L.get("http://jnsti.jinan.gov.cn/col/col%s/index.html" % col)
    m = re.search(r"queryData=\"([^\"]+)\"", html or "")
    probe[col] = m.group(1) if m else None
    print("col", col, "tpl:", (probe[col] or "")[:120])
json.dump(probe, open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_jn_tpl.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
