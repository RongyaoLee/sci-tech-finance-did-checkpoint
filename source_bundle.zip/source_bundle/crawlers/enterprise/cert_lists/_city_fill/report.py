# -*- coding: utf-8 -*-
"""Final metrics for the 城市 back-fill: per-province coverage table."""
import os, sys, collections, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import city_common as cc

ENTRY = {
    "湖北省": ("https://kjt.hubei.gov.cn/ywt/#/portal/bmcx/bm008001",
               "政务服务查询接口 JSON（/ywt/services/portal/search/commonSearch，flid=008001，areaname 字段）"),
    "湖南省": ("http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/", "（见备注）"),
    "陕西省": ("https://kjt.shaanxi.gov.cn/kjdt/ztzl/lszt/gqrd/index.html", "（见备注）"),
}


def main():
    rows_out = []
    for prov in cc.PROVS:
        rows, _ = cc.read_prov(prov)
        filled = [r for r in rows if (r["城市"] or "").strip()]
        empty = len(rows) - len(filled)
        yrs = collections.Counter(r["认定年度"] for r in filled)
        cities = collections.Counter(r["城市"] for r in filled)
        years = sorted(yrs)
        rows_out.append({
            "prov": prov, "total": len(rows), "filled": len(filled), "empty": empty,
            "city_n": len(cities), "years": years,
            "year_counts": dict(sorted(yrs.items())),
            "city_counts": dict(cities.most_common()),
            "entry": ENTRY[prov][0], "kind": ENTRY[prov][1],
        })
        print(f"{prov}\ttotal={len(rows)}\tfilled={len(filled)}\tempty={empty}\t"
              f"cities={len(cities)}\tyears={years[0] if years else '-'}..{years[-1] if years else '-'}")
        print("   year:", dict(sorted(yrs.items())))
        print("   city:", dict(cities.most_common()))
    json.dump(rows_out, open(os.path.join(cc.FILL, "_report.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
