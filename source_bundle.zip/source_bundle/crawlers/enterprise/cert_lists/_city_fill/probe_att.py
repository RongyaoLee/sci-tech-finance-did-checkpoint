# -*- coding: utf-8 -*-
"""Generic: fetch notice pages, download attachments, print table headers (doc/docx/xls/pdf)."""
import requests, urllib3, re, os, io, sys, json
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})


def get(u, bin=False):
    try:
        r = s.get(u, timeout=60, verify=False)
    except Exception as e:
        return 0, ('', str(e)[:70])[0] if not bin else b'', str(e)[:70]
    if r.status_code != 200:
        return r.status_code, (b'' if bin else ''), ''
    if bin:
        return 200, r.content, r.url
    r.encoding = r.apparent_encoding or 'utf-8'
    return 200, r.text, r.url


def tables_from(content, fn):
    out = []
    low = fn.lower()
    try:
        if low.endswith('.docx'):
            from docx import Document
            d = Document(io.BytesIO(content))
            for tb in d.tables:
                out.append([[c.text.strip() for c in row.cells] for row in tb.rows])
            paras = [p.text.strip() for p in d.paragraphs if p.text.strip()]
            out.append([paras[:6]])
        elif low.endswith(('.xlsx', '.et')):
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
            for ws in wb.worksheets:
                out.append([[('' if c is None else str(c).strip()) for c in row] for row in ws.iter_rows(values_only=True)])
        elif low.endswith('.xls'):
            import xlrd
            wb = xlrd.open_workbook(file_contents=content)
            for ws in wb.sheets():
                out.append([[str(ws.cell_value(i, j)) for j in range(ws.ncols)] for i in range(ws.nrows)])
        elif low.endswith('.pdf'):
            import fitz
            doc = fitz.open(stream=content, filetype='pdf')
            txt = '\n'.join(pg.get_text() for pg in doc)
            out.append([[ln] for ln in txt.split('\n')[:60]])
        elif low.endswith('.doc'):
            import olefile
            of = olefile.OleFileIO(io.BytesIO(content))
            data = of.openstream('WordDocument').read()
            dec = data.decode('utf-16-le', 'ignore')
            runs = re.findall(r'[\u4e00-\u9fa5A-Za-z0-9（）()]{2,}', dec)
            out.append([['RUNS'] + runs[:60]])
    except Exception as e:
        out.append([['ERR', str(e)[:80]]])
    return out


pages = sys.argv[1:]
for u in pages:
    st, t, fu = get(u)
    print('=====', u, st, len(t) if isinstance(t, str) else 0)
    if st != 200:
        continue
    base = fu.rsplit('/', 1)[0] + '/'
    atts = []
    for m in re.finditer(r'href=[\'"]([^\'"]+\.(?:pdf|docx?|xlsx?|et|zip|rar))[\'"]', t, re.I):
        h = m.group(1)
        if h.startswith('http'):
            atts.append(h)
        elif h.startswith('/'):
            atts.append('https://kjt.shaanxi.gov.cn' + h)
        else:
            atts.append(base + h.lstrip('./'))
    print('  atts', atts)
    for a in atts[:6]:
        st2, content, _ = get(a, bin=True)
        if st2 != 200:
            print('   skip', a, st2); continue
        fn = a.rsplit('/', 1)[-1]
        open(os.path.join(RAW, 'att_' + fn), 'wb').write(content)
        print('   ==', fn, len(content))
        for tb in tables_from(content, fn)[:2]:
            if not tb:
                continue
            for row in tb[:3]:
                print('      ', [str(c)[:26] for c in row][:10])
            print('      rows', len(tb))
