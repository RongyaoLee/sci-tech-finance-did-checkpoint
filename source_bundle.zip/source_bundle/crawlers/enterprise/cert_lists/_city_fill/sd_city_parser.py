# -*- coding: utf-8 -*-
"""表格解析：保留「所属区市/所在市/区县」列。输出 (name, cert, city, district)。"""
import io, re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_lib as S

CERT_RE = S.CERT_RE
CITY_HDR = ("所属区市", "所在市", "所属市", "地市", "城市", "市地", "区域", "所属区域", "所在地区", "市（地）", "市(地)")
DIST_HDR = ("所属区县", "区县", "县区", "所属县区", "所在区县", "县（市、区）", "区（市）")
NAME_HDR = ("企业名称", "单位名称", "公司名称", "企业")
CERT_HDR = ("证书编号", "证书号", "编号")

SHANDONG_CITIES = ["济南", "青岛", "淄博", "枣庄", "东营", "烟台", "潍坊", "济宁", "泰安",
                   "威海", "日照", "临沂", "德州", "聊城", "滨州", "菏泽"]

DISTRICTS = {
    "济南": ["历下", "市中", "槐荫", "天桥", "历城", "长清", "章丘", "济阳", "莱芜", "钢城", "平阴", "商河"],
    "淄博": ["张店", "淄川", "博山", "临淄", "周村", "桓台", "高青", "沂源"],
    "枣庄": ["市中", "薛城", "峄城", "台儿庄", "山亭", "滕州"],
    "东营": ["东营区", "河口", "垦利", "利津", "广饶"],
    "烟台": ["芝罘", "福山", "牟平", "莱山", "蓬莱", "龙口", "莱阳", "莱州", "招远", "栖霞", "海阳", "开发区", "高新区", "长岛"],
    "潍坊": ["潍城", "寒亭", "坊子", "奎文", "青州", "诸城", "寿光", "安丘", "高密", "昌邑", "临朐", "昌乐", "高新", "滨海", "峡山", "经济区"],
    "济宁": ["任城", "兖州", "微山", "鱼台", "金乡", "嘉祥", "汶上", "泗水", "梁山", "曲阜", "邹城", "高新", "太白湖", "经开区"],
    "泰安": ["泰山", "岱岳", "宁阳", "东平", "新泰", "肥城", "高新"],
    "威海": ["环翠", "文登", "荣成", "乳山", "高区", "经区", "临港", "南海"],
    "日照": ["东港", "岚山", "五莲", "莒县", "开发区", "山海天", "高新"],
    "临沂": ["兰山", "罗庄", "河东", "沂南", "郯城", "沂水", "兰陵", "费县", "平邑", "莒南", "蒙阴", "临沭", "高新", "经开"],
    "德州": ["德城", "陵城", "宁津", "庆云", "临邑", "齐河", "平原", "夏津", "武城", "乐陵", "禹城", "经开", "运河"],
    "聊城": ["东昌府", "阳谷", "莘县", "茌平", "东阿", "冠县", "高唐", "临清", "经开", "高新"],
    "滨州": ["滨城", "沾化", "惠民", "阳信", "无棣", "博兴", "邹平", "经开", "高新"],
    "菏泽": ["牡丹", "定陶", "曹县", "单县", "成武", "巨野", "郓城", "鄄城", "东明", "经开", "高新"],
}


def norm_cell(c):
    if c is None:
        return ""
    s = str(c).replace("\u3000", " ").replace("\xa0", " ").replace("\n", " ")
    return re.sub(r"\s+", "", s).strip()


def _hits(cell, hdrs):
    return any(h in cell for h in hdrs)


def norm_city(s):
    """把 '威海市' '环翠区' '荣成市' 归一到地级市；返回 (city, district) 或 ('','')。"""
    s = norm_cell(s)
    if not s:
        return "", ""
    sc = s.rstrip("市")
    for c in SHANDONG_CITIES:
        if sc == c or s.startswith(c + "市"):
            rest = s[len(c) + 1:] if s.startswith(c + "市") else s[len(c):]
            return c, rest.strip("市")
    # 只给了区县
    for c, ds in DISTRICTS.items():
        for d in ds:
            if s.startswith(d):
                return c, s
    return "", s


def rows_from_tables(tables, default_city="", allow_default=False):
    """tables: list[list[list[cell]]]，每个 table 是行列表。返回 [(name,cert,city,dist)]"""
    out = []
    for tb in tables:
        ci = ni = ti = di = -1
        last_city = last_dist = ""
        for i, row in enumerate(tb[:6]):
            cells = [norm_cell(c) for c in row]
            if not any(cells):
                continue
            for j, c in enumerate(cells):
                if not c:
                    continue
                if ci < 0 and _hits(c, CITY_HDR):
                    ci = j
                elif di < 0 and _hits(c, DIST_HDR):
                    di = j
                elif ni < 0 and _hits(c, NAME_HDR):
                    ni = j
                elif ti < 0 and _hits(c, CERT_HDR):
                    ti = j
        has_geo_col = ci >= 0 or di >= 0
        for row in tb:
            cells = [norm_cell(c) for c in row]
            if not any(cells):
                continue
            if any(_hits(c, CERT_HDR) or _hits(c, NAME_HDR) for c in cells):
                continue
            nm = cells[ni] if 0 <= ni < len(cells) else ""
            ct = S.norm_cert(cells[ti]) if 0 <= ti < len(cells) else ""
            if not ct:
                ct = S.norm_cert(" ".join(cells))
            if not nm:
                cand = [c for c in cells if S.looks_name(c)]
                nm = cand[0] if cand else ""
            city = dist = ""
            if 0 <= ci < len(cells) and cells[ci]:
                city, dist = norm_city(cells[ci])
            if not city and 0 <= di < len(cells) and cells[di]:
                c2, d2 = norm_city(cells[di])
                city, dist = (c2 or city), (d2 or dist)
            if not city and has_geo_col and last_city:
                # 纵向合并单元格：所属市/区县只写在分组首行，向下继承
                city, dist = last_city, (dist or last_dist)
            if not city:
                # 行内其他短单元格可能带地名（如「环翠区」单列）；企业名不参与，防误判
                for j, c in enumerate(cells):
                    if j in (ni, ti) or len(c) > 10 or S.looks_name(c):
                        continue
                    if not re.search(r"[市区县]$", c):
                        continue
                    c2, d2 = norm_city(c)
                    if c2:
                        city, dist = c2, (dist or d2)
                        break
            if city and has_geo_col:
                last_city, last_dist = city, (dist or "")
            if not city and default_city and allow_default:
                # 仅当调用方确认「该文档是本市专属名单」时才允许用文档所属市兜底
                city, dist = norm_city(default_city)[0], dist
            if city and not dist:
                for c in cells:
                    if re.search(r"(区|县|市)$", c) and len(c) <= 8 and c not in (nm,):
                        if re.search(r"(区|县|市)$", c) and c.rstrip("市区县") in ("",):
                            continue
                        d2 = c
                        if any(d2.startswith(d) for d in DISTRICTS.get(city, [])):
                            dist = d2
                            break
            if nm or ct:
                out.append((nm, ct, city, dist))
    return out


def pdf_tables(data):
    import fitz
    tabs = []
    doc = fitz.open(stream=data, filetype="pdf")
    for page in doc:
        try:
            for t in page.find_tables().tables:
                g = t.extract()
                if g:
                    tabs.append(g)
        except Exception:
            pass
    doc.close()
    return tabs


def pdf_text(data):
    import fitz
    doc = fitz.open(stream=data, filetype="pdf")
    t = "\n".join(p.get_text() for p in doc)
    doc.close()
    return t


def xlsx_tables(data):
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    tabs = []
    for ws in wb.worksheets:
        tabs.append([list(r) for r in ws.iter_rows(values_only=True)])
    return tabs


def rows_from_doc(url, data, default_city="", allow_default=False):
    low = url.lower()
    tabs = []
    try:
        if data[:4] == b"%PDF" or ".pdf" in low:
            tabs = pdf_tables(data)
        elif data[:2] == b"PK":
            if b"xl/" in data[:4096] or ".xlsx" in low or ".et" in low:
                tabs = xlsx_tables(data)
            else:
                import docx
                d = docx.Document(io.BytesIO(data))
                tabs = [[[c.text for c in r.cells] for r in t.rows] for t in d.tables]
        elif data[:4] == b"\xd0\xcf\x11\xe0":
            import xlrd
            bk = xlrd.open_workbook(file_contents=data)
            for sh in bk.sheets():
                tabs.append([[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(sh.nrows)])
    except Exception as e:
        return [("##ERR", "", type(e).__name__, str(e)[:60])]
    rows = rows_from_tables(tabs, default_city, allow_default)
    if not rows and (data[:4] == b"%PDF" or ".pdf" in low):
        txt = pdf_text(data)
        city, _ = norm_city(default_city)
        for nm, ct in S.rows_from_text(txt):
            rows.append((nm, ct, city, ""))
    return rows
