# -*- coding: utf-8 -*-
"""唐山科技局 公示公告/市局通知 多页枚举 → 抓高企名单附件。"""
import io, sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from _hhn_hb_city3 import parse_pairs

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, '_hb_city_rows.jsonl')
BASEURL = 'https://kejiju.tangshan.gov.cn'
COLS = ['/tangshankjj/shikjj1kjzx2tzgg3gsgg/index.html',
        '/tangshankjj/shikjj1kjzx2tzgg3sjtz/index.html',
        '/tangshankjj/shikjj1kjzx2tzgg/index.html']

have = set()
if os.path.exists(OUT):
    for line in open(OUT, encoding='utf-8'):
        try:
            d = json.loads(line); have.add((d['name'], d['city']))
        except Exception:
            pass
fh = open(OUT, 'a', encoding='utf-8')
arts = {}
for col in COLS:
    for pg in range(0, 26):
        u = BASEURL + col if pg == 0 else BASEURL + col.replace('index.html', 'index_%d.html' % pg)
        st, txt, fu = H.get(u, timeout=25)
        if st != 200 or not txt or len(txt) < 3000:
            break
        n0 = len(arts)
        for href, lab in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', txt, re.S):
            lab = re.sub(r'\s+', '', re.sub(r'<[^>]+>', '', lab))
            if len(lab) < 6:
                continue
            if any(k in lab for k in ('高新技术企业', '高企', '高新企业')):
                if href.startswith('/'):
                    href = BASEURL + href
                arts.setdefault(href, lab)
        print(col[:40], pg, 'new', len(arts) - n0, 'total', len(arts))
        if len(arts) == n0 and pg > 3:
            break
print('arts', len(arts))
got = 0
for u, lab in arts.items():
    st, txt, fu = H.get(u, timeout=30)
    if st != 200:
        continue
    docs = H.doc_links(H.img_links(txt, fu), fu)
    n = 0
    for d, tt in docs:
        st2, data, _ = H.get(d, timeout=120, binary=True)
        if st2 != 200 or not data:
            continue
        dt = H.doc_text(d, data)
        for name, cert in parse_pairs(dt):
            if (name, '唐山市') in have:
                continue
            have.add((name, '唐山市')); n += 1; got += 1
            fh.write(json.dumps({'city': '唐山市', 'county': '', 'name': name, 'cert': cert,
                                 'src': d}, ensure_ascii=False) + '\n')
    if n:
        print('  +', n, lab[:40])
    fh.flush()
fh.close()
print('TOTAL', got)
