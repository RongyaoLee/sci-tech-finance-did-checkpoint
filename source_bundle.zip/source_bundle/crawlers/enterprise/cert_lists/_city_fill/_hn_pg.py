﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
import cf
u="http://searching.hunan.gov.cn/hunan/001000000/all"
base={"q":"高新技术企业 名单","iszq":"1"}
def sig(h):
    items=re.findall(r'<a[^>]+href="(https?://[^"]+)"[^>]*>(.*?)</a>',h,re.S)
    return [x[0] for x in items][:4]
r=cf.S.get(u,params=base,timeout=30); r.encoding="utf-8"; h1=r.text
print("p0 sig",sig(h1))
for pname in ["page","currentPage","p","pageNum","pageNo"]:
    prm=dict(base); prm[pname]=2
    r=cf.S.get(u,params=prm,timeout=30); r.encoding="utf-8"
    print(pname, sig(r.text)[:2], "same?", sig(r.text)==sig(h1))
