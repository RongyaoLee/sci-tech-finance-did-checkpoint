# -*- coding: utf-8 -*-
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from _hhn_doc_heur import doc_text_heuristic

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(BASE, 'raw')

def text_of(fn):
    p = os.path.join(RAW, fn)
    data = open(p, 'rb').read()
    if fn.endswith(('.doc', '.wps')):
        return doc_text_heuristic(p)
    return H.doc_text(fn, data)

for fn in ['hb_hit_2016122216313760697.docx', 'hb_hit_2017063015373760527.doc',
           'hb_hit_2018050815393890318.docx', 'hb_hit_2023121915465747318.doc']:
    t = text_of(fn)
    print('=' * 20, fn, 'chars', len(t), 'certs', len(H.certs_in_text(t)))
    print(re.sub(r'\n{2,}', '\n', t[:900]))
    print('...')
