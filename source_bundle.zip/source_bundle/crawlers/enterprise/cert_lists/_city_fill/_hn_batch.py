﻿# -*- coding: utf-8 -*-
import os,sys,re,json,urllib.parse
sys.path.insert(0,os.getcwd())
sys.path.insert(0,r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists")
import cf,fetch_common as fc
T=[("https://kjj.changde.gov.cn/kjdt/tzgg/content_907153","常德市"),
   ("http://hygx.hengyang.gov.cn/qyzc/qyxx/20200118/i382337.html","衡阳市"),
   ("http://www.hyzhq.gov.cn/zwgk/bmxxgkml/zhqzfbm/qkgxj/gzjz/20200216/i1392348.html","衡阳市"),
   ("http://wedz.changsha.gov.cn/xwzx/yqdt/202012/t20201225_9692282.html","长沙市"),
   ("http://www.czbeihu.gov.cn/zjbh/bhkj/content_2115798.html","郴州市"),
   ("http://www.cili.gov.cn/c3378/20170906/i298204.html","张家界市"),
   ("http://www.anrenzf.gov.cn/117/51495/65512/65513/65514/65522/content_3661775.html","郴州市"),
   ("http://www.hjs.gov.cn/hjs/c123696/201911/7fc61b71a62c47abad022ad9e9241f77.shtml","未知"),
   ("http://www.hjs.gov.cn/hjs/c123696/201909/ab5af624f42b404f95d20b2e3ba805a8.shtml","未知")]
out=open("_hn_batch.txt","w",encoding="utf-8")
for u,city in T:
    h,f=cf.get(u)
    out.write("\n===== [%s] %s\n"%(city,u))
    if not h:
        out.write("FETCH FAIL\n"); continue
    t=re.search(r"<title>(.*?)</title>",h,re.S)
    out.write("TITLE %s\n"%(t.group(1).strip()[:90] if t else "?"))
    atts=cf.attachments(f,h)
    out.write("ATTS %s\n"%[(a[0][:60],a[1][:100]) for a in atts][:5])
    body=re.sub(r"<(script|style)[^>]*>.*?</\1>","",h,flags=re.S|re.I)
    txt=re.sub(r"<[^>]+>","\n",body).replace("&nbsp;"," ").replace("&amp;","&").replace("&quot;",'"')
    ls=[re.sub(r"\s+","",x) for x in txt.split("\n")]
    cand=[x for x in ls if re.search(r"(公司|厂|中心|研究院|所|集团|企业)$",x) and 5<len(x)<40]
    out.write("NAMES %d\n"%len(cand))
    for x in cand[:8]: out.write("   - %s\n"%x)
    for at,au in atts[:4]:
        p=cf.download(au,"hnx")
        if not p: out.write("   DLFAIL %s\n"%au[:80]); continue
        try: rr=fc.extract(p)
        except Exception as e: out.write("   EXTRACT_ERR %s %s\n"%(os.path.basename(p),e)); continue
        out.write("   ATT %s -> %d rows; e.g. %s\n"%(os.path.basename(p),len(rr),[x.get("name","")[:22] for x in rr[:5]]))
out.close(); print("done")
