# -*- coding: utf-8 -*-
import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

urls = [
    "http://www.innocom.gov.cn/gqrdw/c101419/202512/cada518178604d30b576fb69a3d47296.shtml",
]
for u in urls:
    sc, html, final = H.get(u, timeout=25, tries=2)
    print("===", u, sc, len(html or ""))
    H.save_raw("nb_art", u, html.encode("utf-8", "ignore"))
    if sc != 200:
        continue
    body = re.sub(r"(?is)<script.*?</script>", " ", html)
    body = re.sub(r"(?is)<style.*?</style>", " ", body)
    txt = re.sub(r"<[^>]+>", "\n", body)
    txt = re.sub(r"\n\s*\n+", "\n", txt)
    open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_art1.txt", "w", encoding="utf-8").write(txt)
    for href, t in H.img_links(html, final):
        low = href.lower()
        if any(e in low for e in (".pdf", ".doc", ".xls", ".zip", ".rar")) or "attach" in low or "downfile" in low or "files" in low:
            print("  ATT:", t[:50], "|", href)
    print("  GR in page:", len(H.certs_in_text(txt)))
