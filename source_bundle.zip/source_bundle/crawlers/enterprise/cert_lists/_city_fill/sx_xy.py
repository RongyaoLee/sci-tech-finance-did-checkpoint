# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

u = "https://kjj.xianyang.gov.cn/kjxw/tztg/202410/t20241018_1823764.html"
h, f = cf.get(u, tries=2, timeout=25)
s = cf.soup_of(h)
for t in s(["script", "style"]):
    t.decompose()
txt = re.sub(r"\n{2,}", "\n", s.get_text("\n", strip=True))
idx = [m.start() for m in re.finditer("成功认定", txt)]
print("hits", idx)
k = idx[-1] if idx else 0
print(txt[max(0, k - 300): k + 2600])
