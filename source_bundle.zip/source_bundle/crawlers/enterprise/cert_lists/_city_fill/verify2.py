# -*- coding: utf-8 -*-
import csv, collections, os
CF = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill'
for f in ('陕西省_city.csv', '山西省_city.csv'):
    rows = list(csv.DictReader(open(os.path.join(CF, f), encoding='utf-8-sig', newline='')))
    filled = [r for r in rows if r['城市'].strip()]
    names = {r['企业名称'].strip() for r in filled}
    allnames = {r['企业名称'].strip() for r in rows}
    cc = collections.Counter(r['区县'].strip() for r in filled if r['区县'].strip())
    print(f, 'rows', len(rows), 'filled', len(filled), 'distinct-filled', len(names), 'distinct-all', len(allnames))
    print('   top counties', cc.most_common(6))
    # missing county codes
    miss = collections.Counter()
    for r in filled:
        if not r['区县'].strip():
            miss[r['城市']] += 1
    print('   city w/o county', sum(miss.values()), dict(miss.most_common(6)))
