# -*- coding: utf-8 -*-
"""Generic 湖南 city crawler: walk a column listing, keep articles whose title matches
高企/高新技术企业 keywords, then extract (企业名称, 证书编号, 区县) rows.

Usage: python fc_city_crawl.py spec.json
spec = [{"city":"长沙市","page":"http://kjj.changsha.gov.cn/zfxxgk/tzgg_27202/index_%d.html",
         "pages":40, "start":0, "tag":"changsha"}]
`%d` is replaced with (start..pages). Use "%d" absent -> single page.
"""
import os, sys, re, json, io, time, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup
from fc_hn_rows import tables_of_html, parse_rows2d, doc_rows, log, ROWS

KEY = re.compile(r"(高新技术企业|高企|科技后补助|研发奖补)")
BAD = re.compile(r"(渔业|农业|专利|科技专家|专家库|创新平台|孵化器|众创|瞪羚|科学技术奖|提名)")


def collect(page_tpl, start, pages, city):
    arts = {}
    for i in range(start, pages):
        u = page_tpl % i if "%d" in page_tpl else page_tpl
        html, final = cf.get(u)
        if not html:
            log("  listing FAIL %s" % u)
            continue
        soup = BeautifulSoup(html, "lxml")
        n0 = len(arts)
        for a in soup.find_all("a", href=True):
            t = a.get_text(" ", strip=True)
            if not t or len(t) < 8:
                continue
            if not KEY.search(t) or BAD.search(t):
                continue
            uu = urllib.parse.urljoin(final or u, a["href"])
            if uu.rstrip("/") == (final or u).rstrip("/"):
                continue
            arts.setdefault(uu, t)
        log("  listing p%-3d %s -> +%d (total %d)" % (i, u[-40:], len(arts) - n0, len(arts)))
    return arts


def main():
    spec = json.load(io.open(sys.argv[1], encoding="utf-8"))
    for it in spec:
        city = it["city"]
        log("== %s LISTING %s" % (city, it["page"]))
        arts = collect(it["page"], it.get("start", 0), it.get("pages", 10), city)
        log("  %s articles matched: %d" % (city, len(arts)))
        tot = 0
        with io.open(ROWS, "a", encoding="utf-8") as fout:
            for u, t in arts.items():
                html, final = cf.get(u)
                if not html:
                    log("   FAIL %s" % u)
                    continue
                got = 0
                for rows2d in tables_of_html(html):
                    rows = parse_rows2d(rows2d, city)
                    for r in rows:
                        fout.write(json.dumps(dict(r, src=u, tag=it.get("tag", ""),
                                                   title=t[:60]), ensure_ascii=False) + "\n")
                    got += len(rows)
                for text, au in cf.attachments(u, html):
                    p = cf.download(au, "hn")
                    if not p:
                        continue
                    rows = doc_rows(p, city)
                    log("    att %-40s %s -> %d" % (text[:40], os.path.splitext(p)[1], len(rows)))
                    for r in rows:
                        fout.write(json.dumps(dict(r, src=u, tag=it.get("tag", ""),
                                                   att=os.path.basename(au),
                                                   title=t[:60]), ensure_ascii=False) + "\n")
                    got += len(rows)
                fout.flush()
                tot += got
                log("   %-52s -> %d" % (t[:52], got))
        log("== %s done +%d" % (city, tot))


if __name__ == "__main__":
    main()
