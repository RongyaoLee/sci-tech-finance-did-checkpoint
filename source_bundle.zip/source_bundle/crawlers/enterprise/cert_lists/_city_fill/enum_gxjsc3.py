# -*- coding: utf-8 -*-
"""Parse 山西 gxjsc <li> items, filter 高企认定结果/名单, download attachments, inspect columns."""
import requests, urllib3, re, time, json, os, io
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})


def get(u, binary=False):
    for attempt in range(2):
        try:
            r = s.get(u, timeout=45, verify=False)
        except Exception as e:
            return 0, str(e)[:90], u
        if r.status_code == 200:
            if binary:
                return 200, r.content, r.url
            r.encoding = r.apparent_encoding or 'utf-8'
            return 200, r.text, r.url
        alt = u.replace('https://', 'http://', 1) if u.startswith('https://') else u.replace('http://', 'https://', 1)
        if attempt == 0 and alt != u:
            u = alt
            continue
        return r.status_code, '', u
    return 0, '', u


base = 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/gxjsc/'
items = []
for p in range(0, 19):
    pats = ['', 'index.shtml'] if p == 0 else ['index_{p}.shtml']
    for pat in pats:
        u = base + (pat.format(p=p) if p else pat)
        st, t, fu = get(u)
        if st == 200 and len(t) > 3000:
            break
    if st != 200:
        break
    for m in re.finditer(r'<li>(.*?)</li>', t, re.S):
        blk = m.group(1)
        hm = re.search(r'href="\s*([^"\s]+\.shtml)\s*"', blk)
        if not hm:
            continue
        tm = re.search(r'target="_blank"[^>]*>(.*?)</a>', blk, re.S)
        title = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', tm.group(1))).strip() if tm else ''
        if title:
            items.append((title, hm.group(1).strip(), blk))
    time.sleep(0.35)
print('items', len(items))
uniq = {}
for ti, href, blk in items:
    if ti not in uniq:
        uniq[ti] = href
print('uniq', len(uniq))
json.dump(uniq, open(os.path.join(RAW, '_sxkj_gxjsc_titles.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
hits = {k: v for k, v in uniq.items() if re.search(r'高新', k)}
print('GAOXIN', len(hits))
for k, v in sorted(hits.items()):
    print('  ', k[:120], '|', v)
