# -*- coding: utf-8 -*-
import sys, os, re, json, urllib.parse, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

def ddg(q):
    url = "https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(q)
    h, f = cf.get(url, tries=1, timeout=25)
    if not h:
        return [], f
    out = []
    for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', h, re.S):
        u = m.group(1)
        if "uddg=" in u:
            u = urllib.parse.unquote(re.search(r"uddg=([^&]+)", u).group(1))
        t = re.sub(r"<[^>]+>", "", m.group(2)).strip()
        out.append((t, u))
    return out, f

QS = [
    "西安高新区 领取 高新技术企业证书 通知",
    "宝鸡高新区 高新技术企业证书 名单",
    "咸阳高新区 高新技术企业 证书 名单",
    "渭南高新区 高新技术企业 证书 名单",
]
for q in QS:
    r, f = ddg(q)
    print("##", q, len(r), f if not r else "")
    for t, u in r[:8]:
        print("   ", t[:60], "|", u[:120])
