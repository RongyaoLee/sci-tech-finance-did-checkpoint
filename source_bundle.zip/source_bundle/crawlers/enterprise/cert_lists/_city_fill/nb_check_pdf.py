# -*- coding: utf-8 -*-
import sys, re, os, glob
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H

# find a 2025 pdf in raw/nb_doc
for p in sorted(glob.glob(os.path.join(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw\nb_doc", "*.pdf")))[:3]:
    u = "http://x" + p[p.find("_"):]
    data = open(p, "rb").read()
    txt = H.doc_text(p, data)
    print("====", os.path.basename(p), len(txt))
    lines = [l.strip() for l in txt.split("\n") if "GR" in l]
    print("GR lines:", len(lines))
    for l in lines[:5]:
        print("   ", repr(l[:120]))
    # also check name lines
    nl = [l.strip() for l in txt.split("\n") if "有限公司" in l or "股份" in l]
    print("name lines:", len(nl), nl[:3])
