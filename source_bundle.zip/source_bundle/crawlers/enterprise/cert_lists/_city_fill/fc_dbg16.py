# -*- coding: utf-8 -*-
import sys, os, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

L = [
    ("株洲市", "http://kjj.zhuzhou.gov.cn/c10930/index.html"),
    ("邵阳市", "http://kjj.shaoyang.gov.cn/sykjj/gzdt/rlist.shtml"),
    ("张家界市", "http://kjj.zjj.gov.cn/c903/index.html"),
    ("永州市", "https://kjj.yzcity.gov.cn/kjj/0202/bmlist2.shtml"),
    ("娄底市", "https://kjj.hnloudi.gov.cn/ldkjj/07/list.shtml"),
    ("岳阳市", "http://kjj.yueyang.gov.cn/"),
    ("益阳市", "http://yiyang.gov.cn/yyskjj/1217/default.htm"),
    ("常德市", "https://kjj.changde.gov.cn/zwgk/public/column/6617349?type=4&catId=6718998&action=list"),
]
for city, u in L:
    html, final = cf.get(u, tries=1)
    if not html:
        print("%-10s FAIL %s" % (city, u)); continue
    soup = BeautifulSoup(html, "lxml")
    arts = []
    for a in soup.find_all("a", href=True):
        t = a.get_text(" ", strip=True)
        h = a["href"]
        if len(t) >= 10 and re.search(r"(高新技术企业|高企|奖补|补助|公示|通知)", t):
            arts.append((t[:34], urllib.parse.urljoin(final or u, h)))
    print("%-10s len=%-7d arts=%d" % (city, len(html), len(arts)))
    for t, h in arts[:5]:
        print("     ", t, "->", h[:100])
