# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from fc_hn_rows import tables_of_html, parse_rows2d

for url, city in [("https://kjj.changde.gov.cn/zwgk/public/6617349/3700379621.html", "常德市"),
                  ("https://yiyang.gov.cn/yyskjj/1217/content_2062053.html", "益阳市")]:
    html, final = cf.get(url)
    print("=" * 70)
    print(city, final, "html len", len(html) if html else 0)
    tbs = tables_of_html(html)
    print("tables:", len(tbs))
    for i, t in enumerate(tbs[:3]):
        print(" table", i, "rows", len(t))
        for r in t[:6]:
            print("   ", r)
        print("  parsed:", len(parse_rows2d(t, city)))
