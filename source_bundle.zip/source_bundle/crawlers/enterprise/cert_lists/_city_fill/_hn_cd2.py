﻿# -*- coding: utf-8 -*-
import os,sys,re
sys.path.insert(0,os.getcwd())
import cf
h,f=cf.get("https://kjj.changde.gov.cn/kjdt/tzgg/content_907153")
out=open("_hn_cd2.txt","w",encoding="utf-8")
if h:
    for m in re.finditer(r"附件",h):
        s=max(0,m.start()-400); out.write("...%s...\n\n"%re.sub(r"\s+"," ",h[s:m.start()+600]))
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\']',h,re.I):
        out.write("A %s\n"%m.group(1))
out.close(); print("ok")
