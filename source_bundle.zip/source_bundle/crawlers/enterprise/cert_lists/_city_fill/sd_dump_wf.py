# -*- coding: utf-8 -*-
"""Dump raw rows of the Weifang-hosted 2025 xls to see if it carries a 市 column."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_city_parser as P

p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "raw_so", "WY2022474096813674496.xls")
print("exists", os.path.exists(p), os.path.getsize(p) if os.path.exists(p) else 0)
data = open(p, "rb").read()
print("magic", data[:8])
if data[:4] == b"\xd0\xcf\x11\xe0":
    import xlrd
    bk = xlrd.open_workbook(file_contents=data)
    for sh in bk.sheets():
        print("SHEET", sh.name, sh.nrows, sh.ncols)
        for r in range(min(12, sh.nrows)):
            print(r, [str(sh.cell_value(r, c))[:28] for c in range(min(sh.ncols, 8))])
else:
    tabs = P.xlsx_tables(data)
    for t in tabs[:2]:
        print("TAB", len(t))
        for row in t[:12]:
            print([str(c)[:28] for c in row[:8]])
