# -*- coding: utf-8 -*-
import requests, urllib3, re, sys
urllib3.disable_warnings()
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
cands = [
    'https://kjt.shaanxi.gov.cn/kjdt/tzgg/index.html',
    'https://kjt.shaanxi.gov.cn/kjdt/tzgg/index.shtml',
    'https://kjt.shaanxi.gov.cn/kjdt/tzgg/index_1.shtml',
    'https://kjt.shaanxi.gov.cn/kjdt/tzgg/index_1.html',
    'https://kjt.shaanxi.gov.cn/kjdt/',
    'https://kjt.shaanxi.gov.cn/',
]
for u in cands:
    try:
        r = requests.get(u, headers={'User-Agent': UA}, timeout=40, verify=False)
        r.encoding = r.apparent_encoding or 'utf-8'
        t = r.text
        links = re.findall(r'href=[\'"]((?:\.\./|\./|/)?(?:kjdt/)?tzgg/[^\'"]+\.s?html)[\'"]', t)
        print(f'{r.status_code} {len(t):7d} {u} links={len(links)}')
        if links:
            print('    ', links[:6])
        m = re.findall(r'(拟认定|高新技术企业)', t)
        print('    kw hits', len(m))
    except Exception as e:
        print('ERR', u, str(e)[:70])
