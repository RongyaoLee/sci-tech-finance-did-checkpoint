# -*- coding: utf-8 -*-
"""济南市科技局：分页枚举栏目全部文章（title,url,date）。v2：解析 JSON 外壳。"""
import sys, json, re, requests
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import sd_jnz_lib as L

BASEURL = "http://jnsti.jinan.gov.cn/api-gateway/jpaas-publish-server/front/page/build/unit"
TPL = "GbnFskR3C7PD0nABf9KzT"

def page(col, pageno, size=20):
    p = {"parseType": "bulidstatic", "webId": "10", "tplSetId": TPL, "pageType": "column",
         "tagId": "信息列表", "editType": "null", "pageId": col,
         "paramJson": json.dumps({"pageNo": pageno, "pageSize": size}, ensure_ascii=False)}
    u = BASEURL + "?" + "&".join("%s=%s" % (k, requests.utils.quote(str(v))) for k, v in p.items())
    st, body, final = L.get(u)
    try:
        j = json.loads(body)
        return st, j.get("data", {}).get("html", "")
    except Exception:
        return st, ""

ITEM = re.compile(r'<a href="([^"]+)"[^>]*title="([^"]*)"[^>]*>.*?</a>\s*<span[^>]*>\[(\d{4}-\d{2}-\d{2})\]', re.S)

def parse(html, col):
    out = []
    for m in ITEM.finditer(html or ""):
        u, t, d = m.group(1), m.group(2), m.group(3)
        if "col%s/art" % col not in u:
            continue
        out.append([t.strip(), ("http://jnsti.jinan.gov.cn" + u) if u.startswith("/") else u, d])
    return out

allart = {}
for col in ["13061", "11650"]:
    seen = {}
    for pn in range(1, 120):
        st, html = page(col, pn)
        items = parse(html, col)
        new = 0
        for t, u, d in items:
            if u in seen:
                continue
            seen[u] = [t, d]
            new += 1
        print("col%s p%d st=%s items=%d new=%d total=%d" % (col, pn, st, len(items), new, len(seen)))
        if new == 0 or not items:
            break
    allart[col] = seen

json.dump(allart, open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_jn_arts.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

kw = ["高新", "名单", "公示", "认定", "奖励", "补助"]
hits = []
for col, d in allart.items():
    for u, (t, dt) in d.items():
        if any(k in t for k in kw):
            hits.append([col, dt, t, u])
with open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_jn_hits.txt", "w", encoding="utf-8") as f:
    for col, dt, t, u in sorted(hits, key=lambda x: x[1], reverse=True):
        f.write("%s\t%s\t%s\t%s\n" % (col, dt, t, u))
print("hits", len(hits), "total", sum(len(v) for v in allart.values()))
