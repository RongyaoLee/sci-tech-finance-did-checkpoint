# -*- coding: utf-8 -*-
"""市级发布件采集器：某市科技局站内找「高新技术企业」栏目 -> 翻页 -> 抓文章内嵌表/附件
   发布主体=该市，故整份名单 default_city=该市（合规：城市来自发布主体而非编号反推）。
用法: python _sp_city.py <省> <市> <host1,host2,...>
"""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
import harvest as H
from urllib.parse import urljoin, urlparse

KEY = "高新技术企业"
HERE = os.path.dirname(os.path.abspath(__file__))


def txt(d):
    t = d.decode("utf-8", "ignore")
    if t.count("\ufffd") > 30:
        t = d.decode("gb18030", "ignore")
    return t


def anchors(t, base):
    out = []
    for m in re.finditer(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', t, re.S):
        n = re.sub(r"<[^>]+>|[\s\u200b]+", "", m.group(2))
        if n:
            out.append((n, urljoin(base, m.group(1))))
    return out


def pages_of(base, t, limit=6):
    """栏目翻页：优先找页面里出现的 index_N 链接，其次按常见规则试。"""
    urls = [base]
    cand = set()
    for n, u in anchors(t, base):
        if re.search(r"(index|list)_\d+\.(s?html?)", u) and urlparse(u).path.count("/") <= urlparse(base).path.count("/") + 1:
            cand.add(u)
    dirs = base if base.endswith("/") else base.rsplit("/", 1)[0] + "/"
    stem = re.search(r"(index|list)\.(s?html?)$", base)
    for i in range(1, limit + 1):
        if stem:
            cand.add(dirs + "%s_%d.%s" % (stem.group(1), i, stem.group(2)))
        else:
            cand.add(dirs + "index_%d.shtml" % i)
            cand.add(dirs + "index_%d.html" % i)
    urls += sorted(cand)
    return urls[:limit + 2]


def main():
    prov, city, hosts = sys.argv[1], sys.argv[2], sys.argv[3].split(",")
    OUT = os.path.join(HERE, "parts", prov + ".jsonl")
    home = None
    for h in hosts:
        for scheme in ("http://", "https://"):
            u = scheme + h.strip("/") + "/"
            sc, d, f = H.get(u, timeout=15, tries=1, binary=True)
            if sc == 200 and d and len(d) > 3000:
                home, html = u, txt(d)
                print("HOME", u, len(d), flush=True)
                break
        if home:
            break
    if not home:
        print("NO HOME", city)
        return

    # 1) 栏目发现：首页导航 + 常见栏目名
    cols = {}
    for n, u in anchors(html, home):
        if not re.search(r"(通知|公告|公示|公开|动态|要闻|政策|文件|高新|科技)", n):
            continue
        if not re.search(r"\.(s?html?)$|/$", u) or u.rstrip("/") == home.rstrip("/"):
            continue
        cols.setdefault(u, n)
    print("cand cols", len(cols), flush=True)

    scored = []
    for u, n in list(cols.items())[:22]:
        sc, d, f = H.get(u, timeout=15, tries=1, binary=True)
        if sc != 200 or not d:
            continue
        t = txt(d)
        k = t.count(KEY)
        if k:
            scored.append((k, u, n))
    scored.sort(reverse=True)
    print("scored", [(k, u) for k, u, n in scored[:6]], flush=True)
    if not scored:
        print("NO COLUMN", city)
        return

    # 2) 翻页收集文章
    arts = {}
    for k, u, n in scored[:3]:
        sc, d, f = H.get(u, timeout=15, tries=1, binary=True)
        if sc != 200:
            continue
        t = txt(d)
        for pu in pages_of(f or u, t):
            sc2, d2, f2 = H.get(pu, timeout=15, tries=1, binary=True)
            if sc2 != 200 or not d2:
                continue
            t2 = txt(d2)
            got = 0
            for nm, au in anchors(t2, f2 or pu):
                if KEY in nm and re.search(r"(名单|公布|认定|公示|通知|结果)", nm) and au not in arts:
                    if re.search(r"\.(pdf|docx?|xlsx?)$", au):
                        continue
                    arts[au] = nm
                    got += 1
            if not got and pu != (f or u):
                continue
    print("articles", len(arts), flush=True)

    # 3) 抓文章 -> 表/附件
    tot = 0
    for au, nm in list(arts.items())[:40]:
        ym = re.search(r"(20\d\d)", nm)
        year = ym.group(1) if ym else ""
        bm = re.search(r"第([一二三四1-4])批", nm)
        batch = "第%s批" % (bm.group(1) if bm else "1")
        n1 = S.grab(au, prov, "city_" + city, year=year, batch=batch,
                    default_city=city, require_city=False, min_name=4)
        if not n1:
            sc, d, f = H.get(au, timeout=25, tries=2, binary=True)
            if sc == 200 and d:
                t = txt(d)
                links = [urljoin(f or au, m.group(1)) for m in
                         re.finditer(r'href=[\'"]([^\'"]+\.(?:docx?|xlsx?|pdf))[\'"]', t, re.I)]
                for lu in list(dict.fromkeys(links))[:6]:
                    n1 += S.grab(lu, prov, "city_" + city, year=year, batch=batch,
                                 default_city=city, require_city=False, min_name=4)
        S.append(OUT, n1)
        tot += len(n1)
        print("  %-52s %d" % (nm[:52], len(n1)), flush=True)
    print("TOTAL", city, tot, flush=True)


if __name__ == "__main__":
    main()
