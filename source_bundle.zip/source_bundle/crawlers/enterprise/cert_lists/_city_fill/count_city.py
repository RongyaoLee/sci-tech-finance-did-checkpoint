# -*- coding: utf-8 -*-
import csv, collections, sys
p = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists'
for prov in ('陕西省', '山西省'):
    n = nc = 0
    cn = collections.Counter(); cc = collections.Counter()
    with open(f'{p}\\{prov}.csv', encoding='utf-8-sig', newline='') as f:
        for r in csv.DictReader(f):
            n += 1
            if r['城市'].strip():
                nc += 1
                cn[r['城市'].strip()] += 1
                if r['区县'].strip():
                    cc[r['区县'].strip()] += 1
    print(prov, n, 'city', nc, 'county', len(cc))
    print('   cities:', cn.most_common(14))
    print('   counties sample:', cc.most_common(8))
