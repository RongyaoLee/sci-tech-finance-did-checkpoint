# -*- coding: utf-8 -*-
"""Raw text peek at a downloaded PDF's first page to read its column headers (PyMuPDF)."""
import os, sys, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
import fitz

paths = sorted(glob.glob(os.path.join(cf.CACHE, "att", "kjx_*.pdf")), key=os.path.getmtime)[-1:]
for p in paths:
    print("==", os.path.basename(p), os.path.getsize(p))
    doc = fitz.open(p)
    for i in range(min(2, doc.page_count)):
        t = doc[i].get_text()
        print("--- page", i + 1)
        print(t[:1500])
    doc.close()
