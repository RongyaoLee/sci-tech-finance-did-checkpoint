# -*- coding: utf-8 -*-
"""360 (so.com) based discovery: site:<city sci-tech host> 高新技术企业名单 -> articles -> tables/attachments."""
import os, re, sys, json, html, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_baidu as B
import sd_city_parser as P
import sd_store as ST

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "_so_seen.json")
SEEN = json.load(open(CACHE, encoding="utf-8")) if os.path.exists(CACHE) else {}


def save_seen():
    json.dump(SEEN, open(CACHE, "w", encoding="utf-8"), ensure_ascii=False, indent=0)


def so_links(q, pn=1):
    url = "https://www.so.com/s?q=" + urllib.parse.quote(q) + ("&pn=%d" % pn if pn > 1 else "")
    st, h, _ = B.f(url, referer="https://www.so.com/")
    if st != 200 or not h:
        return []
    out = []
    for m in re.finditer(r'<h3[^>]*>\s*<a ([^>]*)>(.*?)</a>', h, re.S):
        attrs, inner = m.group(1), m.group(2)
        t = html.unescape(re.sub(r"<[^>]+>", "", inner)).strip()
        md = re.search(r'data-mdurl="([^"]+)"', attrs)
        u = html.unescape(md.group(1)) if md else ""
        if not u:
            hr = re.search(r'href="(https?://[^"]+)"', attrs)
            u = html.unescape(hr.group(1)) if hr else ""
        if u.startswith("http"):
            out.append((t, u))
    return out


def resolve(u, host_hint):
    if "so.com/link" in u:
        st, _, final = B.f(u, timeout=25, referer="https://www.so.com/")
        return final, st
    return u, 200


ATT = re.compile(r'(href|src)="([^"]+\.(?:pdf|xlsx?|docx?|et)|[^"]*(?:downfile\.jsp|attach/0/|virtual_attach_file)[^"]*)"', re.I)


def grab(city, art_url):
    st, h, final = B.f(art_url, timeout=30)
    if st != 200 or not h:
        return 0, []
    got = 0
    urls = []
    # inline tables (HTML page)
    try:
        import bs4
        soup = bs4.BeautifulSoup(h, "html.parser")
        tables = []
        for tb in soup.find_all("table"):
            rows = [[c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])] for tr in tb.find_all("tr")]
            rows = [r for r in rows if any(x for x in r)]
            if len(rows) >= 5:
                tables.append(rows)
        if tables:
            rows4 = P.rows_from_tables(tables, city)
            rows4 = [r for r in rows4 if r[0] and r[2]]
            if len(rows4) >= 15:
                ST.append_rows(city, [(a, b, d) for a, b, c, d in rows4], art_url, "", "")
                got += len(rows4)
    except Exception:
        pass
    for m in ATT.finditer(h):
        u = html.unescape(m.group(2))
        if u.startswith("//"):
            u = "http:" + u
        elif u.startswith("/"):
            p = urllib.parse.urlparse(final or art_url)
            u = p.scheme + "://" + p.netloc + u
        elif not u.startswith("http"):
            p = urllib.parse.urlparse(final or art_url)
            u = p.scheme + "://" + p.netloc + "/" + u.lstrip("./")
        urls.append(u)
    for u in list(dict.fromkeys(urls))[:12]:
        if u in SEEN.get("docs", []):
            continue
        SEEN.setdefault("docs", []).append(u)
        st, data, _ = B.f(u, binary=True, timeout=40)
        if st != 200 or len(data) < 2000:
            continue
        try:
            rows4 = P.rows_from_doc(u, data, city)
        except Exception:
            continue
        rows4 = [r for r in rows4 if r[0] and r[2]]
        if len(rows4) >= 15:
            ST.append_rows(city, [(a, b, d) for a, b, c, d in rows4], u, "", "")
            got += len(rows4)
            print("   DOC", u[:100], len(rows4), flush=True)
    return got, urls


HOSTS = {
    "济南": "kjj.jinan.gov.cn", "淄博": "kjj.zibo.gov.cn", "枣庄": "zzst.zaozhuang.gov.cn",
    "东营": "kjj.dongying.gov.cn", "烟台": "kjj.yantai.gov.cn", "潍坊": "kjj.weifang.gov.cn",
    "济宁": "jnkj.jining.gov.cn", "泰安": "kjj.taian.gov.cn", "威海": "kjj.weihai.gov.cn",
    "日照": "kjj.rizhao.gov.cn", "临沂": "kjj.linyi.gov.cn", "德州": "kjj.dezhou.gov.cn",
    "聊城": "kjj.liaocheng.gov.cn", "滨州": "kjj.binzhou.gov.cn", "菏泽": "kjj.heze.gov.cn",
}

QS = ["高新技术企业名单", "高企名单 所属区市", "关于公布 高新技术企业名单 通知"]


def run(cities, pages=1):
    report = {}
    for city in cities:
        host = HOSTS.get(city, "")
        tot = 0
        arts = []
        for q in QS:
            full = ("site:%s %s" % (host, q)) if host else q
            for pn in range(1, pages + 1):
                ls = so_links(full, pn)
                for t, u in ls:
                    if (t, u) in SEEN.get("links", []):
                        continue
                    SEEN.setdefault("links", []).append([t, u])
                    real, st = resolve(u, host)
                    if not real or "so.com" in real:
                        continue
                    if st and st >= 400:
                        continue
                    arts.append((t, real))
                if not ls:
                    break
        arts = list(dict.fromkeys(arts))
        seen_hosts = {}
        for t, u in arts[:25]:
            hh = urllib.parse.urlparse(u).netloc
            if host and host not in hh and "gov.cn" not in hh:
                continue
            seen_hosts[hh] = seen_hosts.get(hh, 0) + 1
            n, _ = grab(city, u)
            if n:
                report.setdefault(city, []).append({"url": u, "rows": n, "title": t})
                tot += n
                print("  +%d %s %s" % (n, city, t[:40]), flush=True)
        save_seen()
        print(city, "arts=%d" % len(arts), "rows=%d" % tot, flush=True)
        report.setdefault(city, [])
    json.dump(report, open(os.path.join(HERE, "_so_report.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    run(sys.argv[1:] or ["潍坊"])
