# -*- coding: utf-8 -*-
"""Shared helpers for the 高企 city back-fill (陕西/湖北/湖南)."""
import csv, io, json, os, shutil

WORK = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists"
FILL = os.path.join(WORK, "_city_fill")
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
PROVS = ["陕西省", "湖北省", "湖南省"]
CODES = {"陕西省": "61", "湖北省": "42", "湖南省": "43"}

# 地级市白名单（来自 cities.json provinceCode 61/42/43 + 直辖县级单位）
ALLOWED = {
    "陕西省": {"西安市", "铜川市", "宝鸡市", "咸阳市", "渭南市", "延安市", "汉中市",
              "榆林市", "安康市", "商洛市", "杨凌示范区", "杨陵区"},
    "湖北省": {"武汉市", "黄石市", "十堰市", "宜昌市", "襄阳市", "鄂州市", "荆门市",
              "孝感市", "荆州市", "黄冈市", "咸宁市", "随州市", "恩施土家族苗族自治州",
              "仙桃市", "潜江市", "天门市", "神农架林区"},
    "湖南省": {"长沙市", "株洲市", "湘潭市", "衡阳市", "邵阳市", "岳阳市", "常德市",
              "张家界市", "益阳市", "郴州市", "永州市", "怀化市", "娄底市",
              "湘西土家族苗族自治州"},
}
ALIAS = {
    "恩施州": "恩施土家族苗族自治州", "恩施": "恩施土家族苗族自治州",
    "湘西州": "湘西土家族苗族自治州", "湘西": "湘西土家族苗族自治州",
    "神农架": "神农架林区", "杨凌": "杨凌示范区", "杨凌区": "杨凌示范区",
    "杨陵": "杨凌示范区", "西安": "西安市", "宝鸡": "宝鸡市", "咸阳": "咸阳市",
    "渭南": "渭南市", "延安": "延安市", "汉中": "汉中市", "榆林": "榆林市",
    "安康": "安康市", "商洛": "商洛市", "铜川": "铜川市",
}


def norm_city(prov, raw):
    """Return a canonical 地级市 name or '' when not confidently a 地级市 of that province."""
    if not raw:
        return ""
    s = str(raw).strip().replace("\u3000", "").replace(" ", "")
    s = s.rstrip("。，,;；")
    if s in ALLOWED[prov]:
        return s
    if s in ALIAS and ALIAS[s] in ALLOWED[prov]:
        return ALIAS[s]
    # 允许「湖北省武汉市」「武汉市（本级）」这类带前缀/后缀的写法
    for a in ALLOWED[prov]:
        if s.startswith(a) or s.endswith(a):
            return a
    if len(s) >= 2 and (s + "市") in ALLOWED[prov]:
        return s + "市"
    return ""


def norm_name(s):
    return (s or "").strip().replace("\u3000", "").replace(" ", "")


def read_prov(prov):
    """Read <prov>.csv -> (rows, newline). rows are dicts with HEADER keys."""
    path = os.path.join(WORK, prov + ".csv")
    raw = open(path, "rb").read()
    nl = "\r\n" if raw.count(b"\r\n") > raw.count(b"\n") * 0.5 else "\n"
    text = raw.decode("utf-8-sig")
    rows = list(csv.DictReader(io.StringIO(text)))
    return rows, nl


def write_rows(path, rows, nl="\r\n"):
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=HEADER, lineterminator=nl, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow({k: r.get(k, "") for k in HEADER})
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        f.write(buf.getvalue())


def load_jsonl(names):
    out = []
    for n in names:
        p = os.path.join(FILL, n)
        if not os.path.exists(p):
            continue
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except Exception:
                    pass
    return out
