# -*- coding: utf-8 -*-
import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

def crawl_col(col, maxpage=20):
    arts = {}
    first = "http://www.innocom.gov.cn/gqrdw/%s/list_gsgg_l3.shtml" % col
    sc, html, final = H.get(first, timeout=25, tries=2)
    print(col, "p1", sc)
    if sc != 200:
        return arts, 0
    m = re.search(r"createPageHTML\([^)]*\)", html)
    npages = 1
    if m:
        nums = re.findall(r"\d+", m.group(0))
        if nums:
            npages = int(nums[0])
        print("  pager:", m.group(0))
    for href, t in H.img_links(html, final):
        if re.search(r"/%s/\d{6}/" % col, href):
            arts[href] = t
    for i in range(2, min(npages, maxpage) + 1):
        u = "http://www.innocom.gov.cn/gqrdw/%s/list_gsgg_l3_%d.shtml" % (col, i)
        sc, html, final = H.get(u, timeout=25, tries=2)
        n0 = len(arts)
        if sc == 200:
            for href, t in H.img_links(html, final):
                if re.search(r"/%s/\d{6}/" % col, href):
                    arts[href] = t
        print("  page", i, sc, "new", len(arts) - n0)
        if sc != 200:
            break
    return arts, npages

res = {}
for col in ("c101455", "c101419"):
    arts, np_ = crawl_col(col)
    res[col] = [{"u": u, "t": t} for u, t in arts.items()]
    print(col, "TOTAL", len(arts))

with open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_cols2.json", "w", encoding="utf-8") as f:
    json.dump(res, f, ensure_ascii=False, indent=1)
