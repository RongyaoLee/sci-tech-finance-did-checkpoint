# -*- coding: utf-8 -*-
"""把栏目所有分页的 (标题, url) 全量落盘，便于本地 grep。"""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S

host = sys.argv[1]
base = sys.argv[2]
out = sys.argv[3]

sc, d, f = S.H.get(host + base, binary=True)
t = d.decode("utf-8", "ignore")
m = re.search(r"共(\d+)页", t)
last = int(m.group(1)) if m else 1
rows = []
p1 = [(a.group(2), a.group(1)) for a in re.finditer(r'<a href="([^"]+)"[^>]*?title="([^"]{4,140})"', t)]
for ttl, u in p1:
    rows.append((ttl.strip(), u))
for p in range(2, last + 1):
    mm = re.search(r"onclick=\"queryArticleByCondition\(this,'([^']+-%d\.shtml)'\)" % p, t)
    if not mm:
        break
    u = host + mm.group(1)
    sc, d, f = S.H.get(u, binary=True)
    if sc != 200:
        print("fail", p, sc)
        continue
    tt = d.decode("utf-8", "ignore")
    for a in re.finditer(r'<a href="([^"]+)"[^>]*?title="([^"]{4,140})"', tt):
        rows.append((a.group(2).strip(), a.group(1)))
    if p % 10 == 0:
        print("page", p, len(rows))
with open(out, "w", encoding="utf-8") as fh:
    for ttl, u in rows:
        fh.write("%s\t%s\n" % (ttl, u))
print("total", len(rows), "->", out)
