# -*- coding: utf-8 -*-
"""辽宁：逐份省级认定通知 -> parts/辽宁省.jsonl"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S

P = "辽宁省"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "parts", P + ".jsonl")

URLS = [
    ("https://kjt.ln.gov.cn/kjt/tztg/bmwj/D921657971AD4F3BA3C109386C98885F/index.shtml", "2018", "第一批"),
    ("https://kjt.ln.gov.cn/kjt/tztg/bmwj/19962863CD224AE5A5C2FCBF90DB8380/index.shtml", "2018", "第二批"),
    ("https://kjt.ln.gov.cn/kjt/tztg/bmwj/935A94EFD7B14A239584E1CF8B17DB75/index.shtml", "2018", "第三批"),
    ("https://kjt.ln.gov.cn/kjt/articleFileDir/2018-09/12/3309727/P020180912538950549755.pdf", "2017", "第二三批"),
    ("https://kjt.ln.gov.cn/kjt/tztg/bmwj/2023091309343286981/index.shtml", "2022", "第一批,第二批"),
    ("https://kjt.ln.gov.cn/kjt/tztg/bmwj/2023091309413821211/index.shtml", "2022", "第三批,第四批"),
    ("https://kjt.ln.gov.cn/kjt/zfxxgk/fdzdgknr/ghxx/ptzc/5E552532964940D198270BA4943BD021/index.shtml", "2019", "第三批"),
    ("https://kjt.ln.gov.cn/kjt/articleFileDir/2020-12/18/4052136/P020201218342754922930.pdf", "2017", "第四批"),
]

if os.path.exists(OUT):
    os.remove(OUT)
tot = 0
for u, y, b in URLS:
    recs = S.grab(u, P, "ln", year=y, batch=b, require_city=True)
    if recs:
        from collections import Counter
        print("    ", Counter(x["city"] for x in recs).most_common(5))
    tot += S.append(OUT, recs)
print("辽宁 parts rows:", tot)
