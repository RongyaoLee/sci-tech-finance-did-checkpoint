# -*- coding: utf-8 -*-
"""Deep inspect of the Jiangxi column page: brace-balanced listData + pagination code."""
import os, sys, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

URL = "http://kjt.jiangxi.gov.cn/jxskxjst/col/col27029/index.html"
h, f = cf.get(URL)


def balanced(t, start):
    i = t.index("{", start)
    depth = 0
    for j in range(i, len(t)):
        c = t[j]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return t[i:j + 1]
    return None


pos = h.find("var listData")
print("listData at", pos)
blob = balanced(h, pos)
print("blob len", len(blob) if blob else None)
d = json.loads(blob)
print("keys:", list(d.keys()))
arts = d.get("articleList") or []
print("articles on page0:", len(arts))
for a in arts[:3]:
    print("  ", a.get("pubDate"), a.get("title")[:40], a.get("urls"))
for k, v in d.items():
    if k != "articleList":
        print("  %s = %s" % (k, str(v)[:300]))
print("--- lines mentioning page/ajax/load ---")
for ln in h.splitlines():
    if re.search(r"page|ajax|loadPage|getJSON|\.json|total", ln, re.I) and len(ln) < 400:
        print("  ", ln.strip()[:300])
