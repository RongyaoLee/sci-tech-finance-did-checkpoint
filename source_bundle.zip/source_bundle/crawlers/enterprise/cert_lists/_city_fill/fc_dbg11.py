# -*- coding: utf-8 -*-
import sys, os, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

html, final = cf.get("http://kjj.changsha.gov.cn/")
soup = BeautifulSoup(html, "lxml")
for f in soup.find_all("form"):
    print("FORM", f.get("action"), [(i.get("name"), i.get("value")) for i in f.find_all("input")][:6])
m = re.findall(r"searching\.hunan\.gov\.cn/hunan/(\d+)/news", html)
print("site codes:", set(m))
m2 = re.findall(r"(\d{9,12})", html)
print("cands:", sorted(set(m2))[:10])
# look for js list api in listing page
h2, f2 = cf.get("http://kjj.changsha.gov.cn/zfxxgk/tzgg_27202/index.html")
for pat in [r'ajax[^"\']{0,80}', r'\.json[^"\']{0,40}', r'page[^"\']{0,60}']:
    hits = re.findall(pat, h2)
    print(pat, hits[:6])
print(h2[:600].replace("\n", " ")[:600])
