# -*- coding: utf-8 -*-
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

u = 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/index.html'
st, txt, fu = H.get(u, timeout=30)
print('status', st, len(txt or ''))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_hb_col.html'), 'w', encoding='utf-8').write(txt or '')
if st == 200:
    for pat in [r'<iframe[^>]*>', r'\.jsp', r'\.js["\']', r'columnid', r'page\s*=', r'load\w*\(', r'createPageHTML', r'"/[a-z0-9_]+/index']:
        ms = re.findall(pat, txt, re.I)
        print(pat, '->', ms[:5])
    # print all script blocks briefly
    for m in re.finditer(r'<script[^>]*>(.*?)</script>', txt, re.S | re.I):
        s = m.group(1).strip()
        if len(s) > 40:
            print('SCRIPT:', re.sub(r'\s+', ' ', s)[:260])
