# -*- coding: utf-8 -*-
import sys, os, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H
import nb_docparse

CF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill"
log = json.load(open(os.path.join(CF, "_nb_log2.json"), encoding="utf-8"))
want = [l for l in log if l.get("pairs") is not None and l.get("pairs") < 5]
for l in want:
    u = l["url"]
    print("=" * 90)
    print(l["title"][:70], "| size", l["size"], "| chars", l["chars"], "| pairs", l["pairs"])
    sc, data, f = H.get(u, binary=True, timeout=60)
    p = H.save_raw("nb_doc", u, data)
    low = u.lower()
    if low.endswith(".doc") or data[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
        txt = nb_docparse.doc_text(p)
    else:
        txt = H.doc_text(u, data)
    print("--- TEXT (%d chars) ---" % len(txt))
    print(txt[:3000].replace("\x07", "<CELL>").replace("\x0c", "<FF>"))
    print("--- TAIL ---")
    print(txt[-1200:].replace("\x07", "<CELL>").replace("\x0c", "<FF>"))
