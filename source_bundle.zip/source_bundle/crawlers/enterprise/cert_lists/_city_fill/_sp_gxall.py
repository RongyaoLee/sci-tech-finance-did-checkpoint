# -*- coding: utf-8 -*-
"""广西：培育库名单全量（doc/docx/docx 皆走统一分支）-> parts/广西壮族自治区.jsonl"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
import harvest as H
from _sp_doc import doc_pairs
from urllib.parse import urljoin

BASE = "http://kjt.gxzf.gov.cn/xxgk/gxkjgk/gxjsqy/gxgxjsqy/"
P = "广西壮族自治区"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "parts", P + ".jsonl")

PAGES = [
    ("t3094438.shtml", "2019", "培育库第一批"),
    ("t3094543.shtml", "2019", "培育库第二批"),
    ("t8846025.shtml", "2021", "培育库第一批"),
    ("t10959664.shtml", "2021", "培育库第二批"),
    ("t14408572.shtml", "2022", "培育库"),
    ("t16218025.shtml", "2023", "培育库"),
    ("t23397806.shtml", "2024", "培育库"),
    ("t23397807.shtml", "2025", "培育库第一批"),
    ("t23397800.shtml", "2025", "培育库第二批"),
]

tot = 0
for t, y, b in PAGES:
    page = BASE + t
    sc, d, f = H.get(page, timeout=30, tries=3, binary=True)
    if sc != 200 or not d:
        print("PAGE FAIL", sc, page)
        continue
    tt = d.decode("utf-8", "ignore")
    docs = [m.group(1) for m in re.finditer(r'href=["\']([^"\']+\.(?:doc|docx|xls|xlsx|pdf))["\']', tt)]
    if not docs:
        print(t, "no docs")
        continue
    for du in set(docs):
        u = urljoin(f or page, du)
        sc2, data, fin = H.get(u, timeout=40, tries=4, binary=True)
        if sc2 != 200 or not data:
            print("  DOC FAIL", sc2, u[-40:])
            continue
        H.save_raw("gx_py", u, data)
        low = u.lower().split("?")[0]
        recs = []
        if low.endswith(".doc") and data[:4] != b"PK\x03\x04":
            for name, code, city in doc_pairs(data):
                c = S.norm_city(P, city)
                if c:
                    recs.append({"name": name, "cert": code, "city": c, "county": "",
                                 "year": y, "batch": b, "src": u})
        else:
            recs = S.extract_from_tables(S.doc_tables(u, data), P, src=u, year=y, batch=b,
                                         require_city=True)
        n = S.append(OUT, recs)
        tot += n
        print("  %-42s %s %d rows" % (u.split("/")[-1][:42], sc2, n))
print("total rows", tot)
