# -*- coding: utf-8 -*-
"""Test: 湖南/陕西「入库科技型中小企业名单」附件是否带 市州 列（若能，可按企业全名 join 出高企城市）。"""
import os, sys, json, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
sys.path.insert(0, os.path.dirname(cf.HERE))
import fetch_common as fc

PAGES = [
    "http://kjt.hunan.gov.cn/kjt/xxgk/tzgg/tzgg_1/202611/t20261109_34098179.html",
]
res = {}
for p in PAGES:
    try:
        html, final = cf.get(p)
    except Exception as e:
        print("ERR", p, type(e).__name__)
        continue
    s = cf.soup_of(html)
    title = s.title.get_text(strip=True) if s.title else ""
    atts = cf.attachments(final, html)
    print("\n==", title[:70], "| atts", len(atts))
    for t, u in atts[:4]:
        print("   att:", t[:50], u.rsplit("/", 1)[-1][:50])
    for t, u in atts[:2]:
        ext = os.path.splitext(u.split("?")[0])[1].lower()
        if ext not in (".pdf", ".xlsx", ".xls", ".docx", ".doc"):
            continue
        try:
            path = cf.download(u, "kjx")
            rows = list(fc.extract(path))
        except Exception as e:
            print("   ERR", type(e).__name__, e)
            continue
        print("   file", path.rsplit("\\", 1)[-1], "rows", len(rows))
        for r in rows[:6]:
            print("     ", r)
