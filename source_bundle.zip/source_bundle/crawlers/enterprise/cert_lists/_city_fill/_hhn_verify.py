# -*- coding: utf-8 -*-
"""交付自检：表头、行数、城市取值合法性、空城市行、样例。"""
import io, sys, os, csv, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
CF = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill'

HB_OK = {'石家庄市', '唐山市', '秦皇岛市', '邯郸市', '邢台市', '保定市', '张家口市', '承德市',
         '沧州市', '廊坊市', '衡水市', '定州市', '辛集市', '雄安新区'}
HN_OK = {'郑州市', '开封市', '洛阳市', '平顶山市', '安阳市', '鹤壁市', '新乡市', '焦作市', '濮阳市',
         '许昌市', '漯河市', '三门峡市', '南阳市', '商丘市', '信阳市', '周口市', '驻马店市', '济源市'}
for name, ok in (('河北省_city.csv', HB_OK), ('河南省_city.csv', HN_OK)):
    p = os.path.join(CF, name)
    with open(p, encoding='utf-8', newline='') as f:
        rd = csv.reader(f)
        head = next(rd)
        rows = list(rd)
    cities = collections.Counter(r[2] for r in rows if r[2])
    bad = {c: n for c, n in cities.items() if c not in ok}
    firms = len({(r[0], r[2]) for r in rows if r[2]})
    filled_src = sum(1 for r in rows if r[2] and ('oss.henan' in r[6] or 'xcoss' in r[6] or '附件' in r[6]))
    print('==', name, 'rows', len(rows), 'header_ok', head == ['企业名称', '证书编号', '城市', '区县', '认定年度', '批次', '来源URL'])
    print('   city_filled', sum(cities.values()), 'firms', firms, 'distinct_city', len(cities), 'outside_set', bad)
    print('   noco_city_rows', sum(1 for r in rows if not r[2]), 'county_filled', sum(1 for r in rows if r[3]))
    print('   by_city', cities.most_common(8))
    print('   sample', rows[0], rows[len(rows) // 2])
