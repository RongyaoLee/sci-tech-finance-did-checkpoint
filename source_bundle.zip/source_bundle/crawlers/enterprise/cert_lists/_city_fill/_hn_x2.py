﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
sys.path.insert(0,r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists")
import cf,fetch_common as fc
for u in ["http://csmls.changsha.gov.cn/zwgk/xxgk/czxx/202308/t20230822_11198490.html",
          "http://www.hnyx.gov.cn/c5636/20201208/i1628402.html"]:
    h,f=cf.get(u)
    body=re.sub(r"<(script|style)[^>]*>.*?</\1>","",h,flags=re.S|re.I)
    txt=re.sub(r"<[^>]+>","\n",body); txt=re.sub(r"&nbsp;"," ",txt)
    lines=[re.sub(r"\s+","",x) for x in txt.split("\n")]
    lines=[x for x in lines if x]
    cand=[x for x in lines if re.search(r"(有限公司|股份有限公司|有限责任公司)$",x) and 6<len(x)<40]
    print("=====",f,len(cand))
    for x in cand[:25]: print("   ",x)
