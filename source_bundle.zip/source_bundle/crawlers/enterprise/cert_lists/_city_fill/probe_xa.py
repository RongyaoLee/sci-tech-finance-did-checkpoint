# -*- coding: utf-8 -*-
import requests, urllib3, re
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
cands = [
    'http://xakj.xa.gov.cn/',
    'https://gqrd.shaanxi.gov.cn/',
    'http://www.sxgq.org.cn/',
    'http://gqrd.sstrc.com/',
    'https://kjj.taiyuan.gov.cn/',
    'http://kjj.taiyuan.gov.cn/',
]
for u in cands:
    try:
        r = requests.get(u, headers=H, timeout=25, verify=False)
        r.encoding = r.apparent_encoding or 'utf-8'
        t = r.text
        ttl = re.search(r'<title>(.*?)</title>', t, re.S)
        print('==', r.status_code, len(t), u, (ttl.group(1).strip()[:60] if ttl else ''))
        if r.status_code == 200:
            cols = set()
            for m in re.finditer(r'href=[\'"]([^\'"]*(?:tzgg|tzgs|ggtz|notice|xwzx|gsgg)[^\'"]*)[\'"]', t):
                cols.add(m.group(1)[:70])
            for c in list(cols)[:10]:
                print('   col', c)
    except Exception as e:
        print('ERR', u, str(e)[:70])
