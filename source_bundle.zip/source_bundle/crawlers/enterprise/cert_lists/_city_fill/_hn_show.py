﻿# -*- coding: utf-8 -*-
import json,re,os
HERE=os.path.dirname(os.path.abspath(__file__))
for l in open(os.path.join(HERE,"_hn_parsed.jsonl"),encoding="utf-8"):
    d=json.loads(l)
    if not d["names"]: continue
    print("=====",d["city"],len(d["names"]),"|",d["url"])
    for r in d["names"][:6]: print("   ",r["name"],"|",r["cert"])
    print("    ...tail:",[r["name"] for r in d["names"][-3:]])
