# -*- coding: utf-8 -*-
"""石家庄市政府门户：找站内搜索端点，搜「高新技术企业 名单」。"""
import io, sys, os, re, json, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

st, txt, fu = H.get('http://www.sjz.gov.cn/', timeout=25)
print(st, len(txt or ''))
cands = set()
for m in re.findall(r'(?:action|href|src)="([^"]*(?:search|so\.|sousuo)[^"]*)"', txt or '', re.I):
    cands.add(m)
for m in re.findall(r'(https?://[a-z0-9.\-]*(?:search|so)[a-z0-9.\-]*\.[a-z]{2,}[^"\' ]*)', txt or '', re.I):
    cands.add(m)
print('search cands', len(cands))
for c in list(cands)[:15]:
    print('  ', c[:110])
