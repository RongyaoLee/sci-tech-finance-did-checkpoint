﻿# -*- coding: utf-8 -*-
import os,sys,re
sys.path.insert(0,os.getcwd())
import cf
for code in ["001000000","973104000"]:
    u="http://searching.hunan.gov.cn/hunan/%s/all"%code
    r=cf.S.get(u,params={"q":"高新技术企业 公示","iszq":"1"},timeout=30); r.encoding="utf-8"
    h=r.text
    print("==",u,r.status_code,len(h),"hits",h.count("高新技术企业"))
    doms=sorted(set(re.findall(r'https?://([a-z0-9\.\-]+\.gov\.cn)',h)))
    print("  doms:",doms[:20],len(doms))
    links=[(re.sub("<[^>]+>","",t).strip(),u2) for u2,t in re.findall(r'<a[^>]+href="(.*?)"[^>]*>(.*?)</a>',h,re.S)]
    for t,u2 in links[:25]:
        if t and "searching" not in u2: print("   ",t[:50],"|",u2[:100])
