# -*- coding: utf-8 -*-
import sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

urls = [
 "http://kjj.linyi.gov.cn/",
 "http://kjj.liaocheng.gov.cn/",
 "http://www.dezhou.gov.cn/",
 "http://www.binzhou.gov.cn/",
 "http://www.heze.gov.cn/",
]
for u in urls:
    sc, html, final = H.get(u, timeout=20, tries=1)
    print("=" * 70)
    print(u, "->", sc, "len", len(html) if html else 0, "final", final)
    if sc == 200 and html:
        t = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
        t = re.sub(r"<style.*?</style>", " ", t, flags=re.S | re.I)
        t = re.sub(r"<[^>]+>", " ", t)
        t = re.sub(r"\s+", " ", t)
        print("TITLE:", t[:180])
        for href, txt in H.img_links(html, final):
            if "高新" in txt or "科技" in txt or "公示" in txt or "通知" in txt:
                print("  A:", txt[:50], "|", href[:120])
