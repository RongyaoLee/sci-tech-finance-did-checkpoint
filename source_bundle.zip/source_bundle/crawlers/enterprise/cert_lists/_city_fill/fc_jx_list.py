# -*- coding: utf-8 -*-
"""江西: locate 省高企办 公示 pages in col27029 and inspect their attachments."""
import os, sys, re, urllib.parse, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

BASE = "http://kjt.jiangxi.gov.cn/jxskxjst/col/col27029/index.html"
KEY = re.compile(r"高新技术企业|高企")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_jx_gq_list.json")


def crawl(base, maxpage=20):
    seen = {}
    for i in range(maxpage):
        u = base if i == 0 else re.sub(r"index\.html$", "index_%d.html" % i, base)
        html, final = cf.get(u)
        if not html:
            print("-- page", u, "FAIL")
            continue
        soup = BeautifulSoup(html, "lxml")
        n0 = len(seen)
        for a in soup.find_all("a", href=True):
            t = a.get_text(" ", strip=True)
            h = a["href"].strip()
            if not t or not KEY.search(t):
                continue
            x = urllib.parse.urljoin(final or u, h)
            if x not in seen:
                seen[x] = t
                print("  [p%d] %s\n        %s" % (i, t[:80], x))
        print("-- page %d: %d total (+%d)" % (i, len(seen), len(seen) - n0))
        if len(soup.find_all("a", href=True)) == 0:
            break
    return seen


if __name__ == "__main__":
    got = crawl(BASE)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(got, f, ensure_ascii=False, indent=1)
    print("saved", len(got), "->", OUT)
