# -*- coding: utf-8 -*-
import sys, os, re, urllib.parse, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

q = urllib.parse.quote("高新技术企业 奖补")
for u in ["https://searching.hunan.gov.cn/hunan/973104000/news?q=" + q,
          "http://kjj.changsha.gov.cn/zfxxgk/tzgg_27202/index.html"]:
    html, final = cf.get(u)
    print("=" * 70)
    print(u)
    print("final", final, "len", len(html) if html else 0)
    if not html:
        continue
    soup = BeautifulSoup(html, "lxml")
    print("title", soup.title.get_text(strip=True) if soup.title else "")
    n = 0
    for a in soup.find_all("a", href=True):
        t = a.get_text(" ", strip=True)
        if re.search(r"(高新技术企业|高企|奖补|补助|公示)", t):
            print("   ", t[:50], "->", urllib.parse.urljoin(final or u, a["href"])[:110])
            n += 1
            if n > 12:
                break
