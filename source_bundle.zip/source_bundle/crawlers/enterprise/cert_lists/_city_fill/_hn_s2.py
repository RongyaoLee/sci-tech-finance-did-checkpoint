﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
import cf
u="http://searching.hunan.gov.cn/hunan/973104000/news"
r=cf.S.get(u,params={"searchWord":"高新技术企业","pageSize":10},timeout=30)
r.encoding="utf-8"
h=r.text
open("_hn_s1.html","w",encoding="utf-8").write(h)
# look for ajax endpoints
for m in set(re.findall(r'''["\'](/[a-zA-Z0-9/_\-\.]*(?:search|query|list|json|api)[a-zA-Z0-9/_\-\.]*)["\']''',h,re.I)):
    print("URL:",m)
print("---- 高新技术企业 count:",h.count("高新技术企业"))
i=h.find("高新技术企业")
print(h[max(0,i-800):i+800])
