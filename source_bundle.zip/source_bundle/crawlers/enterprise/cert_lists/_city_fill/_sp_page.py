# -*- coding: utf-8 -*-
"""页面 -> 附件链接 + 内嵌表格概况。用法: _sp_page.py URL [附件序号...]"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S

url = sys.argv[1]
sc, data, fin = S.H.get(url, timeout=30, tries=3, binary=True)
print("status", sc, "len", len(data or b""), "final", fin)
t = data.decode("utf-8", "ignore")
if t.count("\ufffd") > 20:
    t = data.decode("gb18030", "ignore")
m = re.search(r"<title>(.*?)</title>", t, re.S)
print("title:", (m.group(1).strip() if m else "")[:90])
docs = []
for a in re.finditer(r'href=["\']([^"\']+)["\'][^>]*>([^<]{0,40})</a>', t):
    u, n = a.group(1), a.group(2)
    if re.search(r"(?i)\.(pdf|docx?|xlsx?|zip|rar|wps|et)$", u.split("?")[0]) or "/files/" in u:
        docs.append((u, n.strip()))
seen = set()
k = 0
for u, n in docs:
    if u in seen:
        continue
    seen.add(u)
    k += 1
    if u.startswith("/"):
        from urllib.parse import urljoin
        u = urljoin(fin or url, u)
    print("  DOC%d %-28s %s" % (k, n[:28], u))
print("-- inline tables:", len(S.parse_html_tables(t)))
if len(sys.argv) > 2:
    for idx in sys.argv[2:]:
        u = [x for x in dict(docs).items()]
        print("== sniff", idx, u[int(idx) - 1][0] if int(idx) <= len(u) else "n/a")
