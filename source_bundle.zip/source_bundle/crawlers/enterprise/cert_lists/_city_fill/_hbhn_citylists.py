# -*- coding: utf-8 -*-
import csv, collections, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
for fn in ['唐山市.csv','石家庄市.csv','郑州市.csv','洛阳市.csv']:
    p = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\city_lists\\' + fn
    with open(p, encoding='utf-8-sig', newline='') as f:
        r = csv.DictReader(f)
        rows = list(r)
        print('==', fn, len(rows), r.fieldnames)
        print('  years', collections.Counter(x.get('认定年度','') for x in rows).most_common())
        print('  batch', collections.Counter(x.get('批次','') for x in rows).most_common(6))
        print('  county', collections.Counter(x.get('区县','') for x in rows).most_common(8))
        print('  srcs', collections.Counter(x.get('来源URL','') for x in rows).most_common(4))
        print('  type', collections.Counter(x.get('名单类型','') for x in rows).most_common(5))
        for x in rows[:2]:
            print('   ex', x.get('企业名称'), x.get('证书编号'), x.get('城市'), x.get('区县'))
