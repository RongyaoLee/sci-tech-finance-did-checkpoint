# -*- coding: utf-8 -*-
"""广西：培育库入库名单（附件含「所属地市」列）-> parts/广西壮族自治区.jsonl"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
from urllib.parse import urljoin

P = "广西壮族自治区"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "parts", P + ".jsonl")

# 页面 -> (认定年度, 批次)  —— 这些是省科技厅官网附件（.docx，含所属地市列）
PAGES = [
    ("http://kjt.gxzf.gov.cn/xxgk/gxkjgk/gxjsqy/gxgxjsqy/t23397807.shtml", "2025", "培育库第一批"),
    ("http://kjt.gxzf.gov.cn/xxgk/gxkjgk/gxjsqy/gxgxjsqy/t23397800.shtml", "2025", "培育库第二批"),
]

tot = 0
for page, y, b in PAGES:
    sc, d, f = S.H.get(page, timeout=30, tries=2, binary=True)
    if sc != 200:
        print("page fail", sc, page)
        continue
    t = d.decode("utf-8", "ignore")
    docs = [m.group(1) for m in re.finditer(r'href=["\']([^"\']+\.docx?)["\']', t)]
    print(page[-16:], "docs", docs)
    for du in docs:
        u = urljoin(f, du)
        recs = S.grab(u, P, "gx_py", year=y, batch=b, require_city=True)
        tot += S.append(OUT, recs)
        if recs:
            from collections import Counter
            print("   ", Counter(x["city"] for x in recs).most_common(6))
print("广西 parts rows:", tot)
