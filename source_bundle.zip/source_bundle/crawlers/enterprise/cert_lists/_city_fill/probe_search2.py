# -*- coding: utf-8 -*-
import requests, urllib3, re
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
r = requests.get('https://kjt.shaanxi.gov.cn/', headers=H, timeout=40, verify=False)
r.encoding = r.apparent_encoding or 'utf-8'
t = r.text
m = re.search(r'function\s+submitsearch[\s\S]{0,600}', t)
print(m.group(0) if m else 'no fn')
print('--- js files ---')
for x in re.findall(r'src=[\'"]([^\'"]+\.js)[\'"]', t)[:15]:
    print('  ', x)
print('--- search-ish strings ---')
for x in set(re.findall(r'[\'"]([^\'"]*(?:search|Search)[^\'"]*)[\'"]', t))[:40]:
    print('  ', x[:120])
