# -*- coding: utf-8 -*-
"""JCMS-style column crawler + attachment finder.

Most Zhejiang/Shandong gov sites run 大汉 JCMS:
  list column:  /col/col<ID>/index.html , pages: index_1.html index_2.html ...
  article:      /col/col<ID>/art/<YYYY>/art_<hash>.html
Attachments:    /module/download/downfile.jsp?classid=0&filename=xxx.pdf
                /attach/0/xxxx.pdf
                /cms_files/... , /picture/0/...

API:
    list_articles(index_url, max_pages=40, years=None) -> [(title, url)]
    docs_of(article_url) -> [(url, label)]
    grab(url, tag) -> (text, path)
"""
import re
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

ART_RE = re.compile(r"/art/(\d{4})/art_[0-9a-f]+\.html", re.I)
DOC_RE = re.compile(r"(downfile\.jsp\?[^\"'\s>]+|/attach/[^\"'\s>]+|/cms_files/[^\"'\s>]+"
                    r"|/picture/0/[^\"'\s>]+|/[^\"'\s>]+\.(?:pdf|xlsx?|docx?|zip|rar|wps|et))", re.I)


def _page_url(index_url, p):
    if p == 0:
        return index_url
    return re.sub(r"index\.html$", "index_%d.html" % p, index_url)


def list_articles(index_url, max_pages=40, years=None, stop_after_empty=2):
    """years: set of ints; stop early when page years are all older."""
    out = []
    empty = 0
    for p in range(max_pages):
        u = _page_url(index_url, p)
        sc, html, final = H.get(u, tries=2, timeout=25)
        if sc != 200 or not html:
            empty += 1
            if empty >= stop_after_empty:
                break
            continue
        empty = 0
        rows = []
        for a, t in H.img_links(html, final):
            m = ART_RE.search(a)
            if not m:
                continue
            rows.append((t.strip(), a, int(m.group(1))))
        seen = set()
        uniq = []
        for t, a, y in rows:
            if a in seen:
                continue
            seen.add(a)
            uniq.append((t, a, y))
        if not uniq:
            empty += 1
            if empty >= stop_after_empty:
                break
            continue
        for t, a, y in uniq:
            out.append((t, a))
        if years and all(y < min(years) for _, _, y in uniq):
            break
    # dedupe keep order
    seen = set()
    res = []
    for t, a in out:
        if a in seen:
            continue
        seen.add(a)
        res.append((t, a))
    return res


def docs_of(article_url):
    sc, html, final = H.get(article_url, tries=2, timeout=25)
    if sc != 200 or not html:
        return []
    res = []
    seen = set()
    # anchors with href
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html, re.S | re.I):
        href = m.group(1)
        label = re.sub(r"<[^>]+>", "", m.group(2)).strip()
        if not DOC_RE.search(href):
            continue
        from urllib.parse import urljoin
        u = urljoin(final, href)
        if u in seen:
            continue
        seen.add(u)
        res.append((u, label[:80]))
    # bare urls in text (some pages list attachments as plain text)
    for m in DOC_RE.finditer(html):
        from urllib.parse import urljoin
        u = urljoin(final, m.group(1))
        u = u.replace("&amp;", "&")
        if u in seen:
            continue
        seen.add(u)
        res.append((u, ""))
    return res


def grab(url, tag):
    st, data, fu = H.get(url, binary=True, tries=2, timeout=120)
    if st != 200 or not data:
        return "", ""
    p = H.save_raw(tag, url, data)
    txt = H.doc_text(url, data)
    return txt, p


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    url = sys.argv[1]
    pat = re.compile(sys.argv[2] if len(sys.argv) > 2 else r"高新")
    arts = list_articles(url, max_pages=30)
    print("articles=%d" % len(arts))
    for t, a in arts:
        if pat.search(t):
            print(" HIT %s | %s" % (t[:90], a))
