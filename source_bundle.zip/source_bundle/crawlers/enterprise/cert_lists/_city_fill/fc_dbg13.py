# -*- coding: utf-8 -*-
import sys, os, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

CAND = [
    ("湘潭市", ["http://kjj.xiangtan.gov.cn/", "http://www.xiangtan.gov.cn/kjj/"]),
    ("衡阳市", ["http://kjj.hengyang.gov.cn/", "http://www.hengyang.gov.cn/kjj/"]),
    ("邵阳市", ["http://kjj.shaoyang.gov.cn/"]),
    ("岳阳市", ["http://kjj.yueyang.gov.cn/", "http://www.yueyang.gov.cn/kjj/"]),
    ("张家界市", ["http://kjj.zjj.gov.cn/"]),
    ("郴州市", ["http://kjj.czs.gov.cn/"]),
    ("永州市", ["http://kjj.yzcity.gov.cn/", "http://www.yzcity.gov.cn/kjj/"]),
    ("怀化市", ["http://kjj.huaihua.gov.cn/"]),
    ("娄底市", ["http://kjj.hnloudi.gov.cn/"]),
    ("湘西土家族苗族自治州", ["http://kjj.xxz.gov.cn/"]),
]
for city, urls in CAND:
    for u in urls:
        html, final = cf.get(u, tries=1)
        if not html:
            print("%-16s FAIL %s" % (city, u))
            continue
        soup = BeautifulSoup(html, "lxml")
        t = soup.title.get_text(strip=True) if soup.title else ""
        cols = []
        for a in soup.find_all("a", href=True):
            tt = a.get_text(" ", strip=True)
            if tt and re.search(r"(通知公告|通知 公告|公示公告|公告公示|科技动态|工作动态)", tt) and len(tt) < 14:
                cols.append(urllib.parse.urljoin(final or u, a["href"]))
        print("%-16s OK  %-30s %s | cols=%s" % (city, u, t[:26], cols[:3]))
        break
