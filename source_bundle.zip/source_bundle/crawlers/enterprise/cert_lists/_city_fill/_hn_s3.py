﻿# -*- coding: utf-8 -*-
import os,sys,re
sys.path.insert(0,os.getcwd())
import cf
for j in ["http://searching.hunan.gov.cn/js/hunansearch_r.js","http://searching.hunan.gov.cn/js/common_fixed20160524.js"]:
    h,_=cf.get(j)
    print("=====",j,len(h) if h else None)
    if not h: continue
    open("_"+os.path.basename(j).replace(".js","")+".js","w",encoding="utf-8").write(h)
    for m in re.finditer(r"(ajax|\\$\.post|\\$\.get|fetch)\s*\(",h):
        s=max(0,m.start()-120); print("...",h[s:m.start()+420].replace("\n"," ")[:540]); print("-")
    for m in set(re.findall(r'''["\']([^"\']*(?:/search|/hunanso|/s\?|api|servlet)[^"\']*)["\']''',h)):
        print("EP:",m)
