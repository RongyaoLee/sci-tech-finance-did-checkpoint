import sqlite3, os
base = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work"
for db in ["hn_enterprise.sqlite", "cnki_gaoqi.sqlite"]:
    p = os.path.join(base, db)
    print("=" * 30, db, os.path.getsize(p) if os.path.exists(p) else "MISSING")
    con = sqlite3.connect(p)
    for n, s in con.execute("select name,sql from sqlite_master where type='table'"):
        print(n, "|", (s or "").replace("\n", " ")[:400])
    con.close()
