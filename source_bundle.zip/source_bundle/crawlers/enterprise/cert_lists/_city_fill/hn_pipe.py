﻿# -*- coding: utf-8 -*-
"""Fetch candidate Hunan city pages, parse attachment tables, emit rows."""
import os,sys,re,json,traceback
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,HERE); sys.path.insert(0,os.path.dirname(HERE))
import cf, fetch_common as F

CITIES=["长沙市","株洲市","湘潭市","衡阳市","邵阳市","岳阳市","常德市","张家界市","益阳市","郴州市","永州市","怀化市","娄底市","湘西土家族苗族自治州"]
sel=json.load(open(os.path.join(HERE,"_hn_sel.json"),encoding="utf-8"))
OUT=os.path.join(HERE,"_hn_parsed.jsonl")
done=set()
if os.path.exists(OUT):
    for l in open(OUT,encoding="utf-8"):
        try: done.add(json.loads(l)["url"])
        except: pass
rep=[]
with open(OUT,"a",encoding="utf-8") as fo:
    for city,title,url in sel:
        if url in done: continue
        if not city: continue
        try:
            h,fin=cf.get(url)
        except Exception as e:
            rep.append((city,title,url,"FETCHERR",0)); continue
        if not h:
            rep.append((city,title,url,"FETCHFAIL",0)); continue
        txt=re.sub(r"<[^>]+>"," ",h)
        hits=[c for c in CITIES if c in txt]
        if len(hits)>2:
            rep.append((city,title,url,"PROVINCIAL_SKIP",len(hits)))
            fo.write(json.dumps({"url":url,"city":city,"title":title,"skip":"provincial","names":[]},ensure_ascii=False)+"\n")
            continue
        names=[]
        atts=cf.attachments(url,h)
        for t,au in atts:
            p=cf.download(au,"hn_"+city)
            if not p: continue
            try:
                for r in F.extract(p):
                    if F.looks_like_name(r["name"]): names.append((r["name"],r["cert"]))
            except Exception:
                pass
        # inline tables
        if not names:
            soup=cf.soup_of(h)
            for tb in soup.find_all("table"):
                for tr in tb.find_all("tr"):
                    cells=[c.get_text(" ",strip=True) for c in tr.find_all(["td","th"])]
                    if not cells: continue
                    nm=""
                    for c in cells:
                        cc=F.clean(c)
                        if F.looks_like_name(cc): nm=cc; break
                    if nm: names.append((nm,F.norm_cert(" ".join(cells))))
        seen={}; uniq=[]
        for n,c in names:
            n=F.clean(n)
            if n in seen: continue
            seen[n]=1; uniq.append({"name":n,"cert":c})
        fo.write(json.dumps({"url":url,"city":city,"title":title,"atts":len(atts),"names":uniq},ensure_ascii=False)+"\n")
        fo.flush()
        rep.append((city,title,url,"OK",len(uniq)))
        print("OK",city,len(uniq),len(atts),"atts |",title[:40],flush=True)
print("=== summary ===")
for r in rep:
    print(r[0],"|",r[3],r[4],"|",r[2][:90])
