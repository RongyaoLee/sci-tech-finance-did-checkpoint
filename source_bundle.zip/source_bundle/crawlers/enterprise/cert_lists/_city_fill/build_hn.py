# -*- coding: utf-8 -*-
"""湖南: 官方公示件 -> 主表城市/区县 回填。优先 证书编号 join，其次 名称(+年度)。

rows_湖南_shizhou.jsonl 每行: {"name","city"(地级市,来自发布主体),"county"(区县),"cert","src","tag"}
城市只能来自官方件；县级值按 HN_COUNTY 归并到设区市；解析不出留空。
"""
import os, sys, csv, io, json, re, collections

FILL = os.path.dirname(os.path.abspath(__file__))
LISTS = os.path.dirname(FILL)
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]

CITIES = {"长沙市", "株洲市", "湘潭市", "衡阳市", "邵阳市", "岳阳市", "常德市",
          "张家界市", "益阳市", "郴州市", "永州市", "怀化市", "娄底市",
          "湘西土家族苗族自治州"}

# 县级/园区值 -> 设区市
HN_COUNTY = {
    "芙蓉区": "长沙市", "天心区": "长沙市", "岳麓区": "长沙市", "开福区": "长沙市",
    "雨花区": "长沙市", "望城区": "长沙市", "长沙县": "长沙市", "浏阳市": "长沙市",
    "宁乡市": "长沙市", "长沙高新区": "长沙市", "长沙经开区": "长沙市",
    "长沙经济技术开发区": "长沙市", "望城经开区": "长沙市", "浏阳经开区": "长沙市",
    "宁乡高新区": "长沙市", "宁乡经开区": "长沙市", "金霞经开区": "长沙市",
    "隆平高科技园": "长沙市", "岳麓高新区": "长沙市", "马栏山": "长沙市",
    "武陵区": "常德市", "鼎城区": "常德市", "安乡县": "常德市", "汉寿县": "常德市",
    "澧县": "常德市", "临澧县": "常德市", "桃源县": "常德市", "石门县": "常德市",
    "津市市": "常德市", "常德经开区": "常德市", "常德高新区": "常德市",
    "西洞庭": "常德市", "柳叶湖": "常德市", "西湖": "常德市",
}


def norm_name(s):
    s = (s or "").strip().replace("\u3000", "").replace(" ", "")
    s = s.replace("（", "(").replace("）", ")").replace("．", ".").replace("·", "")
    return s.upper()


def norm_cert(s):
    s = re.sub(r"[^0-9A-Za-z]", "", (s or "")).upper()
    return s if s.startswith("GR") and len(s) >= 10 else ""


def main():
    rows_jsonl = os.path.join(FILL, "rows_湖南_shizhou.jsonl")
    legacy_jsonl = os.path.join(FILL, "rows_湖南.jsonl")
    out_csv = os.path.join(FILL, "湖南省_city.csv")
    main_csv = os.path.join(LISTS, "湖南省.csv")

    cert_map = collections.defaultdict(set)     # cert -> {(city,county)}
    name_map = collections.defaultdict(set)     # name -> {(city,county)}
    nameyear = collections.defaultdict(set)
    n = 0
    for path in (rows_jsonl, legacy_jsonl):
        if not os.path.exists(path):
            continue
        for line in io.open(path, encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            city = (r.get("city") or "").strip()
            cnty = (r.get("county") or "").strip()
            if cnty:
                cnty = re.sub(r"^(湖南省|湖南)", "", cnty)
                g = HN_COUNTY.get(cnty)
                if g:
                    city, cnty = g, cnty
                elif cnty in CITIES:
                    city, cnty = cnty, ""
                elif city not in CITIES:
                    cnty = ""
            if city not in CITIES:
                continue
            key = (city, cnty)
            c = norm_cert(r.get("cert"))
            if c:
                cert_map[c].add(key)
            k = norm_name(r["name"])
            name_map[k].add(key)
            y = str(r.get("year") or "").strip()
            if y:
                nameyear[(k, y)].add(key)
            n += 1
    print("patch rows", n, "certs", len(cert_map), "names", len(name_map))
    both = sum(1 for v in cert_map.values() if len(v) > 1)
    both2 = sum(1 for v in name_map.values() if len(v) > 1)
    print("ambiguous cert", both, "ambiguous name", both2)

    with io.open(main_csv, encoding="utf-8-sig", newline="") as f:
        rd = list(csv.reader(f))
    hdr, body = rd[0], rd[1:]
    print("main rows", len(body))

    out, filled, names = [], 0, set()
    by_cert = by_name = by_year = 0
    for row in body:
        row = (row + [""] * 7)[:7]
        nm, cert, year = row[0], norm_cert(row[1]), (row[4] or "").strip()
        city = cnty = ""
        v = cert_map.get(cert) if cert else None
        if v and len(v) == 1:
            city, cnty = list(v)[0]
            by_cert += 1
        if not city:
            v = name_map.get(norm_name(nm))
            if v and len(v) == 1:
                city, cnty = list(v)[0]
                by_name += 1
            elif v:
                v2 = nameyear.get((norm_name(nm), year))
                if v2 and len(v2) == 1:
                    city, cnty = list(v2)[0]
                    by_year += 1
        if city:
            row[2], row[3] = city, cnty
            filled += 1
            names.add(norm_name(nm))
        out.append(row)

    with io.open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(HEADER)
        w.writerows(out)
    print("wrote", out_csv, "rows", len(out), "with city", filled,
          "distinct firms", len(names))
    print("  via cert", by_cert, "via name", by_name, "via name+year", by_year)
    cc = collections.Counter(r[2] for r in out if r[2])
    print("city dist", cc.most_common())
    cty = collections.Counter(r[3] for r in out if r[3])
    print("county filled", sum(cty.values()), cty.most_common(10))


if __name__ == "__main__":
    main()
