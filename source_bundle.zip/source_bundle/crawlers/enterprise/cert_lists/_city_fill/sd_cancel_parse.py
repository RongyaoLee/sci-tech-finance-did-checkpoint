# -*- coding: utf-8 -*-
"""解析 _yt_wf_cancel_dump.txt：证书号行 -> 前一行=企业名，后一行=地市。"""
import re, json, os, sys
DUMP = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_yt_wf_cancel_dump.txt"
PARTS = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\parts"
CR = re.compile(r"^GR\d{12}$")

def main():
    txt = open(DUMP, encoding="utf-8").read()
    blocks = txt.split("==========")
    rows = []
    for blk in blocks:
        if "http" not in blk[:400]:
            continue
        url = blk.strip().split("\n")[0].strip()
        lines = [l.strip() for l in blk.split("\n")]
        for i, l in enumerate(lines):
            m = CR.match(l.replace(" ", ""))
            if not m:
                continue
            name = ""
            for j in range(i - 1, max(-1, i - 4), -1):
                if lines[j] and not CR.match(lines[j]) and not re.match(r"^(序号|企业名称)", lines[j]):
                    name = lines[j]
                    break
            city = ""
            for k in range(i + 1, min(len(lines), i + 4)):
                if re.match(r"^\S{2,3}市$", lines[k]):
                    city = lines[k]
                    break
            rows.append({"cert": l.replace(" ", ""), "name": name, "city": city, "src": url})
    from collections import Counter
    print(Counter(r["city"] for r in rows))
    yt = [r for r in rows if r["city"] == "烟台市"]
    wf = [r for r in rows if r["city"] == "潍坊市"]
    print("烟台", len(yt), "潍坊", len(wf))
    for r in yt[:5] + wf[:5]:
        print(r)

if __name__ == "__main__":
    main()
