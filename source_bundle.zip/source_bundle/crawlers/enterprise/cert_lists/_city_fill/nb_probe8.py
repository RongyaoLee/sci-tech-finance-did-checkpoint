# -*- coding: utf-8 -*-
import re
p = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_c101481.html"
h = open(p, encoding="utf-8", errors="ignore").read()
ids = sorted(set(re.findall(r"c10\d{4}", h)))
print(ids)
print("--- headings ---")
seen = set()
for m in re.finditer(r'<a[^>]+href="([^"]*c10\d{4}[^"]*)"[^>]*>([^<]{0,30})</a>', h):
    k = m.group(1)
    if k in seen:
        continue
    seen.add(k)
    print(m.group(2), "|", k)
