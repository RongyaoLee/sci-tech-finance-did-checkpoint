﻿# -*- coding: utf-8 -*-
import os,sys,re,json,urllib.parse
sys.path.insert(0,os.getcwd())
import cf
def arts(h,base,pat=r"高新|高企"):
    out=[]
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',h,re.S|re.I):
        u=urllib.parse.urljoin(base,m.group(1)); t=re.sub(r"<[^>]+>","",m.group(2)); t=re.sub(r"\s+","",t).strip()
        if t and re.search(pat,t): out.append((t,u))
    return out
for col,city,pgs in [("https://www.zzgx.gov.cn/tzgg/index.jhtml","株洲市",12),
                     ("https://www.czgxq.gov.cn/czgxq/c116280/listDisplaySon.shtml","郴州市",6)]:
    print("==",col)
    for i in range(1,pgs+1):
        u=col if i==1 else (col.replace("index.jhtml","index_%d.jhtml"%i) if "jhtml" in col else col+"?page=%d"%i)
        h,f=cf.get(u)
        if not h: print("  page",i,"fail"); continue
        r=arts(h,f)
        for t,uu in r[:10]: print("   p%d %s | %s"%(i,t[:50],uu[:95]))
        if not r: break
