# -*- coding: utf-8 -*-
"""Probe 大汉/jeecms site search (jsearchfront) on each city sci-tech bureau host."""
import os, re, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_baidu as B

HOSTS = [
    ("烟台", "http://kjj.yantai.gov.cn"),
    ("潍坊", "http://kjj.weifang.gov.cn"),
    ("济宁", "http://jnkj.jining.gov.cn"),
    ("泰安", "http://kjj.taian.gov.cn"),
    ("威海", "http://kjj.weihai.gov.cn"),
    ("临沂", "http://kjj.linyi.gov.cn"),
    ("聊城", "http://kjj.liaocheng.gov.cn"),
    ("枣庄", "http://zzst.zaozhuang.gov.cn"),
]
res = {}
for city, base in HOSTS:
    st, h, _ = B.f(base + "/", timeout=25)
    info = {"status": st, "len": len(h or ""), "websiteid": [], "jsearch": False}
    if h:
        info["websiteid"] = sorted(set(re.findall(r"websiteid[\"'\s:=]+([0-9]{6,20})", h)))[:5]
        info["jsearch"] = "jsearchfront" in h
        info["searchforms"] = sorted(set(re.findall(r'(action="[^"]*search[^"]*")', h, re.I)))[:5]
    res[city] = info
    print(city, st, info["websiteid"], info["jsearch"], flush=True)
json.dump(res, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_search_probe.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
