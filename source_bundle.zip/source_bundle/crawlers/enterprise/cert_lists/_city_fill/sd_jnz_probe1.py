import sys, json
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

TARGETS = [
    ("jn_home", "http://www.jinan.gov.cn/"),
    ("jn_home2", "https://www.jinan.gov.cn/"),
    ("zb_home", "http://www.zibo.gov.cn/"),
    ("zz_home", "http://www.zaozhuang.gov.cn/"),
    ("jn_kjj", "http://jnkj.jinan.gov.cn/"),
    ("zb_kjj", "http://kjj.zibo.gov.cn/"),
    ("zz_kjj", "http://kjj.zaozhuang.gov.cn/"),
]
out = {}
for tag, url in TARGETS:
    try:
        st, content, final = H.get(url, timeout=25, tries=1)
        txt = ""
        if content:
            try:
                txt = content.decode("utf-8", "ignore")
            except Exception:
                txt = str(content[:400])
        out[tag] = {"url": url, "status": st, "final": final, "len": len(txt), "head": txt[:300]}
        print(tag, st, len(txt), final)
    except Exception as e:
        out[tag] = {"url": url, "err": f"{type(e).__name__}: {e}"}
        print(tag, "ERR", type(e).__name__, e)
json.dump(out, open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_jnz_probe1.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
