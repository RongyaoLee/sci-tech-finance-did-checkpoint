# -*- coding: utf-8 -*-
"""Map exported aliases (j, G) of the Hubei Footer chunk to their values."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

t = open(os.path.join(cf.HERE, "_hb_Footer.js"), encoding="utf-8").read()
m = list(re.finditer(r"export\{([^}]{0,2000})\}", t))
print("n exports blocks:", len(m))
if m:
    print(m[-1].group(1)[:2000])
