# -*- coding: utf-8 -*-
"""Locate the axios instance baseURL / request paths in the Hubei ywt bundles."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

for fn in ("_hb_ywt.js", "_hb_index.js"):
    t = open(os.path.join(cf.HERE, fn), encoding="utf-8").read()
    print("====", fn, len(t))
    for kw in ("baseURL", "interceptors", "axios", "he.defaults", "He=", "VITE_"):
        for m in list(re.finditer(re.escape(kw), t))[:3]:
            print("  [%s]" % kw, repr(t[max(0, m.start() - 120):m.start() + 200]))
    # any quoted path with 2+ segments
    print("  paths:", sorted(set(re.findall(r"['\"](/[a-zA-Z][\w\-/]{3,60})['\"]", t)))[:40])
