# -*- coding: utf-8 -*-
import csv, io, sys, re, os
sys.stdout.reconfigure(encoding="utf-8")
p = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\浙江省.csv"
with open(p, encoding="utf-8-sig", newline="") as f:
    r = csv.reader(f)
    head = next(r)
    print("HEAD", head)
    n = 0
    samples = []
    for row in r:
        n += 1
        if n <= 3:
            samples.append(row)
print("rows", n)
for s in samples:
    print(s)
