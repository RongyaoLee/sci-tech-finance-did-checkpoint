﻿# -*- coding: utf-8 -*-
import json,io
rows=[json.loads(l) for l in open("rows_湖南.jsonl",encoding="utf-8") if l.strip()]
keep=[r for r in rows if r["city"] not in ("株洲市","怀化市")]
drop=len(rows)-len(keep)
with io.open("rows_湖南.jsonl","w",encoding="utf-8") as f:
    for r in keep: f.write(json.dumps(r,ensure_ascii=False)+"\n")
with io.open("_progress_湖南.log","a",encoding="utf-8") as f:
    f.write("修正\t删除误标 %d 条（株洲市77、怀化市15 的来源实为「湖南省…拟变更高新技术企业」全省名单，非市级名单）；保留 %d 条\n"%(drop,len(keep)))
print("kept",len(keep),"dropped",drop)
