# -*- coding: utf-8 -*-
"""Dump attachment heads for given pages (to test for 城市 columns)."""
import os, sys, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

def doc_head(path, n=12):
    ext = os.path.splitext(path)[1].lower()
    lines = []
    if ext == ".pdf":
        import fitz
        d = fitz.open(path)
        lines.append("[pdf pages=%d]" % d.page_count)
        for pno in range(min(2, d.page_count)):
            t = d[pno].get_text("text")
            lines.extend([x for x in t.splitlines() if x.strip()][:n])
            if len(lines) > n:
                break
    elif ext in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
        for ws in wb.worksheets:
            lines.append("[sheet %s dims=%s]" % (ws.title, ws.calculate_dimension()))
            c = 0
            for row in ws.iter_rows(values_only=True):
                vals = ["" if v is None else str(v) for v in row]
                if not any(vals):
                    continue
                lines.append(" | ".join(vals))
                c += 1
                if c >= n:
                    break
            break
    elif ext == ".xls":
        import xlrd
        wb = xlrd.open_workbook(path)
        sh = wb.sheet_by_index(0)
        lines.append("[xls sheet=%s rows=%d cols=%d]" % (sh.name, sh.nrows, sh.ncols))
        for r in range(min(n, sh.nrows)):
            lines.append(" | ".join(str(sh.cell_value(r, c)) for c in range(sh.ncols)))
    elif ext in (".docx",):
        import docx
        d = docx.Document(path)
        for p in d.paragraphs:
            if p.text.strip():
                lines.append(p.text.strip())
            if len(lines) >= n:
                break
        for tb in d.tables:
            lines.append("[table %dx%d]" % (len(tb.rows), len(tb.columns)))
            for r in tb.rows[:n]:
                lines.append(" | ".join(c.text.strip() for c in r.cells))
            break
    else:
        lines.append("[unknown ext %s]" % ext)
    return lines


def probe(page_url):
    print("=" * 78)
    print(page_url)
    html, final = cf.get(page_url)
    if not html:
        print("  FETCH FAIL")
        return
    soup = BeautifulSoup(html, "lxml")
    title = soup.title.get_text(strip=True) if soup.title else ""
    print("  title:", title)
    atts = cf.attachments(page_url, html)
    print("  attachments:", len(atts))
    for text, u in atts:
        print("   -", text[:60], "|", u)
        p = cf.download(u, "probe")
        if not p:
            print("     download FAIL")
            continue
        for ln in doc_head(p, 8):
            print("     ", ln[:160])


if __name__ == "__main__":
    for u in sys.argv[1:]:
        probe(u)
