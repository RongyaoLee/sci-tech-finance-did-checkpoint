# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup
from tblgrid import grid_of, clean

html, final = cf.get("https://kjj.changde.gov.cn/zwgk/public/6617349/3700379621.html")
soup = BeautifulSoup(html, "lxml")
tb = soup.find("table")
g = grid_of(tb)
print("rows", len(g))
for r in g[:10]:
    print(r)
