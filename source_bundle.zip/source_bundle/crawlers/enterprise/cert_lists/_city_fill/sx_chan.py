# -*- coding: utf-8 -*-
"""Generic channel crawler: collect (title,url,date) from paginated gov listing pages."""
import sys, os, re, json, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

DATE_RE = re.compile(r"(20\d{2})[-/年\.](\d{1,2})[-/月\.](\d{1,2})")

def items_of(html, base):
    s = cf.soup_of(html)
    out = []
    for a in s.find_all("a", href=True):
        tx = a.get_text(" ", strip=True)
        if len(tx) < 6:
            continue
        h = a["href"].strip()
        if h.startswith("javascript") or h.startswith("#"):
            continue
        full = urllib.parse.urljoin(base, h)
        # date from sibling text
        par = a.parent
        ctx = ""
        for _ in range(3):
            if par is None:
                break
            ctx = par.get_text(" ", strip=True)
            if DATE_RE.search(ctx):
                break
            par = par.parent
        m = DATE_RE.search(ctx or "")
        d = ("%s-%02d-%02d" % (m.group(1), int(m.group(2)), int(m.group(3)))) if m else ""
        out.append((tx, full, d))
    return out

def crawl(templates, n=25, delay=0.0):
    seen, res = set(), []
    for i in range(1, n + 1):
        got = 0
        for tpl in templates:
            url = tpl.format(i)
            h, f = cf.get(url, tries=1, timeout=20)
            if not h or len(h) < 2000:
                continue
            for tx, u, d in items_of(h, f):
                if u in seen:
                    continue
                seen.add(u)
                res.append({"t": tx, "u": u, "d": d})
                got += 1
            if got:
                break
        if got == 0:
            break
    return res

SITES = {
    "咸阳_gxjs": ["https://kjj.xianyang.gov.cn/bszn/gxjsjqcyh/index_{0}.html",
                  "https://kjj.xianyang.gov.cn/bszn/gxjsjqcyh/index.html"],
    "咸阳_tztg": ["https://kjj.xianyang.gov.cn/kjxw/tztg/index_{0}.html",
                  "https://kjj.xianyang.gov.cn/kjxw/tztg/index.html"],
}

if __name__ == "__main__":
    name = sys.argv[1]
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    res = crawl(SITES[name], n)
    json.dump(res, open(os.path.join(HERE, "_sx_list_%s.json" % name), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    hit = [r for r in res if re.search(r"高新|高企|认定", r["t"])]
    print(name, "total", len(res), "hit", len(hit))
    for r in hit[:40]:
        print(r["d"], r["t"][:60], r["u"][:110])
