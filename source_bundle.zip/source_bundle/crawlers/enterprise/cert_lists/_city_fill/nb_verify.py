# -*- coding: utf-8 -*-
import sys, os, json, random, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H
import nb_docparse
import nb_names
from collections import Counter

CF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill"
out = os.path.join(CF, "parts", "浙江省_宁波市.jsonl")
recs = [json.loads(l) for l in open(out, encoding="utf-8")]
print("rows", len(recs), "uniq", len({r["cert"] for r in recs}))
print("src count", len({r["src"] for r in recs}))
print("cert prefix set", Counter(r["cert"][2:6] + "/" + r["cert"][6:9] for r in recs).most_common(3))
print("name len min/max", min(len(r["name"]) for r in recs), max(len(r["name"]) for r in recs))
print("dup names", len(recs) - len({(r["name"], r["cert"]) for r in recs}))
random.seed(7)
samp = random.sample(recs, 6)
for r in samp:
    print(json.dumps(r, ensure_ascii=False))
# 抽 2 条回原文校验
for r in samp[:2]:
    sc, data, f = H.get(r["src"], binary=True, timeout=60)
    p = H.save_raw("nb_doc", r["src"], data)
    txt = nb_docparse.doc_text(p) if (r["src"].lower().endswith(".doc") or data[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1") else H.doc_text(r["src"], data)
    ok = r["cert"] in txt.replace(" ", "") and r["name"] in txt.replace(" ", "")
    print("VERIFY", r["cert"], ok, "|", r["name"])
