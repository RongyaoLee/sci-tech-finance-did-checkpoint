# -*- coding: utf-8 -*-
"""Resolve 湖南 city gov domains via DoH (AliDNS), then GET by IP with Host header."""
import sys, os, json, socket, ssl
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import requests

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
DOMS = ["kjj.hengyang.gov.cn", "www.hengyang.gov.cn", "kjj.czs.gov.cn", "www.czs.gov.cn",
        "kjj.xiangtan.gov.cn", "www.xiangtan.gov.cn", "kjj.huaihua.gov.cn", "www.huaihua.gov.cn",
        "kjj.xxz.gov.cn", "www.xxz.gov.cn"]


def doh(name):
    try:
        r = requests.get("https://223.5.5.5/resolve", params={"name": name, "type": "A"},
                         timeout=15, verify=False,
                         headers={"accept": "application/dns-json"})
        j = r.json()
        return [a["data"] for a in j.get("Answer", []) if a.get("type") == 1]
    except Exception as e:
        return ["ERR:%s" % e]


for d in DOMS:
    ips = doh(d)
    print(d, ips[:3])
