﻿# -*- coding: utf-8 -*-
import os,sys,re,json,urllib.parse,time
sys.path.insert(0,os.getcwd())
import cf
Q=["常德市 高新技术企业 名单","衡阳市 高新技术企业 名单","郴州市 高新技术企业 名单","长沙市 高新技术企业 名单","湘潭市 高新技术企业 名单","邵阳市 高新技术企业 名单"]
seen={}
for q in Q:
    for p in (1,2):
        u="http://searching.hunan.gov.cn/hunan/001000000/all?q=%s&iszq=1&p=%d"%(urllib.parse.quote(q),p)
        h,f=cf.get(u)
        if not h: break
        for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',h,re.S|re.I):
            uu=urllib.parse.urljoin(f,m.group(1)); tt=re.sub(r"<[^>]+>","",m.group(2)); tt=re.sub(r"\s+","",tt).strip()
            if "searching.hunan.gov.cn" in uu or not tt or len(tt)<8: continue
            if not re.search(r"高新",tt): continue
            seen.setdefault(uu,tt)
        time.sleep(0.4)
open("_hn_hits5.txt","w",encoding="utf-8").write("\n".join("## %s | %s"%(t,u) for u,t in seen.items()))
print(len(seen))
