# -*- coding: utf-8 -*-
"""360 (so.com) discovery v2: per-row city from document column, grouped by real city."""
import os, re, sys, json, html, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_baidu as B
import sd_city_parser as P
import sd_store as ST
import sd_lib as S

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "_so_seen.json")
SEEN = json.load(open(CACHE, encoding="utf-8")) if os.path.exists(CACHE) else {}


def save_seen():
    json.dump(SEEN, open(CACHE, "w", encoding="utf-8"), ensure_ascii=False, indent=0)


def so_links(q, pn=1):
    url = "https://www.so.com/s?q=" + urllib.parse.quote(q) + ("&pn=%d" % pn if pn > 1 else "")
    st, h, _ = B.f(url, referer="https://www.so.com/")
    if st != 200 or not h:
        return []
    out = []
    for m in re.finditer(r'<h3[^>]*>\s*<a ([^>]*)>(.*?)</a>', h, re.S):
        attrs, inner = m.group(1), m.group(2)
        t = html.unescape(re.sub(r"<[^>]+>", "", inner)).strip()
        md = re.search(r'data-mdurl="([^"]+)"', attrs)
        u = html.unescape(md.group(1)) if md else ""
        if not u:
            hr = re.search(r'href="(https?://[^"]+)"', attrs)
            u = html.unescape(hr.group(1)) if hr else ""
        if u.startswith("http") and "so.com" not in u:
            out.append((t, u))
    return out


BAD_NAME = {"附件", "序号", "合计", "企业名称", "单位名称", "备注"}


def ok_name(nm):
    nm = (nm or "").strip()
    if len(nm) < 6 or nm in BAD_NAME or re.fullmatch(r"[\d.\s\-]+", nm):
        return False
    return S.looks_name(nm)


ATT = re.compile(r'(?:href|src)="([^"]+\.(?:pdf|xlsx?|docx?|et)|[^"]*(?:downfile\.jsp|attach/0/|virtual_attach_file|upload-service)[^"]*)"', re.I)


def ingest(src, rows4, stats):
    good = [(a, b, c, d) for (a, b, c, d) in rows4 if c and ok_name(a) and (b or len(a) >= 8)]
    by = {}
    for a, b, c, d in good:
        by.setdefault(c, []).append((a, b, d))
    n = 0
    for city, rr in by.items():
        n += ST.append_rows(city, rr, src, "", "")
    return n, good


def grab(art_url):
    st, h, final = B.f(art_url, timeout=30)
    if st != 200 or not h:
        return 0, {}
    total, detail = 0, {}
    try:
        import bs4
        soup = bs4.BeautifulSoup(h, "html.parser")
        tabs = []
        for tb in soup.find_all("table"):
            rr = [[c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])] for tr in tb.find_all("tr")]
            rr = [r for r in rr if any(x for x in r)]
            if len(rr) >= 5:
                tabs.append(rr)
        if tabs:
            r4 = P.rows_from_tables(tabs, "", False)
            n, good = ingest(art_url, r4, {})
            if n:
                total += n
                detail[art_url] = n
    except Exception:
        pass
    urls = []
    for m in ATT.finditer(h):
        u = html.unescape(m.group(1))
        if u.startswith("//"):
            u = "http:" + u
        elif u.startswith("/"):
            p = urllib.parse.urlparse(final or art_url)
            u = p.scheme + "://" + p.netloc + u
        elif not u.startswith("http"):
            p = urllib.parse.urlparse(final or art_url)
            u = p.scheme + "://" + p.netloc + "/" + u.lstrip("./")
        urls.append(u)
    for u in list(dict.fromkeys(urls))[:14]:
        if u in SEEN.get("docs", []):
            continue
        SEEN.setdefault("docs", []).append(u)
        st, data, _ = B.f(u, binary=True, timeout=60)
        if st != 200 or len(data) < 2000:
            continue
        try:
            r4 = P.rows_from_doc(u, data, "", False)
        except Exception:
            continue
        n, good = ingest(u, r4, {})
        if n:
            total += n
            detail[u] = n
            print("    DOC +%d %s" % (n, u[:96]), flush=True)
    return total, detail


HOSTS = {
    "济南": ["kjj.jinan.gov.cn", "jnkj.jinan.gov.cn"],
    "淄博": ["kjj.zibo.gov.cn", "zibo.gov.cn"],
    "枣庄": ["zzst.zaozhuang.gov.cn", "kjj.zaozhuang.gov.cn"],
    "东营": ["kjj.dongying.gov.cn"],
    "烟台": ["kjj.yantai.gov.cn"],
    "潍坊": ["kjj.weifang.gov.cn"],
    "济宁": ["jnkj.jining.gov.cn", "kjj.jining.gov.cn"],
    "泰安": ["kjj.taian.gov.cn"],
    "威海": ["kjj.weihai.gov.cn", "whcxcy.com"],
    "日照": ["kjj.rizhao.gov.cn"],
    "临沂": ["kjj.linyi.gov.cn"],
    "德州": ["kjj.dezhou.gov.cn"],
    "聊城": ["kjj.liaocheng.gov.cn"],
    "滨州": ["kjj.binzhou.gov.cn"],
    "菏泽": ["kjj.heze.gov.cn"],
}

QS = ["高新技术企业名单", "高新技术企业名单 所属区市", "关于公布高新技术企业名单的通知", "高企名单 区县"]


def run(cities, pages=2):
    report = {}
    for city in cities:
        hosts = HOSTS.get(city, [])
        tot, arts = 0, []
        for host in hosts:
            for q in QS:
                for pn in range(1, pages + 1):
                    ls = so_links("site:%s %s" % (host, q), pn)
                    for t, u in ls:
                        if [t, u] in SEEN.get("links", []):
                            continue
                        SEEN.setdefault("links", []).append([t, u])
                        arts.append((t, u))
                    if not ls:
                        break
        arts = list(dict.fromkeys(arts))
        for t, u in arts[:30]:
            n, det = grab(u)
            if n:
                tot += n
                report.setdefault(city, []).append({"url": u, "rows": n, "title": t})
        save_seen()
        print("%s arts=%d rows=%d" % (city, len(arts), tot), flush=True)
        report.setdefault(city, [])
    json.dump(report, open(os.path.join(HERE, "_so_report.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    run(sys.argv[1:] or ["潍坊"])
