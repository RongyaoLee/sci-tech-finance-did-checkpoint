# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

TAIL = [
 ("https://kjj.xianyang.gov.cn/kjxw/tztg/202410/t20241018_1823764.html", "成功认定"),
]
for u, key in TAIL:
    h, f = cf.get(u, tries=2, timeout=25)
    s = cf.soup_of(h)
    for t in s(["script", "style"]):
        t.decompose()
    txt = re.sub(r"\n{2,}", "\n", s.get_text("\n", strip=True))
    pos = txt.find("责任编辑")
    print("POS", pos, "len", len(txt))
    print(txt[pos:pos + 3000])
