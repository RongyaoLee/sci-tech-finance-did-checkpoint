# -*- coding: utf-8 -*-
import sys, os, re, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

CANDS = [
    "http://kjj.xa.gov.cn/",
    "https://kjj.xa.gov.cn/",
    "http://www.xa.gov.cn/",
    "http://kjj.baoji.gov.cn/",
    "http://kjj.xianyang.gov.cn/",
    "http://kjj.weinan.gov.cn/",
    "http://kjj.yanan.gov.cn/",
    "http://kjj.hanzhong.gov.cn/",
    "http://kjj.yl.gov.cn/",
    "http://kjj.ankang.gov.cn/",
    "http://kjj.shangluo.gov.cn/",
    "http://kjj.tongchuan.gov.cn/",
    "https://kjj.yangling.gov.cn/",
]
out = {}
for u in CANDS:
    h, f = cf.get(u, tries=1, timeout=15)
    if not h:
        out[u] = {"err": f}
        continue
    s = cf.soup_of(h)
    title = s.title.get_text(strip=True) if s.title else ""
    hits = []
    for a in s.find_all("a", href=True):
        tx = a.get_text(" ", strip=True)
        if "高新" in tx or "科技" in tx or "通知" in tx:
            hits.append((tx[:40], a["href"][:160]))
    out[u] = {"len": len(h), "final": f, "title": title, "hits": hits[:15]}
json.dump(out, open(os.path.join(HERE, "_sx_city_probe.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("ok")
