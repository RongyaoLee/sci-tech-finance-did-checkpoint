# -*- coding: utf-8 -*-
import sys, os, re, json, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

q = urllib.parse.quote("高新技术企业")
CANDS = [
    "http://xdz.xa.gov.cn/", "https://xdz.xa.gov.cn/",
    "http://www.xagxq.gov.cn/", "https://www.xagxq.gov.cn/",
    "http://www.hanzhong.gov.cn/",
    "http://www.shangluo.gov.cn/",
    "http://www.tongchuan.gov.cn/",
    "https://www.yangling.gov.cn/",
    "http://www.bjgj.gov.cn/",
    # so-gov search api guesses
    "https://api.so-gov.cn/api/search?siteCode=6101000007&qt=" + q + "&page=1&pageSize=20",
    "https://p.so-gov.cn/api/search?siteCode=6101000007&qt=" + q + "&page=1&pageSize=20",
    "https://api.so-gov.cn/search?siteCode=6101000007&qt=" + q + "&page=1",
]
out = {}
for u in CANDS:
    h, f = cf.get(u, tries=1, timeout=12)
    if not h:
        out[u] = {"err": f}
        continue
    s = cf.soup_of(h) if not h.lstrip().startswith("{") else None
    title = s.title.get_text(strip=True) if (s and s.title) else ""
    hits = []
    if s:
        for a in s.find_all("a", href=True):
            tx = a.get_text(" ", strip=True)
            if re.search(r"高新|高企|认定|公示", tx):
                hits.append((tx[:45], a["href"][:140]))
    out[u] = {"len": len(h), "final": f, "title": title, "hits": hits[:12],
              "head": re.sub(r"\s+", " ", h)[:300]}
json.dump(out, open(os.path.join(HERE, "_sx_probe4.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("ok")
