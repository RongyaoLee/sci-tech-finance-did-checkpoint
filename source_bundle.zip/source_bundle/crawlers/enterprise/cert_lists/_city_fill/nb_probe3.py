# -*- coding: utf-8 -*-
import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

BASE = "http://www.innocom.gov.cn/gqrdw/c101419/list_gsgg_l3.shtml"
sc, html, final = H.get(BASE, timeout=25, tries=2)
print("status", sc, len(html or ""), final)
H.save_raw("nb", BASE, html.encode("utf-8", "ignore"))
if sc == 200:
    rows = []
    for href, txt in H.img_links(html, final):
        if "art/" in href or "content" in href or ".shtml" in href:
            rows.append((txt[:80], href))
    with open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_p1.json", "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=1)
    print("links", len(rows))
    # show paging blocks
    for m in re.finditer(r'(?is)(createPageHTML|pageCount|totalPage|recordCount|pages?)[^\n]{0,120}', html):
        print("PAGE:", m.group(0)[:150].replace("\n", " "))
