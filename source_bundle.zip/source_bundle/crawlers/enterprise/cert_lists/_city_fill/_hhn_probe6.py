# -*- coding: utf-8 -*-
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

u = 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/index.html'
st, txt, fu = H.get(u, timeout=30)
print('==', st, len(txt))
for pat in ['dataproxy', 'columnid', 'appid', 'webid', 'getList', 'ajax', 'json', 'sttz15', 'jpage', 'loadList']:
    for m in re.finditer(pat, txt, re.I):
        s = max(0, m.start() - 120); e = min(len(txt), m.end() + 160)
        print('---', pat, '::', re.sub(r'\s+', ' ', txt[s:e])[:300])
        break
print('===== script srcs')
for m in re.finditer(r'<script[^>]+src=[\'"]([^\'"]+)[\'"]', txt, re.I):
    print(' ', m.group(1))
