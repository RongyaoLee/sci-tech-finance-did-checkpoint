# -*- coding: utf-8 -*-
import sys, os, re, json, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

q = urllib.parse.quote("高新技术企业")
cands = [
    "http://www.xa.gov.cn/so/s?siteCode=6101000007&tab=all&qt=" + q,
    "http://www.xa.gov.cn/so/s?tab=all&qt=" + q,
    "http://www.xa.gov.cn/so/s?siteCode=6101000007&qt=" + q,
]
out = {}
for u in cands:
    h, f = cf.get(u, tries=1, timeout=20)
    if not h:
        out[u] = {"err": f}
        continue
    txt = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", h))
    links = [(a.get_text(" ", strip=True)[:60], a["href"][:160]) for a in cf.soup_of(h).find_all("a", href=True)]
    out[u] = {"len": len(h), "final": f, "snippet": txt[:1200], "links": links[:40]}
json.dump(out, open(os.path.join(HERE, "_sx_xa_search.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("ok")
