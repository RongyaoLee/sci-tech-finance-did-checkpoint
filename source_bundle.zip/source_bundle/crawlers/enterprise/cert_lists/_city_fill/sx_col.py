# -*- coding: utf-8 -*-
"""Probe 陕西省科技厅「高新技术企业认定」专题栏目：列出各年公示/公告页与附件，抽样看附件是否带地市列。"""
import os, sys, json, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

COLS = ["https://kjt.shaanxi.gov.cn/kjdt/ztzl/lszt/gqrd/index.html",
        "https://kjt.shaanxi.gov.cn/kjdt/ztzl/lszt/gqrd/index_1.html",
        "https://kjt.shaanxi.gov.cn/kjdt/ztzl/lszt/gqrd/index_2.html"]

pages = []
for u in COLS:
    try:
        html, final = cf.get(u)
    except Exception as e:
        print("ERR", u, type(e).__name__, flush=True)
        continue
    s = cf.soup_of(html)
    n = 0
    for a in s.find_all("a", href=True):
        t = a.get_text(" ", strip=True)
        href = a["href"]
        if not re.search(r"\d{4}", t):
            continue
        if "高新" not in t and "认定" not in t and "备案" not in t:
            continue
        if not href.endswith(".html") and "/t2" not in href:
            continue
        pages.append({"title": t, "url": urllib.parse.urljoin(final, href)})
        n += 1
    print(u, "->", final, "links", n, flush=True)

seen, uniq = set(), []
for p in pages:
    if p["url"] in seen:
        continue
    seen.add(p["url"])
    uniq.append(p)
json.dump(uniq, open(os.path.join(cf.HERE, "_sx_col_pages.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
for p in uniq[:40]:
    print(p["title"][:70], "|", p["url"])
print("total", len(uniq))
