# -*- coding: utf-8 -*-
import sys, os, json, re
from collections import Counter, defaultdict
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
CF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill"
out = os.path.join(CF, "parts", "浙江省_宁波市.jsonl")
recs = [json.loads(l) for l in open(out, encoding="utf-8")]
print("rows", len(recs), "uniq cert", len({r["cert"] for r in recs}), "city", set(r["city"] for r in recs))
print("year", sorted(Counter(r["year"] for r in recs).items()))
emp = [r for r in recs if not r["name"]]
print("empty names", len(emp))
print("by src:")
for u, n in Counter(r["src"] for r in emp).most_common():
    print(" ", n, u)
print("sample empty:", [r["cert"] for r in emp[:12]])
print("name len dist", sorted(Counter(len(r["name"]) for r in recs).items())[:12])
# 检查是否有可疑名称(含数字/仅数字/超长)
bad = [r for r in recs if r["name"] and (re.fullmatch(r"[\d\.\s]+", r["name"]) or len(r["name"]) > 40)]
print("suspect names", len(bad), bad[:5])
