# -*- coding: utf-8 -*-
"""Parse local HTML file tables; print value distribution of a candidate city column."""
import sys, re, collections
from lxml import html as LH

path = sys.argv[1]
doc = LH.parse(path).getroot()
for ti, t in enumerate(doc.xpath("//table")):
    rows = [[re.sub(r"\s+", " ", (c.text_content() or "")).strip() for c in tr.xpath("./td|./th")]
            for tr in t.xpath(".//tr")]
    rows = [r for r in rows if any(r)]
    if len(rows) < 5:
        continue
    print("=" * 60, "table", ti, "rows", len(rows))
    hdr = rows[0]
    print("hdr:", hdr)
    # find column whose values look like city names
    for ci in range(len(hdr)):
        vals = [r[ci] for r in rows[1:] if ci < len(r) and r[ci]]
        if not vals:
            continue
        c = collections.Counter(vals)
        top = c.most_common(6)
        print(" col%d %r distinct=%d top=%s" % (ci, hdr[ci] if ci < len(hdr) else "", len(c), top))
