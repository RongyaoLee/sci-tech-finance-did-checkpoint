# -*- coding: utf-8 -*-
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

tests = [
    "http://kjj.changsha.gov.cn/zfxxgk/tzgg_27202/index_1.html",
    "http://kjj.changsha.gov.cn/zfxxgk/tzgg_27202/index_2.html",
]
for u in tests:
    html, final = cf.get(u)
    soup = BeautifulSoup(html or "", "lxml")
    links = [a.get_text(" ", strip=True) for a in soup.find_all("a", href=True) if a.get_text(strip=True)]
    print(u, "len", len(html or ""), "links", len(links), links[:3])
# also check whether listing page contains an iframe or a js data file
html, final = cf.get("http://kjj.changsha.gov.cn/zfxxgk/tzgg_27202/index.html")
print("---- inline count:", html.count("<li"), "| has page.js:", "page.js" in html)
i = html.find("page.js")
print(html[max(0, i - 300):i + 200])
