# -*- coding: utf-8 -*-
"""山东地级市高企名单：通用抓取 + 表格解析。仅读网络，写 _city_fill/ 下产物。"""
import io, os, re, sys, json, time, random, hashlib
from urllib.parse import urljoin, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(BASE, "raw")
PARTS = os.path.join(BASE, "parts")
os.makedirs(PARTS, exist_ok=True)

DOC_EXT = (".pdf", ".xls", ".xlsx", ".doc", ".docx", ".et", ".wps", ".zip", ".rar", ".txt")

CERT_RE = re.compile(r"GR\s?(\d{4})\s?(\d{2})\s?(\d{6})")

GX_PAT = re.compile(r"高新技术企业|高企")
LIST_PAT = re.compile(r"名单|公示|公布|认定|备案|奖励|资助|入库")
CITY_PAT = re.compile(r"[\u4e00-\u9fa5]{2,6}(?:市|区|县)")


def get(url, timeout=30, tries=3, binary=False):
    return H.get(url, timeout=timeout, tries=tries, binary=binary)


def norm_cert(s):
    m = CERT_RE.search(s or "")
    return ("GR%s%s%s" % m.groups()) if m else ""


def norm_name(s):
    s = (s or "").replace("\u3000", " ").replace("\xa0", " ")
    s = re.sub(r"\s+", "", s)
    s = s.strip("　 ·、,，;；:：|")
    return s


NAME_TAIL = ("公司", "企业", "厂", "中心", "院", "所", "集团", "合作社", "工作室", "店", "社")


def looks_name(s):
    if not s or len(s) < 4 or len(s) > 60:
        return False
    if re.search(r"[0-9]{6,}", s):
        return False
    if re.match(r"^(序号|企业名称|合计|小计|备注|单位名称)", s):
        return False
    return any(s.endswith(t) for t in NAME_TAIL) or ("(" in s and "公司" in s)


def rows_from_text(txt):
    """从纯文本里抽 (name, cert)。处理 '1 潍坊XX有限公司 GR202137001234' 这类行。"""
    out = []
    for line in (txt or "").splitlines():
        line = line.replace("\u3000", " ").strip()
        if not line:
            continue
        certs = [("GR%s%s%s" % m.groups()) for m in CERT_RE.finditer(line)]
        if certs:
            # 去掉证书号与序号，剩下的当名称
            left = CERT_RE.sub(" ", line)
            left = re.sub(r"^[\s\d、.．)）(（\-]+", " ", left)
            left = re.sub(r"\s+", " ", left).strip()
            left = re.sub(r"[\s\d]+$", "", left).strip()
            nm = norm_name(left)
            if not looks_name(nm):
                nm = ""
            out.append((nm, certs[0]))
        elif looks_name(norm_name(re.sub(r"^[\s\d、.．)）(（\-]+", " ", line))):
            out.append((norm_name(line), ""))
    return out


def rows_from_pdf(data):
    import fitz
    rows = []
    doc = fitz.open(stream=data, filetype="pdf")
    txts = []
    for page in doc:
        try:
            tabs = page.find_tables()
            got = False
            for tb in tabs.tables:
                for row in tb.extract():
                    cells = [norm_name(c) for c in (row or []) if c]
                    if not cells:
                        continue
                    cert = ""
                    nm = ""
                    for c in cells:
                        if CERT_RE.search(c):
                            cert = norm_cert(c)
                        elif looks_name(c) and not nm:
                            nm = c
                    if cert or nm:
                        rows.append((nm, cert))
                        got = True
            if got:
                txts.append(page.get_text())
                continue
        except Exception:
            pass
        txts.append(page.get_text())
    doc.close()
    rows += rows_from_text("\n".join(txts))
    # 去重保序
    seen, res = set(), []
    for nm, ct in rows:
        k = (ct or nm)
        if not k or k in seen:
            continue
        seen.add(k)
        res.append((nm, ct))
    return res


def rows_from_xlsx(data):
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    rows = []
    for ws in wb.worksheets:
        for r in ws.iter_rows(values_only=True):
            cells = [norm_name(str(c)) for c in r if c is not None and str(c).strip()]
            if not cells:
                continue
            cert, nm = "", ""
            for c in cells:
                if CERT_RE.search(c):
                    cert = norm_cert(c)
                elif looks_name(c) and not nm:
                    nm = c
            if cert or nm:
                rows.append((nm, cert))
    wb.close()
    return rows


def rows_from_xls(data):
    import xlrd
    wb = xlrd.open_workbook(file_contents=data)
    rows = []
    for sh in wb.sheets():
        for i in range(sh.nrows):
            cells = [norm_name(str(sh.cell_value(i, j))) for j in range(sh.ncols) if str(sh.cell_value(i, j)).strip()]
            if not cells:
                continue
            cert, nm = "", ""
            for c in cells:
                if CERT_RE.search(c):
                    cert = norm_cert(c)
                elif looks_name(c) and not nm:
                    nm = c
            if cert or nm:
                rows.append((nm, cert))
    return rows


def rows_from_docx(data):
    import docx
    d = docx.Document(io.BytesIO(data))
    rows = []
    for t in d.tables:
        for row in t.rows:
            cells = [norm_name(c.text) for c in row.cells if norm_name(c.text)]
            cert, nm = "", ""
            for c in cells:
                if CERT_RE.search(c):
                    cert = norm_cert(c)
                elif looks_name(c) and not nm:
                    nm = c
            if cert or nm:
                rows.append((nm, cert))
    if not rows:
        rows = rows_from_text("\n".join(p.text for p in d.paragraphs))
    return rows


def parse_doc(url, data):
    low = url.lower().split("?")[0]
    try:
        if low.endswith(".pdf") or data[:4] == b"%PDF":
            return rows_from_pdf(data)
        if low.endswith(".xlsx") or (data[:2] == b"PK" and b"xl/" in data[:4000]):
            return rows_from_xlsx(data)
        if low.endswith(".xls") or low.endswith(".et"):
            return rows_from_xls(data)
        if low.endswith(".docx") or (data[:2] == b"PK" and b"word/" in data[:4000]):
            return rows_from_docx(data)
        if low.endswith(".doc"):
            return rows_from_text(H.text_of_doc(data))
    except Exception as e:
        return [("##ERR", "%s:%s" % (type(e).__name__, str(e)[:60]))]
    return []


def save_raw(tag, url, data):
    return H.save_raw(tag, url, data)


def append_part(city, rows, src, year="", batch=""):
    """rows: [(name, cert)]  -> parts/山东省_<city>.jsonl 追加（去重）"""
    p = os.path.join(PARTS, "山东省_%s.jsonl" % city)
    seen = set()
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            try:
                o = json.loads(line)
                seen.add(o.get("cert") or ("N:" + o.get("name", "")))
            except Exception:
                pass
    n = 0
    with open(p, "a", encoding="utf-8") as f:
        for nm, ct in rows:
            if not ct and not nm:
                continue
            k = ct or ("N:" + nm)
            if k in seen:
                continue
            seen.add(k)
            f.write(json.dumps({"cert": ct, "name": nm, "city": city, "county": "",
                                "src": src, "year": year, "batch": batch}, ensure_ascii=False) + "\n")
            n += 1
    return n
