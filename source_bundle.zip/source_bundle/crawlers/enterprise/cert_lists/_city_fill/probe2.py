# -*- coding: utf-8 -*-
"""Probe 2: enumerate province 通知 lists + inspect Hubei 查询 portal for a city-bearing API."""
import os, re, sys, json, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

OUT = os.path.join(cf.HERE, "_probe2.json")
res = {}


def links(html, base):
    s = cf.soup_of(html)
    out = []
    for a in s.find_all("a", href=True):
        t = a.get_text(" ", strip=True)
        if not t or len(t) < 6:
            continue
        out.append((t, urllib.parse.urljoin(base, a["href"])))
    return out


# 1) Hunan 高企专栏 list pages
hn = []
for i in range(0, 4):
    u = ("http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/index.html" if i == 0
         else "http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/index_%d.html" % i)
    html, final = cf.get(u)
    if not html:
        hn.append({"url": u, "err": final})
        continue
    ls = [(t, x) for t, x in links(html, final) if "高新技术企业" in t or "名单" in t or "公告" in t or "公示" in t]
    hn.append({"url": u, "n": len(ls), "items": ls[:60]})
res["hn_col"] = hn

# 2) Hubei 通知公告 list pages (find 高新技术企业 titles)
hb = []
for i in range(0, 3):
    u = ("https://kjt.hubei.gov.cn/kjdt/tzgg/" if i == 0
         else "https://kjt.hubei.gov.cn/kjdt/tzgg/index_%d.shtml" % i)
    html, final = cf.get(u)
    if not html:
        hb.append({"url": u, "err": final})
        continue
    ls = [(t, x) for t, x in links(html, final) if "高新技术企业" in t]
    hb.append({"url": u, "n": len(ls), "items": ls[:40]})
res["hb_tzgg"] = hb

# 3) Hubei query portal
portal = "https://kjt.hubei.gov.cn/ywt/"
html, final = cf.get(portal)
item = {"url": portal, "final": final if isinstance(final, str) else "", "ok": bool(html)}
if html:
    js = re.findall(r"""(?:src|href)=["']([^"']+\.js)["']""", html)
    item["js"] = [urllib.parse.urljoin(portal, j) for j in js][:20]
    item["len"] = len(html)
    item["head"] = html[:1500]
res["hb_portal"] = item

json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("wrote", OUT)
for k, v in res.items():
    if isinstance(v, list):
        for e in v:
            print(k, e.get("url"), "err=%s" % e.get("err") if e.get("err") else "n=%d" % e.get("n", 0))
    else:
        print(k, v.get("final"), "ok=", v.get("ok"), "js=", len(v.get("js") or []))
