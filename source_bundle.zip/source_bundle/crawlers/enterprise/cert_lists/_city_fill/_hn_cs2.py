﻿# -*- coding: utf-8 -*-
import os,sys,re,urllib.parse
sys.path.insert(0,os.getcwd())
import cf
h,fin=cf.get("http://kjj.changsha.gov.cn/")
print(fin,len(h) if h else None)
if h:
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',h,re.S|re.I):
        u=urllib.parse.urljoin(fin,m.group(1)); t=re.sub(r"<[^>]+>","",m.group(2)); t=re.sub(r"\s+","",t).strip()
        if not t: continue
        if re.search(r"通知|公告|公示|高新|科技|政策|政务",t):
            print("  ",t[:24],"|",u[:95])
