# -*- coding: utf-8 -*-
"""Harvest Jiangxi gov CMS column via POST /queryList, large page size."""
import os, sys, re, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import requests, cf
requests.packages.urllib3.disable_warnings()

UA = getattr(cf, "UA", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
FILL = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(FILL, "_jx_all_articles.json")
LOG = os.path.join(FILL, "_jx_harvest.log")


def log(msg):
    line = time.strftime("%H:%M:%S ") + str(msg)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line, flush=True)


def harvest(channel="col27029", unitid="466678", site="jxskxjst", per=200):
    s = requests.Session()
    s.headers.update({"User-Agent": UA,
                      "Referer": "http://kjt.jiangxi.gov.cn/%s/col/%s/index.html" % (site, channel),
                      "X-Requested-With": "XMLHttpRequest"})
    base = {"unitid": unitid, "webSiteCode": site, "channelCode": channel,
            "perPage": str(per), "pageSize": str(per), "showMode": "full",
            "groupSize": "1", "titleMax": "120", "sort": "pubDate", "order": "desc"}
    out, seen = [], set()
    page, total = 1, None
    while True:
        t0 = time.time()
        try:
            r = s.post("http://kjt.jiangxi.gov.cn/queryList",
                       data=dict(base, current=str(page), page=str(page)),
                       timeout=120, verify=False)
            j = r.json()
        except Exception as e:
            log("page %d ERR %s" % (page, e))
            break
        data = j.get("data") or {}
        total = data.get("total", total)
        res = data.get("results") or []
        log("page %d got %d in %.1fs (total %s)" % (page, len(res), time.time() - t0, total))
        if not res:
            break
        for it in res:
            src = it.get("source") or {}
            urls = src.get("urls")
            try:
                u = json.loads(urls).get("pc") if urls else None
            except Exception:
                u = None
            key = it.get("id") or u
            if key in seen:
                continue
            seen.add(key)
            out.append({"title": src.get("title"), "pubDate": src.get("pubDate"),
                        "url": u, "id": it.get("id")})
        if total and len(out) >= total:
            break
        page += 1
        if page > 60:
            break
        time.sleep(0.3)
    return out, total


if __name__ == "__main__":
    open(LOG, "w", encoding="utf-8").close()
    ch = sys.argv[1] if len(sys.argv) > 1 else "col27029"
    uid = sys.argv[2] if len(sys.argv) > 2 else "466678"
    t0 = time.time()
    arts, total = harvest(ch, uid)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(arts, f, ensure_ascii=False, indent=1)
    log("DONE total %s collected %d in %.1fs" % (total, len(arts), time.time() - t0))
    gq = [a for a in arts if a["title"] and re.search(r"高新技术企业|高企", a["title"])]
    log("高企 articles: %d" % len(gq))
    for a in gq:
        log("   %s  %s  %s" % (a["pubDate"], a["title"][:64], a["url"]))
    if arts:
        log("date range %s -> %s" % (arts[0]["pubDate"], arts[-1]["pubDate"]))
