# -*- coding: utf-8 -*-
"""Assemble 陕西省_city.csv / 山西省_city.csv from parts + existing fills."""
import csv, json, os, re, collections

BASE = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists'
CF = os.path.join(BASE, '_city_fill')
RAW = os.path.join(CF, 'raw')

xz = json.load(open(os.path.join(RAW, '_xzqh2023.json'), encoding='utf-8'))
if isinstance(xz, list):
    xz = {str(k): v for k, v in xz}
CITY = {k: v for k, v in xz.items() if k.endswith('00') and len(k) == 6}
COUNTY = {k: v for k, v in xz.items() if not k.endswith('00')}
PROV = {k[:2]: v for k, v in CITY.items() if k.endswith('0000')}
BAD_CITY = {'陕西省', '山西省', '海南省', '甘肃省', '江苏省', '黑龙江省', '广西壮族自治区',
            '山西省转型综改示范区', '山西转型综改示范区'}
CITY_ALIAS = {'长治高新区': '长治市'}


def norm(n):
    n = (n or '').strip()
    n = n.replace('（', '(').replace('）', ')').replace('　', '')
    n = re.sub(r'\s+', '', n)
    return n.replace('·', '').replace('‧', '')


def from_code(code, prov2):
    code = re.sub(r'[^0-9A-Za-z]', '', code or '').upper()
    if len(code) != 18:
        return '', ''
    d6 = code[2:8]
    if not d6.startswith(prov2):
        return '', ''
    city = CITY.get(d6[:4] + '00', '')
    if city in BAD_CITY or city.endswith('省') or city.endswith('自治区'):
        city = ''
    county = COUNTY.get(d6, '')
    return city, county


def clean_city(c):
    c = (c or '').strip()
    c = CITY_ALIAS.get(c, c)
    if c in BAD_CITY or c.endswith('省') or c.endswith('自治区'):
        return ''
    return c


sx = {}
src_sx = os.path.join(RAW, '_sx_gongshi_codes.json')
if os.path.exists(src_sx):
    for r in json.load(open(src_sx, encoding='utf-8')):
        nm = norm(r.get('name'))
        c, co = from_code(r.get('code'), '61')
        if nm and c and nm not in sx:
            sx[nm] = (c, co, r.get('src', ''))

shx = {}
pf = os.path.join(CF, 'parts', '山西省_补助2024.jsonl')
if os.path.exists(pf):
    for line in open(pf, encoding='utf-8'):
        line = line.strip()
        if not line:
            continue
        try:
            r = json.loads(line)
        except Exception:
            continue
        nm = norm(r.get('name'))
        c = clean_city(r.get('city'))
        co = (r.get('county') or '').strip()
        if nm and c and nm not in shx:
            shx[nm] = (c, co, r.get('src', ''))

HDR = ['企业名称', '证书编号', '城市', '区县', '认定年度', '批次', '来源URL']
for prov, lk in (('陕西省', sx), ('山西省', shx)):
    rows = list(csv.DictReader(open(os.path.join(BASE, prov + '.csv'), encoding='utf-8-sig', newline='')))
    filled = kept = newf = 0
    bycity = collections.Counter()
    out = []
    for r in rows:
        city = clean_city(r['城市'])
        county = (r['区县'] or '').strip()
        srcurl = (r['来源URL'] or '').strip()
        if city:
            kept += 1
        else:
            county = ''
            hit = lk.get(norm(r['企业名称']))
            if hit:
                city, county = hit[0], hit[1]
                srcurl = hit[2] or srcurl
                newf += 1
        if city:
            filled += 1
            bycity[city] += 1
        out.append([r['企业名称'], r['证书编号'], city, county, r['认定年度'], r['批次'], srcurl])
    dst = os.path.join(CF, prov + '_city.csv')
    with open(dst, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(HDR)
        w.writerows(out)
    print(f'{prov}: rows={len(out)} city={filled} kept={kept} new={newf} lookup={len(lk)} county={sum(1 for x in out if x[3])}')
    print('   ', bycity.most_common(20))
