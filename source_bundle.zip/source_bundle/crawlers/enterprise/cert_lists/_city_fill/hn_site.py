﻿# -*- coding: utf-8 -*-
"""Generic: find article links matching 高新技术企业 on a site, then parse lists."""
import os,sys,re,json,urllib.parse
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,HERE); sys.path.insert(0,os.path.dirname(HERE))
import cf, fetch_common as F

def links(h,base):
    out=[]
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',h,re.S|re.I):
        u=urllib.parse.urljoin(base,m.group(1)); t=re.sub(r"<[^>]+>","",m.group(2)); t=re.sub(r"\s+"," ",t).strip()
        out.append((t,u))
    return out

def probe(base,city,cols=(),maxlist=6):
    h,fin=cf.get(base)
    if not h:
        print("HOME FAIL",base); return []
    home=links(h,fin)
    cand=set()
    for t,u in home:
        if any(k in t for k in ("通知公告","公示公告","政务公开","通知公告栏","公告公示","科技动态","政务信息")):
            cand.add(u)
        if re.search(r"/(tzgg|gsgg|gggs|zwgk|tzgg_1|notice)/?$",u): cand.add(u)
    cand=list(cand)[:12]
    arts={}
    for c in cand:
        for p in ("", "index_1.html","index.html"):
            u=c.rstrip("/")+("/"+p if p and not c.endswith(".html") else "")
            hh,f2=cf.get(u)
            if not hh: continue
            for t,uu in links(hh,f2):
                if re.search(r"高新技术企业|高企",t) and re.search(r"名单|公示|公布|认定|备案|证书|推荐",t):
                    arts[uu]=t
            break
    print(city,"home cols",len(cand),"arts",len(arts),flush=True)
    return list(arts.items())
if __name__=="__main__":
    b=sys.argv[1]; c=sys.argv[2]
    r=probe(b,c)
    for t,u in r[:25]: print("  ",t[:60],"|",u[:110])
