# -*- coding: utf-8 -*-
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

h, f = cf.get("https://searching.hunan.gov.cn/hunan/all/news?q=%E9%AB%98%E6%96%B0%E6%8A%80%E6%9C%AF%E4%BC%81%E4%B8%9A")
print("len", len(h))
pats = [r"url\s*[:=]\s*['\"]([^'\"]{5,120})",
        r"['\"](/[A-Za-z0-9_/.\-]*[Ss]earch[A-Za-z0-9_/.\-]*)['\"]",
        r"(searchService|getSearchList|/search/\w+|\.do\b|jsonp)"]
for p in pats:
    s = set(re.findall(p, h))
    print(p, "->", list(s)[:14])
i = h.find("ajax")
print("ctx", h[max(0, i - 300):i + 500] if i > 0 else "no ajax")
