# -*- coding: utf-8 -*-
"""Full dump of one page's attachments: all sheets, header rows, first data rows."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from fc_probe1 import doc_head


def full_dump(path, maxrows=6):
    ext = os.path.splitext(path)[1].lower()
    print("   file:", os.path.basename(path), ext, os.path.getsize(path))
    if ext in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
        for ws in wb.worksheets:
            print("    [sheet %s %s]" % (ws.title, ws.calculate_dimension()))
            n = 0
            for row in ws.iter_rows(values_only=True):
                vals = ["" if v is None else str(v).replace("\n", " ") for v in row]
                if not any(vals):
                    continue
                print("      ", " | ".join(vals)[:300])
                n += 1
                if n >= maxrows:
                    break
    elif ext == ".xls":
        import xlrd
        wb = xlrd.open_workbook(path)
        for sh in wb.sheets():
            print("    [xls %s rows=%d cols=%d]" % (sh.name, sh.nrows, sh.ncols))
            for r in range(min(maxrows, sh.nrows)):
                print("      ", " | ".join(str(sh.cell_value(r, c)) for c in range(sh.ncols))[:300])
    elif ext == ".pdf":
        import pymupdf
        d = pymupdf.open(path)
        print("    [pdf pages %d]" % d.page_count)
        for pno in range(min(2, d.page_count)):
            t = d[pno].get_text("text")
            for ln in [x for x in t.splitlines() if x.strip()][:14]:
                print("      ", ln[:200])
    elif ext in (".docx",):
        import docx
        d = docx.Document(path)
        for tb in d.tables:
            print("    [docx table %dx%d]" % (len(tb.rows), len(tb.columns)))
            for r in tb.rows[:maxrows]:
                print("      ", " | ".join(c.text.strip() for c in r.cells)[:300])
    else:
        print("    (skip ext)")


def probe(url):
    print("=" * 78)
    print(url)
    html, final = cf.get(url)
    if not html:
        print("  FAIL")
        return
    for text, u in cf.attachments(url, html):
        print("  att:", text[:70])
        p = cf.download(u, "probe")
        if p:
            full_dump(p)


if __name__ == "__main__":
    for u in sys.argv[1:]:
        probe(u)
