# -*- coding: utf-8 -*-
import io, sys, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

# 1) inspect the 2024 PDF structure
u = 'https://oss.henan.gov.cn/typtfile/20241017/d837ccceac4249069d1fb91da82fbd27.pdf'
st, data, fu = H.get(u, timeout=30, binary=True)
print('PDF', st, len(data), fu)
if st == 200:
    t = H.doc_text(u, data)
    open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_hn2024p1.txt'), 'w', encoding='utf-8').write(t)
    print('chars', len(t))
    print(t[:1800].replace('\n', ' | '))
    print('...')
    print(t[-600:].replace('\n', ' | '))
