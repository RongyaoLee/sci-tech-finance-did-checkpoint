# -*- coding: utf-8 -*-
"""Dump tail of Jiangxi column page + brute-force pagination patterns."""
import os, sys, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

URL = "http://kjt.jiangxi.gov.cn/jxskxjst/col/col27029/index.html"
h, f = cf.get(URL)
print("=== tail from 9500 ===")
print(h[9500:])
