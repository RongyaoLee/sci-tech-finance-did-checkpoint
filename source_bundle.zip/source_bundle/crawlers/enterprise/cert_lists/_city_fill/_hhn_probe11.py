# -*- coding: utf-8 -*-
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

pages = [
    # henan 2023-12 page that produced 1400 city rows
    'http://www.innocom.gov.cn/gqrdw/c101462/202312/cee1e11326b94389b2640c4468609759.shtml',
    # hebei pages that produced city rows
    'http://www.innocom.gov.cn/gqrdw/c101445/202012/d26ba6ce104346f1b30dd9f5bff25ac6.shtml',
    'http://www.innocom.gov.cn/gqrdw/c101445/201712/d549feefb8e74a3dba1e9b2cad47b0f7.shtml',
]
for u in pages:
    st, txt, fu = H.get(u, timeout=30)
    print('==', u.split('/')[-2:], st, len(txt or ''))
    if st != 200:
        continue
    t = re.search(r'<title>(.*?)</title>', txt, re.S)
    print('  title:', re.sub(r'\s+', ' ', t.group(1)).strip()[:90] if t else '')
    links = H.img_links(txt, fu)
    docs = H.doc_links(links, fu)
    print('  docs', len(docs))
    for d, tt in docs[:3]:
        st2, data, fu2 = H.get(d, timeout=60, binary=True)
        print('   doc', tt[:50], st2, len(data))
        if st2 == 200:
            dt = H.doc_text(d, data)
            head = re.sub(r'\s+', ' ', dt[:400])
            print('     kw:', [k for k in ['所属地市', '所在地域', '地市', '所在地区', '所属地区', '地区', '区县', '县（市、区）'] if k in dt[:3000]])
            print('     head:', head[:300])
