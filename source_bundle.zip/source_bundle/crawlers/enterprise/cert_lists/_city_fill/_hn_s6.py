﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
import cf
r=cf.S.get("http://searching.hunan.gov.cn/hunan/city/data",params={"pid":0},timeout=30)
print(r.status_code, len(r.text))
print(r.text[:1500])
