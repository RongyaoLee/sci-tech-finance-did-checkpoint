# -*- coding: utf-8 -*-
import io, sys, os, re, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from urllib.parse import quote

def search(kw, page=1, size=50, site='4500000004'):
    u = ('https://searchapi.henan.gov.cn/open/api/external-new?keywords=%s&siteId=%s'
         '&searchRange=-1000&sortType=150&pageNumber=%d&pageSize=%d' % (quote(kw), site, page, size))
    st, txt, fu = H.get(u, timeout=30)
    return st, txt

st, txt = search('高新技术企业名单')
print('status', st, 'len', len(txt or ''))
try:
    j = json.loads(txt)
except Exception as e:
    print('json fail', e); print((txt or '')[:800]); raise SystemExit
def walk(o, path=''):
    if isinstance(o, dict):
        for k, v in o.items():
            if isinstance(v, (dict, list)):
                walk(v, path + '/' + k)
            else:
                pass
    elif isinstance(o, list):
        print(path, 'list len', len(o))
        if o and isinstance(o[0], dict):
            print('  keys:', list(o[0].keys()))
            for it in o[:3]:
                print('   ', {k: (str(it.get(k))[:70]) for k in list(it.keys())[:9]})
print('top keys', list(j.keys()))
walk(j)
print('sample json head:', json.dumps(j, ensure_ascii=False)[:600])
