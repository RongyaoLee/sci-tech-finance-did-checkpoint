# -*- coding: utf-8 -*-
"""唐山科技局：网站地图 + 通知公告栏目，找高企名单。"""
import io, sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
st, txt, fu = H.get('https://kejiju.tangshan.gov.cn/tangshankjj/kjj_wangzhanditu/index.html', timeout=30)
print('map', st, len(txt or ''))
if st == 200:
    for href, lab in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', txt, re.S):
        lab = re.sub(r'\s+', '', re.sub(r'<[^>]+>', '', lab))
        if lab and len(lab) <= 20 and any(k in lab for k in ('通知', '公告', '公示', '高新', '动态', '政策', '文件')):
            print('  %-16s %s' % (lab, href[:90]))
