# -*- coding: utf-8 -*-
"""把 parts/*.jsonl 汇总成 补丁 CSV（只含拿到城市的行）。

用法：
    python assemble.py            # 只统计
    python assemble.py --write    # 写出 _city_fill\浙江省_城市.csv / 山东省_城市.csv

匹配规则（严格，不伪造）：
  1. cert 命中主表证书编号 → 取主表的企业名称/认定年度/批次
  2. cert 为空但 name 命中主表且该名称在省内唯一 → 取该行
  3. 名称重复或找不到 → 跳过并计入 unmatched
城市/区县取自 jsonl；主表中该行城市已非空则跳过（不覆盖已有值）。
"""
import csv
import glob
import io
import json
import os
import sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
CERT_LISTS = os.path.dirname(HERE)
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
PROVS = ["浙江省", "山东省"]


def load_parts():
    recs = defaultdict(list)  # prov -> list of dict
    for p in sorted(glob.glob(os.path.join(HERE, "parts", "*.jsonl"))):
        base = os.path.basename(p)
        prov = base.split("_")[0]
        if prov not in PROVS:
            continue
        n = 0
        with io.open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                if not r.get("city"):
                    continue
                r["_file"] = base
                recs[prov].append(r)
                n += 1
        print("  part %-40s %6d rows" % (base, n))
    return recs


def main():
    write = "--write" in sys.argv
    print("== load parts ==")
    parts = load_parts()

    summary = {}
    for prov in PROVS:
        main_path = os.path.join(CERT_LISTS, prov + ".csv")
        rows = list(csv.DictReader(io.open(main_path, encoding="utf-8-sig", newline="")))
        print("== %s 主表 %d 行 ==" % (prov, len(rows)))
        by_cert = {}
        by_name = defaultdict(list)
        for i, r in enumerate(rows):
            c = (r.get("证书编号") or "").strip()
            if c:
                by_cert.setdefault(c, i)
            nm = (r.get("企业名称") or "").strip()
            if nm:
                by_name[nm].append(i)

        patch = {}
        st = Counter()
        for rec in parts.get(prov, []):
            cert = (rec.get("cert") or "").strip().upper()
            name = (rec.get("name") or "").strip()
            idx = None
            if cert and cert in by_cert:
                idx = by_cert[cert]
                st["by_cert"] += 1
            elif name and len(by_name.get(name, [])) == 1:
                idx = by_name[name][0]
                st["by_name"] += 1
            else:
                st["unmatched"] += 1
                continue
            row = rows[idx]
            if (row.get("城市") or "").strip():
                st["already"] += 1
                continue
            city = rec.get("city", "").strip()
            county = (rec.get("county") or "").strip()
            if not city:
                st["noc"] += 1
                continue
            prev = patch.get(idx)
            if prev and prev["城市"] and prev["城市"] != city:
                st["conflict"] += 1
                continue
            patch[idx] = {
                "企业名称": row["企业名称"], "证书编号": row["证书编号"],
                "城市": city, "区县": county,
                "认定年度": row.get("认定年度", ""), "批次": row.get("批次", ""),
                "来源URL": rec.get("src", ""),
            }
        print("  stats:", dict(st))
        out_rows = [patch[k] for k in sorted(patch)]
        summary[prov] = out_rows
        cc = Counter(r["城市"] for r in out_rows)
        yr = sorted({r["认定年度"] for r in out_rows if r["认定年度"]})
        print("  补到 %d 行；城市 %d 个: %s" % (len(out_rows), len(cc), cc.most_common()))
        print("  覆盖认定年度 %s ~ %s (%d 个)" % (yr[0] if yr else "-", yr[-1] if yr else "-", len(yr)))
        print("  仍未拿到城市: %d 行" % (len(rows) - len([r for r in rows if (r.get('城市') or '').strip()]) - len(out_rows)))
        if write:
            outp = os.path.join(HERE, prov + "_城市.csv")
            with io.open(outp, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.DictWriter(f, fieldnames=HEADER)
                w.writeheader()
                for r in out_rows:
                    w.writerow(r)
            print("  -> %s" % outp)
    return summary


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
