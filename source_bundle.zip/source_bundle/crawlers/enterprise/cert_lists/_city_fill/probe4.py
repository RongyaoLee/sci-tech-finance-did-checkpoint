# -*- coding: utf-8 -*-
"""Probe 4: Hunan portal main.js API + Shaanxi 通知公告 list for 高企 notices."""
import os, re, sys, json, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

OUT = os.path.join(cf.HERE, "_probe4.json")
res = {}

# 1) Hunan portal main.js
u = "http://zwfw-new.hunan.gov.cn/hnzwfw/portal/MHWKx-KiTEOZT6Be4BUJF4/js/main.js"
t, f = cf.get(u)
res["hn_main"] = {"ok": bool(t), "len": len(t or "")}
if t:
    open(os.path.join(cf.HERE, "_hn_main.js"), "w", encoding="utf-8").write(t)
    res["hn_main"]["urls"] = sorted(set(re.findall(r"""["']([^"']*(?:action|api|json|query|list|search)[^"']{0,40})["']""", t, re.I)))[:40]
    res["hn_main"]["posts"] = [m.group(0)[:160] for m in re.finditer(r"\$\.(?:post|ajax|get)\([^)]{0,160}", t)][:20]

# 2) Shaanxi 通知公告 list pages
sx = []
for i in range(0, 3):
    uu = ("https://kjt.shaanxi.gov.cn/kjdt/tzgg/" if i == 0
          else "https://kjt.shaanxi.gov.cn/kjdt/tzgg/index_%d.html" % i)
    html, final = cf.get(uu)
    if not html:
        sx.append({"url": uu, "err": str(final)[:70]})
        continue
    s = cf.soup_of(html)
    items = []
    for a in s.find_all("a", href=True):
        tt = a.get_text(" ", strip=True)
        if tt and ("高新技术企业" in tt or "高企" in tt):
            items.append((tt[:80], urllib.parse.urljoin(final, a["href"])))
    sx.append({"url": uu, "n": len(items), "items": items[:30]})
res["sx_tzgg"] = sx

json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps(res, ensure_ascii=False, indent=1)[:4000])
