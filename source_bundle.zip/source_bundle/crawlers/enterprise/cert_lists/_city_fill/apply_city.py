# -*- coding: utf-8 -*-
"""把 `_city_fill\<省>_城市.csv` 补丁回填到 `cert_lists\<省>.csv`。

规则：
- 匹配键 = 企业名称 + 证书编号（两者都要对上；证书编号为空的行不允许参与匹配）
- 原值非空则保留原值（不覆盖别人已填的城市/区县）
- 回填前把主表备份为 `<省>.bak.csv`（已存在则保留最早那份，不覆盖）
- 另存同路径（原地更新）
- 只写拿到城市的行，绝不伪造

用法：
    python apply_city.py            # 预览（不改文件）
    python apply_city.py --apply    # 真正回填
"""
import csv
import io
import os
import shutil
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
CERT_LISTS = os.path.dirname(HERE)
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
def _default_provs():
    """所有已存在补丁文件、且主表存在的省份；可用命令行参数覆盖。"""
    named = [a for a in sys.argv[1:] if not a.startswith("-")]
    if named:
        return named
    out = []
    for fn in sorted(os.listdir(HERE)):
        if not fn.endswith("_城市.csv"):
            continue
        prov = fn[:-len("_城市.csv")]
        if os.path.exists(os.path.join(CERT_LISTS, prov + ".csv")):
            out.append(prov)
    return out


PROVS = _default_provs()


def read_csv(path):
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        rdr = csv.DictReader(f)
        fields = rdr.fieldnames
        rows = list(rdr)
    return fields, rows


def apply_one(prov, do_write):
    main_path = os.path.join(CERT_LISTS, prov + ".csv")
    patch_path = os.path.join(HERE, prov + "_城市.csv")
    if not os.path.exists(patch_path):
        print("[%s] 无补丁文件 %s，跳过" % (prov, patch_path))
        return None
    fields, main_rows = read_csv(main_path)
    if fields[:7] != HEADER:
        print("[%s] 警告：主表表头不是预期顺序: %s" % (prov, fields))
    pfields, patch_rows = read_csv(patch_path)

    # 索引：企业名称+证书编号 -> 主表行号
    key_index = {}
    for i, r in enumerate(main_rows):
        nm = (r.get("企业名称") or "").strip()
        cert = (r.get("证书编号") or "").strip()
        if nm and cert:
            key_index.setdefault((nm, cert), []).append(i)

    filled_city = filled_county = kept = miss = 0
    touched = set()
    city_counter = Counter()
    for pr in patch_rows:
        nm = (pr.get("企业名称") or "").strip()
        cert = (pr.get("证书编号") or "").strip()
        city = (pr.get("城市") or "").strip()
        county = (pr.get("区县") or "").strip()
        if not city:
            continue
        idxs = key_index.get((nm, cert))
        if not idxs:
            miss += 1
            continue
        for i in idxs:
            row = main_rows[i]
            changed = False
            if city and not (row.get("城市") or "").strip():
                row["城市"] = city
                filled_city += 1
                changed = True
            elif city and (row.get("城市") or "").strip():
                kept += 1
            if county and not (row.get("区县") or "").strip():
                row["区县"] = county
                filled_county += 1
                changed = True
            if changed:
                touched.add(i)
                city_counter[city] += 1

    print("[%s] 主表 %d 行 | 补丁 %d 行 | 命中并写入 %d 行（城市 %d / 区县 %d）| 原名已非空保留 %d | 补丁在表中找不到 %d"
          % (prov, len(main_rows), len(patch_rows), len(touched), filled_city, filled_county, kept, miss))
    print("        城市分布: %s" % city_counter.most_common())

    if do_write and touched:
        bak = os.path.join(CERT_LISTS, prov + ".bak.csv")
        if not os.path.exists(bak):
            shutil.copy2(main_path, bak)
            print("        备份 -> %s" % bak)
        else:
            print("        备份已存在，保留原备份: %s" % bak)
        tmp = main_path + ".tmp"
        with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for r in main_rows:
                w.writerow(r)
        os.replace(tmp, main_path)
        print("        已回填 -> %s" % main_path)
    return len(touched)


def main():
    do_write = "--apply" in sys.argv
    total = 0
    for prov in PROVS:
        n = apply_one(prov, do_write)
        if n:
            total += n
    if not do_write:
        print("\n预览模式，未修改任何文件。加 --apply 执行回填。")
    else:
        print("\n合计写入 %d 行。" % total)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
