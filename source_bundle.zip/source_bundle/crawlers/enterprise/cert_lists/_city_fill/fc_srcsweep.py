# -*- coding: utf-8 -*-
"""Sweep every 来源URL of the two provinces: download its attachments, extract text,
and report whether the doc carries a city column (表头关键词) or 区县 column."""
import os, sys, re, json, csv, io, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
import pymupdf

WORK = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_fc_srcsweep.json")

CITY_HDR = ["所在市州", "所在设区市", "设区市", "地市", "所属市", "所在市", "市州", "所在地区", "所属地区", "地区"]
CNTY_HDR = ["区县", "所在县", "所属县", "县市区", "县（市、区）", "所在区"]


def pdf_text(path):
    doc = pymupdf.open(path)
    parts = []
    for i in range(doc.page_count):
        parts.append(doc[i].get_text("text"))
    doc.close()
    return "\n".join(parts)


def doc_text(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        return pdf_text(path)
    if ext in (".xlsx",):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        out = []
        for ws in wb.worksheets:
            for r in ws.iter_rows(values_only=True):
                out.append(" | ".join("" if c is None else str(c) for c in r))
        wb.close()
        return "\n".join(out)
    if ext in (".xls",):
        import xlrd
        bk = xlrd.open_workbook(path)
        out = []
        for sh in bk.sheets():
            for i in range(sh.nrows):
                out.append(" | ".join(str(sh.cell_value(i, j)) for j in range(sh.ncols)))
        return "\n".join(out)
    if ext in (".docx",):
        import docx
        d = docx.Document(path)
        return "\n".join(p.text for p in d.paragraphs) + "\n" + "\n".join(
            " | ".join(c.text for c in row.cells) for t in d.tables for row in t.rows)
    return ""


def main():
    res = {}
    for prov in ("湖南省", "江西省"):
        rows = list(csv.DictReader(io.StringIO(
            open(os.path.join(WORK, prov + ".csv"), encoding="utf-8-sig").read())))
        cnt = collections.Counter(r["来源URL"] for r in rows)
        for url, n in cnt.most_common():
            tag = prov[0] + prov[1] + "_" + re.sub(r"\W", "", url.split("/")[-1])[:24]
            rec = {"prov": prov, "url": url, "rows": n, "atts": [], "city_hdr": [],
                   "cnty_hdr": [], "err": ""}
            html, final = cf.get(url)
            if not html:
                rec["err"] = "page %s" % final
                res[url] = rec
                print("[PAGEFAIL] %s %s" % (url, final))
                continue
            atts = cf.attachments(final or url, html)
            if not atts:
                rec["err"] = "no-att"
            hit = 0
            for t, u in atts:
                p = cf.download(u, tag)
                if not p:
                    rec["atts"].append({"url": u, "text": "", "size": 0, "err": "dl"})
                    continue
                try:
                    txt = doc_text(p)
                except Exception as e:
                    txt = ""
                    rec["err"] += "parse:%s;" % e
                ch = [k for k in CITY_HDR if k in txt[:4000]]
                nh = [k for k in CNTY_HDR if k in txt[:4000]]
                rec["atts"].append({"url": u, "text": txt, "size": os.path.getsize(p)})
                if ch:
                    rec["city_hdr"] += ch
                    hit += 1
                if nh:
                    rec["cnty_hdr"] += nh
            print("[%s] %-6d atts=%d city_hdr=%s cnty=%s %s"
                  % (prov, n, len(atts), sorted(set(rec["city_hdr"])), sorted(set(rec["cnty_hdr"])), url))
            res[url] = rec
    # keep only text of hits to keep the file small
    slim = {}
    for u, r in res.items():
        slim[u] = {k: r[k] for k in ("prov", "url", "rows", "city_hdr", "cnty_hdr", "err")}
        slim[u]["atts"] = [{"url": a["url"], "size": a["size"]} for a in r["atts"]]
        if r["city_hdr"]:
            slim[u]["text_head"] = (r["atts"][0]["text"] or "")[:3000] if r["atts"] else ""
    json.dump(slim, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("saved", OUT)


if __name__ == "__main__":
    main()
