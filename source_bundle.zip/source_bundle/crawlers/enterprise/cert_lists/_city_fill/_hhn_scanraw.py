# -*- coding: utf-8 -*-
import io, sys, os, re, glob
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work'
dirs = [os.path.join(BASE, '_raw', '河北'), os.path.join(BASE, '_raw', '河南')]
KW = ['所属地市', '所在地域', '地市', '所在地区', '所属地区', '地区', '区县', '县区', '所在地']
for d in dirs:
    print('===', d, os.path.isdir(d))
    files = sorted(glob.glob(os.path.join(d, '*')))
    print(' files', len(files))
    for p in files:
        ext = os.path.splitext(p)[1].lower()
        try:
            data = open(p, 'rb').read()
        except Exception as e:
            print('  ERR', p, e); continue
        t = H.doc_text(p, data)
        if not t or t.startswith('##ERR'):
            print('  --', os.path.basename(p), 'NO TEXT', t[:40]); continue
        nc = len(H.certs_in_text(t))
        head = re.sub(r'\s+', ' ', t[:260])
        hits = [k for k in KW if k in t[:3000]]
        print('  %-52s chars=%-7d certs=%-5d kw=%s' % (os.path.basename(p)[:52], len(t), nc, ','.join(hits)))
        print('      head:', head[:200])
