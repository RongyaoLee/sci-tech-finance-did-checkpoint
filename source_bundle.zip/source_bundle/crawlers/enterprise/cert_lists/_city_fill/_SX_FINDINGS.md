# 陕西省 高企「企业→地级市」采集 结题报告（子智能体）

产出文件：`rows_陕西.jsonl` — **0 条**（原因见下，全部为实测结论，无一条靠猜）
进度日志：`_progress_陕西.log`

## 一、结论（一句话）
陕西省**不存在**公开的、含企业名称且带地市归属的高企名单：
省级只发「序号+企业名称+证书编号」，市级科技局只发申报/培育/统计通知，西安高新区通知公告频道只剩 2026-08 以后的内容。要拿地市列，只能走**高新区管委会「领取高企证书」通知的 xlsx 附件**，而该附件的发现必须依赖**可用的外部搜索引擎**（本机 Bing/DDG 均不可用，见下）。

## 二、已实测并排除的路线（别再重走）

| 路线 | 实测结果 |
|---|---|
| 省科技厅 `https://kjt.shaanxi.gov.cn/` 站内搜索 | TRS JS 渲染，服务端返回「0 条结果」 |
| `https://kjt.shaanxi.gov.cn/zwfw/jg/jgcx/` 结果查询 | 唯一外链是 innocom 国家站，无地市 |
| `http://ywgl.sstrc.com` 科技业务系统 | 493 字节空壳，需登录 |
| `_raw\陕西\` 73 个 PDF/DOC | 实测 2 列（企业名称/证书编号），**顺序随机不按地市分组**（2023第一批：西安…安康…杨凌…铜川交错）。已用 pymupdf 验证多份 |
| 省厅「关于公布陕西省2022年第一、二批高新技术企业名单的通知」附件 .doc | 466 行 × 2 列，无地市 |
| 省厅「关于领取20XX年高企证书…通知」附件 | 只有《领取证书联系方式及领取地址》，无企业名单 |
| 宝鸡/渭南/延安/榆林/安康/咸阳 科技局「通知公告」全量翻页（75/207/203/355/27/175 条） | 命中「高新技术企业」的 100% 是申报通知、培育库入库、火炬统计、中介机构登记，**无一份名单** |
| 西安高新区 `http://xdz.xa.gov.cn/xwzx/tzgg/{n}.html`（120 页） | 仅 203 条，日期 2026-08-03~2026-11-13，无「证书/高企名单」标题 |
| 西安高新区 `http://xdz.xa.gov.cn/gxgk/tzgx/1.html` | 16 条政策文件，无分页（2.html/5.html 均 404） |
| so-gov 网站群搜索 `https://api.so-gov.cn/query/s?siteCode=6101000007&...` | HTTP 200 但响应体为空（需 POST/鉴权），未打通 |
| Bing `https://cn.bing.com/search` | 只回站点首页级结果，`<h2><a href=` 抓不到真实条目 |
| DuckDuckGo `https://html.duckduckgo.com/html/?q=` | 全部 ConnectTimeout |
| `web_search` 工具 | 60s 超时 |
| 咸阳市科技局 2024-10-18《咸阳29家企业成功认定！》 | 是**瞪羚企业**不是高企，且正文无企业名（名单在图片里） |
| 榆林市科技局 2019-10-28《我市18家企业进入…公示名单》 | 正文只点名 3 家（陕西大章测绘、陕西广济堂医药集团、陕西北元化工集团），非完整名单，已放弃未落盘 |

## 三、可用资产（父 agent 可直接复用）

1. **省厅通知公告全量索引 1000 条**：`_city_fill\_sx_kjt_tzgg.json`
   - 抓取方式：`https://kjt.shaanxi.gov.cn/kjdt/tzgg/index.html`、`index_{0..66}.html`，每页 15 条，共 1000 条，覆盖 **2021-12 → 2026-11**（page 67 起 404）。
   - 已筛出所有含「高企+名单/证书/公示/公告」的条目 URL（可直接用来批量下附件）。
2. `_city_fill\cf.py`（带 0.5s 限速+缓存的抓取器）、`fetch_common.py`（pdf/doc/docx/xlsx 解析）。
3. `_city_fill\sx_kjt_crawl.py`（省厅索引爬虫）、`sx_city_crawl.py`（市级栏目爬虫，可用 `items_of` 直接复用）、`sx_harvest.py`（页面企业名正则抽取 + 写 JSONL/进度）。
4. 站点可达性：可用 = www.xa.gov.cn、xdz.xa.gov.cn、kjj.baoji/xianyang/weinan/yanan/yl/ankang.gov.cn、www.hanzhong/shangluo/tongchuan/yangling.gov.cn；**不可用** = kjj.xa.gov.cn（DNS 失败）、kjj.hanzhong/shangluo/tongchuan/yangling.gov.cn、www.xagxq.gov.cn、www.bjgj.gov.cn。

## 四、建议的下一步（需要外部搜索能力）
1. 用可用搜索引擎检索：`西安高新区 关于领取2025年度高新技术企业证书的通知`（官网 xdz.xa.gov.cn 或 www.xa.gov.cn 下设高新区栏目），拿 xlsx 附件 → 全部 city=西安市。同法：宝鸡/咸阳/渭南/榆林/汉中/安康高新区 → 对应市；杨凌示范区自身即地级口径。
2. 西安高新区 xlsx 一张表通常 1000–3000 家，是陕西的唯一规模化入口。
3. 若能访问 `api.so-gov.cn/query/s` 的正确 POST 形态（参考 `p.so-gov.cn/web/api/query.js`），可用市政府站群搜索一次性定位全部「领取证书」通知。
