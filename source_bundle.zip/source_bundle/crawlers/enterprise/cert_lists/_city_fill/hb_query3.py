# -*- coding: utf-8 -*-
"""Full payload test against Hubei commonSearch."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

BASE = "https://kjt.hubei.gov.cn/ywt/services"
HDR = {"Content-Type": "application/json;charset=utf-8",
       "Referer": "https://kjt.hubei.gov.cn/ywt/",
       "Origin": "https://kjt.hubei.gov.cn"}

def post(path, body):
    r = cf.S.post(BASE + path, json=body, headers=HDR, timeout=30)
    return r.status_code, r.text

full = {"cpage": 1, "pageSize": 3, "flid": "008001", "name": "", "unit": "",
        "data_no": "", "unit_code": "", "jb": "", "nd": "", "year": ""}
code, txt = post("/portal/search/commonSearch", full)
print("full ->", code, txt[:1500])
print("=" * 60)

# try without flid, with jb only
for extra in ({"jb": "008001"}, {"flid": "008001", "jb": "1"}, {}):
    b = dict(full)
    b.update(extra)
    code, txt = post("/portal/search/commonSearch", b)
    print(extra, "->", code, txt[:300])
