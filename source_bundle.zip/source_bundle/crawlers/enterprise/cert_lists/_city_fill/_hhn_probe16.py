# -*- coding: utf-8 -*-
"""取 MOST 高企查询的验证码图片 + 用人工读出的 code 探测 API 行为。"""
import io, sys, os, json, random, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import requests

BASE = os.path.dirname(os.path.abspath(__file__))
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
S = requests.Session()
S.headers.update({'User-Agent': UA, 'Referer': 'https://fuwu.most.gov.cn/html/fwcx/gxjsqybacx/',
                  'X-Requested-With': 'XMLHttpRequest'})
st, txt, fu = 0, '', ''
r = S.get('https://fuwu.most.gov.cn/dataService/WebService.asmx/getValidCode',
          params={'appName': 'gxjs', 'random': random.random()}, timeout=30, verify=False)
print('captcha', r.status_code, r.headers.get('Content-Type'), len(r.content), 'cookies', dict(S.cookies))
open(os.path.join(BASE, '_cap_gx.png'), 'wb').write(r.content)
print('saved _cap_gx.png')
