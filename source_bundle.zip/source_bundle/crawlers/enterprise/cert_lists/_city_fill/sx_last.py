# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

print("### A. 省厅公布名单附件")
for u in ["https://kjt.shaanxi.gov.cn/kjdt/tzgg/202211/t20221114_3382439.html"]:
    h, f = cf.get(u, tries=1, timeout=25)
    print(u, len(h) if h else 0)
    if h:
        for a in cf.attachments(u, h):
            print("  ATT", a[0][:70], "|", a[1])

print("### B. 西安高新区 /gxgk/tzgx/ 归档")
for u in ["http://xdz.xa.gov.cn/gxgk/tzgx/1.html",
          "http://xdz.xa.gov.cn/gxgk/tzgx/2.html",
          "http://xdz.xa.gov.cn/gxgk/tzgx/5.html"]:
    h, f = cf.get(u, tries=1, timeout=20)
    if not h:
        print(u, "->", f); continue
    s = cf.soup_of(h)
    for t in s(["script", "style"]):
        t.decompose()
    txt = s.get_text("\n", strip=True)
    ds = re.findall(r"20\d{2}-\d{2}-\d{2}", txt)
    print(u, "len", len(h), "dates", (min(ds), max(ds)) if ds else None, "n", len(ds))
    for m in re.finditer(r"([^\n]{6,60}(?:高新技术企业|证书|名单)[^\n]{0,30})", txt):
        print("   T:", m.group(1)[:80])
