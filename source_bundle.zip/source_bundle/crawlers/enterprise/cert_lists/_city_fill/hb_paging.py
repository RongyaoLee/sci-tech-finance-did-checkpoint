# -*- coding: utf-8 -*-
"""Probe: does cpage have to be a QUERY param for the Hubei API paging to advance?"""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

BASE = "https://kjt.hubei.gov.cn/ywt/services/portal/search/commonSearch"
HDR = {"Content-Type": "application/json;charset=utf-8",
       "Referer": "https://kjt.hubei.gov.cn/ywt/",
       "Origin": "https://kjt.hubei.gov.cn"}


def call(params, body):
    r = cf.S.post(BASE, params=params, json=body, headers=HDR, timeout=30)
    return r.json()


body = {"pageSize": 50, "flid": "008001", "name": "", "unit": "", "data_no": "",
        "unit_code": "", "jb": "", "nd": "", "year": ""}
for mode in ("q", "both"):
    ids = []
    for p in (1, 2, 3):
        prm = {"flid": "008001"}
        b = dict(body)
        if mode == "q":
            prm["cpage"] = p
            prm["pageSize"] = 50
        else:
            prm["cpage"] = p
            b["cpage"] = p
        d = call(prm, b)
        rows = d.get("rows") or []
        ids.append((p, len(rows), (rows[0]["id"] if rows else None), (rows[-1]["id"] if rows else None)))
        print(mode, ids[-1], "total", d.get("total"))
    print("distinct first-ids:", len({x[2] for x in ids}))
    print("-" * 50)
