# -*- coding: utf-8 -*-
import json, collections, csv, io, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import city_common as cc

D = cc.FILL
api = collections.Counter(json.loads(l)["areaname"] for l in
                          open(os.path.join(D, "hubei_api_rows.jsonl"), encoding="utf-8"))
rows, _ = cc.read_prov("湖北省")
got = collections.Counter(r["城市"] for r in rows
                          if r["城市"] and r["认定年度"] in ("2023", "2024", "2025"))
print("%-14s %6s %8s" % ("city", "api", "csv23-25"))
for k in sorted(api, key=lambda x: -api[x]):
    print("%-14s %6d %8d" % (k, api[k], got[k]))
print("TOTALS", sum(api.values()), sum(got.values()))
