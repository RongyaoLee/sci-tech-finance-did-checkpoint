# -*- coding: utf-8 -*-
"""快速看若干栏目首页里有无「高新技术企业」相关条目。"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
from urllib.parse import urljoin

COLS = [
    ("贵州", "http://kjt.guizhou.gov.cn/xwzx/tzgg_73876/"),
    ("内蒙古", "https://kjt.nmg.gov.cn/slh/tzgg/"),
    ("黑龙江", "https://kjt.hlj.gov.cn/kjt/c113905/"),
    ("吉林", "https://kjt.jl.gov.cn/xwzx/tzgg/"),
    ("宁夏", "https://kjt.nx.gov.cn/tzgg/"),
    ("海南", "http://dost.hainan.gov.cn/xxgk/tzgg/"),
    ("甘肃", "https://kjt.gansu.gov.cn/kjt/c111529/"),
]
KW = ("高新技术企业", "高企")
for name, u in COLS:
    sc, d, f = S.H.get(u, timeout=20, tries=1, binary=True)
    n = len(d or b"")
    print("=" * 60)
    print(name, u, sc, n)
    if sc != 200 or not d:
        continue
    t = d.decode("utf-8", "ignore")
    if t.count("\ufffd") > 20:
        t = d.decode("gb18030", "ignore")
    hit = 0
    for a in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', t, re.S):
        txt = re.sub(r"<[^>]+>|\s", "", a.group(2))
        if len(txt) < 6:
            continue
        if any(k in txt for k in KW):
            hit += 1
            print("   ", txt[:78], "|", urljoin(f or u, a.group(1))[:100])
    print("   hits", hit)
