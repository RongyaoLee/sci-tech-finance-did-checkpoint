# -*- coding: utf-8 -*-
"""Peek at local downloaded PDFs: do they carry a 地市 column?"""
import os, re, sys, json
import pymupdf

RAW = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "_raw")

SAMPLES = [
    ("陕西", "对陕西省认定机构2024年认定报备的第一批高新技术企业进行备案的公告_bdf50a31a9.pdf"),
    ("陕西", "关于公示陕西省2019年第一批拟认定高新技术企业名单的通知_8d39ceba89.pdf"),
    ("湖北", "对湖北省认定机构2024年认定报备的第一批高新技术企业进行备案的公告_763b18d957.pdf"),
    ("湖南", "对湖南省认定机构2024年认定报备的第一批高新技术企业进行备案的公告_cd9e78655b.pdf"),
]

out = []
for prov, fn in SAMPLES:
    p = os.path.join(RAW, prov, fn)
    if not os.path.exists(p):
        out.append({"prov": prov, "file": fn, "err": "missing"})
        continue
    doc = pymupdf.open(p)
    txt = doc[0].get_text("text")
    out.append({"prov": prov, "file": fn, "pages": doc.page_count,
                "head": txt[:1200]})

print(json.dumps(out, ensure_ascii=False, indent=1))
