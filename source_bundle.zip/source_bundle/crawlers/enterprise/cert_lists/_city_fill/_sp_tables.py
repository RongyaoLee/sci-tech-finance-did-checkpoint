# -*- coding: utf-8 -*-
"""Dump HTML tables of a local file: index, ncols, first 5 rows."""
import sys, os, re
from lxml import html as LH

for path in sys.argv[1:]:
    doc = LH.parse(path).getroot()
    tables = doc.xpath("//table")
    print("=" * 70)
    print(path, "tables:", len(tables))
    for i, t in enumerate(tables):
        rows = t.xpath(".//tr")
        if len(rows) < 3:
            continue
        first = []
        for tr in rows[:4]:
            cells = [re.sub(r"\s+", " ", (c.text_content() or "")).strip() for c in tr.xpath("./td|./th")]
            first.append(" | ".join(cells)[:200])
        print(f"[{i}] rows={len(rows)}")
        for f in first:
            print("    ", f)
