# -*- coding: utf-8 -*-
import sys, os, json
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H
import fitz

CF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill"
log = json.load(open(os.path.join(CF, "_nb_log2.json"), encoding="utf-8"))
tgt = [l for l in log if "2020年高新技术企业补充备案的复函" in l.get("title", "")][0]
sc, data, f = H.get(tgt["url"], binary=True, timeout=60)
p = H.save_raw("nb_doc", tgt["url"], data)
print("file", p, len(data))
d = fitz.open(p)
print("pages", d.page_count)
for i in range(min(d.page_count, 3)):
    pg = d[i]
    imgs = pg.get_images(full=True)
    print("page", i, "rect", pg.rect, "imgs", [(x[2], x[3]) for x in imgs], "textlen", len(pg.get_text()))
    # 尝试渲染首页用于观察
    if i == 0:
        pix = pg.get_pixmap(dpi=150)
        out = os.path.join(CF, "_nb_p2020_p%d.png" % i)
        pix.save(out)
        print("render ->", out, pix.width, pix.height)
