# -*- coding: utf-8 -*-
"""合并 parts/*.jsonl -> 山东省_city.csv（只读主表，不修改）"""
import os, re, sys, csv, json, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_lib as S

BASE = S.BASE
WORK = os.path.dirname(os.path.dirname(BASE))          # ...\xie\work
SRC = os.path.join(WORK, "cert_lists", "山东省.csv")
OUT = os.path.join(BASE, "山东省_city.csv")
PARTS = S.PARTS

CITIES = {"济南","淄博","枣庄","东营","烟台","潍坊","济宁","泰安","威海","日照","临沂","德州","聊城","滨州","菏泽","青岛"}
CERT_OK = re.compile(r"^GR\d{12}$")
BAD_NAME = re.compile(r"^(序号|企业名称|单位名称|合计|小计|备注|注册|主营|技术|知识|人员|财务|附件|填报|说明)")
BAD_DIST = re.compile(r"(有限|公司|集团|研究院|研究所|实验|中心|大学|学院|事务所|协会|学会|厂|部)$|有限|公司|集团|研究所|实验室")


def ok_dist(d):
    """区县合法性：短、以 区/县/市/旗 结尾、且不是企业名/机构名"""
    d = (d or "").strip()
    if not d or len(d) > 12 or BAD_DIST.search(d):
        return ""
    if not re.search(r"[区县市旗]$", d):
        return ""
    return d


def load_parts():
    by_cert = {}
    by_name = collections.defaultdict(set)
    dirs = os.environ.get("SD_PART_DIRS")
    dirs = dirs.split(";") if dirs else [PARTS, os.path.join(BASE, "parts_new"), os.path.join(BASE, "parts_so")]
    bad_src = set()          # 表格错行的源（区县列里塞的是企业名）整份弃用
    for d in dirs:
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            if not fn.startswith("山东省_") or not fn.endswith(".jsonl"):
                continue
            objs = []
            for line in open(os.path.join(d, fn), encoding="utf-8"):
                try:
                    objs.append(json.loads(line))
                except Exception:
                    pass
            stat = collections.defaultdict(collections.Counter)
            for o in objs:
                c = (o.get("county") or "").strip()
                s0 = o.get("src") or ""
                if c:
                    stat[s0]["c"] += 1
                    if not ok_dist(c):
                        stat[s0]["bad"] += 1
            for o in objs:
                city = (o.get("city") or "").strip()
                county = ok_dist(o.get("county"))
                nm = S.norm_name(o.get("name") or "")
                ct = S.norm_cert(o.get("cert") or "")
                if city not in CITIES:
                    continue
                if len(nm) < 4 or BAD_NAME.match(nm):
                    continue
                src = o.get("src") or ""
                if src in bad_src:
                    continue
                if stat[src]["c"] >= 5 and stat[src]["bad"] / stat[src]["c"] > 0.3:
                    # 该文档区县列多为企业名 => 列错位，整份不可信
                    bad_src.add(src)
                    continue
                if ct and CERT_OK.match(ct):
                    by_cert.setdefault(ct, {}).setdefault(nm, (city, county))
                by_name[nm].add((city, county))
    return by_cert, by_name


def main():
    by_cert, by_name = load_parts()
    rows = list(csv.DictReader(open(SRC, encoding="utf-8-sig")))
    hdr = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
    n_city = n_county = n_keep = 0
    out = []
    for r in rows:
        nm = (r.get("企业名称") or "").strip()
        ct = (r.get("证书编号") or "").strip()
        city = (r.get("城市") or "").strip()
        county = (r.get("区县") or "").strip()
        if not city:
            nk = S.norm_name(nm)
            hit = by_cert.get(S.norm_cert(ct)) or {}
            # 证书号必须与文档内的企业名一致，防名单表格错行导致张冠李戴
            if nk in hit:
                city, county2 = hit[nk]
                county = county or county2
            else:
                cand = by_name.get(nk) or set()
                cities = {c for c, d in cand}
                if len(cities) == 1:
                    city = cities.pop()
                    ds = [d for c, d in cand if d]
                    if ds and not county:
                        county = collections.Counter(ds).most_common(1)[0][0]
            # 企业名自带他市地名而城市对不上 -> 判为错行，弃用
            if city:
                cc = city.replace("市", "")
                for c in CITIES:
                    if c in nm and c != cc:
                        city, county = "", ""
                        break
        if city:
            n_city += 1
        if county:
            n_county += 1
        if city and not city.endswith("市"):
            city = city + "市"
        out.append([nm, ct, city, county, r.get("认定年度", ""), r.get("批次", ""), r.get("来源URL", "")])
    with open(OUT, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(hdr)
        w.writerows(out)
    print(json.dumps({"rows": len(out), "with_city": n_city, "with_county": n_county,
                      "cert_keys": len(by_cert), "name_keys": len(by_name)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
