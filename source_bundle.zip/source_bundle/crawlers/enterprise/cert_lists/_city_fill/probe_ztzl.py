# -*- coding: utf-8 -*-
import requests, urllib3, re
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
for u in ['https://kjt.shaanxi.gov.cn/kjdt/ztzl/', 'https://kjt.shaanxi.gov.cn/kjdt/ztzl/index.html']:
    try:
        r = requests.get(u, headers=H, timeout=40, verify=False)
    except Exception as e:
        print('ERR', u, str(e)[:60]); continue
    r.encoding = r.apparent_encoding or 'utf-8'
    print('==', r.status_code, len(r.text), u)
    if r.status_code != 200:
        continue
    for m in re.finditer(r'href=[\'"]([^\'"]*ztzl[^\'"]*)[\'"][^>]*>\s*([^<>]{2,30})\s*</a>', r.text):
        print('   ', m.group(1)[:80], '|', m.group(2).strip())
