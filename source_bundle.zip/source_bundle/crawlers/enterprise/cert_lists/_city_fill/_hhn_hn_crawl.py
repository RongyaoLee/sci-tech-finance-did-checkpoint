# -*- coding: utf-8 -*-
"""河南：抓科技厅公示/认定通知附件，解析自带「所属地市 / 所在地域」列的名单。"""
import io, sys, os, re, json, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, '_hn_region_rows.jsonl')

# 页面清单（公示 + 认定通知），year/batch 由标题推出
PAGES = [
    ('http://kjt.henan.gov.cn/2017/08-29/1523953.html', 2017, '第一批'),
    ('http://kjt.henan.gov.cn/2017/12-01/1523956.html', 2017, '第二批'),
    ('http://kjt.henan.gov.cn/2018/09-12/1524032.html', 2018, '第一批'),
    ('http://kjt.henan.gov.cn/2018/11-30/1523970.html', 2018, '第二批'),
    ('http://kjt.henan.gov.cn/2018/12-05/1523971.html', 2018, '第三批'),
    ('http://kjt.henan.gov.cn/2019/11-01/1523983.html', 2019, '第一批'),
    ('http://kjt.henan.gov.cn/2019/12-04/1523985.html', 2019, '第二批'),
    ('http://kjt.henan.gov.cn/2019/12-04/1523986.html', 2019, '第三批'),
    ('http://kjt.henan.gov.cn/2024/10-17/3074891.html', 2024, '第一批'),
    ('http://kjt.henan.gov.cn/2024/11-12/3085277.html', 2024, '第二批'),
    ('http://kjt.henan.gov.cn/2024/11-25/3090707.html', 2024, '第三批'),
    ('http://kjt.henan.gov.cn/2024/12-03/3094227.html', 2024, '第四批'),
    ('http://kjt.henan.gov.cn/2025/10-11/3234283.html', 2025, '第一批'),
    ('http://kjt.henan.gov.cn/2025/11-28/3268844.html', 2025, '第二批'),
    # 2020-2023 认定通知（备用：附件里可能有地区列）
    ('http://kjt.henan.gov.cn/2021/01-26/2085768.html', 2020, '第一批'),
    ('http://kjt.henan.gov.cn/2021/01-26/2085767.html', 2020, '第二批'),
    ('http://kjt.henan.gov.cn/2021/01-26/2085765.html', 2020, '第三批'),
    ('http://kjt.henan.gov.cn/2021/12-17/2367440.html', 2021, '第一批'),
    ('http://kjt.henan.gov.cn/2022/03-04/2409117.html', 2021, '第二批'),
]

CITY_TOK = r'(?:郑州市|开封市|洛阳市|平顶山市|安阳市|鹤壁市|新乡市|焦作市|濮阳市|许昌市|漯河市|三门峡市|南阳市|商丘市|信阳市|周口市|驻马店市|济源市|郑州航空港区|济源示范区|兰考县|汝州市|滑县|长垣市|邓州市|永城市|固始县|鹿邑县|新蔡县)'
ROW_RE = re.compile(r'(\d{1,4})\s*' + CITY_TOK + r'\s*\S+\s*\S+\s*[0-9A-Z]{18}')

def parse_rows(text):
    """文本按空白切 token，锚定 18 位信用代码回推 序号/地市/地域/企业名。"""
    toks = re.split(r'\s+', text.replace('\u3000', ' '))
    toks = [t for t in toks if t]
    out = []
    for i in range(len(toks)):
        code = toks[i]
        if len(code) == 18 and re.fullmatch(r'[0-9A-Z]{18}', code):
            # 前四项依次是 企业名 / 地域 / 地市 / 序号
            if i >= 4:
                name, region, city, seq = toks[i-1], toks[i-2], toks[i-3], toks[i-4]
                if re.fullmatch(r'\d{1,4}', seq) and re.search(r'(市|区|县)$', city) and len(name) >= 4:
                    out.append((seq, city, region, name, code))
    return out

def main():
    have = set()
    if os.path.exists(OUT):
        for line in open(OUT, encoding='utf-8'):
            try:
                d = json.loads(line)
                have.add((d['name'], d['city']))
            except Exception:
                pass
    fh = open(OUT, 'a', encoding='utf-8')
    grand = 0
    for url, year, batch in PAGES:
        st, txt, fu = H.get(url, timeout=30)
        if st != 200:
            print('PAGE FAIL', url, st); continue
        title = re.search(r'<title>(.*?)</title>', txt, re.S)
        title = re.sub(r'\s+', ' ', title.group(1)).strip() if title else ''
        docs = H.doc_links(H.img_links(txt, fu), fu)
        print('PAGE %s %s docs=%d %s' % (year, batch, len(docs), title[:50]))
        for d, tt in docs:
            st2, data, _ = H.get(d, timeout=90, binary=True)
            if st2 != 200 or not data:
                print('   doc fail', d[:90]); continue
            dt = H.doc_text(d, data)
            rows = parse_rows(dt)
            tag = 'REGION' if ('所属地市' in dt or '所在地域' in dt) else 'no-region'
            print('   %-9s n=%-5d chars=%-7d %s' % (tag, len(rows), len(dt), d.split('/')[-1][:50]))
            for seq, city, region, name, code in rows:
                if (name, city) in have:
                    continue
                have.add((name, city))
                fh.write(json.dumps({'seq': seq, 'city': city, 'county': region, 'name': name,
                                     'uscc': code, 'year': year, 'batch': batch, 'src': d},
                                    ensure_ascii=False) + '\n')
                grand += 1
            fh.flush()
    fh.close()
    print('TOTAL new rows', grand)

if __name__ == '__main__':
    main()
