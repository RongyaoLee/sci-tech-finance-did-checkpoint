# -*- coding: utf-8 -*-
"""Minimal MS Word 97 (.doc) text extractor (piece table) — no external converters.

Returns the document text with Word control chars preserved:
  \x07 = cell/row end, \x0d = paragraph end, \x0b = line break.
"""

import struct

try:
    import olefile
except Exception:  # pragma: no cover
    olefile = None


def _fib(ole):
    wd = ole.openstream("WordDocument").read()
    if wd[:2] != b"\xec\xa5" and wd[:2] != b"\xdb\xa5":
        pass
    flags = struct.unpack_from("<H", wd, 0x0A)[0]
    f_complex = bool(flags & 0x0004)
    which = (flags >> 9) & 1
    fc_min = struct.unpack_from("<I", wd, 0x18)[0]
    fc_mac = struct.unpack_from("<I", wd, 0x1C)[0]
    return wd, f_complex, which, fc_min, fc_mac


def doc_text(path, codepage="gbk"):
    if olefile is None:
        return ""
    ole = olefile.OleFileIO(path)
    try:
        wd, f_complex, which, fc_min, fc_mac = _fib(ole)
        tbl_name = "1Table" if which else "0Table"
        try:
            tbl = ole.openstream(tbl_name).read()
        except Exception:
            tbl = b""
        if not f_complex or len(tbl) < 0x01A8:
            # simple document: text is contiguous
            raw = wd[fc_min:fc_mac]
            return raw.decode(codepage, "ignore")
        fc_clx = struct.unpack_from("<I", wd, 0x01A2)[0]
        lcb_clx = struct.unpack_from("<I", wd, 0x01A6)[0]
        clx = tbl[fc_clx:fc_clx + lcb_clx]
        # skip Prc entries
        i = 0
        while i < len(clx) and clx[i] == 1:
            cb = struct.unpack_from("<h", clx, i + 1)[0]
            i += 3 + cb
        if i >= len(clx) or clx[i] != 2:
            raw = wd[fc_min:fc_mac]
            return raw.decode(codepage, "ignore")
        lcb = struct.unpack_from("<I", clx, i + 1)[0]
        pcdt = clx[i + 5: i + 5 + lcb]
        n = (len(pcdt) - 4) // 12
        cps = [struct.unpack_from("<I", pcdt, 4 * k)[0] for k in range(n + 1)]
        out = []
        for k in range(n):
            off = 4 * (n + 1) + 8 * k
            fc = struct.unpack_from("<I", pcdt, off + 2)[0]
            compressed = bool(fc & 0x40000000)
            real = (fc & 0x3FFFFFFF) // 2 if compressed else (fc & 0x3FFFFFFF)
            ln = cps[k + 1] - cps[k]
            if compressed:
                chunk = wd[real:real + ln]
                out.append(chunk.decode(codepage, "ignore"))
            else:
                chunk = wd[real:real + 2 * ln]
                out.append(chunk.decode("utf-16-le", "ignore"))
        return "".join(out)
    finally:
        try:
            ole.close()
        except Exception:
            pass


def cells_of(text):
    """Split Word text into table cells (\x07) — returns list of cleaned cells."""
    import re
    raw = text.split("\x07")
    out = []
    for c in raw:
        c = c.replace("\x0b", " ").replace("\x0d", " ").replace("\x0c", " ")
        c = re.sub(r"[\x00-\x08\x0e-\x1f]", " ", c)
        c = re.sub(r"\s+", " ", c).strip()
        out.append(c)
    return out


if __name__ == "__main__":
    import sys
    t = doc_text(sys.argv[1])
    print("len", len(t), "cells", len(cells_of(t)))
    print(cells_of(t)[:40])
