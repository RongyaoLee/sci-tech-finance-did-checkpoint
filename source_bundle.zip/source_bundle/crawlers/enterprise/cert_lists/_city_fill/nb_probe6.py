# -*- coding: utf-8 -*-
import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

out = {}
# 1) Ningbo column pages
cands = ["http://www.innocom.gov.cn/gqrdw/c101419/list_gsgg_l3.shtml"] + \
        ["http://www.innocom.gov.cn/gqrdw/c101419/list_gsgg_l3_%d.shtml" % i for i in (1, 2, 3, 4)]
for u in cands:
    sc, html, final = H.get(u, timeout=25, tries=2)
    arts = []
    if sc == 200:
        for href, t in H.img_links(html, final):
            if re.search(r"/c101419/\d{6}/", href):
                arts.append({"t": t, "u": href})
    out[u] = {"status": sc, "n": len(arts), "arts": arts}
    print("P1", u, sc, len(arts))

# 2) national 认定备案公告 c101481 page 1
u = "http://www.innocom.gov.cn/gqrdw/c101481/list_gsgg_l2.shtml"
sc, html, final = H.get(u, timeout=25, tries=2)
arts = []
if sc == 200:
    H.save_raw("nb", u, html.encode("utf-8", "ignore"))
    for href, t in H.img_links(html, final):
        if re.search(r"/c101481/\d{6}/", href):
            arts.append({"t": t, "u": href})
    m = re.search(r"createPageHTML\([^)]*\)", html)
    print("PAGER", m.group(0) if m else None)
out[u] = {"status": sc, "n": len(arts), "arts": arts}
print("BA", u, sc, len(arts))

with open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_cols.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
