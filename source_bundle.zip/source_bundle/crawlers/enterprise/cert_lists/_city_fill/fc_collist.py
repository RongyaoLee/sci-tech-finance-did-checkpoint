# -*- coding: utf-8 -*-
"""List 高企-related articles from a gov column, following common pagination patterns."""
import os, sys, re, urllib.parse, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

KEY = re.compile(r"高新技术企业|高企")
WANT = re.compile(r"公示|名单|公告|备案|认定")


def page_links(url):
    html, final = cf.get(url)
    if not html:
        return [], None
    soup = BeautifulSoup(html, "lxml")
    out = []
    for a in soup.find_all("a", href=True):
        t = a.get_text(" ", strip=True)
        if not t or len(t) < 8:
            continue
        if not KEY.search(t):
            continue
        u = urllib.parse.urljoin(final or url, a["href"].strip())
        out.append((t, u))
    return out, final


def crawl(base, maxpage=6):
    seen = {}
    for i in range(maxpage):
        if i == 0:
            u = base
        else:
            u = re.sub(r"index\.html$", "index_%d.html" % i, base)
        links, final = page_links(u)
        print("-- page", u, "->", len(links), "links")
        if not links:
            break
        for t, x in links:
            if x not in seen:
                seen[x] = t
                print("   %s\n      %s" % (t[:70], x))
    return seen


if __name__ == "__main__":
    for base in sys.argv[1:]:
        print("=" * 78)
        print(base)
        crawl(base)
