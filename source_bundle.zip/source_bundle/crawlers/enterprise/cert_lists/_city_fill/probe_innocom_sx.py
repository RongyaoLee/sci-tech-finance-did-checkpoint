# -*- coding: utf-8 -*-
"""For each CSV source URL of 陕西 2024/2025: fetch page, list attachments, test for 18-char credit codes."""
import requests, urllib3, re, io, json, time, os
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
urls = [
    'http://www.innocom.gov.cn/gqrdw/c101474/202503/b42b1271958343949f70cffe4aaac75e.shtml',
    'http://www.innocom.gov.cn/gqrdw/c101474/202501/9af00895c4954bd9af374a2fc2cc06c7.shtml',
    'http://www.innocom.gov.cn/gqrdw/c101474/202412/1e2c6b64a99c4c89b742f2a3df1faaa1.shtml',
    'http://www.innocom.gov.cn/gqrdw/c101474/202601/b92aac85f2ad439cbeef94f2b46716dc.shtml',
    'http://www.innocom.gov.cn/gqrdw/c101474/202601/d93300601bd34fcab7fcaaad4bb7cdb5.shtml',
]
CODE = re.compile(r'9[0-9A-Z]{17}')


def doc_text(data, fn):
    low = fn.lower()
    try:
        if low.endswith('.pdf'):
            import fitz
            d = fitz.open(stream=data, filetype='pdf')
            return '\n'.join(p.get_text() for p in d)
        if low.endswith(('.xlsx', '.et')):
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(data), data_only=True)
            out = []
            for ws in wb.worksheets:
                for row in ws.iter_rows(values_only=True):
                    out.append('|'.join('' if c is None else str(c) for c in row))
            return '\n'.join(out)
        if low.endswith('.docx'):
            from docx import Document
            d = Document(io.BytesIO(data))
            out = []
            for tb in d.tables:
                for row in tb.rows:
                    out.append('|'.join(c.text.strip() for c in row.cells))
            if not out:
                out = [p.text for p in d.paragraphs]
            return '\n'.join(out)
        if low.endswith('.doc'):
            import olefile
            of = olefile.OleFileIO(io.BytesIO(data))
            return of.openstream('WordDocument').read().decode('utf-16-le', 'ignore')
    except Exception as e:
        return 'ERR ' + str(e)[:60]
    return ''


for u in urls:
    try:
        r = requests.get(u, headers=H, timeout=45, verify=False)
    except Exception as e:
        print('ERR', u, str(e)[:60]); continue
    r.encoding = r.apparent_encoding or 'utf-8'
    t = r.text if r.status_code == 200 else ''
    title = ''
    m = re.search(r'<title>(.*?)</title>', t, re.S)
    if m:
        title = m.group(1).strip()[:70]
    print('==', r.status_code, len(t), title, u[-40:])
    if r.status_code != 200:
        continue
    base = u.rsplit('/', 1)[0] + '/'
    for a in set(re.findall(r'([^\'"\s]+\.(?:pdf|docx?|xlsx?|et))', t, re.I)):
        if a.lower().endswith(('.css', '.js')):
            continue
        au = a if a.startswith('http') else (('http://www.innocom.gov.cn' + a) if a.startswith('/') else base + a)
        try:
            ar = requests.get(au, headers=H, timeout=60, verify=False)
        except Exception as e:
            print('   att ERR', au[-40:], str(e)[:50]); continue
        if ar.status_code != 200:
            print('   att', ar.status_code, au[-45:]); continue
        txt = doc_text(ar.content, au)
        n = len(CODE.findall(txt))
        print(f'   att {len(ar.content):7d} codes={n:5d} {au.rsplit("/",1)[-1][:40]}')
        if n:
            open(os.path.join(RAW, 'sxmm_' + au.rsplit('/', 1)[-1]), 'wb').write(ar.content)
        time.sleep(0.3)
