﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
import cf
u="http://searching.hunan.gov.cn/hunan/973104000/news"
for params in [
    {"searchWord":"高新技术企业"},
    {"searchword":"高新技术企业"},
    {"qt":"高新技术企业"},
    {"q":"高新技术企业"},
    {"keyword":"高新技术企业"},
]:
    try:
        r=cf.S.get(u,params=dict(params,pageSize=10),timeout=30)
        print(params, r.status_code, len(r.text))
        if r.status_code==200:
            print(r.text[:600].replace("\n"," "))
            break
    except Exception as e:
        print(params,"ERR",type(e).__name__,e)
