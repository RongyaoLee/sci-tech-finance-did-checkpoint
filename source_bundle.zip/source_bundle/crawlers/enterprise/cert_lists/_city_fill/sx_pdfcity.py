# -*- coding: utf-8 -*-
import sys, os, re, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
RAW = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_raw\陕西"
CITIES = ["西安市", "铜川市", "宝鸡市", "咸阳市", "渭南市", "延安市", "汉中市", "榆林市", "安康市", "商洛市", "杨凌"]
import fitz

files = sorted(glob.glob(os.path.join(RAW, "*.pdf")))
pick = files[:1] + [f for f in files if "2023" in os.path.basename(f)][:1] + [f for f in files if "2024" in os.path.basename(f)][:1] + [f for f in files if "2025" in os.path.basename(f)][:1]
for fp in pick:
    try:
        doc = fitz.open(fp)
        txt = "\n".join(p.get_text() for p in doc)
    except Exception as e:
        print("ERR", os.path.basename(fp), e); continue
    print("=====", os.path.basename(fp), "pages", len(doc), "chars", len(txt))
    print(txt[:700].replace("\n", " | "))
    print("  CITY HITS:", {c: txt.count(c) for c in CITIES if txt.count(c)})
