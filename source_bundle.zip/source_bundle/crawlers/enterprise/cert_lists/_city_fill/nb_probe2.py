# -*- coding: utf-8 -*-
import sys, json
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

sc, html, final = H.get("http://www.innocom.gov.cn/gqrdw/index.shtml", timeout=25, tries=2)
out = []
for href, txt in H.img_links(html, final):
    if "c1014" in href or "list_gsgg" in href:
        out.append({"txt": txt, "href": href})
with open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_links.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print(len(out))
