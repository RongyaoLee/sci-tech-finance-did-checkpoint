# -*- coding: utf-8 -*-
"""共享抓取/解析工具：为补齐「高新技术企业名单」地级市字段服务。

设计要点：
- 城市来源：官方公布件的标题/正文/表格自带地区信息；本模块只负责“拿文件 -> 抽证书编号集合”，
  城市标签由调用方（按发布单位/标题）给定。
- 证书编号是唯一 join key（GR+4位年+2位省码+6位顺序号，共14位）。
- 只做只读抓取，写入 _city_fill/ 目录，不动 cert_lists/*.csv。
"""
import io
import os
import re
import time
import random
import threading
import hashlib
from urllib.parse import urljoin, urlparse

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(BASE, "raw")
os.makedirs(RAW, exist_ok=True)

UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
]

_lock = threading.Lock()
_last = {}
MIN_INTERVAL = 0.55  # 单站 <= 2 req/s


def _throttle(host):
    with _lock:
        now = time.time()
        prev = _last.get(host, 0.0)
        wait = MIN_INTERVAL - (now - prev)
        if wait > 0:
            time.sleep(wait)
            now = time.time()
        _last[host] = now


_session = requests.Session()
_session.trust_env = True


def get(url, timeout=30, tries=3, allow_https_fallback=True, binary=False):
    """GET with UA, per-host throttle, http/https fallback. Returns (status, content, final_url).

    content is bytes if binary else (str, encoding) -> we return text for html path.
    """
    host = urlparse(url).netloc
    last_err = None
    for i in range(tries):
        _throttle(host)
        try:
            r = _session.get(url, headers={"User-Agent": random.choice(UAS),
                                           "Accept": "*/*",
                                           "Accept-Language": "zh-CN,zh;q=0.9"},
                             timeout=timeout, allow_redirects=True)
            if r.status_code == 200:
                if binary:
                    return 200, r.content, r.url
                r.encoding = r.apparent_encoding or r.encoding or "utf-8"
                return 200, r.text, r.url
            last_err = "HTTP %s" % r.status_code
        except Exception as e:
            last_err = "%s:%s" % (type(e).__name__, str(e)[:80])
            if allow_https_fallback and i == 0:
                if url.startswith("https://"):
                    url = "http://" + url[8:]
                elif url.startswith("http://"):
                    url = "https://" + url[7:]
                continue
        time.sleep(1.5 * (i + 1))
    return 0, (b"" if binary else ""), url


def img_links(html, base_url):
    out = []
    for m in re.finditer(r'<a[^>]+href\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)</a>', html, re.S | re.I):
        href, inner = m.group(1), re.sub(r"<[^>]+>", " ", m.group(2))
        inner = re.sub(r"\s+", " ", inner).strip()
        out.append((urljoin(base_url, href), inner))
    return out


DOC_EXT = (".pdf", ".xls", ".xlsx", ".doc", ".docx", ".zip", ".rar", ".et", ".wps")


def doc_links(items, base_url=""):
    out = []
    for url, txt in items:
        low = url.lower().split("?")[0]
        if low.endswith(DOC_EXT) or "/files/" in low and any(low.endswith(e) for e in DOC_EXT):
            out.append((url, txt))
    return out


def save_raw(tag, url, data):
    name = re.sub(r"[^\w.\-]", "_", os.path.basename(urlparse(url).path))[:120]
    if not name:
        name = "index"
    h = hashlib.md5(url.encode("utf-8")).hexdigest()[:8]
    d = os.path.join(RAW, tag)
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, "%s_%s" % (h, name))
    if not os.path.exists(p):
        with open(p, "wb") as f:
            f.write(data)
    return p


CERT_RE = re.compile(r"GR\s?(\d{4})\s?(\d{2})\s?(\d{6})")


def certs_in_text(t):
    res = set()
    for m in CERT_RE.finditer(t or ""):
        res.add("GR%s%s%s" % (m.group(1), m.group(2), m.group(3)))
    return res


def text_of_pdf(data):
    import fitz
    doc = fitz.open(stream=data, filetype="pdf")
    parts = []
    for p in doc:
        parts.append(p.get_text())
    doc.close()
    return "\n".join(parts)


def text_of_docx(data):
    import docx
    d = docx.Document(io.BytesIO(data))
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            parts.append("\t".join(c.text for c in row.cells))
    return "\n".join(parts)


def text_of_doc(data):
    """Word 97 二进制：用 olefile 提取 WordDocument 流的可见文本（粗糙但足以拿证书编号）。"""
    try:
        import olefile
        ole = olefile.OleFileIO(io.BytesIO(data))
        raw = ole.openstream("WordDocument").read()
    except Exception:
        return data.decode("utf-16-le", "ignore")
    # 常见形态：正文以 UTF-16LE 存放；直接按 UTF-16LE / GBK 双解码取可打印段
    txt = raw.decode("utf-16-le", "ignore")
    if txt.count("GR") >= 1 or "企业" in txt:
        return txt
    return txt + "\n" + raw.decode("gb18030", "ignore")


def text_of_xlsx(data):
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    parts = []
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            cells = [str(c) for c in row if c is not None]
            if cells:
                parts.append("\t".join(cells))
    wb.close()
    return "\n".join(parts)


def text_of_xls(data):
    import xlrd
    wb = xlrd.open_workbook(file_contents=data)
    parts = []
    for sh in wb.sheets():
        for r in range(sh.nrows):
            cells = [str(sh.cell_value(r, c)) for c in range(sh.ncols)]
            parts.append("\t".join(cells))
    return "\n".join(parts)


def doc_text(url, data):
    low = url.lower().split("?")[0]
    try:
        if low.endswith(".pdf") or data[:4] == b"%PDF":
            return text_of_pdf(data)
        if low.endswith(".docx") or data[:2] == b"PK" and b"word/" in data[:4000]:
            return text_of_docx(data)
        if low.endswith(".xlsx"):
            return text_of_xlsx(data)
        if low.endswith(".xls") or low.endswith(".et"):
            return text_of_xls(data)
        if low.endswith(".doc") or data[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
            return text_of_doc(data)
        if low.endswith(".zip") or low.endswith(".rar"):
            return ""
    except Exception as e:
        return "##ERR %s: %s" % (type(e).__name__, e)
    return ""


def fetch_certs(url, tag):
    """下载附件并返回 (cert_set, path, note)。"""
    sc, data, final = get(url, binary=True)
    if sc != 200 or not data:
        return set(), None, "dl_fail(%s)" % sc
    p = save_raw(tag, url, data)
    txt = doc_text(url, data)
    if txt.startswith("##ERR"):
        return set(), p, txt[:80]
    return certs_in_text(txt), p, "ok"


YEAR_RE = re.compile(r"(20\d{2})\s*年")


def years_in(s):
    return sorted(set(int(y) for y in YEAR_RE.findall(s or "")))


def crawl(start_urls, hit_pat, max_pages=120, same_host_only=True, verbose=True):
    """BFS 抓取站内页面，返回命中 hit_pat 的 (url, anchor_text, page_html)。"""
    host0 = urlparse(start_urls[0]).netloc
    seen = set()
    queue = list(start_urls)
    hits = []
    n = 0
    while queue and n < max_pages:
        url = queue.pop(0)
        if url in seen:
            continue
        seen.add(url)
        low = url.lower().split("?")[0]
        if low.endswith(DOC_EXT):
            continue
        sc, html, final = get(url, timeout=25, tries=2)
        n += 1
        if sc != 200 or not html:
            continue
        for href, txt in img_links(html, final):
            if same_host_only and urlparse(href).netloc != host0:
                continue
            if href in seen:
                continue
            if hit_pat.search(txt) and not href.lower().split("?")[0].endswith(DOC_EXT):
                hits.append((href, txt, final))
                seen.add(href)
            elif not href.lower().split("?")[0].endswith(DOC_EXT) and len(seen) + len(queue) < max_pages * 3:
                queue.append(href)
        if verbose and n % 20 == 0:
            print("  crawled %d, queue %d, hits %d" % (n, len(queue), len(hits)), flush=True)
    return hits, n
