# -*- coding: utf-8 -*-
"""探测省工信厅「通知公告/公示公告」栏目路径：打印 status / 关键字命中数"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

SITES = {
    "黑龙江": "gxt.hlj.gov.cn",
    "内蒙古": "gxt.nmg.gov.cn",
    "贵州": "gxt.guizhou.gov.cn",
    "宁夏": "gxt.nx.gov.cn",
    "吉林": "gxt.jl.gov.cn",
}
PATHS = ["zwgk/tzgg/", "xxgk/tzgg/", "tzgg/", "zwgk/gsgg/", "xwzx/tzgg/",
         "gkml/tzgg/", "zwgk/fdzdgknr/glfw/gsgg/", "xxgk/gsgg/", "zwgk/zfxxgk/tzgg/",
         "sy/tzgg/", "zwgk/xxgkml/tzgg/", "gkml/gsgg/"]
KWS = ("专精特新", "创新型中小企业", "高新技术企业")

for name, host in SITES.items():
    print("==", name, host)
    for p in PATHS:
        for scheme in ("http://", "https://"):
            u = scheme + host + "/" + p
            sc, d, f = H.get(u, timeout=12, tries=1, binary=True)
            if sc == 200 and d and len(d) > 2000:
                t = d.decode("utf-8", "ignore")
                if t.count("\ufffd") > 30:
                    t = d.decode("gb18030", "ignore")
                hits = {k: t.count(k) for k in KWS if t.count(k)}
                print("  %-46s %6d %s" % (u, len(d), hits))
                break
