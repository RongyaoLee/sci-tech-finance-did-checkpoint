# -*- coding: utf-8 -*-
"""Rebuild parts from their distinct sources with the fixed (no default-city) parser.
Keeps only rows whose city came from the document's own column.
"""
import os, sys, json, glob, hashlib, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_baidu as B
import sd_city_parser as P
import sd_lib as S

HERE = os.path.dirname(os.path.abspath(__file__))
PARTS = os.path.join(HERE, "parts")
OUT = os.environ.get("SD_OUT") or os.path.join(HERE, "parts_new")
CACHE = os.path.join(HERE, "raw_rebuild")
os.makedirs(OUT, exist_ok=True)
os.makedirs(CACHE, exist_ok=True)

DOC_RE = re.compile(r"\.(pdf|xlsx?|docx?|et)(\?|$)", re.I)

BAD_NAME = {"附件", "序号", "合计", "企业名称", "单位名称"}


def ok_name(nm):
    nm = (nm or "").strip()
    if len(nm) < 6 or nm in BAD_NAME:
        return False
    if re.fullmatch(r"[\d.\s\-]+", nm):
        return False
    if not S.looks_name(nm):
        return False
    return True


def fetch(url):
    key = hashlib.md5(url.encode()).hexdigest()[:16]
    for ext in ("", ".pdf", ".xls", ".xlsx", ".doc", ".docx"):
        p = os.path.join(CACHE, key + ext)
        if os.path.exists(p) and os.path.getsize(p) > 500:
            return open(p, "rb").read()
    st, data, _ = B.f(url, binary=True, timeout=60)
    if st != 200 or not data:
        return b""
    ext = os.path.splitext(url.split("?")[0])[1].lower()
    if not ext:
        ext = ".pdf" if data[:4] == b"%PDF" else (".xls" if data[:4] == b"\xd0\xcf\x11\xe0" else (".xlsx" if data[:2] == b"PK" else ".bin"))
    open(os.path.join(CACHE, key + ext), "wb").write(data)
    return data


def parse_src(url):
    data = fetch(url)
    if not data:
        return [], "fetch_fail"
    if DOC_RE.search(url) or data[:4] == b"%PDF" or data[:4] == b"\xd0\xcf\x11\xe0" or data[:2] == b"PK":
        try:
            rows = P.rows_from_doc(url, data, "", False)
        except Exception as e:
            return [], "parse_err:" + repr(e)[:60]
        return rows, "doc"
    # html page: inline tables
    html = data.decode("utf-8", "ignore")
    try:
        import bs4
        soup = bs4.BeautifulSoup(html, "html.parser")
        tabs = []
        for tb in soup.find_all("table"):
            rr = [[c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])] for tr in tb.find_all("tr")]
            rr = [r for r in rr if any(x for x in r)]
            if len(rr) >= 5:
                tabs.append(rr)
        return P.rows_from_tables(tabs, "", False), "html"
    except Exception as e:
        return [], "html_err:" + repr(e)[:60]


def main():
    summary = {}
    files = sorted(glob.glob(os.path.join(PARTS, "*.jsonl")))
    if os.environ.get("SD_ONLY"):
        files = [f for f in files if os.path.basename(f).startswith(os.environ["SD_ONLY"])]
    for path in files:
        recs = []
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                recs.append(json.loads(line))
            except Exception:
                pass
        by_src = {}
        for r in recs:
            by_src.setdefault(r.get("src", ""), set()).add((r.get("year", ""), r.get("batch", "")))
        kept = 0
        stats = []
        for src, ybs in by_src.items():
            rows, kind = parse_src(src)
            good = [(a, b, d) for (a, b, c, d) in rows
                    if c and ok_name(a) and (b or len(a) >= 8)]
            stats.append({"src": src, "kind": kind, "parsed": len(rows), "kept": len(good)})
            for (a, b, d) in good:
                y, bt = sorted(ybs)[0] if ybs else ("", "")
                recs_out = {"cert": b, "name": a, "city": "", "county": d, "src": src, "year": y, "batch": bt}
                # city filled below from rows
                recs_out["city"] = ""  # placeholder, set in loop
            kept += len(good)
        # second pass to write with city
        out_path = os.path.join(OUT, os.path.basename(path))
        seen = set()
        with open(out_path, "w", encoding="utf-8") as fo:
            for src, ybs in by_src.items():
                rows, kind = parse_src(src)
                good = [(a, b, c, d) for (a, b, c, d) in rows
                        if c and ok_name(a) and (b or len(a) >= 8)]
                y, bt = sorted(ybs)[0] if ybs else ("", "")
                for (a, b, c, d) in good:
                    k = b if b else "N:" + a
                    if k in seen:
                        continue
                    seen.add(k)
                    fo.write(json.dumps({"cert": b, "name": a, "city": c, "county": d,
                                         "src": src, "year": y, "batch": bt}, ensure_ascii=False) + "\n")
        summary[os.path.basename(path)] = {"before": len(recs), "after": len(seen), "srcs": stats}
        print(os.path.basename(path), "before=%d after=%d" % (len(recs), len(seen)), flush=True)
    json.dump(summary, open(os.path.join(HERE, "_rebuild.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
