# -*- coding: utf-8 -*-
import json, io
p = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_cols2.json"
d = json.load(open(p, encoding="utf-8"))
out = []
for col, rows in d.items():
    out.append("===== %s (%d) =====" % (col, len(rows)))
    for r in rows:
        out.append("%s\t%s" % (r["t"], r["u"]))
open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_arts.txt", "w", encoding="utf-8").write("\n".join(out))
print("ok", len(out))
