﻿# -*- coding: utf-8 -*-
import json,re,collections
d=json.load(open("_hn_hits.json",encoding="utf-8"))
CITY={"changsha":"长沙市","zhuzhou":"株洲市","xiangtan":"湘潭市","hengyang":"衡阳市",
"shaoyang":"邵阳市","yueyang":"岳阳市","changde":"常德市","zjj":"张家界市",
"yiyang":"益阳市","chenzhou":"郴州市","czs":"郴州市","yzcity":"永州市","huaihua":"怀化市",
"loudi":"娄底市","xxz":"湘西土家族苗族自治州"}
def city_of(u):
    m=re.match(r"https?://([a-z0-9\.\-]+)",u); h=m.group(1) if m else ""
    parts=h.split(".")
    for k,v in CITY.items():
        if k in parts or ("."+k+".") in h: return v
    return ""
CNT=collections.Counter()
sel=[]
for u,v in d.items():
    t=v["t"]
    if "高新技术企业" not in t and "高企" not in t and "高新企业" not in t: continue
    if not re.search(r"名单|公示|公布|认定|备案|推荐",t): continue
    c=city_of(u)
    CNT[c or "(非市级:"+re.match(r"https?://([a-z0-9\.\-]+)",u).group(1)+")"]+=1
    sel.append((c,t,u))
print("candidates",len(sel))
for k,n in CNT.most_common(40): print(f"  {k:28s} {n}")
json.dump(sel,open("_hn_sel.json","w",encoding="utf-8"),ensure_ascii=False)
print("--- 市级样本 ---")
for c,t,u in [x for x in sel if x[0]][:45]:
    print(c,"|",t[:56],"|",u[:100])
