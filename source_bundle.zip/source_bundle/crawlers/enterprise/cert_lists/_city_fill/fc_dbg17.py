# -*- coding: utf-8 -*-
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup
from tblgrid import grid_of
from fc_hn_rows import parse_rows2d, tables_of_html

for u in ["https://cstexun.com/article/2219.html", "https://cstexun.com/article/5068.html"]:
    html, final = cf.get(u)
    print("=" * 70); print(u, "len", len(html) if html else 0)
    if not html:
        continue
    soup = BeautifulSoup(html, "lxml")
    tbs = soup.find_all("table")
    print("tables", len(tbs))
    for i, tb in enumerate(tbs[:3]):
        g = grid_of(tb)
        print(" table", i, "rows", len(g), "sample", g[:3])
        print("  parsed", len(parse_rows2d(g, "长沙市")))
    txt = soup.get_text("\n", strip=True)
    hits = [l for l in txt.split("\n") if re.search(r"(GR\d|区$|县$)", l)]
    print("   text hits", len(hits), hits[:5])
