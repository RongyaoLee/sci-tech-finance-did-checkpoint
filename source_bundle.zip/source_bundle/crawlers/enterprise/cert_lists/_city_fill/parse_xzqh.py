# -*- coding: utf-8 -*-
"""Parse MCA 2023 xzqh table into code->name map for 61/14 provinces."""
import re, os, json
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
t = open(os.path.join(RAW, '_mca_xzqh2023.html'), encoding='utf-8').read()
rows = re.findall(r'<td[^>]*>\s*(\d{6})\s*</td>\s*<td[^>]*>(.*?)</td>', t, re.S)
code2name = {}
for code, nm in rows:
    nm = re.sub(r'<[^>]+>', '', nm).replace('&nbsp;', '')
    nm = re.sub(r'\s+', '', nm)
    if nm and code not in code2name:
        code2name[code] = nm
print('total codes', len(code2name))
sub = {c: n for c, n in code2name.items() if c[:2] in ('61', '14')}
print('61/14 codes', len(sub))
json.dump(code2name, open(os.path.join(RAW, '_xzqh2023.json'), 'w', encoding='utf-8'), ensure_ascii=False)
cities = sorted([(c, n) for c, n in sub.items() if c.endswith('0000') and not c.endswith('000000')])
print('provinces:', [(c, n) for c, n in cities if c.endswith('0000')][:4])
for prov in ('61', '14'):
    print('== province', prov)
    cs = sorted([(c, n) for c, n in sub.items() if c.startswith(prov) and c.endswith('00') and not c.endswith('0000')])
    for c, n in cs:
        cnt = len([1 for cc in sub if cc.startswith(c[:4]) and not cc.endswith('00')])
        print('  ', c, n, 'counties:', cnt)
