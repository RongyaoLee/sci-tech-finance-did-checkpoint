# -*- coding: utf-8 -*-
"""Hit the Jiangxi CMS /queryList endpoint to enumerate column articles."""
import os, sys, re, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import requests, cf

UA = cf.UA if hasattr(cf, "UA") else "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36"
S = requests.Session()
S.headers.update({"User-Agent": UA, "Referer": "http://kjt.jiangxi.gov.cn/jxskxjst/col/col27029/index.html"})

BASE = {"current": "1", "unitid": "466678", "webSiteCode": "jxskxjst",
        "channelCode": "col27029", "perPage": "20", "pageSize": "20",
        "showMode": "full", "groupSize": "1", "titleMax": "80",
        "sort": "pubDate", "order": "desc"}

for url in ["http://kjt.jiangxi.gov.cn/queryList",
            "http://kjt.jiangxi.gov.cn/jxskxjst/queryList"]:
    for method in ["GET", "POST"]:
        try:
            if method == "GET":
                r = S.get(url, params=BASE, timeout=25, verify=False)
            else:
                r = S.post(url, data=BASE, timeout=25, verify=False)
            body = r.text[:400].replace("\n", " ")
            print("%-4s %-48s %s len=%d %s" % (method, url, r.status_code, len(r.text), body))
        except Exception as e:
            print("%-4s %-48s ERR %s" % (method, url, e))
        time.sleep(0.6)
