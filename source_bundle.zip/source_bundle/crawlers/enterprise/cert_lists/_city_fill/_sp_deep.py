# -*- coding: utf-8 -*-
"""指定栏目深挖：翻 N 页收集「名单」类文章 -> 抓内嵌表/附件（要求含地区列）
用法: python _sp_deep.py <省> <栏目URL> <页数> [关键词1,关键词2]
"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
import harvest as H
from urllib.parse import urljoin

HERE = os.path.dirname(os.path.abspath(__file__))
DEF_KW = ("创新型中小企业", "专精特新", "小巨人", "高新技术企业", "科技型中小企业")


def txt(d):
    t = d.decode("utf-8", "ignore")
    if t.count("\ufffd") > 30:
        t = d.decode("gb18030", "ignore")
    return t


def anchors(t, base):
    for m in re.finditer(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', t, re.S):
        n = re.sub(r"<[^>]+>|[\s\u200b]+", "", m.group(2))
        if n:
            yield n, urljoin(base, m.group(1))


def main():
    prov, col, npages = sys.argv[1], sys.argv[2], int(sys.argv[3])
    kws = tuple(sys.argv[4].split(",")) if len(sys.argv) > 4 else DEF_KW
    OUT = os.path.join(HERE, "parts", prov + ".jsonl")
    stem = re.search(r"(index|list)\.(s?html?)$", col)
    d0 = col if col.endswith("/") else col.rsplit("/", 1)[0] + "/"
    urls = [col]
    for i in range(1, npages + 1):
        if stem:
            urls.append(d0 + "%s_%d.%s" % (stem.group(1), i, stem.group(2)))
        else:
            urls.append(d0 + "index_%d.html" % i)
            urls.append(d0 + "index_%d.shtml" % i)

    arts = {}
    for u in urls:
        sc, d, f = H.get(u, timeout=20, tries=2, binary=True)
        if sc != 200 or not d:
            continue
        t = txt(d)
        got = 0
        for nm, au in anchors(t, f or u):
            if any(k in nm for k in kws) and re.search(r"(名单|公布|认定|公示|结果)", nm):
                if re.search(r"\.(pdf|docx?|xlsx?)$", au, re.I):
                    continue
                if au not in arts:
                    arts[au] = nm
                    got += 1
        print("%-60s +%d (总%d)" % (u[-60:], got, len(arts)), flush=True)

    tot = 0
    for au, nm in sorted(arts.items(), key=lambda x: x[1]):
        ym = re.search(r"(20\d\d)", nm)
        year = ym.group(1) if ym else ""
        recs = S.grab(au, prov, "deep_" + prov[:2], year=year, batch="工信名单",
                      require_city=True, carry=True, min_name=4)
        if not recs:
            sc, d, f = H.get(au, timeout=25, tries=2, binary=True)
            if sc == 200 and d:
                t = txt(d)
                links = [urljoin(f or au, m.group(1)) for m in
                         re.finditer(r'href=[\'"]([^\'"]+\.(?:docx?|xlsx?|pdf))[\'"]', t, re.I)]
                for lu in list(dict.fromkeys(links))[:8]:
                    recs += S.grab(lu, prov, "deep_" + prov[:2], year=year, batch="工信名单",
                                   require_city=True, carry=True, min_name=4)
        if recs:
            S.append(OUT, recs)
        tot += len(recs)
        print("  %-58s %d" % (nm[:58], len(recs)), flush=True)
    print("TOTAL", prov, tot, flush=True)


if __name__ == "__main__":
    main()
