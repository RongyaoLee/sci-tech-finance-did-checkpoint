# -*- coding: utf-8 -*-
import sys, os, json
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
import fitz
CF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill"
p = os.path.join(CF, "raw", "nb_doc", "2263031f_04caa10d43c74ac4a11ae\nf483553b61d.pdf".replace("\n", ""))
p = [os.path.join(CF, "raw", "nb_doc", x) for x in os.listdir(os.path.join(CF, "raw", "nb_doc")) if x.endswith(".pdf")]
p = [x for x in p if os.path.getsize(x) == 379296][0]
d = fitz.open(p)
for i in range(d.page_count):
    pix = d[i].get_pixmap(dpi=200)
    out = os.path.join(CF, "_nb2020_p%d.png" % i)
    pix.save(out)
    print(out, pix.width, pix.height)
