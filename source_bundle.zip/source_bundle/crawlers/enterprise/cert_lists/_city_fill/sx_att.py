# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

for u in ["https://kjt.shaanxi.gov.cn/kjdt/tzgg/202401/t20240119_3382989.html",
          "https://kjt.shaanxi.gov.cn/kjdt/tzgg/202401/t20240105_3382974.html"]:
    h, f = cf.get(u, tries=1, timeout=25)
    print("=====", u)
    for a in cf.attachments(u, h):
        print("   ATT", a[0][:70], "|", a[1])
    # also any href with xls/doc/pdf
    for m in re.finditer(r'href="([^"]+\.(?:xlsx|xls|docx?|pdf))"', h, re.I):
        print("   RAW", m.group(1)[:120])
    s = cf.soup_of(h)
    for t in s(["script", "style"]):
        t.decompose()
    txt = re.sub(r"\n{2,}", "\n", s.get_text("\n", strip=True))
    j = txt.find("附件")
    print("--- 附件区 ---")
    print(txt[j:j + 400] if j >= 0 else "(no 附件)")
