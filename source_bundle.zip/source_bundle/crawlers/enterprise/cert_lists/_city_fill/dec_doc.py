# -*- coding: utf-8 -*-
"""Decode WPS .doc via utf-16-le heuristic; detect 名单 tables."""
import re, os, olefile
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
for fn in ['bz2022_P020240719616378375968.doc', 'bz2022_P020240719616378525701.doc',
           'bz2022_P020240719616378657563.doc', 'bz2021_P020220802349459474588.doc']:
    p = os.path.join(RAW, fn)
    of = olefile.OleFileIO(p)
    data = of.openstream('WordDocument').read()
    best = None
    for enc in ('utf-16-le', 'gb18030'):
        try:
            dec = data.decode(enc, 'ignore')
        except Exception:
            continue
        runs = re.findall(r'[\u4e00-\u9fa5]{2,}', dec)
        # score: fraction of runs containing common chars
        common = sum(1 for r_ in runs if re.search(r'[公司有限科技市局县区省]', r_))
        score = common / max(1, len(runs))
        print(fn, enc, 'runs', len(runs), 'common-frac', round(score, 3), 'sample', ' / '.join(runs[:12]))
        if best is None or score > best[0]:
            best = (score, enc, dec, runs)
    print('  BEST', best[1], round(best[0], 3))
    runs = best[3]
    joined = ' '.join(runs)
    for kw in ['序号', '企业名称', '所在', '县', '市', '奖励', '名单']:
        if kw in joined:
            i = joined.find(kw)
            print('   kw', kw, 'ctx', joined[max(0, i - 60):i + 120])
    print()
