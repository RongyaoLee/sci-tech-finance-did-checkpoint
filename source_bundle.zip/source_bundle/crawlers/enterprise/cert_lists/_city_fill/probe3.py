# -*- coding: utf-8 -*-
"""Probe 湖南 高企查询 portal + 陕西 科技厅 site for a query system / list pages."""
import os, re, sys, json, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

OUT = os.path.join(cf.HERE, "_probe3.json")
res = {}

# --- Hunan portal
u = "http://zwfw-new.hunan.gov.cn/hnzwfw/portal/MHWKx-KiTEOZT6Be4BUJF4/index.html"
html, final = cf.get(u)
res["hn_portal"] = {"url": u, "final": final if isinstance(final, str) else "", "ok": bool(html)}
if html:
    res["hn_portal"]["len"] = len(html)
    res["hn_portal"]["head"] = html[:2500]
    res["hn_portal"]["iframes"] = re.findall(r"""<iframe[^>]+src=["']([^"']+)""", html)[:10]
    res["hn_portal"]["js"] = [urllib.parse.urljoin(u, j) for j in
                              re.findall(r"""<script[^>]+src=["']([^"']+)""", html)][:15]

# --- Shaanxi home
for u2 in ("http://kjt.shaanxi.gov.cn/", "https://kjt.shaanxi.gov.cn/"):
    html2, f2 = cf.get(u2)
    if html2:
        s = cf.soup_of(html2)
        ls = []
        for a in s.find_all("a", href=True):
            t = a.get_text(" ", strip=True)
            if any(k in t for k in ("高新", "认定", "查询", "名单")):
                ls.append((t[:60], urllib.parse.urljoin(f2, a["href"])))
        res["sx_home"] = {"url": u2, "final": f2, "n": len(ls), "items": ls[:40],
                          "bytes": len(html2)}
        break
else:
    res["sx_home"] = {"err": "both schemes failed"}

json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps({k: (v if not isinstance(v, dict) else {kk: vv for kk, vv in v.items() if kk != "head"})
                  for k, v in res.items()}, ensure_ascii=False, indent=1)[:3000])
