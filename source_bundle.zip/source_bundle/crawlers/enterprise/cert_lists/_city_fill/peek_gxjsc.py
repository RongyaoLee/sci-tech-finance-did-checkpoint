# -*- coding: utf-8 -*-
import requests, urllib3, re
urllib3.disable_warnings()
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})
u = 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/gxjsc/index.shtml'
r = s.get(u, timeout=30, verify=False); r.encoding = r.apparent_encoding or 'utf-8'
t = r.text
open(r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw\_sx_gxjsc_p0.html', 'w', encoding='utf-8').write(t)
i = t.find('高新')
print('--- snippet around first 高新 ---')
print(t[max(0, i - 1500):i + 500])
