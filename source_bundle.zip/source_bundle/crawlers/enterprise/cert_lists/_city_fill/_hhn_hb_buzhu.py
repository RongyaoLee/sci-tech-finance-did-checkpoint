# -*- coding: utf-8 -*-
"""河北「拟补助名单公示」等页面：检验是否含地市/归口列。"""
import io, sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
PAGES = [
 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418345642675/index.html',
 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418344253295/index.html',
 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418343866054/index.html',
 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418343390136/index.html',
 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418343092159/index.html',
]
CITY_KW = ['石家庄', '唐山', '秦皇岛', '邯郸', '邢台', '保定', '张家口', '承德', '沧州', '廊坊', '衡水']
for u in PAGES:
    st, txt, fu = H.get(u, timeout=30)
    if st != 200:
        print('X', st, u[-24:]); continue
    t = re.search(r'<title>(.*?)</title>', txt, re.S)
    title = re.sub(r'\s+', '', re.sub(r'<[^>]+>', '', t.group(1))) if t else ''
    print('==', title[:50], u[-24:])
    docs = H.doc_links(H.img_links(txt, fu), fu)
    print('   docs', len(docs))
    for d, tt in docs:
        st2, data, _ = H.get(d, timeout=120, binary=True)
        if st2 != 200 or not data:
            print('   dl-fail', st2, d[-40:]); continue
        dt = H.doc_text(d, data)
        cnt = {k: dt.count(k) for k in CITY_KW}
        print('   %-34s chars=%-6d cityhits=%s' % (tt[:34], len(dt),
              {k: v for k, v in cnt.items() if v}))
        print('     head:', re.sub(r'\s+', ' ', dt[:160]))
