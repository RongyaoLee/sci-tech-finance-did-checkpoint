# -*- coding: utf-8 -*-
"""Test the Hubei 高企查询 API (baseURL https://kjt.hubei.gov.cn/ywt/services)."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

BASE = "https://kjt.hubei.gov.cn/ywt/services"
HDR = {"Content-Type": "application/json;charset=utf-8",
       "Referer": "https://kjt.hubei.gov.cn/ywt/",
       "Origin": "https://kjt.hubei.gov.cn"}

def post(path, body):
    r = cf.S.post(BASE + path, json=body, headers=HDR, timeout=30)
    return r.status_code, r.text

for body in ({"cpage": 1, "pageSize": 3, "flid": "008001"},
             {"cpage": 1, "pageSize": 3, "flid": "008001", "name": "", "unit": ""}):
    code, txt = post("/portal/search/commonSearch", body)
    print("BODY", json.dumps(body, ensure_ascii=False), "->", code)
    print(txt[:1500])
    print("=" * 70)

code, txt = post("/portal/search/commonSearch", {"cpage": 1, "pageSize": 3, "flid": "008001", "name": "武汉市"})
print("name=武汉市 ->", code, txt[:600])
