# -*- coding: utf-8 -*-
"""多点探测：广西栏目老页、甘肃可达性、海南官网培育库。"""
import sys, os, re, traceback
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
import harvest as H

TESTS = [
    "http://kjt.gxzf.gov.cn/xxgk/gxkjgk/gxjsqy/gxgxjsqy/index_1.shtml",
    "http://kjt.gxzf.gov.cn/xxgk/gxkjgk/gxjsqy/gxgxjsqy/index.shtml",
    "https://kjt.gansu.gov.cn/kjt/c111529/202610/174415389.shtml",
    "http://kjt.gansu.gov.cn/kjt/c111529/202610/174415389.shtml",
    "https://dost.hainan.gov.cn/",
]
for u in TESTS:
    try:
        sc, d, f = H.get(u, timeout=20, tries=1, binary=True)
        print("%-72s %s %d" % (u[-72:], sc, len(d or b"")))
        if sc == 200 and d and len(d) > 5000:
            t = d.decode("utf-8", "ignore")
            if t.count("\ufffd") > 20:
                t = d.decode("gb18030", "ignore")
            hits = [(re.sub(r"<[^>]+>|\s", "", m.group(2)), m.group(1))
                    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', t, re.S)
                    if "高新技术企业" in m.group(2)]
            print("    高新 hits", len(hits))
            for n, uu in hits[:6]:
                print("      ", n[:70], "|", uu[:80])
    except Exception as e:
        print("%-72s EXC %s: %s" % (u[-72:], type(e).__name__, e))
