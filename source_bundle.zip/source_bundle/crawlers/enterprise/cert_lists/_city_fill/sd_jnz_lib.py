# -*- coding: utf-8 -*-
"""济南/淄博/枣庄 专用抓取小工具（GBK 安全解码版）。文件名带 _sd_jnz_ 前缀避免撞车。"""
import re, time, random, os, hashlib
from urllib.parse import urljoin, urlparse
import requests

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(BASE, "raw")
os.makedirs(RAW, exist_ok=True)

UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0",
]
S = requests.Session()
S.trust_env = True
_last = {}

def _th(h):
    n = time.time()
    w = 0.55 - (n - _last.get(h, 0.0))
    if w > 0:
        time.sleep(w); n = time.time()
    _last[h] = n

def get(url, timeout=25, tries=2, binary=False, extra_headers=None):
    host = urlparse(url).netloc
    last = ""
    for i in range(tries):
        _th(host)
        try:
            hd = {"User-Agent": random.choice(UAS), "Accept": "*/*",
                  "Accept-Language": "zh-CN,zh;q=0.9"}
            if extra_headers:
                hd.update(extra_headers)
            r = S.get(url, headers=hd, timeout=timeout, allow_redirects=True)
            if r.status_code == 200:
                if binary:
                    return 200, r.content, r.url
                return 200, decode(r), r.url
            last = "HTTP %s" % r.status_code
        except Exception as e:
            last = "%s:%s" % (type(e).__name__, str(e)[:70])
            if url.startswith("https://"):
                url = "http://" + url[8:]
            elif url.startswith("http://"):
                url = "https://" + url[7:]
            continue
        time.sleep(1.0)
    return 0, (b"" if binary else ""), url

def decode(r):
    raw = r.content
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16", "ignore")
    head = raw[:4000].decode("ascii", "ignore").lower()
    cs = None
    m = re.search(r'charset\s*=\s*["\']?([\w-]+)', head)
    if m:
        cs = m.group(1)
    if cs in ("gb2312", "gbk", "gb18030"):
        return raw.decode("gb18030", "ignore")
    if cs == "utf-8":
        return raw.decode("utf-8", "ignore")
    for enc in ("utf-8", "gb18030"):
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return raw.decode("utf-8", "ignore")

def anchors(html, base):
    out = []
    for m in re.finditer(r'<a[^>]+href\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)</a>', html or "", re.S | re.I):
        href = m.group(1)
        txt = re.sub(r"<[^>]+>", " ", m.group(2))
        txt = re.sub(r"\s+", " ", txt).replace("&nbsp;", " ").strip()
        out.append((urljoin(base, href), txt))
    return out

DOC_EXT = (".pdf", ".xls", ".xlsx", ".doc", ".docx", ".zip", ".rar", ".et", ".wps")

def is_doc(u):
    return u.lower().split("?")[0].endswith(DOC_EXT)

def save(tag, url, data):
    d = os.path.join(RAW, tag)
    os.makedirs(d, exist_ok=True)
    name = re.sub(r"[^\w.\-]", "_", os.path.basename(urlparse(url).path))[:100] or "index"
    p = os.path.join(d, hashlib.md5(url.encode()).hexdigest()[:8] + "_" + name)
    open(p, "wb").write(data)
    return p

CERT_RE = re.compile(r"GR\s?(\d{4})\s?(\d{2})\s?(\d{6})")

def certs(t):
    return set("GR%s%s%s" % m for m in CERT_RE.findall(t or ""))
