# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S

URLS = [
    ("https://kjt.ln.gov.cn/kjt/tztg/bmwj/19962863CD224AE5A5C2FCBF90DB8380/index.shtml", "辽宁省", dict(year="2018", batch="第二批")),
    ("https://kjt.ln.gov.cn/kjt/tztg/bmwj/2023091309343286981/index.shtml", "辽宁省", dict(year="2022", batch="第一批,第二批")),
]
allrec = []
for u, prov, kw in URLS:
    r = S.grab(u, prov, "ln_test", **kw)
    if r:
        from collections import Counter
        c = Counter(x["city"] for x in r)
        print("   cities:", c.most_common(8))
        print("   sample:", r[0], r[-1])
    allrec += r
print("total", len(allrec), "with city", sum(1 for x in allrec if x["city"]))
