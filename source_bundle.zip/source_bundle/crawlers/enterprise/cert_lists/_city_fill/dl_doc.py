# -*- coding: utf-8 -*-
"""Download 山西 bz2022/bz2021 attachments (.doc/.docx) and try to extract tables/text."""
import requests, urllib3, re, os, io, json, subprocess, sys
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})

sets = {
    'bz2022': ('https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202407/',
               ['P020240719616378375968.doc', 'P020240719616378525701.doc', 'P020240719616378657563.doc']),
    'bz2021': ('https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/202208/',
               ['P020220802349440396061.docx', 'P020220802349440479390.docx', 'P020220802349459474588.doc']),
}
for tag, (base, files) in sets.items():
    for fn in files:
        u = base + fn
        r = s.get(u, timeout=90, verify=False)
        p = os.path.join(RAW, f'{tag}_{fn}')
        if r.status_code == 200:
            open(p, 'wb').write(r.content)
        print('==', tag, fn, r.status_code, len(r.content))
        if r.status_code != 200:
            continue
        txt = ''
        if fn.endswith('.docx'):
            try:
                from docx import Document
                d = Document(io.BytesIO(r.content))
                for ti, tb in enumerate(d.tables[:1]):
                    print('   table', ti, len(tb.rows), 'x', len(tb.columns))
                    for row in tb.rows[:3]:
                        print('     ', [c.text.strip()[:30] for c in row.cells])
                txt = '\n'.join(p_.text for p_ in d.paragraphs if p_.text.strip())[:300]
            except Exception as e:
                print('   docx ERR', str(e)[:70])
        else:
            try:
                import olefile
                if olefile.isOleFile(p):
                    of = olefile.OleFileIO(p)
                    print('   streams', of.listdir()[:6])
                    data = of.openstream('WordDocument').read()
                    # crude: decode as gb18030 and keep CJK runs
                    try:
                        dec = data.decode('gb18030', 'ignore')
                    except Exception:
                        dec = ''
                    runs = re.findall(r'[\u4e00-\u9fa5]{2,}', dec)
                    print('   cjk runs', len(runs), 'sample', ' / '.join(runs[:25]))
                    txt = ' '.join(runs[:80])
                else:
                    print('   not ole')
            except Exception as e:
                print('   doc ERR', str(e)[:70])
        print('   TXT:', re.sub(r'\s+', ' ', txt)[:200])
