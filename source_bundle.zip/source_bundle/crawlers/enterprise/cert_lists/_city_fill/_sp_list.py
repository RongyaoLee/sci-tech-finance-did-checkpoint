# -*- coding: utf-8 -*-
"""列某栏目所有分页里的标题（用于找 高新技术企业认定 通知）。"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S

base = sys.argv[1]           # 形如 /kjt/tztg/bmwj/index.shtml
key = sys.argv[2] if len(sys.argv) > 2 else "高新技术企业"
host = "https://kjt.ln.gov.cn"
pages = int(sys.argv[3]) if len(sys.argv) > 3 else 8

sc, d, f = S.H.get(host + base, binary=True)
t = d.decode("utf-8", "ignore")
m = re.search(r"共(\d+)页", t)
last = int(m.group(1)) if m else pages
stem = re.sub(r"index\.shtml$", "", base)
print("pages", last)
urls = []
for p in range(1, last + 1):
    u = host + base if p == 1 else host + stem + "e-2.shtml"
    if p > 1:
        mm = re.search(r"onclick=\"queryArticleByCondition\(this,'([^']+-%d\.shtml)'\)" % p, t)
        u = host + mm.group(1) if mm else None
    if not u:
        continue
    sc, d, f = S.H.get(u, binary=True)
    if sc != 200:
        print("  fail", p, sc)
        continue
    tt = d.decode("utf-8", "ignore")
    for a in re.finditer(r'<a href="([^"]+)"[^>]*?title="([^"]{4,120})"', tt):
        if key in a.group(2):
            urls.append((a.group(2)[:80], a.group(1)))
    for a in re.finditer(r'<a href="([^"]+)"[^>]*>([^<]{10,120})</a>', tt):
        if key in a.group(2) and (a.group(1),) not in urls:
            urls.append((a.group(2)[:80], a.group(1)))
seen = set()
for ttl, u in urls:
    if u in seen:
        continue
    seen.add(u)
    print(ttl, "|", u)
