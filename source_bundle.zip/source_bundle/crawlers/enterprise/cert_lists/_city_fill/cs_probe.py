# -*- coding: utf-8 -*-
"""Probe 长沙市科技局/长沙市政府 站内搜索，找「高新技术企业」名单页。"""
import os, sys, json, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

OUT = os.path.join(cf.HERE, "_cs_probe.json")
res = {}

def try_get(u, tag, want=("高新", "名单", "认定", "公示")):
    try:
        html, final = cf.get(u)
    except Exception as e:
        res[tag] = {"url": u, "err": type(e).__name__}
        return None
    if not isinstance(html, str) or not html.strip():
        res[tag] = {"url": u, "err": "empty/non-text", "final": final}
        return None
    s = cf.soup_of(html)
    title = (s.title.get_text(strip=True) if s.title else "")
    hits = []
    for a in s.find_all("a", href=True):
        t = a.get_text(" ", strip=True)
        if not t or len(t) < 6:
            continue
        if any(w in t for w in want):
            hits.append([t[:80], urllib.parse.urljoin(final, a["href"])])
    res[tag] = {"url": u, "final": final, "title": title, "len": len(html), "hits": hits[:25]}
    return final

for u, tag in [("http://kjj.changsha.gov.cn/", "cs_kjj_home"),
               ("http://www.changsha.gov.cn/", "cs_gov_home"),
               ("http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/index.html", "hn_col")]:
    try_get(u, tag)

for base in ["http://www.changsha.gov.cn", "http://kjj.changsha.gov.cn"]:
    for path in ["/so/s?qt=%E9%AB%98%E6%96%B0%E6%8A%80%E6%9C%AF%E4%BC%81%E4%B8%9A",
                 "/search?qt=%E9%AB%98%E6%96%B0%E6%8A%80%E6%9C%AF%E4%BC%81%E4%B8%9A"]:
        try_get(base + path, "search:" + base.replace("http://", "") + path[:10])

json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for k, v in res.items():
    print(k, "->", v.get("err") or (v.get("title"), v.get("len"), len(v.get("hits", []))))
    for h in (v.get("hits") or [])[:8]:
        print("    ", h[0][:60], "|", h[1])
