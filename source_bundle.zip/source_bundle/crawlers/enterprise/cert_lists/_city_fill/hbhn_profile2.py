# -*- coding: utf-8 -*-
import csv, collections, os, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
base = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists'
for fn in ['河北省.csv', '河南省.csv']:
    with open(os.path.join(base, fn), encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    print('==', fn)
    cc = collections.Counter(x['城市'] for x in rows if x['城市'])
    print(' cities:', cc.most_common())
    # county values sample for filled rows
    ex = [x for x in rows if x['城市']][:5]
    for x in ex:
        print('  ex', x['企业名称'], '|', x['城市'], '|', x['区县'], '|', x['认定年度'], x['批次'], '|', x['来源URL'][:80])
    uc = collections.Counter(x['来源URL'] for x in rows if x['城市'])
    print(' srcs of filled:', uc.most_common(10))
