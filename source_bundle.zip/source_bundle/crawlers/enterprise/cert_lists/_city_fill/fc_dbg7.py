# -*- coding: utf-8 -*-
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pymupdf

p = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_cache\att\hn_67b8748e7324c5f0.pdf"
d = pymupdf.open(p)
for pno in (0, 1):
    pg = d[pno]
    words = pg.get_text("words")
    lines = {}
    for w in words:
        lines.setdefault(round(w[1] / 4), []).append(w)
    print("=== page", pno)
    for k in sorted(lines)[14:26]:
        ws = sorted(lines[k], key=lambda x: x[0])
        print(" | ".join("%s@%.0f" % (w[4], w[0]) for w in ws))
