# -*- coding: utf-8 -*-
"""把已保存 HTML 的锚点导出到 UTF-8 txt（避开控制台编码问题）。"""
import sys, json, os
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import sd_jnz_lib as L

BASE = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill"
files = sys.argv[1:]
for f in files:
    p = os.path.join(BASE, f)
    if not os.path.exists(p):
        print("missing", f); continue
    html = open(p, encoding="utf-8", errors="ignore").read()
    # 猜 base
    base = "http://" + f.split("_")[2] + "/" if False else ""
    ls = L.anchors(html, "http://x/")
    out = os.path.join(BASE, "_anchors_" + f + ".txt")
    with open(out, "w", encoding="utf-8") as fh:
        for u, t in ls:
            fh.write("%s\t%s\n" % (t, u))
    print(f, "->", out, len(ls))
