# -*- coding: utf-8 -*-
"""山东各市高企名单抓取 v2：大汉 CMS record 解析 + dataproxy 翻页 + 附件表格。
用法: python sd_crawl2.py 威海 泰安 ...   (无参数=全部)
"""
import os, re, sys, json, html
from urllib.parse import urljoin, urlparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_lib as S, sd_city_parser as P, sd_store as ST

BASE = S.BASE
LOG = []


def log(*a):
    msg = " ".join(str(x) for x in a)
    LOG.append(msg)
    print(msg, flush=True)


HOMES = {
    "济南": ["http://jnsti.jinan.gov.cn/", "http://kjj.jinan.gov.cn/"],
    "淄博": ["https://www.zibo.gov.cn/", "http://kjj.zibo.gov.cn/"],
    "枣庄": ["http://kjj.zaozhuang.gov.cn/", "http://www.zaozhuang.gov.cn/"],
    "东营": ["http://dysti.dongying.gov.cn/", "http://www.dongying.gov.cn/"],
    "烟台": ["https://kjj.yantai.gov.cn/"],
    "潍坊": ["http://kjj.weifang.gov.cn/"],
    "济宁": ["http://jnkj.jining.gov.cn/"],
    "泰安": ["https://kjj.taian.gov.cn/"],
    "威海": ["https://kjj.weihai.gov.cn/"],
    "日照": ["http://stc.rizhao.gov.cn/", "http://kjj.rizhao.gov.cn/"],
    "临沂": ["https://kjj.linyi.gov.cn/"],
    "德州": ["http://kjj.dezhou.gov.cn/"],
    "聊城": ["http://kjj.liaocheng.gov.cn/"],
    "滨州": ["http://kj.binzhou.gov.cn/", "http://kjj.binzhou.gov.cn/"],
    "菏泽": ["http://kjj.heze.gov.cn/"],
}
# 已知可用栏目（city -> cols）
KNOWN_COLS = {
    "威海": ["https://kjj.weihai.gov.cn/col/col23341/index.html", "https://kjj.weihai.gov.cn/col/col21403/index.html"],
    "泰安": ["https://kjj.taian.gov.cn/col/col45670/index.html"],
    "淄博": ["https://www.zibo.gov.cn/col/col2067/index.html"],
    "东营": ["http://www.dongying.gov.cn/col/col38799/index.html"],
    "烟台": ["https://kjj.yantai.gov.cn/col/col16248/index.html"],
    "东营2": [],
}
TITLE_HIT = re.compile(r"高新|高企")
TITLE_LIST = re.compile(r"名单|公布|认定|公示|备案|通知|结果|证书")
LINK_RE = re.compile(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', re.S | re.I)
DOC_RE = re.compile(r"(attach/0/|downfile\.jsp|\.pdf|\.xlsx?|\.docx?|\.et\b|\.wps\b)", re.I)


def records(h):
    """从页面/片段抽出 [(title, href)]，兼容 CDATA record 与普通 a"""
    out = []
    for chunk in re.findall(r"<record><!\[CDATA\[(.*?)\]\]></record>", h, re.S):
        for href, txt in LINK_RE.findall(chunk):
            t = re.sub(r"<[^>]+>", "", txt)
            t = re.sub(r"\s+", "", t)
            if t and href:
                out.append((t, href))
    if not out:
        for href, txt in LINK_RE.findall(h):
            t = re.sub(r"<[^>]+>", "", txt)
            t = re.sub(r"\s+", "", t)
            if t and len(t) > 5:
                out.append((t, href))
    return out


def dataproxy(h, base):
    m = re.search(r"dataproxy\.jsp\?([^\"'\s>]+)", h)
    if not m:
        return []
    qs = html.unescape(m.group(1))
    urls = []
    for p in range(1, 41):
        urls.append(urljoin(base, "/module/web/jpage/dataproxy.jsp?page=%d&%s" % (
            p, re.sub(r"page=\d+&?", "", qs).lstrip("&"))))
    return urls


def list_links(col, maxp=25):
    try:
        sc, h, fin = S.get(col, tries=1, timeout=30)
    except Exception as e:
        log("  col ERR %r" % (e,))
        return []
    if not isinstance(h, str) or sc != 200 or len(h) < 300:
        return []
    base = fin or col
    items = [(t, urljoin(base, u)) for t, u in records(h)]
    dps = dataproxy(h, base)
    stop = 0
    for du in dps[:maxp]:
        if stop >= 3:
            break
        try:
            sc2, frag, fin2 = S.get(du, tries=1, timeout=30)
        except Exception:
            stop += 1
            continue
        if not isinstance(frag, str) or not frag.strip():
            stop += 1
            continue
        got = [(t, urljoin(base, u)) for t, u in records(frag)]
        if not got:
            stop += 1
            continue
        items += got
    return items


def find_cols(home):
    try:
        sc, h, fin = S.get(home, tries=1, timeout=30)
    except Exception:
        return []
    if not isinstance(h, str) or sc != 200:
        return []
    cols = []
    for href, txt in LINK_RE.findall(h):
        t = re.sub(r"<[^>]+>", "", txt)
        t = re.sub(r"\s+", "", t)
        u = urljoin(fin or home, href)
        if "/col/col" in u and re.search(r"通知|公告|公示|政务公开|信息公开|政策|文件|新闻", t):
            if u not in cols:
                cols.append(u)
    return cols[:8]


def html_tables(h):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(h, "html.parser")
    tabs = []
    for t in soup.find_all("table"):
        rows = []
        for tr in t.find_all("tr"):
            cells = [re.sub(r"\s+", "", td.get_text(" ")) for td in tr.find_all(["td", "th"])]
            if cells and any(cells):
                rows.append(cells)
        if len(rows) >= 3:
            tabs.append(rows)
    return tabs


def handle_article(city, title, url):
    try:
        sc, h, fin = S.get(url, tries=1, timeout=30)
    except Exception:
        return 0
    if not isinstance(h, str) or sc != 200:
        return 0
    year = ""
    m = re.search(r"(20\d\d)\s*年", title) or re.search(r"/(20\d\d)/", url)
    if m:
        year = m.group(1)
    n = 0
    tabs = html_tables(h)
    if tabs:
        rows = [(a, b, d) for a, b, c, d in P.rows_from_tables(tabs, city + "市") if (c == city or not c)]
        if len(rows) >= 5:
            add = ST.append_rows(city, rows, url, year, "")
            n += add
            log("    inline add=%d/%d %s" % (add, len(rows), title[:36]))
    docs = []
    for href, txt in LINK_RE.findall(h):
        full = urljoin(fin or url, href)
        if DOC_RE.search(full) and len(full) < 400:
            docs.append(full)
    for full in list(dict.fromkeys(docs))[:15]:
        try:
            sc2, data, fin2 = S.get(full, tries=1, timeout=60, binary=True)
        except Exception:
            continue
        if not isinstance(data, bytes) or len(data) < 800:
            continue
        if not (data[:5] == b"%PDF-" or data[:2] == b"PK" or data[:4] == b"\xd0\xcf\x11\xe0"):
            continue
        rows = P.rows_from_doc(full, data, city + "市")
        rows = [(a, b, d) for a, b, c, d in rows if (c == city or not c)]
        if rows:
            add = ST.append_rows(city, rows, full, year, "")
            n += add
            log("    doc add=%d/%d %s" % (add, len(rows), os.path.basename(urlparse(full).path)[:40]))
    return n


def run_city(city):
    cols = list(KNOWN_COLS.get(city, []))
    if not cols:
        for home in HOMES.get(city, []):
            got = find_cols(home)
            if got:
                cols += got
                log("  home %s cols=%d" % (home, len(got)))
                break
    if not cols:
        log("SKIP %s (no col)" % city)
        return 0
    total = 0
    seen = set()
    for col in cols:
        items = list_links(col)
        log("  col %s items=%d" % (col, len(items)))
        hits = [(t, u) for t, u in items if TITLE_HIT.search(t) and TITLE_LIST.search(t)]
        log("  hits=%d" % len(hits))
        for t, u in hits:
            if u in seen:
                continue
            seen.add(u)
            try:
                total += handle_article(city, t, u)
            except Exception as e:
                log("  art ERR %s %r" % (u, e))
    log("TOTAL %s=%d" % (city, total))
    return total


def main(cities):
    res = {}
    for c in cities:
        log("== %s" % c)
        try:
            res[c] = run_city(c)
        except Exception as e:
            log("CITY ERR %s %r" % (c, e))
            res[c] = -1
    with open(os.path.join(BASE, "_crawl2.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False)


if __name__ == "__main__":
    main(sys.argv[1:] or list(HOMES))
