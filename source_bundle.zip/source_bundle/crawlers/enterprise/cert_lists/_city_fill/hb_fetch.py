# -*- coding: utf-8 -*-
"""Pull the whole 湖北省高新技术企业 registry from the 湖北科技一网通 便民查询 API.

Endpoint: POST https://kjt.hubei.gov.cn/ywt/services/portal/search/commonSearch
Params : flid=008001&cpage=N&pageSize=50   (BOTH must be in the QUERY STRING, else paging
         silently repeats page 1 / "数据分类参数不能为空")
Body   : JSON {cpage, pageSize, flid, name, unit, data_no, unit_code, jb, nd, year}
Rows   : id, data_no(证书编号), name(企业名称), nd(年度), areaname(地市), lb(企业类型), unit_code
"""
import os, sys, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

BASE = "https://kjt.hubei.gov.cn/ywt/services/portal/search/commonSearch"
HDR = {"Content-Type": "application/json;charset=utf-8",
       "Referer": "https://kjt.hubei.gov.cn/ywt/",
       "Origin": "https://kjt.hubei.gov.cn"}
OUT = os.path.join(cf.HERE, "hubei_api_rows.jsonl")


def page(n, year="", size=50):
    body = {"cpage": n, "pageSize": size, "flid": "008001", "name": "", "unit": "",
            "data_no": "", "unit_code": "", "jb": "", "nd": year, "year": year}
    r = cf.S.post(BASE, params={"flid": "008001", "cpage": n, "pageSize": size},
                  json=body, headers=HDR, timeout=40)
    r.raise_for_status()
    return r.json()


seen, total, n = set(), None, 1
with open(OUT, "w", encoding="utf-8") as f:
    while True:
        try:
            d = page(n)
        except Exception as e:
            print("retry page", n, type(e).__name__, flush=True)
            time.sleep(1.5)
            try:
                d = page(n)
            except Exception:
                print("give up at", n, flush=True)
                break
        if not d.get("success"):
            print("FAIL", n, d.get("msg"), flush=True)
            break
        if total is None:
            total = d.get("total") or 0
            print("total", total, flush=True)
        chunk = d.get("rows") or []
        new = 0
        for r in chunk:
            k = r.get("id")
            if k in seen:
                continue
            seen.add(k)
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
            new += 1
        if n % 50 == 0:
            print("page", n, "distinct", len(seen), "new", new, flush=True)
        if not chunk or len(seen) >= total:
            break
        n += 1
        if n > 800:
            break

print("DONE distinct", len(seen), flush=True)
