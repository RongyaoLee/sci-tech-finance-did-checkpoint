﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
import cf
cands={
 "长沙市":"http://kjj.changsha.gov.cn/",
 "株洲市":"http://kjj.zhuzhou.gov.cn/",
 "湘潭市":"http://xtst.xiangtan.gov.cn/",
 "衡阳市":"http://kjj.hengyang.gov.cn/",
 "邵阳市":"http://kjj.shaoyang.gov.cn/",
 "岳阳市":"http://kjj.yueyang.gov.cn/",
 "常德市":"http://kjj.changde.gov.cn/",
 "张家界市":"http://kjj.zjj.gov.cn/",
 "益阳市":"http://kjj.yiyang.gov.cn/",
 "郴州市":"http://kjj.chenzhou.gov.cn/",
 "永州市":"http://kjj.yzcity.gov.cn/",
 "怀化市":"http://kjj.huaihua.gov.cn/",
 "娄底市":"http://kjj.loudi.gov.cn/",
 "湘西土家族苗族自治州":"http://kjj.xxz.gov.cn/",
}
res={}
for city,u in cands.items():
    h,fin=cf.get(u)
    if not h:
        res[city]=("FAIL",fin); print(city,"FAIL",fin,flush=True); continue
    t=re.search(r"<title>(.*?)</title>",h,re.S)
    res[city]=("OK",fin,(t.group(1).strip()[:60] if t else "?"),len(h))
    print(city,"OK",fin,res[city][2],len(h),flush=True)
json.dump(res,open("_hn_homes.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
