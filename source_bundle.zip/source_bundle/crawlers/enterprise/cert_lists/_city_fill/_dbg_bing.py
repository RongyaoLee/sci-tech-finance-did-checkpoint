# -*- coding: utf-8 -*-
import re, requests, urllib.parse, urllib3
urllib3.disable_warnings()
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/126.0 Safari/537.36",
      "Accept-Language": "zh-CN,zh;q=0.9"}
q = "2023年潍坊市高新技术企业名单"
u = "https://cn.bing.com/search?q=" + urllib.parse.quote(q) + "&first=1"
r = requests.get(u, headers=UA, timeout=25, verify=False)
t = r.text
out = ["status=%s len=%d b_algo=%d h2a=%d" % (r.status_code, len(t), t.count("b_algo"), len(re.findall(r"<h2", t)))]
i = t.find("b_algo")
out.append(repr(t[max(0, i - 200):i + 800]) if i > 0 else "NO b_algo")
out.append("GOV:" + str(list(dict.fromkeys(re.findall(r"https?://[a-z0-9.\-]+\.gov\.cn[^\"'<>\s]{0,80}", t)))[:8]))
open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_bing.txt", "w", encoding="utf-8").write("\n".join(out))
print("ok")
