# -*- coding: utf-8 -*-
"""Crawl 山西 高企认定 column ayw_11724/gxjsqyrd/ ; probe 陕西 site search."""
import requests, urllib3, re, time, json, os
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})


def get(u, binary=False):
    for attempt in range(2):
        try:
            r = s.get(u, timeout=30, verify=False)
        except Exception as e:
            return 0, str(e)[:90], u
        if r.status_code == 200:
            if binary:
                return 200, r.content, r.url
            r.encoding = r.apparent_encoding or 'utf-8'
            return 200, r.text, r.url
        alt = u.replace('https://', 'http://', 1) if u.startswith('https://') else u.replace('http://', 'https://', 1)
        if attempt == 0 and alt != u:
            u = alt
            continue
        return r.status_code, '', u
    return 0, '', u


def links(html):
    out = []
    for m in re.finditer(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', html, re.S):
        txt = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', m.group(2))).strip()
        if txt:
            out.append((txt, m.group(1)))
    return out


base = 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/ayw_11724/gxjsqyrd/'
seen = {}
for p in range(0, 15):
    for pat in (['', 'index.shtml', 'index_{p}.shtml'] if p == 0 else ['index_{p}.shtml', 'index_{p}.html']):
        u = base + (pat.format(p=p) if p else pat)
        st, t, fu = get(u)
        if st == 200 and len(t) > 3000:
            break
    if st != 200:
        print('stop', p, u, st)
        break
    n = 0
    for txt, href in links(t):
        if len(txt) < 12:
            continue
        if re.search(r'(高新|公示|名单|认定)', txt) and 'shtml' in href:
            if txt not in seen:
                seen[txt] = href
                n += 1
    print('page', p, len(t), 'new', n)
    if n == 0 and p > 0:
        break
    time.sleep(0.5)
json.dump(seen, open(os.path.join(RAW, '_sxkj_gxrd.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('TOTAL', len(seen))
for k, v in list(seen.items()):
    print('  ', k[:85], '|', v)

print('=== 陕西 search probe')
for su in ['https://kjt.shaanxi.gov.cn/sxsearch-a/search.shtml?code=191b76850fb&dataTypeId=20770&searchWord=%E9%AB%98%E6%96%B0%E6%8A%80%E6%9C%AF%E4%BC%81%E4%B8%9A']:
    st, t, fu = get(su)
    print(su, st, len(t))
    if st == 200:
        open(os.path.join(RAW, '_sx_search.html'), 'w', encoding='utf-8').write(t)
        print(re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', t))[:1500])
