# -*- coding: utf-8 -*-
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

urls = [
    'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418344688721/index.html',
    'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418345546934/index.html',
]
for u in urls:
    st, txt, fu = H.get(u, timeout=30)
    print('==', u, st, len(txt or ''))
    if st != 200:
        continue
    title = re.search(r'<title>(.*?)</title>', txt, re.S)
    print('  title:', (title.group(1).strip() if title else '')[:100])
    links = H.img_links(txt, fu)
    docs = H.doc_links(links, fu)
    print('  docs:', len(docs))
    for d, t in docs[:12]:
        print('   -', t[:70], '|', d)
    # any table in page
    tbls = re.findall(r'<table.*?</table>', txt, re.S | re.I)
    print('  tables:', len(tbls))
    for seg in tbls[:2]:
        rows = re.findall(r'<tr.*?</tr>', seg, re.S | re.I)
        head = re.sub(r'<[^>]+>', ' ', rows[0]) if rows else ''
        print('   rows=%d head=%s' % (len(rows), re.sub(r'\s+', ' ', head).strip()[:100]))
