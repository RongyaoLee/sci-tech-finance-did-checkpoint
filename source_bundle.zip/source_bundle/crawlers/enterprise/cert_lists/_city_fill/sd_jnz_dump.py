# -*- coding: utf-8 -*-
"""通用：抓 URL -> 存 HTML -> 导出锚点 txt。用法: sd_jnz_dump.py tag=url [tag=url ...]"""
import sys, os, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import sd_jnz_lib as L

BASE = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill"
args = sys.argv[1:]
for a in args:
    tag, url = a.split("=", 1)
    st, html, final = L.get(url)
    print("%s\t%s\tlen=%d\t%s" % (tag, st, len(html or ""), final))
    if not html:
        continue
    hp = os.path.join(BASE, "_h_%s.html" % tag)
    open(hp, "w", encoding="utf-8").write(html)
    ls = L.anchors(html, final)
    ap = os.path.join(BASE, "_a_%s.txt" % tag)
    with open(ap, "w", encoding="utf-8") as fh:
        for u, t in ls:
            fh.write("%s\t%s\n" % (t, u))
    print("   anchors", len(ls), "->", os.path.basename(ap))
