# -*- coding: utf-8 -*-
"""把各来源的 企业->城市 映射合并进 浙江省.csv，写出 浙江省_city.csv。
来源（全部为官方名单自带地区列/栏目）：
 1) parts/浙江省_宁波市.jsonl   证书编号 => 宁波市（innocom 宁波市认定机构栏目）
 2) parts/浙江省_stbrain.jsonl  企业名称 => 所在地(市/县)（浙江科技大脑名录清单）
 3) city_lists/*.csv           省/城市/区县（各设区市已抓名单）
 4) city_lists/_raw/*/rows.jsonl 同上 jsonl 版
规则：名称/证书精确匹配；同名指向不同城市 => 丢弃该名称（不猜）。
输出：cert_lists/_city_fill/浙江省_city.csv
"""
import os, sys, csv, json, re, collections

sys.stdout.reconfigure(encoding="utf-8")
WORK = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work"
CF = os.path.join(WORK, "cert_lists", "_city_fill")
SRC = os.path.join(WORK, "cert_lists", "浙江省.csv")
OUT = os.path.join(CF, "浙江省_city.csv")
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
CITIES = ["杭州市", "宁波市", "温州市", "嘉兴市", "湖州市", "绍兴市", "金华市",
          "衢州市", "舟山市", "台州市", "丽水市"]


def norm_name(s):
    s = (s or "").strip()
    s = s.replace("\u3000", "").replace(" ", "")
    s = s.replace("（", "(").replace("）", ")")
    s = s.replace("．", ".").replace("·", "")
    s = s.replace("股份有限公司", "股份公司")
    return s


def norm_city(raw):
    raw = (raw or "").strip()
    for c in CITIES:
        if raw == c or raw.startswith(c):
            return c
    return ""


def norm_cert(s):
    s = re.sub(r"[^0-9A-Za-z]", "", (s or "")).upper()
    return s


def split_area(raw):
    raw = (raw or "").strip()
    for c in CITIES:
        if raw.startswith(c):
            rest = raw[len(c):].strip()
            if rest in ("", "市辖区", "市本级", "市区", "本级", "县"):
                rest = ""
            return c, rest
    return "", ""


class Map:
    def __init__(self):
        self.by_cert = {}     # cert -> (city,county)
        self.by_name = {}     # name -> set((city,county))
        self.stat = collections.Counter()

    def add(self, cert, name, city, county, tag):
        city = norm_city(city)
        if not city:
            return
        county = (county or "").strip()
        c = norm_cert(cert)
        if c and len(c) >= 12:
            old = self.by_cert.get(c)
            if old is None:
                self.by_cert[c] = (city, county)
                self.stat[tag + ":cert"] += 1
            elif old[0] != city:
                self.by_cert[c] = None  # 冲突
        n = norm_name(name)
        if n and len(n) >= 4:
            self.by_name.setdefault(n, set()).add((city, county))

    def get(self, cert, name):
        c = norm_cert(cert)
        if c and c in self.by_cert and self.by_cert[c]:
            return self.by_cert[c]
        n = norm_name(name)
        v = self.by_name.get(n)
        if v and len({x[0] for x in v}) == 1:
            # 同城多个区县 => 取非空第一个
            cand = [x for x in v if x[1]]
            return (list(v)[0][0], cand[0][1] if cand else "")
        return None


def main():
    M = Map()
    # 1) 宁波
    p = os.path.join(CF, "parts", "浙江省_宁波市.jsonl")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            try:
                d = json.loads(line)
            except Exception:
                continue
            M.add(d.get("cert"), d.get("name"), d.get("city") or "宁波市", d.get("county"), "nb")
    # 2) stbrain
    p = os.path.join(CF, "parts", "浙江省_stbrain.jsonl")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            try:
                d = json.loads(line)
            except Exception:
                continue
            M.add("", d.get("name"), d.get("city"), d.get("county"), "stb")
    # 3) city_lists csv
    cl = os.path.join(WORK, "city_lists")
    for f in sorted(os.listdir(cl)):
        if not f.endswith(".csv"):
            continue
        fp = os.path.join(cl, f)
        try:
            with open(fp, encoding="utf-8-sig", newline="") as fh:
                r = csv.DictReader(fh)
                if not r.fieldnames or "企业名称" not in r.fieldnames:
                    continue
                for row in r:
                    if (row.get("省") or "").strip() not in ("浙江", "浙江省"):
                        continue
                    M.add(row.get("证书编号"), row.get("企业名称"), row.get("城市"), row.get("区县"), "cl")
        except Exception as e:
            print("skip", f, e)
    # 4) city_lists/_raw/*/rows.jsonl  (省,城市,区县,企业名称,证书编号,年度,批次,名单类型,URL)
    raw = os.path.join(cl, "_raw")
    if os.path.isdir(raw):
        for d1 in os.listdir(raw):
            fp = os.path.join(raw, d1, "rows.jsonl")
            if not os.path.exists(fp):
                continue
            for line in open(fp, encoding="utf-8", errors="replace"):
                try:
                    a = json.loads(line)
                except Exception:
                    continue
                if not isinstance(a, list) or len(a) < 5:
                    continue
                prov, city, county, name = a[0], a[1], a[2], a[3]
                cert = a[4] if len(a) > 4 else ""
                if (prov or "") not in ("浙江", "浙江省"):
                    continue
                M.add(cert, name, city, county, "raw")
    print("MAP cert=", len(M.by_cert), "name=", len(M.by_name), dict(M.stat), flush=True)

    rows = list(csv.DictReader(open(SRC, encoding="utf-8-sig", newline="")))
    print("main rows", len(rows), flush=True)
    out = []
    hit = 0
    for r in rows:
        name = (r.get("企业名称") or "").strip()
        cert = (r.get("证书编号") or "").strip()
        city = (r.get("城市") or "").strip()
        county = (r.get("区县") or "").strip()
        src = (r.get("来源URL") or "").strip()
        if not norm_city(city):
            g = M.get(cert, name)
            if g:
                city, county = g[0], (county or g[1])
                hit += 1
        out.append([name, cert, city, county, (r.get("认定年度") or "").strip(),
                    (r.get("批次") or "").strip(), src])
    with open(OUT, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(HEADER)
        w.writerows(out)
    filled = sum(1 for x in out if norm_city(x[2]))
    print("filled by map", hit, "total filled", filled, "/", len(out), flush=True)
    # 分年统计
    st = collections.defaultdict(lambda: [0, 0])
    for x in out:
        k = (x[4], x[5])
        st[k][0] += 1
        if norm_city(x[2]):
            st[k][1] += 1
    for k in sorted(st):
        print("  %-32s %6d/%6d" % (str(k), st[k][1], st[k][0]), flush=True)
    cc = collections.Counter(x[2] for x in out if norm_city(x[2]))
    print("city dist", cc.most_common(12), flush=True)
    print("OUT", OUT, flush=True)


if __name__ == "__main__":
    main()
