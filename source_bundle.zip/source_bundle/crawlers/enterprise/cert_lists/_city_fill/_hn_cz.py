﻿# -*- coding: utf-8 -*-
import os,sys,re,urllib.parse
sys.path.insert(0,os.getcwd())
import cf
u="https://www.czgxq.gov.cn/czgxq/c116280/listDisplaySon.shtml"
h,f=cf.get(u)
print(f,len(h) if h else None)
if h:
    t=re.search(r"<title>(.*?)</title>",h,re.S)
    print("TITLE",t.group(1).strip() if t else "?")
    n=0
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',h,re.S|re.I):
        tt=re.sub(r"<[^>]+>","",m.group(2)); tt=re.sub(r"\s+","",tt).strip()
        if tt and len(tt)>8:
            print("  ",tt[:60],"|",urllib.parse.urljoin(f,m.group(1))[:100]); n+=1
            if n>18: break
