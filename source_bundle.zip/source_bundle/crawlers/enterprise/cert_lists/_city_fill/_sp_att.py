# -*- coding: utf-8 -*-
"""看页面里 附件 附近的内容 + 所有含 pdf/doc/xls/zip 的 href。"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S

url = sys.argv[1]
sc, data, fin = S.H.get(url, timeout=30, tries=2, binary=True)
print("status", sc, "len", len(data or b""))
t = data.decode("utf-8", "ignore")
for m in re.finditer(r"附件[^<]{0,60}", t):
    print("ATT:", m.group(0)[:100])
for m in re.finditer(r"(?i)href=\"([^\"]+\.(?:pdf|doc|docx|xls|xlsx|zip|rar|wps))\"", t):
    print("DOC:", m.group(1)[:160])
for m in re.finditer(r"(?i)(download|fujian|附件)[^\"'<>]{0,40}", t):
    pass
# 正文里表格
print("tables:", len(S.parse_tables(t)))
for i, rows in enumerate(S.parse_tables(t)[:6]):
    print(" T%d rows=%d head=%s" % (i, len(rows), rows[0][:8] if rows else None))
