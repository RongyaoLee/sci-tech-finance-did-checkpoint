# -*- coding: utf-8 -*-
"""jpaas unit 接口：带 paramJson 翻页/全量测试。"""
import sys, json, re, requests
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import sd_jnz_lib as L

BASEURL = "http://jnsti.jinan.gov.cn/api-gateway/jpaas-publish-server/front/page/build/unit"
D = {"parseType": "bulidstatic", "webId": "10", "tplSetId": "GbnFskR3C7PD0nABf9KzT",
     "pageType": "column", "tagId": "信息列表", "editType": "null", "pageId": "13061"}
tests = [
    ("plain", {}),
    ("p1_s99999", {"pageNo": 1, "pageSize": 99999}),
    ("p2_s15", {"pageNo": 2, "pageSize": 15}),
    ("p3_s15", {"pageNo": 3, "pageSize": 15}),
    ("searchtag", {"pageNo": 99999, "pageSize": 99999, "search": json.dumps({"tagId": "信息列表"})}),
]
res = {}
for name, pj in tests:
    p = dict(D)
    if pj:
        p["paramJson"] = json.dumps(pj, ensure_ascii=False)
    u = BASEURL + "?" + "&".join("%s=%s" % (k, requests.utils.quote(str(v))) for k, v in p.items())
    st, body, final = L.get(u)
    arts = sorted(set(re.findall(r"col\d+/art/\d{4}/art_[0-9a-f]+\.html", body or "")))
    res[name] = {"url": u[:300], "st": st, "len": len(body or ""), "n": len(arts), "sample": arts[:3]}
    print("%-12s st=%s len=%d n=%d" % (name, st, len(body or ""), len(arts)))
    if arts:
        print("    first:", arts[0], " last:", arts[-1])
json.dump(res, open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_unit2.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
