# -*- coding: utf-8 -*-
import sys, json, urllib.parse
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import sd_jnz_lib as L

SITES = {
    "jinan": "https://www.jinan.gov.cn",
    "zibo": "https://www.zibo.gov.cn",
    "zaozhuang": "http://www.zaozhuang.gov.cn",
    "zbsti": "https://sti.zibo.gov.cn",
    "zzst": "http://zzst.zaozhuang.gov.cn",
}
Q = ["高新技术企业名单", "高新技术企业认定 公示"]
out = {}
for tag, base in SITES.items():
    out[tag] = {}
    for q in Q:
        url = base + "/api-gateway/jpaas-jsearch-web-server/search?q=" + urllib.parse.quote(q)
        st, body, final = L.get(url)
        out[tag][q] = {"url": url, "st": st, "final": final, "len": len(body or ""), "body": (body or "")[:3000]}
        print(tag, q, st, len(body or ""), final[:90])
json.dump(out, open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_search1.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
