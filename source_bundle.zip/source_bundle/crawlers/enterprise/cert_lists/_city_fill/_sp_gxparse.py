# -*- coding: utf-8 -*-
"""重写 广西 培育库 parts：docx 走表格；.doc 先代码列三元组，失败再用「名称紧邻地区」序列法。"""
import sys, os, re, glob, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
from _sp_doc import doc_pairs, doc_seq_pairs

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "raw", "gx_py")
P = "广西壮族自治区"
OUT = os.path.join(HERE, "parts", P + ".jsonl")
BASE = "http://kjt.gxzf.gov.cn/xxgk/gxkjgk/gxjsqy/gxgxjsqy/"
META = {
    "W020200323786329738931.doc": ("2019", "培育库第一批"),
    "W020200323786395067401.doc": ("2019", "培育库第二批"),
    "P020210512674266627262.doc": ("2021", "培育库第一批"),
    "P020221215659441721435.doc": ("2022", "培育库"),
    "P020230330587986285315.doc": ("2023", "培育库"),
    "P020250811675887139594.doc": ("2024", "培育库"),
    "P020211215415603759868.docx": ("2021", "培育库第二批"),
    "P020250811675896073222.docx": ("2025", "培育库第一批"),
    "P020250811673839318625.docx": ("2025", "培育库第二批"),
}

rows = []
for path in sorted(glob.glob(os.path.join(RAW, "*"))):
    fn = re.sub(r"^[0-9a-f]{8}_", "", os.path.basename(path))
    if fn not in META:
        continue
    y, b = META[fn]
    data = open(path, "rb").read()
    u = BASE + fn
    recs = []
    if data[:4] == b"PK\x03\x04":
        recs = S.extract_from_tables(S.doc_tables(u, data), P, src=u, year=y, batch=b, require_city=True)
    if not recs and data[:4] == b"\xd0\xcf\x11\xe0":
        for name, code, city in doc_pairs(data):
            c = S.norm_city(P, city)
            if c:
                recs.append({"name": name, "cert": code, "city": c, "county": "",
                             "year": y, "batch": b, "src": u})
        if len(recs) < 50:
            recs = []
            for name, code, city in doc_seq_pairs(data, P):
                recs.append({"name": name, "cert": code, "city": city, "county": "",
                             "year": y, "batch": b, "src": u})
    print("%-34s %-6s %-12s %5d" % (fn, y, b, len(recs)), flush=True)
    rows += recs

# 与既有 parts 合并（保留来自 docx 的旧记录不重复）
old = []
if os.path.exists(OUT):
    for line in open(OUT, encoding="utf-8"):
        line = line.strip()
        if line:
            try:
                old.append(json.loads(line))
            except Exception:
                pass
key = lambda r: (r.get("name"), r.get("city"), r.get("year"), r.get("batch"))
seen = set(key(r) for r in rows)
merged = rows + [r for r in old if key(r) not in seen]
with open(OUT, "w", encoding="utf-8") as f:
    for r in merged:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")
print("parts rows", len(merged))
