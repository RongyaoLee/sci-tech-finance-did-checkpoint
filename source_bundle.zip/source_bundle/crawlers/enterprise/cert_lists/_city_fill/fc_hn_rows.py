# -*- coding: utf-8 -*-
"""湖南: extract (企业名称, 证书编号, 区县) rows from 市州 财政/科技 pages.

Usage: python fc_hn_rows.py spec.json
spec.json = [{"url":..., "city":"长沙市", "tag":"..."}, ...]
Inline HTML tables (rowspan-aware) AND attachments (pdf/xlsx/xls/docx) are parsed.
"""
import os, sys, re, json, io, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup
from tblgrid import grid_of, clean

FILL = os.path.dirname(os.path.abspath(__file__))
ROWS = os.path.join(FILL, "rows_湖南_shizhou.jsonl")
LOG = os.path.join(FILL, "_hn_rows.log")

NAME_KEYS = ("企业名称", "企业 名称", "单位名称", "申报单位", "企业(名称)", "公司名称")
CERT_H = ("证书编号", "高企证书", "证书号")
CNTY_H = ("区县市", "区县", "所属区域", "所在区县", "县市区", "所在区域", "区域", "所属区县", "县（市、区）", "所在地")
CITY_H = ("地市", "所在市", "设区市", "市州", "所属市")
BIZ = re.compile(r"(公司|企业|厂|中心|院|所|合作社|集团|工作室|学校|大学|医院)")


def log(m):
    line = time.strftime("%H:%M:%S ") + str(m)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line, flush=True)


def find_col(cells, keys, exclude=()):
    for j, c in enumerate(cells):
        if any(k in c for k in keys) and not any(e in c for e in exclude):
            return j
    return None


def parse_rows2d(rows2d, city_default):
    hdr_i, cmap = None, None
    for i, r in enumerate(rows2d[:20]):
        cells = [clean(c) for c in r]
        joined = "|".join(cells)
        if any(k in joined for k in NAME_KEYS):
            nm = find_col(cells, NAME_KEYS)
            if nm is None:
                nm = find_col(cells, ("企业", "单位"), exclude=("类型", "性质"))
            if nm is None:
                continue
            hdr_i = i
            cmap = {"name": nm,
                    "cnty": find_col(cells, CNTY_H, exclude=("类型", "性质", "范围", "类别")),
                    "cert": find_col(cells, CERT_H),
                    "city": find_col(cells, CITY_H)}
            break
    if hdr_i is None:
        return []
    out = []
    for r in rows2d[hdr_i + 1:]:
        cells = [clean(c) for c in r]
        if len(cells) <= cmap["name"]:
            continue
        name = cells[cmap["name"]]
        if not name or name in ("企业名称", "单位名称", "合计", "小计", "总计"):
            continue
        if re.fullmatch(r"[\d,.\s%-]+", name):
            continue
        if not BIZ.search(name) or len(name) < 4:
            continue
        def col(key):
            j = cmap[key]
            return cells[j] if j is not None and j < len(cells) else ""
        cnty, cert, city = col("cnty"), col("cert"), col("city")
        out.append({"name": name, "city": (city or city_default).strip(),
                    "county": cnty.strip(), "cert": cert.strip()})
    return out


def tables_of_html(html):
    soup = BeautifulSoup(html, "lxml")
    res = []
    for tb in soup.find_all("table"):
        try:
            g = grid_of(tb)
        except Exception:
            continue
        if len(g) >= 3:
            res.append(g)
    return res


def doc_rows(path, city_default):
    ext = os.path.splitext(path)[1].lower()
    out = []
    try:
        if ext in (".xlsx", ".xlsm"):
            import openpyxl
            wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
            for ws in wb.worksheets:
                rows2d = [[clean(v) for v in row] for row in ws.iter_rows(values_only=True)]
                out.extend(parse_rows2d(rows2d, city_default))
        elif ext == ".xls":
            import xlrd
            wb = xlrd.open_workbook(path)
            for sh in wb.sheets():
                rows2d = [[clean(sh.cell_value(r, c)) for c in range(sh.ncols)] for r in range(sh.nrows)]
                out.extend(parse_rows2d(rows2d, city_default))
        elif ext == ".docx":
            import docx
            d = docx.Document(path)
            for tb in d.tables:
                rows2d = [[clean(c.text) for c in r.cells] for r in tb.rows]
                out.extend(parse_rows2d(rows2d, city_default))
        elif ext == ".pdf":
            out.extend(pdf_rows_cols(path, city_default))
        elif ext == ".doc":
            out.extend(doc_rows2d(path, city_default))
    except Exception as e:
        log("    parse ERR %s: %s" % (os.path.basename(path), e))
    return out


def doc_rows2d(path, city_default):
    """Word97 .doc via docparse: rebuild a 2-D grid from the \\x07-delimited cell stream."""
    import docparse
    txt = docparse.doc_text(path)
    cells = docparse.cells_of(txt)
    # locate header: a window whose joined text hits 企业名称/单位 and a 序号-like cell
    hi, ncol = None, None
    for i in range(min(len(cells), 400)):
        if any(k in cells[i] for k in NAME_KEYS):
            head = [c for c in cells[max(0, i - 2):i + 8]]
            hi = i
            break
    if hi is None:
        return []
    # column count: walk forward from header until the next pure-number cell
    j = hi + 1
    ncol = 0
    while j < len(cells) and not re.fullmatch(r"\d{1,6}", cells[j]):
        ncol += 1
        j += 1
        if ncol > 14:
            break
    if not ncol:
        return []
    ncol += 1  # include the 序号 cell itself
    rows2d, cur = [], []
    for c in cells[hi:]:
        cur.append(c)
        if len(cur) == ncol:
            rows2d.append(cur)
            cur = []
    return parse_rows2d(rows2d, city_default)


CERT_RE = re.compile(r"^(GR\d{9,}|GR\d+)$")


def pdf_rows_cols(path, city_default):
    """Column-model PDF parser: uses the GR certificate token as an anchor.

    Line = [序号] 企业名称... GRxxxx 区县 ...
    """
    import pymupdf
    d = pymupdf.open(path)
    out = []
    for pno in range(d.page_count):
        words = d[pno].get_text("words")
        if not words:
            continue
        lines = {}
        for w in words:
            lines.setdefault(round(w[1] / 4), []).append(w)
        for k in sorted(lines):
            ws = sorted(lines[k], key=lambda x: x[0])
            toks = [w[4] for w in ws]
            ci = None
            for j, t in enumerate(toks):
                if CERT_RE.match(t.replace(" ", "")):
                    ci = j
                    break
            if ci is None:
                continue
            left = toks[:ci]
            if left and re.fullmatch(r"\d{1,5}[.、]?", left[0]):
                left = left[1:]
            name = "".join(left)
            if not BIZ.search(name) or len(name) < 4:
                continue
            right = toks[ci + 1:]
            county = right[0] if right else ""
            if re.fullmatch(r"(首次认定|重新认定|复审|复评)", county):
                county = ""
            out.append({"name": name, "city": city_default,
                        "county": county, "cert": toks[ci]})
    return out


def main():
    spec = json.load(io.open(sys.argv[1], encoding="utf-8"))
    if not os.path.exists(LOG):
        open(LOG, "w", encoding="utf-8").close()
    tot = 0
    with io.open(ROWS, "a", encoding="utf-8") as fout:
        for it in spec:
            url, city = it["url"], it["city"]
            log("== %s | %s" % (city, url))
            html, final = cf.get(url)
            if not html:
                log("   FETCH FAIL")
                continue
            got = 0
            for ti, rows2d in enumerate(tables_of_html(html)):
                rows = parse_rows2d(rows2d, city)
                if rows:
                    log("   inline table%d -> %d rows" % (ti, len(rows)))
                    for r in rows:
                        fout.write(json.dumps(dict(r, src=url, tag=it.get("tag", "")),
                                               ensure_ascii=False) + "\n")
                    got += len(rows)
            for text, u in cf.attachments(url, html):
                p = cf.download(u, "hn")
                if not p:
                    log("   dl FAIL %s" % u)
                    continue
                rows = doc_rows(p, city)
                log("   att %-44s %s -> %d" % (text[:44], os.path.splitext(p)[1], len(rows)))
                for r in rows:
                    fout.write(json.dumps(dict(r, src=url, tag=it.get("tag", ""),
                                               att=os.path.basename(u)), ensure_ascii=False) + "\n")
                got += len(rows)
            fout.flush()
            tot += got
            log("   +%d (accum %d)" % (got, tot))
    log("DONE %d rows -> %s" % (tot, ROWS))


if __name__ == "__main__":
    main()
