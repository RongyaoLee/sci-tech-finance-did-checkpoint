﻿# -*- coding: utf-8 -*-
"""浙江省_city.csv 组装器 v2：在 v1 基础上加强名称匹配（只增城市，不猜城市）。

v1 规则：证书精确 + 名称精确（同城唯一才用）。
v2 追加：
  A) 名称变体双向归一（全半角、括号、股份公司/有限公司、空白、点号）
  B) 核心名（去掉括号内容与公司类后缀）—— 只允许唯一城市时采用，且只写城市不写区县
  C) 区县也来自名单自带列；冲突则留空
所有映射 100% 来自官方名单自带地区列，不做编号反推。
"""
import os, sys, csv, json, re, collections

sys.stdout.reconfigure(encoding="utf-8")
WORK = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work"
CF = os.path.join(WORK, "cert_lists", "_city_fill")
SRC = os.path.join(WORK, "cert_lists", "浙江省.csv")
OUT = os.path.join(CF, "浙江省_city.csv")
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
# 区县→地级市 的确定性行政区划表（来自同目录 zj_mirror.py），用于剔除内部矛盾的「城市+区县」
try:
    _spec = __import__("importlib.util", fromlist=["util"]).spec_from_file_location(
        "_zm", os.path.join(os.path.dirname(os.path.abspath(__file__)), "zj_mirror.py"))
    _zm = __import__("importlib.util", fromlist=["util"]).module_from_spec(_spec)
    _spec.loader.exec_module(_zm)
    COUNTY2CITY = _zm.COUNTY2CITY
except Exception:
    COUNTY2CITY = {}
CITIES = ["杭州市", "宁波市", "温州市", "嘉兴市", "湖州市", "绍兴市", "金华市",
          "衢州市", "舟山市", "台州市", "丽水市"]
SUFFIX = ["股份有限公司", "有限责任公司", "有限公司", "股份公司", "集团有限公司",
          "集团有限责任公司", "公司", "集团", "厂", "研究院", "研究所", "中心"]
PAREN = re.compile(r"\([^()]*\)|（[^（）]*）")
SEQ = re.compile(r"^\d{2,6}(?=[\u4e00-\u9fff])")


def clean_name(s):
    """去掉源表里粘连的序号前缀（2019 年 5159 行是 「1000杭州齐圣科技有限公司」 这种）。"""
    n = (s or "").strip()
    m = SEQ.match(n)
    if m:
        n = n[m.end():].strip()
    return n


def norm_name(s):
    s = (s or "").strip()
    s = s.replace("\u3000", "").replace(" ", "").replace("\t", "")
    s = s.replace("（", "(").replace("）", ")")
    s = s.replace("．", ".").replace("·", "").replace("•", "")
    s = s.replace("股份有限公司", "股份公司")
    return s


def core_name(s):
    n = norm_name(s)
    n = PAREN.sub("", n)
    changed = True
    while changed:
        changed = False
        for suf in SUFFIX:
            if n.endswith(suf) and len(n) - len(suf) >= 4:
                n = n[: -len(suf)]
                changed = True
    return n


def variants(s):
    """查询侧候选：原名 / 去括号 / 核心名"""
    out = []
    n = norm_name(s)
    if n:
        out.append(n)
    p = PAREN.sub("", n)
    if p and p not in out:
        out.append(p)
    c = core_name(s)
    if c and c not in out:
        out.append(c)
    return out


def norm_city(raw):
    raw = (raw or "").strip()
    for c in CITIES:
        if raw == c or raw.startswith(c):
            return c
    return ""


def norm_cert(s):
    return re.sub(r"[^0-9A-Za-z]", "", (s or "")).upper()


def split_area(raw):
    raw = (raw or "").strip()
    for c in CITIES:
        if raw.startswith(c):
            rest = raw[len(c):].strip()
            if rest in ("", "市辖区", "市本级", "市区", "本级", "县"):
                rest = ""
            return c, rest
    return "", ""


class Map:
    def __init__(self):
        self.by_cert = {}
        self.by_name = {}   # norm name -> set((city,county))
        self.by_core = {}   # core name -> set(city)
        # 省科技型中小企业名单（各市局发布，自带「区县市」列）→ 仅作兜底来源，
        # 因为它是另一类认定，重名率高于高企；只在 cert/name/core 全部未命中时使用。
        self.by_sme = {}
        self.stat = collections.Counter()

    def add(self, cert, name, city, county, tag):
        city = norm_city(city)
        if not city:
            return
        county = (county or "").strip()
        c = norm_cert(cert)
        if c and len(c) >= 12:
            old = self.by_cert.get(c)
            if old is None:
                self.by_cert[c] = (city, county)
                self.stat[tag + ":cert"] += 1
            elif old[0] != city:
                self.by_cert[c] = None
        n = norm_name(name)
        if n and len(n) >= 4:
            self.by_name.setdefault(n, set()).add((city, county))
            p = PAREN.sub("", n)
            if p and p != n:
                self.by_name.setdefault(p, set()).add((city, county))
        k = core_name(name)
        if k and len(k) >= 4:
            self.by_core.setdefault(k, set()).add(city)

    def get_cert(self, cert):
        c = norm_cert(cert)
        if c and len(c) >= 12:
            return self.by_cert.get(c)
        return None

    def add_sme(self, name, city, county):
        city = norm_city(city)
        n = norm_name(name)
        if not city or not n or len(n) < 4:
            return
        self.by_sme.setdefault(n, set()).add((city, (county or "").strip()))

    def get_sme(self, name):
        for v in variants(name):
            s = self.by_sme.get(v)
            if s and len({x[0] for x in s}) == 1:
                city = list(s)[0][0]
                # 企业名自带另一个市名却落到本市 → 扫描页里的分组标题/串行会造成错配
                # （实测 14/25780，均出现在义乌/永康这类县级市名单页），一律不采用
                n = norm_name(name)
                for c in CITIES:
                    if c != city and n.startswith(c[:2]):
                        if n.startswith("杭州湾"):
                            break
                        self.stat["sme_prefix_conflict"] += 1
                        return None
                cand = [x[1] for x in s if x[1]]
                return (city, cand[0] if cand else "")
        return None

    def get_name(self, name):
        for v in variants(name):
            s = self.by_name.get(v)
            if s and len({x[0] for x in s}) == 1:
                cand = [x[1] for x in s if x[1]]
                return (list(s)[0][0], cand[0] if cand else "")
        k = core_name(name)
        if k and len(k) >= 4:
            cs = self.by_core.get(k)
            if cs and len(cs) == 1:
                return (list(cs)[0], "")
        return None

    def get(self, cert, name):
        """证书键与名称键冲突时以名称为准：城市分文件抓的 name_lists 里证书列存在错位
        （实测 绍兴市.csv 把 GR202333013196 挂在「浙江扬帆新材料」名下，而主表该证书是
        「杭州余杭振华日化玻璃」），名称自带识别性更强。"""
        c1 = self.get_cert(cert)
        c2 = self.get_name(name)
        if c1 and c2 and c1[0] != c2[0]:
            self.stat["cert_name_conflict"] += 1
            return c2
        return c1 or c2


def load_map():
    M = Map()
    p = os.path.join(CF, "parts", "浙江省_宁波市.jsonl")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            try:
                d = json.loads(line)
            except Exception:
                continue
            M.add(d.get("cert"), d.get("name"), d.get("city") or "宁波市", d.get("county"), "nb")
    p = os.path.join(CF, "parts", "浙江省_stbrain.jsonl")
    stb = {}
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            try:
                d = json.loads(line)
            except Exception:
                continue
            M.add("", d.get("name"), d.get("city"), d.get("county"), "stb")
            n = norm_name(d.get("name"))
            c = norm_city(d.get("city"))
            if n and c:
                stb.setdefault(n, set()).add(c)
    cl = os.path.join(WORK, "city_lists")
    # 省级高新技术企业研究开发中心名录（code=RC）：依托单位即企业，地址首段含市/县
    p = os.path.join(CF, "parts", "浙江省_stbrain_RC.jsonl")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            try:
                d = json.loads(line)
            except Exception:
                continue
            M.add("", d.get("name"), d.get("city"), d.get("county"), "rc")
            n = norm_name(d.get("name"))
            c = norm_city(d.get("city"))
            if n and c:
                stb.setdefault(n, set()).add(c)
    dropped = collections.Counter()
    for f in sorted(os.listdir(cl)):
        if not f.endswith(".csv"):
            continue
        try:
            with open(os.path.join(cl, f), encoding="utf-8-sig", newline="") as fh:
                r = csv.DictReader(fh)
                if not r.fieldnames or "企业名称" not in r.fieldnames:
                    continue
                for row in r:
                    if (row.get("省") or "").strip() not in ("浙江", "浙江省"):
                        continue
                    nm, cty, cou = row.get("企业名称"), norm_city(row.get("城市")), (row.get("区县") or "").strip()
                    # 一致性闸门：city_lists 是按市分文件抓的，翻页越界会把邻市条目带进来
                    # （实测 city_lists\金华市.csv 混入 19~24 条杭州企业，城市列停在「金华市」、
                    #  区县列却是「杭州市」/「杭州市滨江区」）。两种错配一律丢弃，不参与建映射。
                    c2 = norm_city(cou)
                    if c2 and c2 != cty:
                        dropped["county_is_other_city:" + f] += 1
                        continue
                    n2 = norm_name(nm)
                    if n2 in stb and cty and cty not in stb[n2]:
                        dropped["contradict_stbrain:" + f] += 1
                        continue
                    # 企业名前缀自带另一个市名，却被放在按市分的文件里 → 越界条目（如绍兴市.csv
                    # 里出现「杭州余杭振华日化玻璃有限公司」且区县为空，逃过了上一道闸门）
                    pre = ""
                    for cc in CITIES:
                        if (nm or "").startswith(cc[:2]):
                            pre = cc
                            break
                    if pre and cty and pre != cty:
                        dropped["name_prefix_city:" + f] += 1
                        continue
                    M.add(row.get("证书编号"), nm, cty, cou, "cl")
        except Exception as e:
            print("skip", f, e)
    if dropped:
        print("DROPPED city_lists rows %d %s" % (sum(dropped.values()), dict(dropped)), flush=True)
    # raw 源（city_lists\_raw\<市>\rows.jsonl）已停用：实测按目录名当城市不可靠，
    # _raw\嘉兴市 8.3%、_raw\金华市 7.6% 的行其企业名自带另一个市的名字（如
    # '舟山遨拓海洋工程技术有限公司' 被归到金华、来源URL 却是 zskjj.zhoushan.gov.cn），
    # 属跨市 dump 错配。为满足「不许猜测城市」，整类弃用（仅损失 429 个证书键）。
    USE_RAW = False
    raw = os.path.join(cl, "_raw")
    if USE_RAW and os.path.isdir(raw):
        for d1 in os.listdir(raw):
            fp = os.path.join(raw, d1, "rows.jsonl")
            if not os.path.exists(fp):
                continue
            for line in open(fp, encoding="utf-8", errors="replace"):
                try:
                    a = json.loads(line)
                except Exception:
                    continue
                if not isinstance(a, list) or len(a) < 5:
                    continue
                if (a[0] or "") not in ("浙江", "浙江省"):
                    continue
                M.add(a[4], a[3], a[1], a[2], "raw")
        # 省科技型中小企业认定名单（各市局 PDF / 聚合站镜像整表）→ 兜底索引
    p = os.path.join(CF, "parts", "浙江省_sme.jsonl")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            try:
                d = json.loads(line)
            except Exception:
                continue
            M.add_sme(d.get("name"), d.get("city"), d.get("county"))
    # 附加：cert_lists/浙江_2016 等历史文件若带城市列
    return M


def main():
    M = load_map()
    print("MAP cert=%d name=%d core=%d sme=%d %s" % (len(M.by_cert), len(M.by_name), len(M.by_core), len(M.by_sme), dict(M.stat)), flush=True)
    rows = list(csv.DictReader(open(SRC, encoding="utf-8-sig", newline="")))
    print("main rows", len(rows), flush=True)
    out, hit, fixed, hit_sme = [], 0, 0, 0
    for r in rows:
        raw_name = (r.get("企业名称") or "").strip()
        name = clean_name(raw_name)
        cert = (r.get("证书编号") or "").strip()
        city = (r.get("城市") or "").strip()
        county = (r.get("区县") or "").strip()
        g = M.get(cert, name)
        if not g:
            g = M.get_sme(name)
            if g:
                hit_sme += 1
        if g:
            if not norm_city(city):
                city = g[0]
                county = county or g[1]
                hit += 1
            elif norm_city(city) != g[0]:
                # 源表 13,833 个历史城市值里混入了 city_lists\金华市.csv 的翻页越界块
                # （艾*/阿里/UT斯达康 等 28 行被标成金华市），以官方名录的所在地/地址为准改回
                fixed += 1
                city = g[0]
                if not county or norm_city(county):
                    county = g[1]
        if county and COUNTY2CITY.get(county) not in (None, norm_city(city)):
            county = ""   # 源表自带值里 4 行城市/区县互斥（如 嘉兴市 + 萧山区），区县留空
            fixed += 1
        out.append([name, cert, city, county, (r.get("认定年度") or "").strip(),
                    (r.get("批次") or "").strip(), (r.get("来源URL") or "").strip()])
    with open(OUT, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(HEADER)
        w.writerows(out)
    filled = sum(1 for x in out if norm_city(x[2]))
    print("filled by sme", hit_sme, flush=True)
    print("filled by map", hit, "total filled", filled, "/", len(out),
          "%.1f%%" % (100.0 * filled / len(out)), flush=True)
    st = collections.defaultdict(lambda: [0, 0])
    for x in out:
        k = (x[4], x[5])
        st[k][0] += 1
        if norm_city(x[2]):
            st[k][1] += 1
    for k in sorted(st):
        print("  %-32s %6d/%6d" % (str(k), st[k][1], st[k][0]), flush=True)
    cc = collections.Counter(x[2] for x in out if norm_city(x[2]))
    print("city dist", cc.most_common(12), flush=True)
    co = sum(1 for x in out if x[3].strip())
    print("county filled", co, flush=True)
    print("OUT", OUT, flush=True)


if __name__ == "__main__":
    main()
