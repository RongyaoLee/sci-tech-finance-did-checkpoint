# -*- coding: utf-8 -*-
"""石家庄市科技局 / 唐山科技局 栏目枚举：找含「高新」的名单页。"""
import io, sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
SITES = {
    'sjz': 'http://kjj.sjz.gov.cn/',
    'ts': 'http://kejiju.tangshan.gov.cn/',
}

for key, home in SITES.items():
    st, txt, fu = H.get(home, timeout=30)
    print('==', key, st, len(txt or ''), fu)
    if st != 200:
        continue
    links = re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', txt, re.S)
    seen = set()
    for href, label in links:
        lab = re.sub(r'<[^>]+>', '', label)
        lab = re.sub(r'\s+', '', lab)
        if not lab or len(lab) > 20:
            continue
        if any(k in lab for k in ('通知', '公告', '公示', '高新', '动态', '文件', '信息公开')):
            if href in seen:
                continue
            seen.add(href)
            print('  ', lab, '->', href[:90])
