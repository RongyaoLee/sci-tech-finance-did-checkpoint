# -*- coding: utf-8 -*-
import csv, collections, os
CF = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill'
for f in ('陕西省_city.csv', '山西省_city.csv'):
    p = os.path.join(CF, f)
    rows = list(csv.reader(open(p, encoding='utf-8-sig', newline='')))
    hdr, body = rows[0], rows[1:]
    n = len(body)
    city = sum(1 for r in body if r[2].strip())
    cty = sum(1 for r in body if r[3].strip())
    byyear = collections.defaultdict(lambda: [0, 0])
    for r in body:
        y = r[4]
        byyear[y][0] += 1
        if r[2].strip():
            byyear[y][1] += 1
    print('=====', f, os.path.getsize(p) // 1024, 'KB')
    print('  hdr', hdr)
    print(f'  rows={n} city={city} ({city/n*100:.1f}%) county={cty} ({cty/n*100:.1f}%)')
    print('  by year (rows/filled):', {k: tuple(v) for k, v in sorted(byyear.items())})
    print('  sample:', body[0], body[-1])
