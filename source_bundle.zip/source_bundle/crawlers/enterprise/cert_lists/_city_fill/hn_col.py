﻿# -*- coding: utf-8 -*-
"""Crawl a TRS-style column, find 高新技术企业 articles."""
import os,sys,re,json,urllib.parse
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,HERE); sys.path.insert(0,os.path.dirname(HERE))
import cf, fetch_common as F

def arts(h,base):
    out=[]
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',h,re.S|re.I):
        u=urllib.parse.urljoin(base,m.group(1)); t=re.sub(r"<[^>]+>","",m.group(2)); t=re.sub(r"\s+","",t).strip()
        out.append((t,u))
    return out

def crawl(col,city,pages=25,pat=r"高新技术企业|高企"):
    hits={}
    for i in range(pages):
        u=col+("index.html" if i==0 else "index_%d.html"%i)
        h,f=cf.get(u)
        if not h: break
        n=0
        for t,uu in arts(h,f):
            if re.search(pat,t) and re.search(r"名单|公示|公布|认定|备案|证书|推荐|奖励|补助|奖补",t):
                if uu not in hits: hits[uu]=t; n+=1
        if n==0 and i>3: break
    print(city,"hits",len(hits),flush=True)
    return hits

if __name__=="__main__":
    col=sys.argv[1]; city=sys.argv[2]; pg=int(sys.argv[3]) if len(sys.argv)>3 else 25
    h=crawl(col,city,pg)
    out={}
    for u,t in h.items():
        print("  ",t[:66],"|",u[:110])
        out[u]=t
    json.dump(out,open(os.path.join(HERE,"_hn_col_%s.json"%city),"w",encoding="utf-8"),ensure_ascii=False,indent=1)
