# -*- coding: utf-8 -*-
"""稳健名称抽取：兼容 序号/名称/证书号 竖排、证书号在前、序号与名称同排 三类版式。"""
import re

CERT_RE = re.compile(r"GR\d{12}")
SUF = r"(?:股份有限公司|有限责任公司|有限公司|公司|分公司|厂|中心|研究院|研究所|设计院|集团|事务所|学校|医院|合作社|社|院|所|站)"
NAME_RE = re.compile(r"^[\u4e00-\u9fff（）()·&\-A-Za-z0-9]{2,34}" + SUF + r"$")
HDR = {"序号", "企业名称", "证书编号", "附件", "名单", "备案", "公示", "公告", "复函", "补充备案名单",
       "发证日期", "合计"}


def _clean(s):
    s = s.replace("\x07", " ").replace("\x0c", " ")
    s = re.sub(r"[\x00-\x1f]", "", s)
    s = re.sub(r"\s+", "", s)
    s = re.sub(r"^[\d\.、]+", "", s)
    s = re.sub(r"[\d\.、]+$", "", s) if not re.search(r"(公司|厂|中心|院|所|集团|社|站)$", s) else s
    return s.strip()


def _valid(s):
    if not s or len(s) < 4 or len(s) > 40:
        return False
    if s in HDR or "GR" in s or "证书" in s or "企业名称" in s:
        return False
    if len(re.findall(r"\d", s)) > 4:
        return False
    return bool(NAME_RE.match(s))


def extract(txt):
    """返回 [(cert, name)]，按文本顺序（可能重复，调用方去重）。"""
    raw = txt.replace("\x07", "\n")
    lines = [re.sub(r"[ \t\u00a0]+", " ", l).strip() for l in raw.split("\n")]
    lines = [l for l in lines if l]
    out = []
    for i, L in enumerate(lines):
        ms = list(CERT_RE.finditer(L))
        if not ms:
            continue
        for m in ms:
            cert = m.group(0)
            post = L[m.end():].strip()
            pre = L[:m.start()].strip()
            cands = [_clean(post), _clean(pre)]
            for d in (1, 2):
                if i - d >= 0:
                    cands.append(_clean(lines[i - d]))
                if i + d < len(lines):
                    cands.append(_clean(lines[i + d]))
            # 跨行拼接（长名称换行）
            for d in (1, 2):
                if i - d - 1 >= 0 and i - d >= 0:
                    cands.append(_clean(lines[i - d - 1] + lines[i - d]))
                if i + d + 1 < len(lines):
                    cands.append(_clean(lines[i + d] + lines[i + d + 1]))
            name = ""
            for c in cands:
                if _valid(c):
                    name = c
                    break
            out.append((cert, name))
    return out
