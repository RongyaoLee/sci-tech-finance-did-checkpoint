# -*- coding: utf-8 -*-
"""Inspect a page's raw HTML: title, tables, and every candidate download link."""
import os, sys, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

EXT = re.compile(r"\.(pdf|xlsx?|docx?|wps|et|zip|rar|csv)(\?|$)", re.I)


def inspect(url):
    print("=" * 78)
    print(url)
    html, final = cf.get(url)
    if not html:
        print("  FETCH FAIL")
        return
    print("  final:", final, "len:", len(html))
    soup = BeautifulSoup(html, "lxml")
    print("  title:", soup.title.get_text(strip=True) if soup.title else "")
    for i, tb in enumerate(soup.find_all("table")[:4]):
        rows = tb.find_all("tr")
        print("  table%d rows=%d" % (i, len(rows)))
        for tr in rows[:4]:
            cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
            print("     ", " | ".join(cells)[:200])
    for a in soup.find_all("a", href=True):
        h = a["href"]
        t = a.get_text(" ", strip=True)
        if EXT.search(h) or "download" in h.lower() or "attach" in h.lower() or EXT.search(t):
            print("  LINK:", t[:50], "->", urllib.parse.urljoin(final or url, h))


if __name__ == "__main__":
    for u in sys.argv[1:]:
        inspect(u)
