# -*- coding: utf-8 -*-
"""Probe 湖南省政府统一搜索 for a cross-site query and print hit titles/urls."""
import sys, os, re, json, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

Q = sys.argv[1] if len(sys.argv) > 1 else "高新技术企业 补助 名单"
BASES = [
    "https://searching.hunan.gov.cn/hunan/all/news?q=%s",
    "https://searching.hunan.gov.cn/hunan/news?q=%s",
    "http://searching.hunan.gov.cn/hunan/all/news?q=%s",
]
qq = urllib.parse.quote(Q)
for b in BASES:
    u = b % qq
    html, final = cf.get(u, use_cache=False)
    print("=" * 70)
    print(u, "->", (final or "")[:90], "len", len(html) if html else 0)
    if not html:
        continue
    soup = BeautifulSoup(html, "lxml")
    print("title:", soup.title.get_text(strip=True) if soup.title else None)
    n = 0
    for a in soup.find_all("a", href=True):
        t = a.get_text(" ", strip=True)
        if len(t) >= 10 and re.search(r"高新技术企业|高企", t):
            print("  ", t[:70], "|", a["href"][:110])
            n += 1
            if n >= 12:
                break
    print("  hits", n)
