# -*- coding: utf-8 -*-
"""温州/衢州/舟山 市政府门户 + 金华科技局 首页探测：找科技局频道与高企相关链接"""
import sys, re, json
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

TARGETS = [
    ("wenzhou", "http://www.wenzhou.gov.cn/"),
    ("quzhou", "http://www.qz.gov.cn/"),
    ("zhoushan", "http://www.zhoushan.gov.cn/"),
    ("jinhua_kjj", "http://kjj.jinhua.gov.cn/"),
]

pat = re.compile(r"科技|高新|公示|公告|通知|公开")
out = {}
for tag, url in TARGETS:
    sc, html, final = H.get(url, timeout=25, tries=2)
    print("=== %s %s -> %s len=%d" % (tag, url, sc, len(html or "")), flush=True)
    rec = {"status": sc, "final": final, "n": len(html or ""), "links": []}
    if sc == 200 and html:
        seen = set()
        for href, txt in H.img_links(html, final):
            if not txt or len(txt) > 60:
                continue
            if pat.search(txt):
                k = (href, txt)
                if k in seen:
                    continue
                seen.add(k)
                rec["links"].append([href, txt])
        H.save_raw(tag + "_home", url, html.encode("utf-8", "ignore"))
    out[tag] = rec
    for href, txt in rec["links"][:60]:
        print("   ", txt, "|", href, flush=True)

with open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_zj_probe_wz.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("done")
