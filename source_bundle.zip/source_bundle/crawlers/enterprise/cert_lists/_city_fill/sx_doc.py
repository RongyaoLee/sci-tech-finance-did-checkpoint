# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import cf
import fetch_common as FC

u = "https://kjt.shaanxi.gov.cn/kjdt/tzgg/202211/P020250118832220573989.doc"
p = cf.download(u, "sx_gongbu2022")
print("saved", p, os.path.getsize(p) if p and os.path.exists(p) else 0)
if p:
    try:
        for fn in ("rows_from_doc", "rows_from_docx", "rows_from_pdf"):
            if hasattr(FC, fn):
                r = getattr(FC, fn)(p)
                print(fn, "rows", len(r), r[:5])
    except Exception as e:
        print("ERR", repr(e)[:300])
    # raw sniff
    with open(p, "rb") as f:
        b = f.read(400)
    print("head", b[:200])
