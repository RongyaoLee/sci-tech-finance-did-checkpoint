# -*- coding: utf-8 -*-
"""石家庄市科技局 政策文件 2019-2025 各年栏目：找含「高新」条目。"""
import io, sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

YEARS = {
 '2025': 'http://kjj.sjz.gov.cn/columns/a218ffd8-98d7-4a7c-a507-4bccedca9f32/index.html',
 '2024': 'http://kjj.sjz.gov.cn/columns/7c2b8d66-225b-44e9-a73c-acff296adbd8/index.html',
 '2023': 'http://kjj.sjz.gov.cn/columns/b9253570-d4cc-4d24-9694-a0f382201453/index.html',
 '2022': 'http://kjj.sjz.gov.cn/columns/08cfa893-8000-46d2-8c01-35cf75e7a0b1/index.html',
 '2021': 'http://kjj.sjz.gov.cn/columns/0a64e947-3939-4cb1-9f1a-92b8f7de6e36/index.html',
 '2020': 'http://kjj.sjz.gov.cn/columns/b049ff1d-a333-43b5-8abf-b2a1ebfa1000/index.html',
 '2019': 'http://kjj.sjz.gov.cn/columns/aadafd42-01f3-421b-845c-c9361413330d/index.html',
}
out = {}
for y, u in YEARS.items():
    st, txt, fu = H.get(u, timeout=30)
    items = re.findall(r'<a[^>]+href="([^"]+)"[^>]*title="([^"]*)"', txt or '')
    if not items:
        items = [(h, re.sub(r'<[^>]+>', '', t)) for h, t in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', txt or '', re.S)]
    hits = []
    for h, t in items:
        t = re.sub(r'\s+', '', t)
        if any(k in t for k in ('高新', '高企', '科技型企业', '认定')):
            hits.append({'t': t, 'u': h if h.startswith('http') else ('http://kjj.sjz.gov.cn' + h if h.startswith('/') else fu.rsplit('/', 1)[0] + '/' + h)})
    out[y] = hits
    print(y, st, len(items), 'hits', len(hits))
    for h in hits[:20]:
        print('   ', h['t'][:60], '|', h['u'][-70:])
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_sjz_hits.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
