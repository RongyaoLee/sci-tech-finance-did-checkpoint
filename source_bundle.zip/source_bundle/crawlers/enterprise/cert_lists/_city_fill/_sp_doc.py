# -*- coding: utf-8 -*-
"""从 .doc（Word97 二进制）里用 UTF-16LE 字符串游程重建 企业名称/代码/所属地市 三元组。
原理：Word 文档正文以 UTF-16LE 存放单元格文本，游程按文档顺序出现；
      培育库表格列序为 序号|企业名称|统一社会信用代码|所属地市
      -> 找到 18 位统一社会信用代码游程，其前一条 CJK 游程=企业名称，其后一条=所属地市。
"""
import re
import sys
import os

CJK = r"\u4e00-\u9fff"
RUN = re.compile(r"[\u4e00-\u9fffA-Za-z0-9()（）\-\.·、]{2,}")
CODE = re.compile(r"^[0-9A-HJ-NPQRTUWXY]{18}$")


def doc_text_runs(data):
    s = data.decode("utf-16-le", "ignore")
    out = []
    for m in RUN.finditer(s):
        out.append(m.group(0))
    return out


def doc_pairs(data):
    runs = doc_text_runs(data)
    recs = []
    for i in range(1, len(runs) - 1):
        if CODE.match(runs[i]):
            name, code, city = runs[i - 1], runs[i], runs[i + 1]
            if re.search("[" + CJK + "]", name) and re.search("[" + CJK + "]", city):
                recs.append((name, code, city))
    return recs


if __name__ == "__main__":
    import _sp_lib as S
    import harvest as H
    u = sys.argv[1]
    prov = sys.argv[2]
    sc, d, f = H.get(u, timeout=40, tries=4, binary=True)
    print("fetch", sc, len(d or b""))
    if sc == 200 and d:
        recs = doc_pairs(d)
        print("pairs", len(recs))
        for r in recs[:8]:
            print("   ", r)
        from collections import Counter
        print(Counter(S.norm_city(prov, r[2]) for r in recs).most_common(8))

def doc_seq_pairs(data, prov):
    """无代码列时：企业名称游程紧邻地区游程（地区须命中该省城市白名单）。"""
    import _sp_lib as S
    runs = doc_text_runs(data)
    out = []
    for i in range(len(runs) - 1):
        name, cand = runs[i], runs[i + 1]
        if len(name) < 4 or not re.search(r"[\u4e00-\u9fff]", name):
            continue
        c = S.norm_city(prov, cand)
        if c:
            out.append((name, "", c))
    return out
