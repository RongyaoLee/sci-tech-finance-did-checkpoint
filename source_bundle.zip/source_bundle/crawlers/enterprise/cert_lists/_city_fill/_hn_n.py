﻿# -*- coding: utf-8 -*-
import json
rows=[json.loads(l) for l in open("rows_湖南.jsonl",encoding="utf-8") if l.strip()]
for city in ["株洲市","怀化市","岳阳市"]:
    o=["== "+city]
    for r in rows:
        if r["city"]==city: o.append("%s | %s"%(r["name"], r.get("cert") or ""))
    open("_hn_names_%s.txt"%city,"w",encoding="utf-8").write("\n".join(o))
print("ok")
