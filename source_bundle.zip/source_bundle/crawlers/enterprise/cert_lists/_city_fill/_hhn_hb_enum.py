# -*- coding: utf-8 -*-
"""枚举河北省科技厅「通知公告」栏目里所有含「高新技术企业」的条目。"""
import io, sys, os, re, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
TPL = 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/63f257b1-%d.html'
OUT = os.path.join(BASE, '_hb_enum.json')

hits = {}
if os.path.exists(OUT):
    hits = {h['url']: h for h in json.load(open(OUT, encoding='utf-8'))}

for p in range(1, 118):
    u = 'https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/index.html' if p == 1 else TPL % p
    st, txt, fu = H.get(u, timeout=30)
    if st != 200:
        print('fail page', p, st); continue
    n = 0
    for m in re.finditer(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', txt, re.S):
        href, inner = m.group(1), re.sub(r'<[^>]+>', '', m.group(2))
        inner = re.sub(r'\s+', ' ', inner).strip()
        if not inner or '高新' not in inner and '高企' not in inner:
            continue
        full = H.urljoin(fu, href) if hasattr(H, 'urljoin') else href
        if href.startswith('/'):
            full = 'https://kjt.hebei.gov.cn' + href
        hits[full] = {'url': full, 'title': inner}
        n += 1
    if p % 10 == 0:
        json.dump(list(hits.values()), open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print('page', p, 'cum hits', len(hits))
json.dump(list(hits.values()), open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('done hits', len(hits))
for h in list(hits.values())[:40]:
    print('  ', h['title'][:60], '|', h['url'][:100])
