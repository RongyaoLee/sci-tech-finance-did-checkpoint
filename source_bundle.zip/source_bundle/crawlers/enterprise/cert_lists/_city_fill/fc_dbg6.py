# -*- coding: utf-8 -*-
import sys, os, re, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pymupdf

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_cache", "att")
cands = []
for p in glob.glob(os.path.join(D, "*.pdf")):
    try:
        d = pymupdf.open(p)
        t = d[0].get_text()[:400]
        if "长沙市" in t and "高新技术企业奖补" in t:
            cands.append((p, d.page_count))
    except Exception:
        pass
print("cands:", cands[:5])
if cands:
    p = cands[0][0]
    d = pymupdf.open(p)
    pg = d[0]
    words = pg.get_text("words")
    lines = {}
    for w in words:
        lines.setdefault(round(w[1] / 4), []).append(w)
    for k in sorted(lines)[:12]:
        ws = sorted(lines[k], key=lambda x: x[0])
        print(" | ".join("%s@%.0f" % (w[4], w[0]) for w in ws))
