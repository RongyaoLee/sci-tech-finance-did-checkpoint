# -*- coding: utf-8 -*-
"""Shotgun: try parameter-name variants against Hubei /portal/search/commonSearch."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

BASE = "https://kjt.hubei.gov.cn/ywt/services"
HDR = {"Content-Type": "application/json;charset=utf-8",
       "Referer": "https://kjt.hubei.gov.cn/ywt/",
       "Origin": "https://kjt.hubei.gov.cn"}

def post(path, body, hdr=None, data=None, params=None):
    r = cf.S.post(BASE + path, json=None if data else body, data=data,
                  params=params, headers={**HDR, **(hdr or {})}, timeout=25)
    return r.status_code, r.text[:200]

base = {"cpage": 1, "pageSize": 3, "flid": "008001", "name": "", "unit": "",
        "data_no": "", "unit_code": "", "jb": "", "nd": "", "year": ""}

variants = [
    ("hdr-flid", dict(base), {"flid": "008001"}, None, None),
    ("flid-int", {**base, "flid": 8001}, None, None, None),
    ("flid-list", {**base, "flid": ["008001"]}, None, None, None),
    ("q-flid", dict(base), None, None, {"flid": "008001"}),
    ("form", None, None, "cpage=1&pageSize=3&flid=008001", None),
    ("datacls", {**base, "data_class": "008001", "dataClass": "008001",
                 "type": "008001", "ssqd_name": "008001"}, None, None, None),
]
for name, body, hdr, data, params in variants:
    try:
        code, txt = post("/portal/search/commonSearch", body, hdr, data, params)
        print("%-10s %s %s" % (name, code, txt.replace("\n", " ")[:150]))
    except Exception as e:
        print(name, "ERR", type(e).__name__, str(e)[:80])

# also check dataStatByYear and combinedDataStat which take flid in the query string
for p in ("/portal/search/dataStatByYear?flid=008001",
          "/portal/search/combinedDataStat?flid=008001",
          "/portal/search/totalStat"):
    try:
        code, txt = post(p, {})
        print("%-46s %s %s" % (p, code, txt.replace("\n", " ")[:150]))
    except Exception as e:
        print(p, "ERR", str(e)[:80])
