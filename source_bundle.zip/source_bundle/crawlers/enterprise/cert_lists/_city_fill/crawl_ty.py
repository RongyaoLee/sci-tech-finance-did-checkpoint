# -*- coding: utf-8 -*-
import requests, urllib3, re, time, json, os
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
B = 'http://kjj.taiyuan.gov.cn'
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
A = re.compile(r'href=[\'"](/gggs2/\d{8}/\d+\.html)[\'"][^>]*>(.*?)</a>', re.S)
items = {}
variants = ['/gggs2.html'] + [f'/gggs2/index_{i}.html' for i in range(1, 25)] + [f'/gggs2_{i}.html' for i in range(1, 25)]
dead = 0
for v in variants:
    try:
        r = requests.get(B + v, headers=H, timeout=30, verify=False)
    except Exception as e:
        print('ERR', v, str(e)[:40]); dead += 1; continue
    if r.status_code != 200:
        dead += 1
        if dead > 3 and 'index_' in v:
            pass
        continue
    r.encoding = r.apparent_encoding or 'utf-8'
    got = 0
    for m in A.finditer(r.text):
        if m.group(1) in items:
            continue
        t = re.sub(r'<[^>]+>', '', m.group(2))
        t = re.sub(r'\s+', ' ', t).strip()
        items[m.group(1)] = t
        got += 1
    print(f'{v} 200 items+{got} total {len(items)}')
    time.sleep(0.4)
print('TOTAL', len(items))
json.dump(items, open(os.path.join(RAW, '_ty_gggs.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
for k, v in items.items():
    if re.search(r'(高新技术企业|高企)', v):
        print('HIT', k, '|', v[:70])
