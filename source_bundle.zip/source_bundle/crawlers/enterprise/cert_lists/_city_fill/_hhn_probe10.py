# -*- coding: utf-8 -*-
import io, sys, os, re, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from urllib.parse import quote

def api(host, site, kw, page=1, size=50):
    u = ('https://%s/open/api/external-new?keywords=%s&siteId=%s'
         '&searchRange=-1000&sortType=150&pageNumber=%d&pageSize=%d' % (host, quote(kw), site, page, size))
    st, txt, fu = H.get(u, timeout=30)
    if st != 200:
        return st, None
    try:
        return st, json.loads(txt)
    except Exception:
        return st, None

print('### henan sweep: 拟认定')
found = {}
for kw in ['拟认定', '拟认定高新技术企业名单']:
    for page in range(1, 14):
        st, j = api('searchapi.henan.gov.cn', '4500000004', kw, page, 50)
        if not j or j.get('code') not in (1, 200):
            print(' stop', kw, page, st); break
        d = j.get('data') or {}
        ds = d.get('datas') or []
        if not ds: break
        for it in ds:
            t = (it.get('title') or '').strip()
            if '拟认定' in t and '高新' in t:
                found[str(it.get('id'))] = (it.get('pubDate') or '')[:10] + ' ' + t + ' ' + (it.get('selfUrl') or '')
        if page * 50 >= int(d.get('totalRow') or 0): break
for k in sorted(found, key=lambda x: found[x]):
    print('  ', k, found[k][:120])

print('### hebei site id')
st, txt, fu = H.get('https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418344688721/index.html', timeout=30)
print(' status', st, len(txt or ''))
if st == 200:
    m = re.search(r'name="SiteIDCode"\s+content="([^"]+)"', txt)
    print(' SiteIDCode:', m.group(1) if m else None)
    m2 = re.search(r'name="SiteDomain"\s+content="([^"]+)"', txt)
    print(' SiteDomain:', m2.group(1) if m2 else None)
