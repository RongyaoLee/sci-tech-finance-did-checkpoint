# -*- coding: utf-8 -*-
import sys, os, re, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
from bs4 import BeautifulSoup

for base in ["http://kjj.changsha.gov.cn/", "http://kjj.zhuzhou.gov.cn/"]:
    html, final = cf.get(base)
    if not html:
        print(base, "FAIL"); continue
    soup = BeautifulSoup(html, "lxml")
    print("=" * 70); print(base, final)
    seen = set()
    for a in soup.find_all("a", href=True):
        t = a.get_text(" ", strip=True)
        h = a["href"]
        if not t:
            continue
        if re.search(r"(通知|公告|公示|信息公开|政策|申报|动态)", t) and len(t) < 20:
            u = urllib.parse.urljoin(final or base, h)
            if u in seen:
                continue
            seen.add(u)
            print("   %-18s %s" % (t[:18], u[:110]))
    for f in soup.find_all("form"):
        print("   FORM", f.get("action"), [i.get("name") for i in f.find_all("input")][:6])
