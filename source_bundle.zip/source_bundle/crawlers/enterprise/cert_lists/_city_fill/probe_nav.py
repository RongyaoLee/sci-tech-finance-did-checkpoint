# -*- coding: utf-8 -*-
import requests, urllib3, re
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
r = requests.get('https://kjt.shaanxi.gov.cn/', headers=H, timeout=40, verify=False)
r.encoding = r.apparent_encoding or 'utf-8'
t = r.text
paths = {}
for m in re.finditer(r'href=[\'"]([^\'"]+)[\'"][^>]*>\s*([^<>]{2,24})\s*</a>', t):
    href, txt = m.group(1), m.group(2).strip()
    if re.search(r'(公示|公告|通知|动态|专题|高企|高新)', txt):
        paths.setdefault(txt, set()).add(href[:70])
for k, v in list(paths.items())[:40]:
    print(k, '->', list(v)[:2])
