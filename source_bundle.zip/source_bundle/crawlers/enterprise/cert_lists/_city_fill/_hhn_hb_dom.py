# -*- coding: utf-8 -*-
"""河北四市（保定/邯郸/沧州/承德）科技局域名探测。"""
import io, sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

CAND = {
 '保定市': ['http://kjj.baoding.gov.cn/', 'http://www.bdkjj.gov.cn/', 'http://kjj.bd.gov.cn/',
          'http://www.baoding.gov.cn/col/col1001/index.html'],
 '邯郸市': ['http://kjj.hd.gov.cn/', 'http://www.hdkjj.gov.cn/', 'http://kjj.hdskjj.gov.cn/',
          'http://www.hd.gov.cn/'],
 '沧州市': ['http://kjj.cangzhou.gov.cn/', 'http://www.czkjj.gov.cn/', 'http://kjj.cangzhou.gov.cn/index.html',
          'http://www.cangzhou.gov.cn/'],
 '承德市': ['http://kjj.chengde.gov.cn/', 'http://www.cdkjj.gov.cn/', 'http://www.chengde.gov.cn/'],
}
for city, urls in CAND.items():
    print('==', city)
    for u in urls:
        st, txt, fu = H.get(u, timeout=25)
        t = re.search(r'<title>(.*?)</title>', txt or '', re.S)
        title = re.sub(r'\s+', '', re.sub(r'<[^>]+>', '', t.group(1)))[:40] if t else ''
        print('  %-3s %-7s %-38s %s' % (st, len(txt or ''), u[:38], title))
