# -*- coding: utf-8 -*-
"""Probe: are there other flid categories in the Hubei 便民查询 portal with older years?"""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

BASE = "https://kjt.hubei.gov.cn/ywt/services"
HDR = {"Content-Type": "application/json;charset=utf-8",
       "Referer": "https://kjt.hubei.gov.cn/ywt/",
       "Origin": "https://kjt.hubei.gov.cn"}
out = {}

# 1) 分类/栏目接口
for path in ["/portal/search/flList", "/portal/fl/list", "/portal/search/fl", "/portal/search/category",
             "/portal/search/getFlList", "/portal/index/flList"]:
    try:
        r = cf.S.get(BASE + path, headers=HDR, timeout=20)
        out[path] = {"status": r.status_code, "body": r.text[:400]}
    except Exception as e:
        out[path] = {"err": type(e).__name__}

# 2) 逐 flid 试 dataStatByYear，看哪些有 2023 以前的年份
fl_probe = {}
for n in range(800001, 800021):
    flid = "00%d" % n if n < 800010 else "0080%02d" % (n - 800000)
    flid = "008%03d" % (n - 800000)
    try:
        r = cf.S.get(BASE + "/portal/search/dataStatByYear", params={"flid": flid}, headers=HDR, timeout=20)
        j = r.json()
        rows = j.get("rows") or j.get("data") or []
        years = sorted({str(x.get("nd") or x.get("year")) for x in rows if isinstance(x, dict)})
        fl_probe[flid] = {"n": len(rows), "years": years, "total": j.get("total")}
    except Exception as e:
        fl_probe[flid] = {"err": type(e).__name__}
out["flid_probe"] = fl_probe

json.dump(out, open(os.path.join(cf.HERE, "_hb_flid.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print(json.dumps({k: v for k, v in out.items() if k != "flid_probe"}, ensure_ascii=False)[:1500])
print(json.dumps({k: v for k, v in fl_probe.items() if v.get("n")}, ensure_ascii=False)[:1500])
