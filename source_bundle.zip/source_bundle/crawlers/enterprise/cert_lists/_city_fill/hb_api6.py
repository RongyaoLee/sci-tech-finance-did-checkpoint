# -*- coding: utf-8 -*-
"""Print the exact payload keys the Hubei 高企查询 page sends."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

t = open(os.path.join(cf.HERE, "_hb_ConvenientQuery.js"), encoding="utf-8").read()
i = t.find("B.stringify")
print(repr(t[max(0, i - 400):i + 900]))
