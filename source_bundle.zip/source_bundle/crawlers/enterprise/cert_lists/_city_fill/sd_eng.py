# -*- coding: utf-8 -*-
"""Test which search engine yields usable site: results for city gov sci-tech sites."""
import os, re, sys, json, html, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_baidu as B

TESTS = [
    ("bing", "https://cn.bing.com/search?q={q}&count=30&setlang=zh-CN"),
    ("bing2", "https://www.bing.com/search?q={q}&count=30&mkt=zh-CN"),
    ("sogou", "https://www.sogou.com/web?query={q}"),
    ("so360", "https://www.so.com/s?q={q}"),
    ("baidu_m", "https://m.baidu.com/s?word={q}"),
]

Q = "site:kjj.weifang.gov.cn 高新技术企业名单"

def links(h, eng):
    out = []
    if eng.startswith("bing"):
        for m in re.finditer(r'<h2[^>]*><a[^>]+href="(https?://[^"]+)"[^>]*>(.*?)</a>', h, re.S):
            out.append((re.sub(r"<[^>]+>", "", m.group(2)).strip(), html.unescape(m.group(1))))
    elif eng == "sogou":
        for m in re.finditer(r'<h3[^>]*>\s*<a[^>]+href="(/link\?url=[^"]+)"[^>]*>(.*?)</a>', h, re.S):
            out.append((re.sub(r"<[^>]+>", "", m.group(2)).strip(), "https://www.sogou.com" + html.unescape(m.group(1))))
    elif eng == "so360":
        for m in re.finditer(r'<h3[^>]*>\s*<a[^>]+href="(https?://[^"]+)"[^>]*>(.*?)</a>', h, re.S):
            out.append((re.sub(r"<[^>]+>", "", m.group(2)).strip(), html.unescape(m.group(1))))
    else:
        for m in re.finditer(r'mu="([^"]+)"', h):
            out.append(("", html.unescape(m.group(1))))
    return out

log = []
for eng, tpl in TESTS:
    url = tpl.format(q=urllib.parse.quote(Q))
    st, h, final = B.f(url, timeout=25)
    ls = links(h or "", eng)
    log.append({"eng": eng, "status": st, "len": len(h or ""), "n": len(ls),
                "final": final[:100], "top": ls[:6]})
json.dump(log, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_eng.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for e in log:
    print(e["eng"], e["status"], e["len"], e["n"], e["final"][:60])
    for t, u in e["top"]:
        print("   ", t[:40], "|", u[:110])
