# -*- coding: utf-8 -*-
"""给一批首页，打印含关键词的栏目链接。"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S

HOSTS = [
    "https://kjt.jl.gov.cn/",
    "https://kjt.hlj.gov.cn/",
    "http://kjt.gxzf.gov.cn/",
    "http://kjt.gansu.gov.cn/",
    "http://kjt.guizhou.gov.cn/",
    "https://kjt.nmg.gov.cn/",
    "http://dost.hainan.gov.cn/",
    "https://kjt.nx.gov.cn/",
]
KW = ("高新", "高企", "认定", "名单", "公示", "公告", "通知")
for h in HOSTS:
    sc, d, f = S.H.get(h, timeout=25, tries=2, binary=True)
    print("=" * 70)
    print(h, sc, len(d or b""))
    if sc != 200:
        continue
    t = d.decode("utf-8", "ignore")
    if "charset=gb" in t[:2000].lower() or "gb2312" in t[:2000].lower():
        t = (d or b"").decode("gb18030", "ignore")
    seen = set()
    for a in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>([^<]{2,24})</a>', t):
        u, n = a.group(1), re.sub(r"\s", "", a.group(2))
        if any(k in n for k in ("高新", "高企")) and u not in seen:
            seen.add(u)
            print("  ", n, "|", u)
