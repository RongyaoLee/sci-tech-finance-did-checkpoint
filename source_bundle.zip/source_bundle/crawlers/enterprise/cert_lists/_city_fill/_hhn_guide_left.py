# -*- coding: utf-8 -*-
"""归口单位里未被映射的值，看看能否按县/县级市补全。"""
import io, sys, os, json, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _hhn_build import guide_to_city

c = collections.Counter()
for line in open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_hb_guikou.jsonl'), encoding='utf-8'):
    try:
        d = json.loads(line)
    except Exception:
        continue
    if not guide_to_city(d['guide']):
        c[d['guide']] += 1
print('unmapped distinct', len(c))
for k, v in c.most_common(40):
    print(v, k)
