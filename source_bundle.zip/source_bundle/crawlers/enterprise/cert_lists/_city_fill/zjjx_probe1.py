# -*- coding: utf-8 -*-
"""嘉兴/湖州/绍兴 三市探测：列表页可达性 + 「高新」条目定位。"""
import sys, os, re, json
sys.stdout.reconfigure(encoding="utf-8")
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import harvest as H
import jcms as J

TAGS = ["kjj.jiaxing.gov.cn", "kjj.huzhou.gov.cn", "www.shaoxing.gov.cn", "kjj.shaoxing.gov.cn"]

def probe(url, tag):
    sc, html, final = H.get(url, timeout=25, tries=1)
    print("=== %s -> %s len=%s final=%s" % (url, sc, len(html or ""), final))
    if sc != 200:
        return None
    arts = []
    for a, t in H.img_links(html, final):
        if J.ART_RE.search(a):
            arts.append((t.strip()[:90], a))
    print("  art_links=%d" % len(arts))
    for t, a in arts[:8]:
        print("   -", t, "|", a)
    return html

if __name__ == "__main__":
    tests = [
        "http://kjj.jiaxing.gov.cn/col/col1229113779/index.html",
        "http://kjj.huzhou.gov.cn/col/col1229209483/index.html",
        "http://www.shaoxing.gov.cn/",
        "http://kjj.shaoxing.gov.cn/",
    ]
    for u in tests:
        try:
            probe(u, "probe")
        except Exception as e:
            print("ERR", u, type(e).__name__, str(e)[:120])
