# -*- coding: utf-8 -*-
import sys, os, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_cache", "att")
docs = glob.glob(os.path.join(D, "*.doc"))
print("doc count", len(docs))
for p in docs[:8]:
    with open(p, "rb") as f:
        head = f.read(8)
    print(os.path.basename(p), os.path.getsize(p), head)
try:
    import olefile
    print("olefile OK", olefile.__version__)
except Exception as e:
    print("olefile missing:", e)
