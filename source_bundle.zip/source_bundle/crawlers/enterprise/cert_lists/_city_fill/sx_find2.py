# -*- coding: utf-8 -*-
import json, os, re, io, sys
HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "_sx_bing.json"), encoding="utf-8"))
lines = []
for q, items in d.items():
    lines.append("### " + q)
    for t, u in items:
        if re.search(r"gov\.cn|sstrc\.com|innocom", u):
            lines.append("  %s | %s" % (t[:50], u[:150]))
    lines.append("")
open(os.path.join(HERE, "_sx_bing_gov.txt"), "w", encoding="utf-8").write("\n".join(lines))
print("ok")
