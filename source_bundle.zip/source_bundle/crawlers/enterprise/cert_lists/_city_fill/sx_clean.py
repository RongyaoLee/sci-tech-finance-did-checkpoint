# -*- coding: utf-8 -*-
import sys, os, re, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

OUT = os.path.join(HERE, "rows_陕西.jsonl")
LOG = os.path.join(HERE, "_progress_陕西.log")

# 1) purge junk written earlier (fragments from a prose paragraph)
if os.path.exists(OUT):
    kept, drop = [], 0
    for ln in open(OUT, encoding="utf-8"):
        ln = ln.strip()
        if not ln:
            continue
        try:
            o = json.loads(ln)
        except Exception:
            drop += 1; continue
        nm = o.get("name", "")
        if len(nm) < 6 or nm in ("股份有限公司", "有限责任公司") or o.get("source_url", "").endswith("774874.html"):
            drop += 1; continue
        kept.append(ln)
    open(OUT, "w", encoding="utf-8").write("\n".join(kept) + ("\n" if kept else ""))
    print("purged", drop, "kept", len(kept))

# 2) retry xianyang page over https/http, several UA-agnostic attempts
for u in ["https://kjj.xianyang.gov.cn/kjxw/tztg/202410/t20241018_1823764.html",
          "http://kjj.xianyang.gov.cn/kjxw/tztg/202410/t20241018_1823764.html"]:
    h, f = cf.get(u, tries=2, timeout=25, use_cache=False)
    print("==", u, "->", (len(h) if h else 0), f)
    if not h:
        continue
    s = cf.soup_of(h)
    for t in s(["script", "style"]):
        t.decompose()
    txt = re.sub(r"\n{2,}", "\n", s.get_text("\n", strip=True))
    i = txt.find("29")
    print(txt[max(0, i - 200): i + 1200])
    break
