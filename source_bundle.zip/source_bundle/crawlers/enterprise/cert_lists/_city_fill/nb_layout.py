# -*- coding: utf-8 -*-
import sys, os, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
sys.stdout.reconfigure(encoding="utf-8")
import harvest as H
CF = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill"
urls = [
 ("2021first-empty", "http://www.innocom.gov.cn/gqrdw/c101455/202201/5978243d443b4d4996716a035c9c60cd/files/10048c93dcf1489e9c4180a834fa5e58.pdf"),
 ("2017inline", "http://www.innocom.gov.cn/uploadfiles/c/e1e3e0ae8f9f473f8b82375d66348ff3.pdf"),
 ("2024one-empty", "http://www.innocom.gov.cn/gqrdw/c101455/202401/7d014844a66840c98fa064d8a9099768/files/e22620f1c8fa4174882869b7875b4b2d.pdf"),
]
for tag, u in urls:
    sc, data, f = H.get(u, binary=True, timeout=60)
    p = H.save_raw("nb_doc", u, data)
    txt = H.doc_text(u, data)
    print("=" * 100)
    print(tag, len(txt))
    i = txt.find("GR")
    print("--- head 700 chars (repr) ---")
    print(repr(txt[:700]))
    print("--- around first GR (300 before / 300 after) ---")
    print(repr(txt[max(0, i - 300):i + 300]))
