# -*- coding: utf-8 -*-
"""广西高企栏目翻页，收集「培育库入库企业名单」附件（含所属地市）-> parts"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
import harvest as H
from urllib.parse import urljoin

BASE = "http://kjt.gxzf.gov.cn/xxgk/gxkjgk/gxjsqy/gxgxjsqy/"
P = "广西壮族自治区"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "parts", P + ".jsonl")

links = {}
for n in range(0, 10):
    u = BASE + ("index.shtml" if n == 0 else "index_%d.shtml" % n)
    sc, d, f = H.get(u, timeout=25, tries=2, binary=True)
    if sc != 200 or not d:
        print("stop at", u, sc)
        break
    t = d.decode("utf-8", "ignore")
    if t.count("\ufffd") > 20:
        t = d.decode("gb18030", "ignore")
    got = 0
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']*t\d{7,9}\.shtml)["\'][^>]*>(.*?)</a>', t, re.S):
        n2 = re.sub(r"<[^>]+>|[\s\u200b]", "", m.group(2))
        if "培育库" in n2 and "名单" in n2:
            links.setdefault(m.group(1), n2)
            got += 1
    print("page", n, "培育库条目", got, "累计", len(links))
    if got == 0 and n > 3:
        break

print("---- 培育库页面:")
tot = 0
for href, title in sorted(links.items()):
    page = urljoin(BASE, href)
    ym = re.search(r"(20\d\d)", title)
    year = ym.group(1) if ym else ""
    bm = re.search(r"第([一二三1-3])批", title)
    batch = "培育库第%s批" % (bm.group(1) if bm else "1")
    print(" ", title[:70], "|", page)
    sc, d, f = H.get(page, timeout=25, tries=2, binary=True)
    if sc != 200 or not d:
        print("    page fail", sc)
        continue
    t = d.decode("utf-8", "ignore")
    if t.count("\ufffd") > 20:
        t = d.decode("gb18030", "ignore")
    docs = [m.group(1) for m in re.finditer(r'href=["\']([^"\']+\.docx?)["\']', t)]
    if not docs:
        print("    no docx")
        continue
    for du in docs:
        recs = S.grab(urljoin(f or page, du), P, "gx_py", year=year, batch=batch, require_city=True)
        tot += S.append(OUT, recs)
print("培育库 rows total:", tot)
