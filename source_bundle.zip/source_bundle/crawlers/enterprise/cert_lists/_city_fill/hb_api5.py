# -*- coding: utf-8 -*-
"""Find how the axios instance builds its base URL inside the Footer chunk."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf

t = open(os.path.join(cf.HERE, "_hb_Footer.js"), encoding="utf-8").read()
for kw in ("create(", "defaults", "baseURL", "commonSearch", "interceptors.request"):
    for m in list(re.finditer(re.escape(kw), t))[:4]:
        print("[%s]" % kw, repr(t[max(0, m.start() - 260):m.start() + 260]))
        print("-" * 40)
