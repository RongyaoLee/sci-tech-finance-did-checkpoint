﻿# -*- coding: utf-8 -*-
import os,sys,re,json
sys.path.insert(0,os.getcwd())
import cf
res=json.load(open("_hn_homes.json",encoding="utf-8"))
for city,v in res.items():
    if v[0]!="OK": continue
    h,_=cf.get(v[1])
    if not h: continue
    forms=re.findall(r"<form[^>]*>",h,re.I)
    sf=[f for f in forms if "search" in f.lower() or "sousuo" in f.lower()]
    scr=set(re.findall(r"(?:irs|search|sousuo|so\.)[\w/\.\-]*",h,re.I))
    act=re.findall(r'''action=["\']([^"\']+)["\']''',h,re.I)
    print("==",city,v[1])
    print("  forms(search):",sf[:5])
    print("  actions:",act[:8])
    print("  toks:",sorted(scr)[:12])
