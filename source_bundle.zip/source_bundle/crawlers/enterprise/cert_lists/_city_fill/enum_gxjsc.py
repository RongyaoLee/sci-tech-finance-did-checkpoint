# -*- coding: utf-8 -*-
"""Crawl 山西 gxjsc (高新技术处) column fully; list 高企 items."""
import requests, urllib3, re, time, json, os
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})


def get(u):
    for attempt in range(2):
        try:
            r = s.get(u, timeout=30, verify=False)
        except Exception as e:
            return 0, str(e)[:90], u
        if r.status_code == 200:
            r.encoding = r.apparent_encoding or 'utf-8'
            return 200, r.text, r.url
        alt = u.replace('https://', 'http://', 1) if u.startswith('https://') else u.replace('http://', 'https://', 1)
        if attempt == 0 and alt != u:
            u = alt
            continue
        return r.status_code, '', u
    return 0, '', u


def links(html):
    out = []
    for m in re.finditer(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', html, re.S):
        txt = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', m.group(2))).strip()
        if txt:
            out.append((txt, m.group(1)))
    return out


base = 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/gxjsc/'
seen = {}
prev = None
for p in range(0, 40):
    pats = ['', 'index.shtml'] if p == 0 else ['index_{p}.shtml']
    st = 0
    for pat in pats:
        u = base + (pat.format(p=p) if p else pat)
        st, t, fu = get(u)
        if st == 200 and len(t) > 3000:
            break
    if st != 200:
        print('stop', p, u, st)
        break
    h = hash(t)
    if h == prev:
        print('same page, stop', p)
        break
    prev = h
    n = 0
    for txt, href in links(t):
        if len(txt) < 10 or 'shtml' not in href:
            continue
        if re.search(r'(高新|认定|公示|名单)', txt):
            if txt not in seen:
                seen[txt] = href
                n += 1
    print('page', p, len(t), 'new', n, 'total', len(seen))
    time.sleep(0.4)
json.dump(seen, open(os.path.join(RAW, '_sxkj_gxjsc.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('TOTAL', len(seen))
for k, v in list(seen.items())[:80]:
    print('  ', k[:95], '|', v)
