﻿import os,sys,re,json
sys.path.insert(0,os.getcwd())
import cf
url="http://zwfw-new.hunan.gov.cn/hnzwfw/portal/MHWKx-KiTEOZT6Be4BUJF4/index.html"
h,fin=cf.get(url)
print("final",fin,"len",len(h) if h else None)
if h:
    print(h[:1500])
    js=re.findall(r'''src=["\']([^"\']+\.js[^"\']*)["\']''',h)
    css=re.findall(r'''href=["\']([^"\']+\.css[^"\']*)["\']''',h)
    print("JS:",js)
    print("CSS:",css)
