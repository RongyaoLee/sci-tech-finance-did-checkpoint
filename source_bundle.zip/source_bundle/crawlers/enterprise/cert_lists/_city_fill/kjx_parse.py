# -*- coding: utf-8 -*-
"""Parse 「入库科技型中小企业名单」PDF: 企业名称 + 入库登记编号(含6位行政区划码) -> 地级市。

编号格式(全国统一): 4位年份 + 6位行政区划代码 + 1位(A/B/...) + 7位序号
  例 2026430181A0027183 -> 年份2026, 区划430181(长沙市浏阳市), 类型A
地级市 = 区划码前4位 + "00"（省直辖县级单位另处理）。
"""
import os, sys, re, glob, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
import fitz

CODE_RE = re.compile(r"^\d{4}(\d{6})([A-Z])(\d{7})$")
SUFFIX = ("公司", "企业", "厂", "中心", "院", "所", "合作社", "工作室", "集团", "商行", "店", "部", "社", "队")


def parse_pdf(path):
    doc = fitz.open(path)
    out = []
    for page in doc:
        lines = [l.strip() for l in page.get_text().split("\n") if l.strip()]
        for i, ln in enumerate(lines):
            m = CODE_RE.match(ln.replace(" ", ""))
            if not m:
                continue
            # 往前找企业名（可能跨行）
            name = ""
            for j in range(i - 1, max(-1, i - 4), -1):
                cand = lines[j]
                if CODE_RE.match(cand.replace(" ", "")) or re.fullmatch(r"\d{1,5}", cand):
                    continue
                name = cand + name if name else cand
                if any(s in name for s in SUFFIX):
                    break
            if name:
                out.append((name.replace(" ", ""), m.group(1)))
    doc.close()
    return out


if __name__ == "__main__":
    paths = sorted(glob.glob(os.path.join(cf.CACHE, "att", "kjx_*.pdf")))
    rows = []
    for p in paths:
        r = parse_pdf(p)
        print(os.path.basename(p), len(r))
        rows += r
    print("total", len(rows))
    print(rows[:5])
    cc = collections.Counter(c[:4] for _, c in rows)
    print("prefix4:", cc.most_common(20))
