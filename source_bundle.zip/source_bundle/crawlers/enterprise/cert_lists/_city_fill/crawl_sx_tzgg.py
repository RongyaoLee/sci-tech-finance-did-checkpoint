# -*- coding: utf-8 -*-
"""Crawl 陕西 kjt tzgg list pages (index.html, index_1..index_N.html), keep all items."""
import requests, urllib3, re, json, os, time
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})
ITEM = re.compile(r'href=[\'"](\.?/?\d{6}/t\d+_\d+\.html)[\'"][^>]*>(.*?)</a>', re.S)
BASE = 'https://kjt.shaanxi.gov.cn/kjdt/tzgg/'

items = []          # (href, title)
seen = set()
for i in range(0, 200):
    u = BASE + ('index.html' if i == 0 else f'index_{i}.html')
    try:
        r = s.get(u, timeout=40, verify=False)
    except Exception as e:
        print('ERR', u, str(e)[:60]); break
    if r.status_code != 200:
        print('stop', u, r.status_code); break
    r.encoding = r.apparent_encoding or 'utf-8'
    got = []
    for m in ITEM.finditer(r.text):
        href = m.group(1)
        title = re.sub(r'<[^>]+>', '', m.group(2))
        title = re.sub(r'\s+', ' ', title).strip()
        if href in seen:
            continue
        seen.add(href)
        got.append([href, title])
    print(f'page {i}: {len(got)} new (total {len(items)+len(got)})', got[-1][0] if got else '')
    if not got:
        break
    items.extend(got)
    time.sleep(0.4)

json.dump(items, open(os.path.join(RAW, '_sx_tzgg_all.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('TOTAL items', len(items))
kw = re.compile(r'(高新技术企业|高企)')
hits = [x for x in items if kw.search(x[1])]
print('高企-related', len(hits))
for h in hits:
    print('  ', h[0], h[1][:70])
