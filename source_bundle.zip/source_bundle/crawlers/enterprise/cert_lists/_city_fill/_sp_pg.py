# -*- coding: utf-8 -*-
"""探测栏目分页形式：给定栏目首页，试常见分页 URL。"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _sp_lib as S
from urllib.parse import urljoin

col = sys.argv[1]
sc, d, f = S.H.get(col, timeout=25, tries=2, binary=True)
print("col", sc, len(d or b""), f)
t = d.decode("utf-8", "ignore")
if t.count("\ufffd") > 20:
    t = d.decode("gb18030", "ignore")
for pat in [r"共\s*(\d+)\s*页", r"totalpage[\"']?\s*[:=]\s*[\"']?(\d+)", r"共\s*(\d+)\s*条",
            r"createPageHTML\([^)]*\)"]:
    m = re.search(pat, t)
    print("  pat", pat, "->", m.group(0)[:80] if m else None)
# 打印分页区域片段
i = t.find("page")
for kw in ("分页", "page-nav", "pagination", "page_div", "list_", "index_"):
    j = t.find(kw)
    if j > 0:
        print("  KW", kw, t[max(0, j - 100):j + 160].replace("\n", " ")[:260])
        break

base = f or col
d2 = base.rsplit("/", 1)[0]
cands = []
for i2 in (2, 3):
    for stem in ("index_%d.shtml", "list_%d.shtml", "index_%d.html", "list_%d.html",
                 "index_%d.htm", "list_%d.htm"):
        cands.append("%s/%s" % (d2, stem % (i2 - 1)))
    cands.append("%s?page=%d" % (base, i2))
for u in cands:
    sc2, d2b, f2 = S.H.get(u, timeout=15, tries=1, binary=True)
    print("  try", u[-46:], sc2, len(d2b or b""))
