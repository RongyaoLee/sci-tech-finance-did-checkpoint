# -*- coding: utf-8 -*-
import requests, urllib3, re, time
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
BASE = 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/zhqykjc/'
LI = re.compile(r'<li>(.*?)</li>', re.S)
HR = re.compile(r'href="\s*([^"\s]+\.shtml)\s*"', re.S)
TI = re.compile(r'target="_blank"[^>]*>(.*?)</a>', re.S)
seen = []
for i in range(0, 6):
    u = BASE + ('index.shtml' if i == 0 else f'index_{i}.shtml')
    try:
        r = requests.get(u, headers=H, timeout=40, verify=False)
    except Exception as e:
        print('ERR', u, str(e)[:50]); break
    if r.status_code != 200:
        print('stop', u, r.status_code); break
    r.encoding = r.apparent_encoding or 'utf-8'
    n0 = len(seen)
    for li in LI.findall(r.text):
        m = HR.search(li); t = TI.search(li)
        if not m:
            continue
        title = re.sub(r'<[^>]+>', '', t.group(1)) if t else ''
        title = re.sub(r'\s+', ' ', title).strip()
        seen.append((m.group(1), title))
    print(f'page {i}: +{len(seen)-n0} total {len(seen)}')
    if len(seen) == n0:
        break
    time.sleep(0.4)
for href, title in seen:
    print(href, '|', title[:80])
