# -*- coding: utf-8 -*-
import sys, os, re, json, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

q = urllib.parse.quote("高新技术企业")
tries = [
    "https://api.so-gov.cn/query/s?siteCode=6101000007&tab=all&qt=%s&page=1&pageSize=20" % q,
    "https://api.so-gov.cn/query/s?siteCode=6101000007&qt=%s&page=1" % q,
    "https://api.so-gov.cn/query/site?siteCode=6101000007",
]
for u in tries:
    h, f = cf.get(u, tries=1, timeout=20)
    print("URL", u[:90])
    print("  ->", (h[:600] if h else f))
