# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

h, _ = cf.get("https://p.so-gov.cn/web/api/api.js")
i = h.find("path")
print(h[max(0, i - 600): i + 1800])
