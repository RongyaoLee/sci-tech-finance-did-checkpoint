# -*- coding: utf-8 -*-
"""Parse 山西 gxjsc column pages with title attributes; filter 高企名单/证书 notices; list attachments."""
import requests, urllib3, re, time, json, os
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})


def get(u):
    for attempt in range(2):
        try:
            r = s.get(u, timeout=30, verify=False)
        except Exception as e:
            return 0, str(e)[:90], u
        if r.status_code == 200:
            r.encoding = r.apparent_encoding or 'utf-8'
            return 200, r.text, r.url
        alt = u.replace('https://', 'http://', 1) if u.startswith('https://') else u.replace('http://', 'https://', 1)
        if attempt == 0 and alt != u:
            u = alt
            continue
        return r.status_code, '', u
    return 0, '', u


base = 'https://kjt.shanxi.gov.cn/xxgk/zfxxgkml/acs_11737/gxjsc/'
items = []
for p in range(0, 19):
    pats = ['', 'index.shtml'] if p == 0 else ['index_{p}.shtml']
    for pat in pats:
        u = base + (pat.format(p=p) if p else pat)
        st, t, fu = get(u)
        if st == 200 and len(t) > 3000:
            break
    if st != 200:
        break
    # anchors that carry title= attribute
    for m in re.finditer(r'<a([^>]*?)title="([^"]{6,200})"([^>]*?)href="([^"]+shtml)"', t, re.S):
        items.append((re.sub(r'\s+', ' ', m.group(2)).strip(), m.group(4)))
    for m in re.finditer(r'<a([^>]*?)href="([^"]+shtml)"([^>]*?)title="([^"]{6,200})"', t, re.S):
        items.append((re.sub(r'\s+', ' ', m.group(4)).strip(), m.group(2)))
    time.sleep(0.4)
print('items', len(items))
uniq = {}
for ti, href in items:
    ti = re.sub(r'^(分类：.*?发布时间：[0-9.]+)', '', ti).strip()
    if ti not in uniq:
        uniq[ti] = href
print('uniq', len(uniq))
hits = {k: v for k, v in uniq.items() if re.search(r'高新', k) and re.search(r'(名单|结果|公布|发放|领取|认定)', k)}
json.dump(uniq, open(os.path.join(RAW, '_sxkj_gxjsc_titles.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('HITS', len(hits))
for k, v in sorted(hits.items()):
    print('  ', k[:110], '|', v)
