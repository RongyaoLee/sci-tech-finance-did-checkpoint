# -*- coding: utf-8 -*-
import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

u = "http://www.innocom.gov.cn/gqrdw/c101419/202512/cada518178604d30b576fb69a3d47296/files/374525a7298340f5ba3d2d6dadbfb6cc.pdf"
sc, data, final = H.get(u, binary=True)
print("dl", sc, len(data or b""))
p = H.save_raw("nb", u, data)
txt = H.doc_text(u, data)
open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_att1.txt", "w", encoding="utf-8").write(txt)
print("chars", len(txt), "certs", len(H.certs_in_text(txt)))
print(txt[:1500])
