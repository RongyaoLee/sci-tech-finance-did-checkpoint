# -*- coding: utf-8 -*-
import requests, urllib3, re
urllib3.disable_warnings()
H = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
tests = [
    'http://xakj.xa.gov.cn/kjdt/tzgg/',
    'http://xakj.xa.gov.cn/kjdt/tzgg/index.html',
    'https://kjj.taiyuan.gov.cn/',
]
for u in tests:
    try:
        r = requests.get(u, headers=H, timeout=30, verify=False)
        r.encoding = r.apparent_encoding or 'utf-8'
        t = r.text
    except Exception as e:
        print('ERR', u, str(e)[:60]); continue
    print('=====', r.status_code, len(t), u)
    arts = re.findall(r'href=[\'"]([^\'"]*/kjdt/tzgg/\d+\.html)[\'"]', t)
    print('  article links', len(arts), arts[:3])
    idx = sorted(set(re.findall(r'href=[\'"]([^\'"]*(?:index|list)[^\'"]*\.(?:html|shtml|jhtml))[\'"]', t)))
    print('  list links', idx[:10])
    if 'taiyuan' in u:
        for m in re.finditer(r'href=[\'"]([^\'"]+)[\'"][^>]*>([^<]{2,30}?)<', t):
            if re.search(r'(通知|公告|公示|名单|高企|高新)', m.group(2)):
                print('   ', m.group(1)[:70], '|', m.group(2))
