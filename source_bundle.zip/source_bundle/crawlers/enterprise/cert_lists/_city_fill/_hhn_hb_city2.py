# -*- coding: utf-8 -*-
"""列出站点首页/栏目页全部导航链接，人工挑「通知公告」栏目。"""
import io, sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

URLS = [
    'http://kjj.sjz.gov.cn/columns/411da69e-e11d-4853-b016-e581e60993db/index.html',
    'https://kejiju.tangshan.gov.cn/',
]
for u in URLS:
    st, txt, fu = H.get(u, timeout=30)
    print('==', st, len(txt or ''), fu)
    if st != 200:
        continue
    for href, label in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', txt, re.S):
        lab = re.sub(r'\s+', '', re.sub(r'<[^>]+>', '', label))
        if lab and len(lab) <= 24 and ('index' in href or href.endswith('/') or 'list' in href or 'column' in href):
            print('  %-22s %s' % (lab, href[:100]))
