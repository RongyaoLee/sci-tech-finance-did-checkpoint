# -*- coding: utf-8 -*-
"""Download 民政部 2023 行政区划代码 page, parse 61/14 rows."""
import requests, urllib3, re, os, json
urllib3.disable_warnings()
RAW = r'C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\raw'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
u = 'https://www.mca.gov.cn/mzsj/xzqh/2023/202301xzqh.html'
r = requests.get(u, timeout=60, verify=False, headers={'User-Agent': UA})
r.encoding = r.apparent_encoding or 'utf-8'
t = r.text
open(os.path.join(RAW, '_mca_xzqh2023.html'), 'w', encoding='utf-8').write(t)
print('len', len(t))
i = t.find('610100')
print('snippet:', re.sub(r'\s+', ' ', t[max(0, i - 500):i + 700]))
