# -*- coding: utf-8 -*-
"""parts/*.jsonl -> <省>_city.csv（补 城市/区县）。
用法: _sp_build.py 辽宁省 [辽宁省 吉林省 ...]
"""
import csv
import json
import os
import re
import sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.dirname(os.path.dirname(HERE))
CERTDIR = os.path.join(WORK, "cert_lists")
PARTS = os.path.join(HERE, "parts")
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]


def norm_name(s):
    t = (s or "").strip()
    t = t.replace("（", "(").replace("）", ")").replace("　", "")
    t = re.sub(r"\s+", "", t)
    t = t.replace("(", "").replace(")", "")
    return t


def norm_cert(s):
    t = re.sub(r"[\s\-]", "", s or "").upper()
    m = re.search(r"GR\d{10,14}", t)
    return m.group(0) if m else ""


def load_parts(prov):
    recs = []
    if not os.path.isdir(PARTS):
        return recs
    for fn in sorted(os.listdir(PARTS)):
        if not fn.endswith(".jsonl"):
            continue
        if prov not in fn:
            continue
        with open(os.path.join(PARTS, fn), encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    r = json.loads(ln)
                except Exception:
                    continue
                r["name"] = (r.get("name") or "").strip()
                if r["name"] and (r.get("city") or ""):
                    recs.append(r)
    return recs


def build(prov):
    src = os.path.join(CERTDIR, prov + ".csv")
    rows = list(csv.DictReader(open(src, encoding="utf-8-sig")))
    recs = load_parts(prov)
    by_cert = defaultdict(Counter)
    by_name = defaultdict(Counter)
    county_by_cert = defaultdict(Counter)
    for r in recs:
        c, n, city = norm_cert(r.get("cert")), norm_name(r["name"]), r["city"]
        if not city:
            continue
        if c:
            by_cert[c][city] += 1
            if r.get("county"):
                county_by_cert[c][r["county"]] += 1
        if n:
            by_name[n][city] += 1
    filled = 0
    src_used = Counter()
    for row in rows:
        if (row.get("城市") or "").strip():
            filled += 1
            continue
        c = norm_cert(row.get("证书编号"))
        n = norm_name(row.get("企业名称"))
        city = ""
        cnty = ""
        if c and c in by_cert:
            city = by_cert[c].most_common(1)[0][0]
            if c in county_by_cert:
                cnty = county_by_cert[c].most_common(1)[0][0]
            src_used["cert"] += 1
        elif n and n in by_name:
            city = by_name[n].most_common(1)[0][0]
            src_used["name"] += 1
        if city:
            row["城市"] = city
            if cnty and not (row.get("区县") or "").strip():
                row["区县"] = cnty
            filled += 1
    out = os.path.join(HERE, prov + "_city.csv")
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=HEADER)
        w.writeheader()
        for row in rows:
            w.writerow({k: (row.get(k) or "") for k in HEADER})
    cities = Counter((r.get("城市") or "") for r in rows)
    nz = sum(v for k, v in cities.items() if k)
    print("%-10s rows=%-6d 城市行数=%-6d 覆盖率=%.1f%% (cert=%d name=%d) parts=%d"
          % (prov, len(rows), nz, 100.0 * nz / max(1, len(rows)),
             src_used["cert"], src_used["name"], len(recs)))
    print("    top:", [x for x in cities.most_common(8) if x[0]][:8])
    return len(rows), nz, len(recs)


if __name__ == "__main__":
    provs = sys.argv[1:] or ["辽宁省"]
    for p in provs:
        build(p)
