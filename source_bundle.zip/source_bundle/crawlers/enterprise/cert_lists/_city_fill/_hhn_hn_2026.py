# -*- coding: utf-8 -*-
"""河南 2026 公示页补抓（用于 2023 年同名企业回填）。"""
import io, sys, os, re, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from _hhn_hn_crawl2 import doc_text_heur, parse_rows, CITY_SET

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, '_hn_region_rows.jsonl')
PAGES = [('http://kjt.henan.gov.cn/2026/11-06/3445327.html', 2026, '第一批'),
         ('http://kjt.henan.gov.cn/2026/11-06/3445327.html', 2026, '第一批')]

have = set()
for line in open(OUT, encoding='utf-8'):
    try:
        d = json.loads(line); have.add((d['name'], d['city']))
    except Exception:
        pass
fh = open(OUT, 'a', encoding='utf-8')
new = 0
for url, year, batch in PAGES[:1]:
    st, txt, fu = H.get(url, timeout=30)
    print('page', st, len(txt or ''))
    if st != 200:
        continue
    t = re.search(r'<title>(.*?)</title>', txt, re.S)
    print('title', re.sub(r'\s+', ' ', t.group(1))[:80] if t else '')
    docs = H.doc_links(H.img_links(txt, fu), fu)
    print('docs', len(docs))
    for d, tt in docs:
        st2, data, _ = H.get(d, timeout=120, binary=True)
        if st2 != 200 or not data:
            print(' fail', st2, d[:90]); continue
        dt = H.doc_text(d, data)
        toks = [x for x in re.split(r'[\s\u3000]+', dt) if x]
        n = 0
        for i, tok in enumerate(toks):
            if tok not in CITY_SET:
                continue
            if i + 3 < len(toks) and re.fullmatch(r'[0-9A-Z]{18}', toks[i + 3]) and len(toks[i + 2]) >= 4:
                city, region, name, code = tok, toks[i + 1], toks[i + 2], toks[i + 3]
            elif i + 2 < len(toks) and re.fullmatch(r'[0-9A-Z]{18}', toks[i + 2]) and len(toks[i + 1]) >= 4:
                city, region, name, code = tok, '', toks[i + 1], toks[i + 2]
            else:
                continue
            if (name, city) in have:
                continue
            have.add((name, city)); n += 1; new += 1
            fh.write(json.dumps({'city': city, 'county': region, 'name': name, 'uscc': code,
                                 'year': year, 'batch': batch, 'src': d}, ensure_ascii=False) + '\n')
        print(' rows', n, d.split('/')[-1][:50])
fh.close()
print('NEW', new)
