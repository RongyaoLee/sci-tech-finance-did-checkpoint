# -*- coding: utf-8 -*-
"""对 m.sme-gov.cn 浙江各市频道做定向扫描：只用「名单正文自带区县列」的页面补城市/区县。

安全阀：
- 城市由页面所属频道（路径）给出，区县必须属于该市（COUNTY2CITY 校验），
  否则该行丢弃 → 不会把 A 市企业写到 B 市。
- 每页解析出的行数过少（<3）视为非名单页，跳过。
- 断点续扫：已完成 URL 记在 raw\\_sme_sweep_done.txt。
用法：python zj_sme_sweep.py [sample|full] [max_pages]
"""
import os, sys, re, json, time, random, importlib.util

sys.stdout.reconfigure(encoding="utf-8")
CF = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("zm", os.path.join(CF, "zj_mirror.py"))
zm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(zm)

OUT = os.path.join(CF, "parts", "浙江省_sme.jsonl")
DONE = os.path.join(CF, "raw", "_sme_sweep_done.txt")
CITYDIR = {
    "hangzhou": "杭州市", "ningbo": "宁波市", "wenzhou": "温州市",
    "jiaxing": "嘉兴市", "huzhou": "湖州市", "shaoxing": "绍兴市",
    "jinhua": "金华市", "quzhou": "衢州市", "zhoushan": "舟山市",
    "taizhou": "台州市", "lishui": "丽水市",
}


def collect():
    h = zm.get("https://m.sme-gov.cn/sitemap/sitemapindex.xml")
    locs = re.findall(r"<loc>([^<]+)</loc>", h)
    files = [x for x in locs if re.search(r"/sitemap/news\d*\.txt$", x)]
    urls = []
    for f in files:
        try:
            t = zm.get(f)
        except Exception as e:
            print("sitemap fail", f, repr(e)[:60], flush=True)
            continue
        urls += re.findall(r"https?://m\.sme-gov\.cn/([a-z]+)/news/(\d+)\.html", t)
        print("sitemap", f.split("/")[-1], "total", len(urls), flush=True)
        time.sleep(0.5)
    seen, out = set(), []
    for c, n in urls:
        if c not in CITYDIR or c == "ningbo":
            continue
        k = (c, n)
        if k in seen:
            continue
        seen.add(k)
        out.append((c, n))
    return out


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "sample"
    cap = int(sys.argv[2]) if len(sys.argv) > 2 else (40 if mode == "sample" else 400)
    os.makedirs(os.path.join(CF, "raw"), exist_ok=True)
    done = set()
    if os.path.exists(DONE):
        done = set(x.strip() for x in open(DONE, encoding="utf-8") if x.strip())
    allu = collect()
    print("zj urls", len(allu), flush=True)
    if mode == "sample":
        random.seed(7)
        allu = random.sample(allu, min(cap, len(allu)))
    else:
        allu = [x for x in allu if "https://m.sme-gov.cn/%s/news/%s.html" % x not in done]
        allu = allu[:cap]
    total_new = 0
    for c, n in allu:
        url = "https://m.sme-gov.cn/%s/news/%s.html" % (c, n)
        city = CITYDIR[c]
        try:
            page = zm.get(url)
            rows = zm.parse(page, city)
        except Exception as e:
            print("FAIL", url, repr(e)[:60], flush=True)
            continue
        if len(rows) >= 3:
            with open(OUT, "a", encoding="utf-8") as fh:
                for nm, cu in rows:
                    fh.write(json.dumps({"name": nm, "city": city, "county": cu,
                                         "src": url, "tag": "sweep_" + c}, ensure_ascii=False) + "\n")
            total_new += len(rows)
            print("HIT  %-12s %-6s rows=%4d %s" % (city, n, len(rows), url), flush=True)
        with open(DONE, "a", encoding="utf-8") as fh:
            fh.write(url + "\n")
        time.sleep(0.5)
    print("SWEEP new rows", total_new, flush=True)


if __name__ == "__main__":
    main()
