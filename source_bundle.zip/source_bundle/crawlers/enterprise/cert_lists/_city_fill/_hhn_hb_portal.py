# -*- coding: utf-8 -*-
"""石家庄/邯郸/沧州/承德 门户：找科技局频道与通知公告入口（宽匹配）。"""
import io, sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

URLS = ['http://kjj.sjz.gov.cn/', 'http://www.hd.gov.cn/', 'http://www.cangzhou.gov.cn/',
        'http://www.chengde.gov.cn/']
for u in URLS:
    st, txt, fu = H.get(u, timeout=25)
    print('==', st, len(txt or ''), u)
    if st != 200:
        continue
    seen = set()
    for href, lab in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', txt, re.S):
        lab = re.sub(r'\s+', '', re.sub(r'<[^>]+>', '', lab))
        if not lab or len(lab) > 18 or href in seen:
            continue
        if any(k in lab for k in ('科技', '通知', '公告', '公示', '信息公开', '部门')):
            seen.add(href)
            print('   %-14s %s' % (lab, href[:96]))
