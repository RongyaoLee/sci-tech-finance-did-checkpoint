﻿# -*- coding: utf-8 -*-
import os,sys,re
sys.path.insert(0,os.getcwd())
import cf
u="http://searching.hunan.gov.cn/hunan/973104000/news"
r=cf.S.get(u,params={"q":"高新技术企业"},timeout=30)
r.encoding="utf-8"; h=r.text
open("_hn_s4.html","w",encoding="utf-8").write(h)
print(len(h), "count 高新技术企业:", h.count("高新技术企业"))
# find result links
links=re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>',h,re.S)
print("links",len(links))
for u2,t in links[:40]:
    t=re.sub(r"<[^>]+>","",t).strip()
    if t: print(t[:60],"|",u2[:110])
