# -*- coding: utf-8 -*-
import re, sys, os, urllib.parse, html
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_baidu as B

Q = "site:kjj.weifang.gov.cn 高新技术企业名单"
url = "https://www.so.com/s?q=" + urllib.parse.quote(Q)
st, h, fin = B.f(url, referer="https://www.so.com/")
print("status", st, "len", len(h or ""))
h = h or ""
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "raw_baidu", "so_search.html"), "w", encoding="utf-8").write(h)
i = h.find("<h3")
blk = h[i-400:i+2600] if i > 0 else ""
print("----BLOCK----")
print(blk)
print("----ATTRS----")
for pat in [r'mu="[^"]*"', r'data-[a-z]+="https?://[^"]+"', r'<cite[^>]*>.{0,200}?</cite>', r'https?://(?!www\.so\.com)[\w.\-]+\.(?:gov\.cn|com|cn)[^"\' <>]{0,120}']:
    m = re.findall(pat, h, re.I)[:8]
    print("PAT", pat[:26], len(m))
    for x in m[:6]:
        print("    ", x[:180])
