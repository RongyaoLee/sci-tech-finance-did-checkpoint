# -*- coding: utf-8 -*-
"""Probe province S&T dept sites for 高企认定名单 columns that carry 地市."""
import sys, os, re, time, json
import requests
from bs4 import BeautifulSoup

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
H = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9",
     "Accept": "text/html,application/xhtml+xml,*/*;q=0.8"}
S = requests.Session()
S.headers.update(H)
S.verify = False
import urllib3
urllib3.disable_warnings()


def get(url, binary=False, tries=2):
    urls = [url]
    if url.startswith("https://"):
        urls.append("http://" + url[8:])
    last = None
    for u in urls:
        for _ in range(tries):
            try:
                r = S.get(u, timeout=30)
                if r.status_code == 200:
                    time.sleep(0.4)
                    if binary:
                        return r.content, r.url
                    r.encoding = r.apparent_encoding or "utf-8"
                    return r.text, r.url
                last = "HTTP %s" % r.status_code
            except Exception as e:
                last = type(e).__name__ + ":" + str(e)[:60]
            time.sleep(0.8)
    return None, last


TARGETS = {
    "陕西_home": "http://kjt.shaanxi.gov.cn/",
    "湖北_home": "https://kjt.hubei.gov.cn/",
    "湖南_col": "http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/",
    "湖南_home": "http://kjt.hunan.gov.cn/",
}

out = {}
for k, u in TARGETS.items():
    html, fin = get(u)
    if not html:
        out[k] = {"url": u, "err": fin}
        continue
    soup = BeautifulSoup(html, "lxml")
    title = soup.title.get_text(strip=True) if soup.title else ""
    anchors = []
    for a in soup.find_all("a", href=True):
        t = a.get_text(strip=True)
        if not t:
            continue
        if re.search(r"高新技术企业|高企|认定", t):
            anchors.append([t[:60], a["href"][:160]])
    out[k] = {"url": u, "final": fin, "title": title, "len": len(html),
              "hits": anchors[:40], "nhit": len(anchors)}
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_%s.html" % k), "w",
              encoding="utf-8") as f:
        f.write(html)

p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "probe1.json")
open(p, "w", encoding="utf-8").write(json.dumps(out, ensure_ascii=False, indent=1))
print("done")
