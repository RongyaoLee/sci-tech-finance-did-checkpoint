# -*- coding: utf-8 -*-
"""通用抓取器（requests 直连）：列表页翻页 -> 文章 -> 附件/内联表 -> parts
用法: python sd_run.py 威海 枣庄 ...
"""
import os, re, sys, json, time, random, html
from urllib.parse import urljoin, urlparse, urldefrag
import requests, urllib3
urllib3.disable_warnings()
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_lib as S, sd_city_parser as P, sd_store as ST

BASE = S.BASE
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
LAST = {}
LOG = []


def log(*a):
    m = " ".join(str(x) for x in a)
    LOG.append(m)
    print(m, flush=True)


def f(url, binary=False, timeout=40, referer=None, tries=3):
    host = urlparse(url).netloc
    dt = time.time() - LAST.get(host, 0)
    if dt < 0.55:
        time.sleep(0.55 - dt)
    LAST[host] = time.time()
    hdr = {"User-Agent": UA, "Accept": "*/*", "Accept-Language": "zh-CN,zh;q=0.9"}
    if referer:
        hdr["Referer"] = referer
    for i in range(tries):
        try:
            r = requests.get(url, headers=hdr, timeout=timeout, verify=False,
                             allow_redirects=True)
            if r.status_code != 200:
                time.sleep(0.8 * (i + 1))
                continue
            if binary:
                return r.content, r.url
            r.encoding = r.apparent_encoding or "utf-8"
            return r.text, r.url
        except Exception:
            time.sleep(0.8 * (i + 1))
    return (b"" if binary else ""), url


LINK_RE = re.compile(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', re.S | re.I)
HIT = re.compile(r"高新技术企业|高企")
LISTY = re.compile(r"名单|公布|认定|公示|备案|证书|结果|通知|公告")
DOC = re.compile(r"(\.pdf|\.xlsx?|\.docx?|\.et\b|\.wps\b|downfile\.jsp|attach/0/)", re.I)


def paginate(seed):
    yield seed
    base, q = (seed.split("?", 1) + [""])[:2]
    for i in range(2, 31):
        if q:
            yield "%s?%s&page=%d" % (base, q, i)
        elif base.endswith(".html"):
            yield re.sub(r"\.html$", "_%d.html" % i, base)
        else:
            yield base.rstrip("/") + "/index_%d.html" % i


def texts_links(h, base):
    out = []
    for href, t in LINK_RE.findall(h or ""):
        tt = re.sub(r"\s+", "", re.sub(r"<[^>]+>", "", t))
        if not tt:
            continue
        out.append((tt, urljoin(base, href)))
    return out


def html_tables(h):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(h or "", "html.parser")
    tabs = []
    for t in soup.find_all("table"):
        rows = []
        for tr in t.find_all("tr"):
            cells = [re.sub(r"\s+", "", td.get_text(" ")) for td in tr.find_all(["td", "th"])]
            if cells and any(cells):
                rows.append(cells)
        if len(rows) >= 3:
            tabs.append(rows)
    return tabs


def grab_article(city, title, url):
    h, fin = f(url, referer="https://" + urlparse(url).netloc + "/")
    if not h:
        return 0
    year = ""
    m = re.search(r"(20\d\d)\s*年", title) or re.search(r"/(20\d\d)/", url)
    if m:
        year = m.group(1)
    n = 0
    tabs = html_tables(h)
    if tabs:
        rows = [(a, b, d) for a, b, c, d in P.rows_from_tables(tabs, city + "市") if (c == city or not c)]
        if len(rows) >= 5:
            add = ST.append_rows(city, rows, url, year, "")
            n += add
            if add:
                log("    inline +%d/%d %s" % (add, len(rows), title[:34]))
    docs = []
    for t, u in texts_links(h, fin or url):
        if DOC.search(u) and len(u) < 400:
            docs.append(u)
    for u in list(dict.fromkeys(docs))[:15]:
        data, fin2 = f(u, binary=True, timeout=90, referer=fin or url)
        if not data or len(data) < 900:
            continue
        if not (data[:5] == b"%PDF-" or data[:2] == b"PK" or data[:4] == b"\xd0\xcf\x11\xe0"):
            continue
        try:
            rows = P.rows_from_doc(fin2 or u, data, city + "市")
        except Exception as e:
            log("    parse ERR %r" % (e,))
            continue
        rows = [(a, b, d) for a, b, c, d in rows if (c == city or not c)]
        if rows:
            add = ST.append_rows(city, rows, fin2 or u, year, "")
            n += add
            if add:
                log("    doc +%d/%d %s" % (add, len(rows), os.path.basename(urlparse(fin2 or u).path)[:36]))
    return n


def crawl_seed(city, seed, want_deep=True):
    seen = set()
    got = 0
    empty = 0
    for i, u in enumerate(paginate(seed)):
        h, fin = f(u, referer="https://" + urlparse(seed).netloc + "/")
        if not h or len(h) < 400:
            empty += 1
            if empty >= 3:
                break
            continue
        ls = texts_links(h, fin or u)
        arts = [(t, uu) for t, uu in ls if HIT.search(t) and LISTY.search(t)]
        # 直接附件（专栏页直接挂 xlsx）
        direct = [(t, uu) for t, uu in ls if ABS.search(uu)] if False else []
        new = 0
        for t, uu in arts:
            if uu in seen:
                continue
            seen.add(uu)
            new += 1
            try:
                got += grab_article(city, t, uu)
            except Exception as e:
                log("    art ERR %s %r" % (uu, e))
        log("  pg%d %s arts=%d new=%d" % (i + 1, u[:76], len(arts), new))
        empty = 0 if new else empty + 1
        if empty >= 4:
            break
        if not want_deep and i >= 2:
            break
    return got


SEEDS = {
    "威海": ["http://www.whcxcy.com/channels/2.html"],
    "枣庄": ["http://zzst.zaozhuang.gov.cn/gxjsqy/", "http://zzst.zaozhuang.gov.cn/gxjsqy/index.html"],
    "烟台": ["https://kjj.yantai.gov.cn/col/col16248/index.html"],
    "潍坊": ["http://kjj.weifang.gov.cn/kjjgd/?id=10"],
    "济宁": ["http://jnkj.jining.gov.cn/col/col34419/index.html"],
    "泰安": ["https://kjj.taian.gov.cn/col/col45670/index.html"],
    "临沂": ["https://kjj.linyi.gov.cn/info/1177/1.htm"],
    "聊城": ["http://kjj.liaocheng.gov.cn/col/col28061/index.html"],
    "德州": ["http://kjj.dezhou.gov.cn/col/col2355/index.html"],
    "滨州": ["http://kj.binzhou.gov.cn/"],
    "日照": ["http://stc.rizhao.gov.cn/"],
    "东营": ["http://dysti.dongying.gov.cn/"],
    "淄博": ["https://www.zibo.gov.cn/col/col2067/index.html"],
    "济南": ["http://jnsti.jinan.gov.cn/"],
    "菏泽": ["http://kjj.heze.gov.cn/"],
}


def main(cities):
    res = {}
    for c in cities:
        log("== %s" % c)
        tot = 0
        for seed in SEEDS.get(c, []):
            try:
                tot += crawl_seed(c, seed)
            except Exception as e:
                log("  SEED ERR %s %r" % (seed, e))
        res[c] = tot
        log("TOTAL %s=%d" % (c, tot))
    with open(os.path.join(BASE, "_run.json"), "w", encoding="utf-8") as fh:
        json.dump(res, fh, ensure_ascii=False)


if __name__ == "__main__":
    main(sys.argv[1:] or list(SEEDS))
