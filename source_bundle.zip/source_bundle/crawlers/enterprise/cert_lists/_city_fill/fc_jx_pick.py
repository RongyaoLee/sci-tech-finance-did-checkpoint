# -*- coding: utf-8 -*-
"""List the 江西 拟申请备案 公示 articles found in the harvested column dump."""
import os, sys, re, json, io

FILL = os.path.dirname(os.path.abspath(__file__))
arts = json.load(io.open(os.path.join(FILL, "_jx_all_articles.json"), encoding="utf-8"))
PAT = re.compile(r"拟申请备案|拟报备|拟认定")
rows = [a for a in arts if a["title"] and PAT.search(a["title"])]
rows.sort(key=lambda a: a["pubDate"] or "")
print("拟申请备案 articles:", len(rows))
for a in rows:
    ym = re.search(r"(\d{4})年", a["title"] or "")
    pc = re.search(r"第([一二三四五六七八九十]+)批", a["title"] or "")
    print("%s | %s | %s | %s%s" % (a["pubDate"], (a["title"] or "")[:52],
                                   a["url"], ym.group(1) if ym else "?",
                                   pc.group(1) if pc else ""))
json.dump(rows, io.open(os.path.join(FILL, "_jx_gongshi.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
