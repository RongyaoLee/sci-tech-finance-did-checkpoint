# -*- coding: utf-8 -*-
"""聚合站镜像页解析：chacewang / keceyun / sme-gov / zjintel 等把各市
「省科技型中小企业/创新型中小企业/研发中心」名单整表贴进正文。
本脚本按「企业名 + 区县」相邻出现配对，区县必须能反证到该市才收。
用法：python zj_mirror.py jobs_mirror.json   （[{"url","city","tag"}]）
输出：parts\浙江省_sme.jsonl （与 zj_sme.py 同文件，去重）
"""
import os, re, sys, json, time, html

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PARTS = os.path.join(HERE, "parts")
OUT = os.path.join(PARTS, "浙江省_sme.jsonl")
RAW = os.path.join(HERE, "raw")
sys.path.insert(0, HERE)
from zj_stbrain_rc import COUNTY2CITY  # noqa

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Accept-Language": "zh-CN,zh;q=0.9"}
CN = r"\u4e00-\u9fff"
SUF = ("有限公司", "股份公司", "有限责任公司", "公司", "厂", "中心", "研究院", "研究所",
       "事务所", "工作室", "合作社", "农场", "集团")
NAME_RE = re.compile(r"^[%s（）()·A-Za-z0-9\-—]{3,60}$" % CN)


def get(url, tries=3):
    import urllib.request
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            raw = urllib.request.urlopen(req, timeout=45).read()
            for enc in ("utf-8", "gb18030"):
                try:
                    return raw.decode(enc)
                except UnicodeDecodeError:
                    continue
            return raw.decode("utf-8", "ignore")
        except Exception as e:  # noqa
            last = e
            time.sleep(1.2 + i)
    raise last


def tokens(page):
    """把正文切成 token：表格行按 | 切，段落按换行/句读切。"""
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(page, "html.parser")
        for t in soup(["script", "style"]):
            t.decompose()
        for tr in soup.find_all("tr"):
            cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
            if cells:
                yield "\x00" + "\x00".join(cells) + "\x00"
        text = soup.get_text("\n", strip=True)
    except Exception:  # noqa
        text = re.sub(r"<[^>]+>", "\n", page)
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        for part in re.split(r"[|｜\t]+", line):
            part = part.strip()
            if not part:
                continue
            # sme-gov 这类站把整行「1 某某有限公司 缙云县」当一个文本节点，按空白再切
            for w in part.split():
                if w:
                    yield w


def is_name(s):
    return (3 < len(s) < 60 and NAME_RE.match(s) and
            (any(s.endswith(x) or x in s for x in SUF)) and not s.isdigit()
            and "序号" not in s and "企业名称" not in s)


def parse(page, city):
    cset = {c for c, ct in COUNTY2CITY.items() if ct == city}
    toks = list(tokens(page))
    got = []
    cur = ""            # 「婺城区（40家）」这类分组标题给出的当前区县
    for i, t in enumerate(toks):
        if t.startswith("\x00"):
            cells = [c for c in t.split("\x00") if c]
            nm = [c for c in cells if is_name(c)]
            cu = [c for c in cells if c in cset]
            if nm and cu:
                got.append((nm[0], cu[0]))
                cur = cu[0]
            elif nm and cur:
                got.append((nm[0], cur))
            continue
        hit = [c for c in cset if c in t]
        if hit and (re.search(r"[（(]\s*\d+\s*家\s*[)）]", t) or t in cset or len(t) <= len(hit[0]) + 6):
            cur = hit[0]
            continue
        if t in cset:
            cur = t
            for j in (i - 1, i - 2, i + 1):
                if 0 <= j < len(toks) and is_name(toks[j]):
                    got.append((toks[j].strip(), t))
                    break
            continue
        if is_name(t) and cur:
            got.append((t, cur))
    # 去重保序
    seen, out = set(), []
    for nm, cu in got:
        if nm in seen:
            continue
        seen.add(nm)
        out.append((nm, cu))
    return out


def main():
    jobs = json.load(open(sys.argv[1], encoding="utf-8"))
    have = set()
    if os.path.exists(OUT):
        for l in open(OUT, encoding="utf-8"):
            try:
                d = json.loads(l)
                have.add((d["name"], d["city"]))
            except Exception:
                pass
    with open(OUT, "a", encoding="utf-8") as fh:
        for j in jobs:
            try:
                page = get(j["url"])
                rows = parse(page, j["city"])
                new = 0
                for nm, cu in rows:
                    if (nm, j["city"]) in have:
                        continue
                    have.add((nm, j["city"]))
                    fh.write(json.dumps({"name": nm, "city": j["city"], "county": cu,
                                         "src": j["url"], "tag": j["tag"]}, ensure_ascii=False) + "\n")
                    new += 1
                fh.flush()
                print(f"{j['tag']:26s} {j['city']} bytes={len(page):7d} rows={len(rows):5d} new={new:5d}", flush=True)
                time.sleep(0.8)
            except Exception as e:  # noqa
                print(f"{j['tag']:26s} {j['city']} FAIL {type(e).__name__}: {str(e)[:80]}", flush=True)


if __name__ == "__main__":
    main()
