﻿# -*- coding: utf-8 -*-
import os,sys,re
sys.path.insert(0,os.getcwd())
import cf, requests
hosts=["www.zzgx.gov.cn","zzgxq.zhuzhou.gov.cn","www.xthtz.gov.cn","xthtz.xiangtan.gov.cn",
"hygx.hengyang.gov.cn","www.yygxq.gov.cn","www.czgxq.gov.cn","www.cdgxq.gov.cn","www.hhgxq.gov.cn",
"kfq.yueyang.gov.cn","www.yzjkq.gov.cn","www.syjkq.gov.cn","www.zjjjkq.gov.cn","www.loudijkq.gov.cn",
"www.changsha.gov.cn","kjj.changsha.gov.cn"]
for h in hosts:
    ok=None
    for u in ("http://"+h+"/","https://"+h+"/"):
        try:
            r=cf.S.get(u,timeout=8,allow_redirects=True)
            t=re.search(r"<title>(.*?)</title>",r.text,re.S)
            print("%-28s %s %s %s"%(h,r.status_code,len(r.content),(t.group(1).strip()[:40] if t else "")),flush=True)
            ok=1; break
        except Exception as e:
            pass
    if not ok: print("%-28s DEAD"%h,flush=True)
