# -*- coding: utf-8 -*-
import io, sys, os, re, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

BASE = os.path.dirname(os.path.abspath(__file__))
u = 'https://kjt.henan.gov.cn/2024/10-17/3074891.html'
st, txt, fu = H.get(u, timeout=30)
print('==', st, len(txt or ''))
open(os.path.join(BASE, '_hn3074891.html'), 'w', encoding='utf-8').write(txt or '')
for pat in ['上一篇', '下一篇', 'column', '栏目', 'search', 'breadcrumb', '当前位置']:
    for m in re.finditer(pat, txt or '', re.I):
        s = max(0, m.start() - 200); e = min(len(txt), m.end() + 260)
        print('---', pat, '::', re.sub(r'\s+', ' ', txt[s:e])[:420])
        break
