# -*- coding: utf-8 -*-
"""列出各市科技局/门户通知公告列表页中含「高新」的条目。"""
import sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

TARGETS = {
    "linyi": "https://kjj.linyi.gov.cn/tzgg.htm",
    "liaocheng": "http://kjj.liaocheng.gov.cn/channel_t_185_13371/",
}

for tag, url in TARGETS.items():
    sc, html, final = H.get(url, timeout=25, tries=2)
    print("=" * 70)
    print(tag, sc, len(html) if html else 0, final)
    if not html:
        continue
    # print all anchors with dates
    for href, txt in H.img_links(html, final):
        if txt and len(txt) > 6:
            print("  ", txt[:90], "|", href[:110])
