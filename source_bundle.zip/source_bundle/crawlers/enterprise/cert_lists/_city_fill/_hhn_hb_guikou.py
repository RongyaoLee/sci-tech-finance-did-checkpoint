# -*- coding: utf-8 -*-
"""扫 raw/ 下所有河北附件：token 级找「归口单位」，取前一个 token 作企业名。"""
import io, sys, os, re, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H
from _hhn_doc_heur import doc_text_heuristic

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(BASE, 'raw')
OUT = os.path.join(BASE, '_hb_guikou.jsonl')

GUIDE_RE = re.compile(r'^[\u4e00-\u9fa5]{2,8}(市科技局|市科学技术局|高新区.*|开发区.*|新区.*|管委会|县科技局|区科技局|科技局)$')
NAME_RE = re.compile(r'(公司|厂|院|所|中心|集团|大学|合作社|研究院|事务所|银行)$')

def text_of(fn):
    p = os.path.join(RAW, fn)
    data = open(p, 'rb').read()
    if fn.lower().endswith(('.doc', '.wps')):
        return doc_text_heuristic(p)
    return H.doc_text(fn, data)

fh = open(OUT, 'w', encoding='utf-8')
tot = 0
for fn in sorted(os.listdir(RAW)):
    if not fn.startswith('hb_hit_'):
        continue
    try:
        t = text_of(fn)
    except Exception as e:
        print('ERR', fn, e); continue
    toks = [x.strip() for x in re.split(r'[\t\n\r|｜]+', t)]
    toks = [x for x in toks if x]
    pairs = []
    for i in range(1, len(toks)):
        if GUIDE_RE.match(toks[i]) and len(toks[i]) <= 18 and NAME_RE.search(toks[i - 1]) and len(toks[i - 1]) >= 6:
            pairs.append((toks[i - 1], toks[i]))
    flag = '归口' in t
    print('%-38s chars=%-7d 归口=%-5s pairs=%d' % (fn, len(t), flag, len(pairs)))
    for nm, g in pairs:
        fh.write(json.dumps({'name': nm, 'guide': g, 'src': fn}, ensure_ascii=False) + '\n')
        tot += 1
fh.close()
print('total pairs', tot)
