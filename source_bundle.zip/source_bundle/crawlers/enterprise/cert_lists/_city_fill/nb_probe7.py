# -*- coding: utf-8 -*-
import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import harvest as H

arts = {}
for i, u in enumerate(["http://www.innocom.gov.cn/gqrdw/c101419/list_gsgg_l3.shtml"] +
                      ["http://www.innocom.gov.cn/gqrdw/c101419/list_gsgg_l3_%d.shtml" % n for n in (2, 3)]):
    sc, html, final = H.get(u, timeout=25, tries=2)
    print("page", i + 1, sc)
    if sc != 200:
        continue
    for href, t in H.img_links(html, final):
        if re.search(r"/c101419/\d{6}/", href):
            arts[href] = t
rows = [{"u": u, "t": t} for u, t in arts.items()]
with open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_arts.json", "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=1)
print("total arts", len(rows))

# inspect c101481 for link shape
sc, html, final = H.get("http://www.innocom.gov.cn/gqrdw/c101481/list_gsgg_l2.shtml", timeout=25, tries=2)
print("c101481", sc, len(html or ""))
if sc == 200:
    open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_nb_c101481.html", "w", encoding="utf-8").write(html)
    for href, t in H.img_links(html, final):
        if re.search(r"/20\d{4}/", href):
            print("   ", t[:70], "|", href)
