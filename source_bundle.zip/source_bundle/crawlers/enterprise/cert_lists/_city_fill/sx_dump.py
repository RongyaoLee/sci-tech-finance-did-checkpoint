# -*- coding: utf-8 -*-
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cf

for u in ["https://kjj.yl.gov.cn/kjdt/tzgg/201910/t20191028_774874.html",
          "https://kjj.xianyang.gov.cn/kjxw/tztg/202410/t20241018_1823764.html"]:
    h, f = cf.get(u, tries=1, timeout=20)
    print("=====", u, "len", len(h) if h else 0, "final", f)
    if not h:
        continue
    s = cf.soup_of(h)
    for t in s(["script", "style"]):
        t.decompose()
    txt = re.sub(r"\n{2,}", "\n", s.get_text("\n", strip=True))
    i = txt.find("企业")
    print(txt[:60].replace("\n", " / "))
    # print middle part around company names
    j = max(0, txt.find("有限公司") - 800)
    print("...", txt[j:j + 1800])
