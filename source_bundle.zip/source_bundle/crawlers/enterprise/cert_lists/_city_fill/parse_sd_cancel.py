# -*- coding: utf-8 -*-
"""Parse 山东省科技厅「取消/更名高新技术企业名单」附件（带 地市 列）。

PDF 用 fitz 抽文本后是逐行：序号 / 企业名称 / 证书编号 / 地市 / 年份
本脚本按「证书编号行 + 相邻地市行」定位，输出 JSONL。
"""
import io
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harvest as H

CITY_RE = re.compile(r"^(济南|青岛|淄博|枣庄|东营|烟台|潍坊|济宁|泰安|威海|日照|临沂|德州|聊城|滨州|菏泽|莱芜)市?$")
CERT_RE = re.compile(r"GR\d{12}")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "parts", "山东省_省级附件.jsonl")

SOURCES = [
    "http://kjt.shandong.gov.cn/attach/0/da7db68431974c4b94ead4d058b98604.pdf",
    "http://kjt.shandong.gov.cn/attach/0/1776752ffe7c47c5b76c1ec8b98b94dc.pdf",
    "http://kjt.shandong.gov.cn/module/download/downfile.jsp?classid=0&filename=c99c95ed67834a2daf1765c71f0f9c66.pdf",
]


def rows_from_text(txt, src):
    lines = [re.sub(r"\s+", "", x) for x in txt.split("\n")]
    lines = [x for x in lines if x]
    out = []
    for i, ln in enumerate(lines):
        m = CERT_RE.search(ln)
        if not m:
            continue
        cert = m.group(0)
        name = ""
        city = ""
        # name: nearest previous line that is not pure digits and not a header
        for j in range(i - 1, max(-1, i - 4), -1):
            cand = lines[j]
            if re.fullmatch(r"\d+", cand) or cand in ("企业名称", "高企证书编号", "地市", "序号"):
                continue
            if len(cand) >= 4 and not CITY_RE.match(cand):
                name = cand
                break
        for j in range(i + 1, min(len(lines), i + 4)):
            cand = lines[j]
            mm = CITY_RE.match(cand)
            if mm:
                city = mm.group(1) + "市"
                break
        if not city:
            continue
        out.append({"cert": cert, "name": name, "city": city, "county": "",
                    "src": src, "year": int(cert[2:6]), "batch": "取消资格名单"})
    return out


def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    allrows = []
    for u in SOURCES:
        st, data, fu = H.get(u, binary=True, tries=2, timeout=120)
        if st != 200 or not data:
            print("FAIL", u, st)
            continue
        H.save_raw("sd_cancel", u, data)
        txt = H.doc_text(u, data)
        rs = rows_from_text(txt, u)
        print(u[-40:], "rows=", len(rs))
        allrows += rs
    # dedupe by cert
    seen = {}
    for r in allrows:
        seen.setdefault(r["cert"], r)
    with io.open(OUT, "a", encoding="utf-8") as f:
        for r in seen.values():
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("TOTAL", len(seen), "->", OUT)
    from collections import Counter
    print(Counter(r["city"] for r in seen.values()).most_common())


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
