# -*- coding: utf-8 -*-
"""Dump a local attachment: first N rows + column heuristic (does it have a city column?)."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cf
sys.path.insert(0, os.path.dirname(cf.HERE))
import fetch_common as fc

path = sys.argv[1]
n = int(sys.argv[2]) if len(sys.argv) > 2 else 8
rows = []
if path.lower().endswith(".pdf"):
    it = fc.rows_from_pdf(path)
elif path.lower().endswith(".docx"):
    it = fc.rows_from_docx(path)
elif path.lower().endswith(".doc"):
    it = [list(r) for r in fc.rows_from_doc(path)]
else:
    it = fc.rows_from_xlsx(path)
for i, r in enumerate(it):
    rows.append(r)
    if i >= n:
        break
print(json.dumps({"file": os.path.basename(path), "rows": rows}, ensure_ascii=False, indent=1))
