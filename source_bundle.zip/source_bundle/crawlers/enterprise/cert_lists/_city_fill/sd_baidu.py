# -*- coding: utf-8 -*-
"""Baidu-based discovery of city-level 高新技术企业名单 documents (with 所属区市 column)."""
import os, re, sys, time, json, html, urllib.parse
import requests

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sd_city_parser as P
import sd_store as ST

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "raw_baidu")
os.makedirs(RAW, exist_ok=True)

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
_last = {}


def throttle(host, gap=0.6):
    t = _last.get(host, 0)
    d = time.time() - t
    if d < gap:
        time.sleep(gap - d)
    _last[host] = time.time()


def f(url, binary=False, timeout=30, tries=2, referer=None):
    h = urllib.parse.urlparse(url).netloc
    headers = {"User-Agent": UA,
               "Accept": "*/*",
               "Accept-Language": "zh-CN,zh;q=0.9",
               "Connection": "close"}
    if referer:
        headers["Referer"] = referer
    for i in range(tries):
        throttle(h)
        try:
            r = requests.get(url, headers=headers, timeout=timeout, verify=False,
                             allow_redirects=True)
            return r.status_code, (r.content if binary else r.text), r.url
        except Exception as e:
            err = repr(e)[:120]
            time.sleep(1.0 + i)
    return 0, (b"" if binary else ""), url


def baidu(q, pn=0):
    """Return list of (title, url) using mu= attr or baidu link."""
    url = "https://www.baidu.com/s?wd=" + urllib.parse.quote(q) + "&pn=%d&rn=20" % pn
    st, h, _ = f(url, referer="https://www.baidu.com/")
    if st != 200 or not h:
        return [], st, 0
    tag = "bd_" + re.sub(r"\W+", "_", q)[:40]
    try:
        open(os.path.join(RAW, tag + ".html"), "w", encoding="utf-8").write(h)
    except Exception:
        pass
    out = []
    # each result block
    for blk in re.split(r'<div[^>]*class="result', h)[1:]:
        m = re.search(r'mu="([^"]+)"', blk)
        t = re.search(r'<h3[^>]*>(.*?)</h3>', blk, re.S)
        title = re.sub(r"<[^>]+>", "", t.group(1)) if t else ""
        title = html.unescape(title).strip()
        if m:
            u = html.unescape(m.group(1))
            if u.startswith("http"):
                out.append((title, u))
    if not out:
        for m in re.finditer(r'href="(https?://www\.baidu\.com/link\?url=[^"]+)"', h):
            out.append(("", html.unescape(m.group(1))))
    return out, st, len(h)


DOC_RE = re.compile(r"\.(pdf|xlsx?|docx?|et)(\?|$)", re.I)
GOOD_KEY = ("高新", "名单", "认定")


def candidates(q, pages=1):
    seen, res = set(), []
    for pn in range(0, pages * 10, 10):
        items, st, ln = baidu(q, pn)
        for title, u in items:
            if u in seen:
                continue
            seen.add(u)
            res.append((title, u))
        if not items:
            break
    return res


def main(cities, years=(2022, 2023, 2024), pages=1, follow=True):
    report = {}
    for city in cities:
        got = 0
        docs = []
        for y in years:
            for q in ("%d年%s市高新技术企业名单" % (y, city),
                      '"%d年%s市高新技术企业名单" filetype:pdf' % (y, city),
                      "%s市%d年度高新技术企业名单 所属区市" % (city, y)):
                cands = candidates(q, pages)
                for title, u in cands:
                    if DOC_RE.search(u) or "attach" in u or "downfile" in u or "upload" in u:
                        docs.append((title, u))
                        break
        docs = list(dict.fromkeys(docs))
        for title, u in docs[:6]:
            st, data, final = f(u, binary=True)
            if st != 200 or len(data) < 2000:
                continue
            try:
                rows = P.rows_from_doc(u, data, city)
            except Exception as e:
                rows = []
            rows = [r for r in rows if r[0] and r[2]]
            if len(rows) >= 20:
                ST.append_rows(city, rows, u, "", "")
                got += len(rows)
                report.setdefault(city, []).append({"url": u, "rows": len(rows), "title": title})
        report.setdefault(city, [])
        print(city, "docs=%d" % len(docs), "rows=%d" % got, flush=True)
    json.dump(report, open(os.path.join(HERE, "_baidu_report.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    return report


if __name__ == "__main__":
    cities = sys.argv[1:] or ["潍坊"]
    main(cities)
