# -*- coding: utf-8 -*-
import sys, json, re
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill")
import sd_jnz_lib as L

T = [
    ("zb_sti", "http://sti.zibo.gov.cn/"),
    ("zz_st", "http://zzst.zaozhuang.gov.cn/"),
    ("jn_tzgg", "https://www.jinan.gov.cn/col/col44545/index.html"),
    ("jn_gk", "https://www.jinan.gov.cn/col/col24/index.html"),
    ("zb_tzgg", "https://www.zibo.gov.cn/col/col2067/index.html"),
]
out = {}
for tag, url in T:
    st, html, final = L.get(url)
    print("==", tag, st, len(html or ""), final)
    out[tag] = {"url": url, "st": st, "final": final, "len": len(html or "")}
    if not html:
        continue
    open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_%s.html" % tag, "w", encoding="utf-8").write(html)
    ls = L.anchors(html, final)
    print("   anchors:", len(ls))
    for h, t in ls[:25]:
        print("     ", t[:48], "|", h[:110])
json.dump(out, open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_city_fill\_sd_jnz_probe3.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
