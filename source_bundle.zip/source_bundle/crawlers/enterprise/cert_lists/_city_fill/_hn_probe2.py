﻿import os,sys,re
sys.path.insert(0,os.getcwd())
import cf
url="http://zwfw-new.hunan.gov.cn/hnzwfw/portal/MHWKx-KiTEOZT6Be4BUJF4/index.html"
h,_=cf.get(url)
print(h[1500:])
