# -*- coding: utf-8 -*-
import requests, urllib3, re, sys
urllib3.disable_warnings()
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
s = requests.Session(); s.headers.update({'User-Agent': UA})
ITEM = re.compile(r'href=[\'"](\.?/?\d{6}/t\d+_\d+\.html)[\'"][^>]*>(.*?)</a>', re.S)


def parse(u):
    r = s.get(u, timeout=40, verify=False)
    r.encoding = r.apparent_encoding or 'utf-8'
    t = r.text
    if r.status_code != 200:
        return r.status_code, len(t), []
    items = []
    for m in ITEM.finditer(t):
        title = re.sub(r'<[^>]+>', '', m.group(2))
        title = re.sub(r'\s+', ' ', title).strip()
        items.append((m.group(1), title))
    if not items:
        items = [(m, '') for m in re.findall(r'(\.?/?\d{6}/t\d+_\d+\.html)', t)]
    return r.status_code, len(t), items


for suf in ['index.html', 'index_1.html', 'index_2.html', 'index_3.html', 'index_20.html']:
    u = 'https://kjt.shaanxi.gov.cn/kjdt/tzgg/' + suf
    st, ln, items = parse(u)
    print(f'{st} {ln} {suf} items={len(items)}')
    for it in items[:3]:
        print('   ', it[0], it[1][:52])
    for it in items[-2:]:
        print('   ..', it[0], it[1][:52])
