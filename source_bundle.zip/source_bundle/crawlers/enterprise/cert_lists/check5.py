# -*- coding: utf-8 -*-
"""Sanity checks: province code inside cert, 2026 rows, weird names."""
import csv, io, re, collections, sys

CODE = {"陕西": "61", "甘肃": "62", "青海": "63", "宁夏": "64", "新疆": "65"}
for p, code in CODE.items():
    rows = list(csv.DictReader(io.open(p + ".csv", encoding="utf-8-sig")))
    certs = [r["证书编号"] for r in rows if r["证书编号"]]
    pc = collections.Counter(c[6:8] for c in certs)
    bad = {k: v for k, v in pc.items() if k != code}
    r26 = [r for r in rows if r["认定年度"] == "2026"]
    print("%s expect=%s got=%s bad=%s  rows2026=%d" % (p, code, dict(pc), bad or "-", len(r26)))
    for r in r26[:3]:
        print("     ", r["证书编号"], r["企业名称"][:28], r["批次"], r["来源URL"][-46:])
    # suspicious names
    sus = [r["企业名称"] for r in rows
           if len(r["企业名称"]) < 5 or re.search(r"(序号|企业名称|证书编号|合计|附件)", r["企业名称"])]
    if sus:
        print("     suspicious names:", len(sus), sus[:5])
    empty = sum(1 for r in rows if not r["企业名称"])
    print("     empty-name=%d  batch set=%s" % (empty, sorted({r["批次"] for r in rows})[:6]))
