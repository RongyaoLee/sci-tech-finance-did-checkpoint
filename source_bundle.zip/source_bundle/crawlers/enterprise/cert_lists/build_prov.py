# -*- coding: utf-8 -*-
"""Build final <prov>.csv for NW provinces from innocom 公示 + 备案公告 attachments.

- reuses fetch_common v2 (list/attachment/download/parse)
- adds .doc support (2016 复函) via work/cert_doc.py
- merges by cert (fallback name+year+batch), prefers rows carrying cert/city
- validates ^GR\\d{12}$ and cross-checks 认定年度 vs cert year
Usage: python build_prov.py [prov ...]
"""
import csv, hashlib, json, os, re, sys, collections

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.dirname(HERE)
sys.path.insert(0, WORK)
sys.path.insert(0, HERE)

import fetch_common as fc
import cert_doc

HTML_CACHE = os.path.join(HERE, "_cache", "html")
os.makedirs(HTML_CACHE, exist_ok=True)

_orig_get = fc.get


def cached_get(url, binary=False, tries=3):
    """Cache HTTP GETs on disk so re-runs do not hammer the site."""
    if not binary:
        key = hashlib.md5(url.encode()).hexdigest()
        p = os.path.join(HTML_CACHE, key + ".html")
        if os.path.exists(p):
            return open(p, encoding="utf-8").read(), url
        txt, real = _orig_get(url, binary=False, tries=tries)
        if txt:
            open(p, "w", encoding="utf-8").write(txt)
        return txt, real
    return _orig_get(url, binary=binary, tries=tries)


fc.get = cached_get

CERT_OK = re.compile(r"^GR\d{12}$")


def extract_any(path):
    """fetch_common.extract now understands .doc; fall back to cert_doc."""
    rows = fc.extract(path)
    if rows:
        return rows
    if path.lower().endswith(".doc"):
        try:
            got = cert_doc.parse_doc(path)
        except Exception as e:
            print("   ! doc err", os.path.basename(path)[:60], type(e).__name__)
            return []
        return [{"name": r["name"], "cert": r["cert"],
                 "city": r.get("region", ""), "county": ""}
                for r in got if r.get("name") and r.get("cert")]
    return []


def build(prov, pages=4):
    # replicate harvest() but with extract_any (adds .doc support)
    items = fc.list_items(prov, pages, kind="gg") + fc.list_items(prov, pages, kind="gs")
    print(f"[{prov}] items={len(items)}")
    allrows, dead = [], []
    for it in items:
        year, batch = fc.parse_meta(it["title"])
        if year and year < "2016":
            continue
        for atitle, aurl in fc.attachments(it["url"]):
            p = fc.download(aurl, prov, it["title"][:60] + "_" + os.path.basename(aurl)[:10])
            if not p:
                continue
            try:
                rs = extract_any(p)
            except Exception as e:
                print("   ! parse", os.path.basename(p)[:60], e)
                continue
            if not rs:
                dead.append((it["title"][:50], os.path.basename(p)[:60]))
                continue
            for r in rs:
                r.update(prov=prov, year=year, batch=batch, src=it["url"],
                         afile=os.path.basename(p))
                allrows.append(r)
    print(f"   raw rows={len(allrows)}  dead files={len(dead)}")
    for t, f in dead:
        print(f"   ~ 0-row(跳过): {f}  <- {t}")
    return allrows


def nm(s):
    return re.sub(r"\s+", "", s or "")


def merge(rows):
    """Attach certs to 公示 rows by exact (name, year) join, then dedupe by cert."""
    for r in rows:
        c = (r.get("cert") or "").strip().upper()
        r["cert"] = c if c and CERT_OK.match(c) else ""
        r["_n"] = nm(r.get("name"))

    by_ny, by_name = collections.defaultdict(set), collections.defaultdict(set)
    for r in rows:
        if not r["cert"]:
            continue
        by_ny[(r["_n"], r.get("year", ""))].add(r["cert"])
        by_name[r["_n"]].add(r["cert"])

    filled = 0
    for r in rows:
        if r["cert"] or not r["_n"]:
            continue
        cand = by_ny.get((r["_n"], r.get("year", ""))) or by_name.get(r["_n"])
        if cand and len(cand) == 1:          # unambiguous only — never guess
            r["cert"] = next(iter(cand))
            filled += 1
    print(f"   join-filled certs={filled}")

    merged, order = {}, []
    for r in rows:
        if not r["_n"]:
            continue
        key = ("C", r["cert"]) if r["cert"] else ("N", r["_n"], r.get("year", ""), r.get("batch", ""))
        if key not in merged:
            merged[key] = dict(r)
            order.append(key)
            continue
        cur = merged[key]
        if r["cert"] and not cur["cert"]:
            cur["cert"] = r["cert"]
        for f in ("city", "county"):
            if not cur.get(f) and r.get(f):
                cur[f] = r.get(f)
        if not cur.get("year") and r.get("year"):
            cur["year"] = r["year"]
        if not cur.get("batch") and r.get("batch"):
            cur["batch"] = r["batch"]
    return [merged[k] for k in order]


def write(prov, rows):
    out = os.path.join(HERE, prov + ".csv")
    nrec = collections.Counter()
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"])
        for r in rows:
            name = re.sub(r"\s+", "", r["name"] or "")
            cert = r.get("cert") or ""
            year = r.get("year") or ""
            if cert:
                cy = cert[2:6]
                if cy.isdigit():
                    if year and year != cy:
                        nrec["year_mismatch"] += 1
                    year = cy
            w.writerow([name, cert, r.get("city", ""), r.get("county", ""),
                        year, r.get("batch", ""), r.get("src", "")])
    n = len(rows)
    nc = sum(1 for r in rows if r.get("cert"))
    print(f"== {prov}: {n} rows, {nc} with cert ({100.0*nc/max(n,1):.0f}%) -> {out}")
    if nrec:
        print("   flags:", dict(nrec))
    return out


if __name__ == "__main__":
    provs = sys.argv[1:] or ["陕西", "甘肃", "青海", "宁夏", "新疆"]
    for p in provs:
        rows = merge(build(p, 4))
        write(p, rows)
