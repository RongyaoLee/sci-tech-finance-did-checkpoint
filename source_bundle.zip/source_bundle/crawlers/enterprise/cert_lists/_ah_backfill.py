# -*- coding: utf-8 -*-
"""补抓安徽 2019/2020 备案复函（c101456 第 2 页上的 5 条），并入 安徽.csv。"""
import csv, os, re, sys
import fetch_common as fc

HERE = os.path.dirname(os.path.abspath(__file__))
PAGES = [
    ("关于安徽省2019年第一批高新技术企业备案的复函", "/gqrdw/c101456/201912/96699a03a415448dbaf44ad7f6f9a9fe.shtml"),
    ("关于安徽省2019年第二批高新技术企业备案的复函", "/gqrdw/c101456/202001/cb92427eae4f48a3a16f3d4f023b12ea.shtml"),
    ("关于安徽省2020年第一批高新技术企业备案的复函", "/gqrdw/c101456/202012/4c441d208b1544fdba20cbcb2d30fa4f.shtml"),
    ("关于安徽省2020年第二批高新技术企业备案的复函", "/gqrdw/c101456/202012/1f644134f65e4ae3914810ab5da123df.shtml"),
    ("安徽省：关于2020年高新技术企业补充备案的复函", "/gqrdw/c101456/202103/7e44cc92ab744f87a27ffbda96d8ecdb.shtml"),
]
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]

existing = {}
if os.path.exists(os.path.join(HERE, "安徽.csv")):
    for r in csv.DictReader(open(os.path.join(HERE, "安徽.csv"), encoding="utf-8-sig")):
        c = (r.get("证书编号") or "").strip()
        if c:
            existing[c] = r

new = []
for title, path in PAGES:
    url = fc.BASE + path
    year, batch = fc.parse_meta(title)
    atts = fc.attachments(url)
    print(f"[{title[:38]}] year={year} batch={batch} atts={len(atts)}")
    for atitle, aurl in atts:
        p = fc.download(aurl, "安徽", title[:50] + "_" + os.path.basename(aurl)[:10])
        if not p:
            print("   ! download fail", aurl)
            continue
        try:
            rows = fc.extract(p)
        except Exception as e:
            print("   ! parse err", e)
            continue
        keep = [r for r in rows if len(r["cert"]) >= 8 and r["cert"][6:8] == "34"]
        print(f"   {os.path.basename(p)}: rows={len(rows)} 安徽={len(keep)}")
        for r in keep:
            r.update(year=year, batch=batch, src=url)
            new.append(r)

added = 0
for r in new:
    if r["cert"] in existing:
        continue
    existing[r["cert"]] = {"企业名称": r["name"], "证书编号": r["cert"], "城市": "",
                           "区县": "", "认定年度": r["year"], "批次": r["batch"], "来源URL": r["src"]}
    added += 1
print("新增", added, "总", len(existing))
with open(os.path.join(HERE, "安徽.csv"), "w", encoding="utf-8-sig", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=HEADER)
    w.writeheader()
    for r in existing.values():
        w.writerow({f: r.get(f, "") for f in HEADER})
