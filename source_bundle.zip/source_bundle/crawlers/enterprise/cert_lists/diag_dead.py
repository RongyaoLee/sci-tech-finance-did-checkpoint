# -*- coding: utf-8 -*-
"""Diagnose every attachment that produced 0 rows: scanned vs bad-font vs no-cert vs parser bug."""
import glob, os, re, sys, csv, io

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fetch_common as fc
import fitz

DEAD = {
    "陕西": ["陕西省_关于2020年高新技术企业补充备案的复函_19c46bd4d1.pdf"],
    "甘肃": ["关于甘肃省2021年第一批备案高新技术企业名单的公告_05bbe7b153.pdf",
             "关于甘肃省2020年第二批高新技术企业备案的复函_8228fffec3.pdf",
             "关于甘肃省2020年第一批高新技术企业备案的复函_3461a7e0fa.pdf",
             "关于公示甘肃省2021年第二批认定报备高新技术企业名单的通知_c2bc3e278d.pdf"],
    "宁夏": ["关于宁夏回族自治区2021年第一批备案高新技术企业名单的公告_47db33d149.pdf",
             "关于宁夏回族自治区2020年第二批高新技术企业备案的复函_7c314b6888.pdf",
             "关于宁夏回族自治区2020年第一批高新技术企业备案的复函_505dc40d3f.pdf"],
    "青海": ["关于青海省2020年第一批高新技术企业备案的复函_728b8bb0ce.pdf"],
    "新疆": ["关于新疆维吾尔自治区2021年第一批备案高新技术企业名单的公告_9166c9dd4a.pdf",
             "新疆维吾尔自治区_关于2020年高新技术企业补充备案的复函_c7a093cacb.pdf",
             "关于新疆维吾尔自治区2020年第二批高新技术企业备案的复函_f7f6bc7ddb.pdf",
             "关于新疆维吾尔自治区2020年第一批高新技术企业备案的复函_18e145dd95.pdf",
             "关于公示新疆维吾尔自治区2016年第一批拟通过认定高新技术企业名单的通知_685a85eac5.pdf"],
}


def diag(path):
    d = fitz.open(path)
    np = d.page_count
    chars = 0
    sample = ""
    gr = 0
    for i in range(min(np, 3)):
        t = d[i].get_text()
        chars += len(t.strip())
        if not sample and t.strip():
            sample = re.sub(r"\s+", " ", t.strip())[:120]
        gr += len(re.findall(r"GR\s?\d{6,}", t))
    d.close()
    return np, chars, gr, sample


print("%-4s %-58s %5s %6s %5s %s" % ("省", "文件", "页", "字符", "GR数", "判定"))
for prov, files in DEAD.items():
    for fn in files:
        p = os.path.join(HERE, "_raw", prov, fn)
        if not os.path.exists(p):
            print("%-4s %-58s  缺失" % (prov, fn[:58]))
            continue
        np, chars, gr, sample = diag(p)
        if chars == 0:
            verdict = "扫描件(无文字层)"
        elif gr == 0:
            verdict = "有文字层但无GR编号(该件本身无证书编号)" 
        else:
            verdict = "有GR但解析失败(可修)"
        print("%-4s %-58s %5d %6d %5d %s" % (prov, fn[:58], np, chars, gr, verdict))
        if sample and verdict.startswith("有"):
            print("      sample:", sample)
