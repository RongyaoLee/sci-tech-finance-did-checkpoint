# -*- coding: utf-8 -*-
"""定稿：同一年同一企业只留一行（优先带证书编号的那行），重庆补城市=重庆市。"""
import csv, os, re, sys

BASE = os.path.dirname(os.path.abspath(__file__))
FIELDS = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
CERT = re.compile(r"GR\d{12}")


def clean(s):
    return re.sub(r"\s+", "", (s or "")).strip()


def batch_key(b):
    return b or ""


def main(prov, city):
    src = os.path.join(BASE, prov + ".csv")
    rows = list(csv.DictReader(open(src, encoding="utf-8-sig")))
    groups = {}
    order = []
    for r in rows:
        name = clean(r["企业名称"])
        if not name:
            continue
        cert = clean(r["证书编号"])
        if cert and not CERT.fullmatch(cert):
            cert = ""
        year = clean(r["认定年度"])
        key = (name, year)
        rec = {
            "企业名称": name,
            "证书编号": cert,
            "城市": city,
            "区县": clean(r["区县"]),
            "认定年度": year,
            "批次": clean(r["批次"]),
            "来源URL": clean(r["来源URL"]),
        }
        cur = groups.get(key)
        if cur is None:
            groups[key] = rec
            order.append(key)
            continue
        # 合并：证书优先；批次取非空；来源取带证书那行
        if rec["证书编号"] and not cur["证书编号"]:
            rec["批次"] = cur["批次"] or rec["批次"]
            groups[key] = rec
        else:
            if not cur["批次"] and rec["批次"]:
                cur["批次"] = rec["批次"]
            if not cur["来源URL"]:
                cur["来源URL"] = rec["来源URL"]
    out = [groups[k] for k in order]
    out.sort(key=lambda r: (r["认定年度"], r["批次"], r["企业名称"]))
    with open(src, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(out)
    ncert = sum(1 for r in out if r["证书编号"])
    print(f"{prov}: {len(rows)} -> {len(out)} rows, cert {ncert} ({ncert*100.0/max(len(out),1):.1f}%)")


if __name__ == "__main__":
    main("重庆", "重庆市")
    main("西藏", "")
