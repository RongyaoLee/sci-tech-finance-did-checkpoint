# -*- coding: utf-8 -*-
"""列出 innocom 某栏目多页的公告标题（用于定位 2017-2020 备案复函）。"""
import sys, re
import fetch_common as fc
from bs4 import BeautifulSoup

ch = sys.argv[1] if len(sys.argv) > 1 else "c101456"
pages = int(sys.argv[2]) if len(sys.argv) > 2 else 8
kw = sys.argv[3] if len(sys.argv) > 3 else ""
for p in range(1, pages + 1):
    suffix = "" if p == 1 else "_%d" % p
    url = f"{fc.BASE}/gqrdw/{ch}/list_gsgg_l3{suffix}.shtml"
    html, _ = fc.get(url)
    if not html:
        print(p, "FAIL")
        continue
    soup = BeautifulSoup(html, "lxml")
    n = 0
    for a in soup.find_all("a", href=True):
        t = a.get_text(strip=True)
        if not t or "高新技术企业" not in t:
            continue
        if kw and kw not in t:
            continue
        n += 1
        print(f"p{p} | {t} | {a['href']}")
    print(f"-- page {p}: {n} hits")
