# -*- coding: utf-8 -*-
"""审计 _raw/<省>/ 下 PDF 的可用性：页数、字符数、CJK 占比、可否解析出表格行。"""
import csv
import glob
import os
import re
import sys

import pymupdf

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

CJK = re.compile(r'[\u4e00-\u9fff]')


def main():
    base = os.path.dirname(os.path.abspath(__file__))
    provs = sys.argv[1:] or ['云南', '贵州', '广西', '江西', '海南']
    out = []
    for p in provs:
        for f in sorted(glob.glob(os.path.join(base, '_raw', p, '*.pdf'))):
            try:
                d = pymupdf.open(f)
                txt = ''.join(pg.get_text() for pg in d)
                pages = d.page_count
                d.close()
            except Exception as e:  # noqa: BLE001
                out.append([p, os.path.basename(f), -1, -1, -1, 'ERR:' + type(e).__name__])
                continue
            stripped = txt.strip()
            cjk = len(CJK.findall(stripped))
            ratio = round(cjk / max(1, len(stripped)), 3)
            if not stripped:
                verdict = 'scanned(0 char)'
            elif ratio < 0.15:
                verdict = 'garbled-font'
            else:
                verdict = 'text-ok'
            out.append([p, os.path.basename(f), pages, len(stripped), ratio, verdict])
    dest = os.path.join(base, '_raw', 'pdf_audit.csv')
    with open(dest, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['省', '文件', '页数', '字符数', 'CJK占比', '判定'])
        w.writerows(out)
    for row in out:
        if row[5] != 'text-ok':
            print(row[0], '|', row[1][:60], '|', row[2], row[3], row[4], '|', row[5])
    print('---')
    from collections import Counter
    print(Counter(r[5] for r in out))
    print('audit ->', dest)


if __name__ == '__main__':
    main()
