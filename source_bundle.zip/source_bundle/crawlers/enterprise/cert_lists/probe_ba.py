# -*- coding: utf-8 -*-
"""Probe innocom 备案公告 column (c101481) for target provinces; report titles + attachment urls."""
import sys, re, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bs4 import BeautifulSoup
import fetch_common as F

TARGET = ["云南", "贵州", "广西", "江西", "海南"]
COLS = ["c101481", "c101480", "c101482", "c101479"]

out = {}
for col in COLS:
    items = []
    for p in range(1, 4):
        suffix = "" if p == 1 else "_%d" % p
        url = f"{F.BASE}/gqrdw/{col}/list_gsgg_l2{suffix}.shtml"
        html, _ = F.get(url)
        if not html:
            print("no html", url)
            continue
        soup = BeautifulSoup(html, "lxml")
        n = 0
        for a in soup.find_all("a", href=True):
            t = a.get_text(strip=True)
            h = a["href"]
            if not re.search(r"/gqrdw/", h) or not t:
                continue
            items.append({"title": t, "url": h if h.startswith("http") else F.BASE + (h if h.startswith("/") else "/" + h)})
            n += 1
        print(f"[{col}] p{p}: {n} links")
        if n == 0:
            break
    out[col] = items
    print(f"[{col}] total {len(items)}")

json.dump(out, open(os.path.join(F.HERE, "_raw", "probe_ba.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

for col, items in out.items():
    hits = [it for it in items if any(t in it["title"] for t in TARGET)]
    print(f"== {col}: {len(hits)} target hits")
    for h in hits[:8]:
        print("   ", h["title"][:70], h["url"])
