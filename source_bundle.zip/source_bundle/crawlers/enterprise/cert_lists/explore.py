# -*- coding: utf-8 -*-
"""Probe innocom.gov.cn structure for province announcement lists."""
import re, sys, requests
from bs4 import BeautifulSoup

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
H = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9"}

PROVS = ["四川", "重庆", "河南", "湖北", "湖南", "河北", "山西", "陕西", "云南",
         "贵州", "广西", "江西", "安徽", "福建", "辽宁", "吉林", "黑龙江",
         "内蒙古", "甘肃", "宁夏", "青海", "新疆", "西藏", "海南", "天津"]


def get(url, tries=2):
    last = None
    for u in ([url] + ([url.replace("https://", "http://")] if url.startswith("https") else [])):
        for _ in range(tries):
            try:
                r = requests.get(u, headers=H, timeout=30, verify=False)
                r.encoding = r.apparent_encoding or "utf-8"
                if r.status_code == 200:
                    return r
            except Exception as e:
                last = e
    if last:
        print("  ERR", url, type(last).__name__, str(last)[:100])
    return None


def probe_home():
    r = get("http://www.innocom.gov.cn")
    if not r:
        return
    soup = BeautifulSoup(r.text, "lxml")
    out = []
    for a in soup.find_all("a", href=True):
        txt = a.get_text(strip=True)
        for p in PROVS:
            if p in txt and len(txt) < 30:
                out.append((p, txt, a["href"]))
    seen = set()
    for p, t, h in out:
        k = (p, h)
        if k in seen:
            continue
        seen.add(k)
        print(p, "|", t, "|", h)


def probe_list(url):
    r = get(url)
    if not r:
        return
    soup = BeautifulSoup(r.text, "lxml")
    print("== ", url, r.status_code, len(r.content))
    for a in soup.find_all("a", href=True):
        t = a.get_text(strip=True)
        if len(t) > 8:
            print("  ", t[:70], "|", a["href"])


if __name__ == "__main__":
    if len(sys.argv) > 1:
        probe_list(sys.argv[1])
    else:
        probe_home()
