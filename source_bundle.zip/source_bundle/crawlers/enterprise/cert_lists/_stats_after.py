# -*- coding: utf-8 -*-
"""合并后统计：行数/有证书/有城市/年度区间/覆盖度（行数 ÷ 当年各码段最大顺序号之和）。"""
import csv, os, collections

HERE = os.path.dirname(os.path.abspath(__file__))
FILES = [("江苏", "江苏省.csv"), ("浙江", "浙江省.csv"), ("上海", "上海市.csv"), ("安徽", "安徽省.csv")]

for prov, fn in FILES:
    rows = list(csv.DictReader(open(os.path.join(HERE, fn), encoding="utf-8-sig")))
    certs = [(r.get("证书编号") or "").strip() for r in rows]
    dup = len(certs) - len(set(certs))
    ncert = sum(1 for c in certs if c)
    ncity = sum(1 for r in rows if (r.get("城市") or "").strip())
    cities = collections.Counter((r.get("城市") or "").strip() for r in rows if (r.get("城市") or "").strip())
    per = collections.Counter((r.get("认定年度") or "") for r in rows)
    # 覆盖度：按年度、按 4 位码段统计最大顺序号
    segmax = collections.defaultdict(int)
    for c in certs:
        if len(c) >= 14:
            y, seg, seq = c[2:6], c[6:10], int(c[10:])
            segmax[(y, seg)] = max(segmax[(y, seg)], seq)
    denom = collections.defaultdict(int)
    for (y, seg), mx in segmax.items():
        denom[y] += mx
    years = sorted(per)
    print(f"== {prov} rows={len(rows)} cert={ncert} dup={dup} city={ncity} cities={len(cities)} years={years[0]}-{years[-1]}")
    for y in years:
        d = denom.get(y, 0)
        print(f"   {y}: rows={per[y]:6d} 估算证书总数={d:6d} 覆盖度={per[y]/d:.3f}" if d else f"   {y}: rows={per[y]}")
    if cities:
        print("   top cities:", cities.most_common(6))
