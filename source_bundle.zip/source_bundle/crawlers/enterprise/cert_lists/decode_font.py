# -*- coding: utf-8 -*-
"""Decode PDFs whose embedded subset fonts lack ToUnicode (garbled text layer).

Strategy: code -> glyph id (identity encoding) -> unicode via the font's own cmap,
inverted. Test on one file first.
"""
import sys, os, re, io
import pymupdf
from fontTools.ttLib import TTFont

path = sys.argv[1]
doc = pymupdf.open(path)


def font_unicode_map(xref):
    """Return {code_char: unicode_char} using the embedded font's cmap (inverted)."""
    name, ext, typ, buf = doc.extract_font(xref)
    if not buf:
        return {}
    try:
        tt = TTFont(io.BytesIO(buf), fontNumber=0, lazy=True)
    except Exception:
        return {}
    if "cmap" not in tt:
        return {}
    inv = {}
    for table in tt["cmap"].tables:
        for uni, gid in table.cmap.items():
            # identity encoding: the PDF byte code equals the glyph id
            inv.setdefault(gid, uni)
    # glyph id -> code used in the PDF: usually gid itself
    out = {}
    for gid, uni in inv.items():
        if 0 <= gid < 0x10000:
            out[chr(gid)] = chr(uni)
    return out


page = doc[int(sys.argv[2]) if len(sys.argv) > 2 else 3]
print("raw:", repr(page.get_text()[:160]))
for f in page.get_fonts(full=True):
    xref = f[0]
    m = font_unicode_map(xref)
    print(f[3], "map size", len(m), "sample", list(m.items())[:6])
    if m:
        t = page.get_text()
        dec = "".join(m.get(ch, ch) for ch in t)
        print("decoded sample:", repr(dec[:300]))
