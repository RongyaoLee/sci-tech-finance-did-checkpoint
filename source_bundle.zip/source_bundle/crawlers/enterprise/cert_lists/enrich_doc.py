# -*- coding: utf-8 -*-
"""从 .doc（Word97，UTF-16 文本流）里抽取 序号/企业名称/证书编号 三元组，追加进省 CSV。

重庆 2016 第一批的公示与备案复函都是 .doc，pymupdf 无法解析；
其 WordDocument 流内表格以 \\x07 分列，可直接用 UTF-16LE 解码后正则提取。
"""
import csv, glob, os, re, sys

BASE = os.path.dirname(os.path.abspath(__file__))
FIELDS = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]

TARGETS = {
    "重庆": dict(
        pattern="*2016*复函*.doc",
        year="2016",
        batch="第1批",
        city="重庆市",
        url="http://www.innocom.gov.cn/gqrdw/c101469/201612/9608f480d31e4db19124dc2c8bf6c435.shtml",
    ),
}

ROW = re.compile(r"\x07(\d{1,4})\x07([^\x07]{4,60}?)\x07(GR\d{12})\x07")


def parse_doc(path):
    txt = open(path, "rb").read().decode("utf-16-le", "ignore")
    return [(int(a), b.strip(), c) for a, b, c in ROW.findall(txt)]


def main():
    for prov, cfg in TARGETS.items():
        files = glob.glob(os.path.join(BASE, "_raw", prov, cfg["pattern"]))
        if not files:
            print(prov, "no file")
            continue
        rows = parse_doc(files[0])
        print(prov, os.path.basename(files[0]), "->", len(rows), "rows")
        if not rows:
            continue
        path = os.path.join(BASE, prov + ".csv")
        old = list(csv.DictReader(open(path, encoding="utf-8-sig")))
        have = {(r["企业名称"], r["认定年度"]) for r in old}
        add = []
        for _, name, cert in rows:
            if (name, cfg["year"]) in have:
                continue
            add.append({
                "企业名称": name, "证书编号": cert, "城市": cfg["city"],
                "区县": "", "认定年度": cfg["year"], "批次": cfg["batch"],
                "来源URL": cfg["url"],
            })
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=FIELDS)
            w.writeheader()
            w.writerows(old)
            w.writerows(add)
        print("   appended", len(add), "-> total", len(old) + len(add))


if __name__ == "__main__":
    main()
