# -*- coding: utf-8 -*-
"""过滤国家网抓取结果（混入了别省复函）并按省合并进省级 CSV。
- 国家网文件：江苏.csv / 浙江.csv / 上海.csv / 安徽.csv（fetch_common 产出）
- 过滤：只保留证书编号第 7-8 位等于本省前缀的行（32/33/31/34）
- 合并：以省级 CSV（带城市）为基底，按证书编号对齐，城市永不被空值覆盖
"""
import csv, os, collections

HERE = os.path.dirname(os.path.abspath(__file__))
PFX = {"江苏": "32", "浙江": "33", "上海": "31", "安徽": "34"}
TARGET = {"江苏": "江苏省.csv", "浙江": "浙江省.csv", "上海": "上海市.csv", "安徽": "安徽省.csv"}
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]


def read(p):
    with open(p, encoding="utf-8-sig", newline="") as fh:
        return [dict(r) for r in csv.DictReader(fh)]


summary = []
for prov, pfx in PFX.items():
    nat_p = os.path.join(HERE, prov + ".csv")
    tgt_p = os.path.join(HERE, TARGET[prov])
    nat = read(nat_p)
    keep = []
    dropped = collections.Counter()
    for r in nat:
        c = (r.get("证书编号") or "").strip()
        if len(c) >= 8 and c.startswith("GR"):
            if c[6:8] == pfx:
                keep.append(r)
            else:
                dropped[c[3:7]] += 1
        else:
            dropped["无证书"] += 1
    mine = read(tgt_p)

    by_cert = {(r["证书编号"] or "").strip(): r for r in mine if (r.get("证书编号") or "").strip()}
    by_name = collections.defaultdict(list)
    for r in mine:
        by_name[(r["企业名称"].strip(), (r.get("认定年度") or "").strip())].append(r)

    added = filled = 0
    for r in keep:
        c = (r.get("证书编号") or "").strip()
        nm = (r.get("企业名称") or "").strip()
        if not nm:
            continue
        if c in by_cert:
            t = by_cert[c]
            for f in ("城市", "区县"):
                if not (t.get(f) or "").strip() and (r.get(f) or "").strip():
                    t[f] = r[f]
            if not (t.get("来源URL") or "").strip():
                t["来源URL"] = r.get("来源URL", "")
            continue
        cand = by_name.get((nm, (r.get("认定年度") or "").strip()))
        if cand:
            t = cand[0]
            if not (t.get("证书编号") or "").strip():
                t["证书编号"] = c
                by_cert[c] = t
                filled += 1
            continue
        row = {f: (r.get(f) or "") for f in HEADER}
        mine.append(row)
        by_cert[c] = row
        by_name[(nm, row.get("认定年度", ""))].append(row)
        added += 1

    seen_c, seen_n, out = set(), set(), []
    for r in mine:
        c = (r.get("证书编号") or "").strip()
        nk = (r["企业名称"].strip(), (r.get("认定年度") or "").strip(), (r.get("批次") or "").strip())
        if c:
            if c in seen_c:
                continue
            seen_c.add(c)
        elif nk in seen_n:
            continue
        seen_n.add(nk)
        out.append(r)

    out.sort(key=lambda r: ((r.get("认定年度") or ""), (r.get("批次") or ""), (r.get("证书编号") or "")))
    with open(tgt_p, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=HEADER)
        w.writeheader()
        for r in out:
            w.writerow({f: r.get(f, "") for f in HEADER})

    ncert = sum(1 for r in out if (r.get("证书编号") or "").strip())
    ncity = sum(1 for r in out if (r.get("城市") or "").strip())
    years = sorted({(r.get("认定年度") or "") for r in out if r.get("认定年度")})
    per = collections.Counter((r.get("认定年度") or "") for r in out)
    print(f"[{prov}] nat_in={len(nat)} kept={len(keep)} dropped={sum(dropped.values())} "
          f"({dict(dropped.most_common(4))}) mine={len(mine)-added} added={added} cert_filled={filled}")
    print(f"    -> rows={len(out)} cert={ncert} city={ncity} years={years[0]}-{years[-1]}")
    print("    per-year:", {y: per[y] for y in years})
    summary.append((prov, len(out), ncert, ncity, f"{years[0]}-{years[-1]}"))

print("\n== SUMMARY ==")
for s in summary:
    print(s)
