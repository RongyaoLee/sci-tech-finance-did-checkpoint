# -*- coding: utf-8 -*-
"""Rebuild a province CSV from already-downloaded attachments in _raw/<省>/.

No network for the attachments themselves; only the detail-page list is fetched
(once) so that each row keeps a traceable 来源URL.

usage:  python reextract.py <省> [out_suffix] [pages]
        out_suffix default "" -> writes <省>.csv ; pass "_v2" -> <省>_v2.csv
"""
import csv
import os
import re
import sys

import fetch_common as F

SUFFIX_RE = re.compile(r"_[0-9a-f]{10}$")
OK_EXT = (".pdf", ".xlsx", ".xls", ".docx", ".doc")


def title_of(path):
    base = os.path.splitext(os.path.basename(path))[0]
    return SUFFIX_RE.sub("", base)


def url_map(prov, pages):
    m = {}
    for kind in ("gg", "gs"):
        try:
            for it in F.list_items(prov, pages, kind):
                m.setdefault(it["title"], it["url"])
        except Exception as e:
            print("   ! list fail", kind, e)
    return m


def run(prov, suffix="", pages=4):
    root = os.path.join(F.RAW, prov)
    if not os.path.isdir(root):
        print(prov, "no _raw dir")
        return
    files = []
    for d, _, fn in os.walk(root):
        for f in fn:
            if f.lower().endswith(OK_EXT):
                files.append(os.path.join(d, f))
    files.sort()
    umap = url_map(prov, pages)

    def src_of(title):
        if title in umap:
            return umap[title]
        for t, u in umap.items():
            if t[:24] == title[:24]:
                return u
        return ""

    rows = []
    stat = []
    for p in files:
        title = title_of(p)
        year, batch = F.parse_meta(title)
        if not year:
            continue
        if year < "2016":
            continue
        try:
            got = F.extract(p)
        except Exception as e:
            stat.append((os.path.basename(p), year, batch, -1, 0))
            print("   ! parse err", os.path.basename(p)[:50], e)
            continue
        ncert = sum(1 for r in got if r["cert"])
        stat.append((os.path.basename(p), year, batch, len(got), ncert))
        if not got:
            continue
        src = src_of(title)
        for r in got:
            r.update(prov=prov, year=year, batch=batch, src=src)
            rows.append(r)

    print(f"== {prov}: {len(files)} files -> {len(rows)} raw rows")
    for b, y, ba, n, c in stat:
        print(f"   {y}/{ba or '-':8s} {n:6d} cert={c:6d}  {b[:60]}")

    out = os.path.join(F.HERE, prov + suffix + ".csv")
    merged = {}
    for r in rows:
        if not r.get("name"):
            continue
        if prov == "重庆" and not r.get("city"):
            r["city"] = "重庆市"
        key = (r["name"], r.get("year", ""), r.get("batch", ""))
        cur = merged.get(key)
        if cur is None:
            merged[key] = dict(r)
            continue
        for f in ("cert", "city", "county"):
            if not cur.get(f) and r.get(f):
                cur[f] = r[f]
        if r.get("src") and not cur.get("src"):
            cur["src"] = r["src"]
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"])
        for r in merged.values():
            w.writerow([r["name"], r.get("cert", ""), r.get("city", ""),
                        r.get("county", ""), r.get("year", ""), r.get("batch", ""),
                        r.get("src", "")])
    nc = sum(1 for r in merged.values() if r.get("cert"))
    print(f"   -> {os.path.basename(out)}: {len(merged)} rows, {nc} cert")


if __name__ == "__main__":
    a = sys.argv[1:]
    prov = a[0]
    suffix = a[1] if len(a) > 1 else ""
    pages = int(a[2]) if len(a) > 2 else 4
    run(prov, suffix, pages)
