# -*- coding: utf-8 -*-
"""Inspect one 备案公告 detail page: list attachment urls and peek at the PDF text."""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fetch_common as F

URL = sys.argv[1] if len(sys.argv) > 1 else None
if not URL:
    d = json.load(open(os.path.join(F.HERE, "_raw", "ba_items.json"), encoding="utf-8"))
    for prov, items in d.items():
        arts = [it for it in items if re.search(r"备案的公告|认定的高新技术企业进行", it["title"])]
        if arts:
            URL = arts[0]["url"]
            print("prov", prov, arts[0]["title"])
            break

print("URL:", URL)
atts = F.attachments(URL)
print("attachments:", len(atts))
for t, u in atts:
    print("   ", (t or "")[:50], u)

if atts:
    t, u = atts[0]
    p = F.download(u, "_probe2", "probe_ba")
    print("saved:", p)
    if p:
        try:
            rows = list(F.rows_from_pdf(p)) if p.lower().endswith(".pdf") else list(F.rows_from_xlsx(p))
            print("rows:", len(rows))
            for r in rows[:14]:
                print("   ", r)
        except Exception as e:
            print("parse err", e)
