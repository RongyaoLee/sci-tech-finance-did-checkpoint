# -*- coding: utf-8 -*-
"""Minimal Word 97-2003 (.doc) binary text extractor (piece-table based).

Returns a list of visual rows (list of cell strings), approximating table cells:
Word stores table cell ends as \\x07 and paragraph ends as \\x0d, so replacing
\\x07 with a tab and \\x0d with a newline recovers an editable grid.
"""
import olefile, struct


def _clx_pieces(doc: bytes, tbl: bytes) -> list:
    """Parse the Clx piece table -> [(cp_start, cp_end, fc, compressed)]."""
    fcClx, lcbClx = struct.unpack_from("<II", doc, 0x01A2)
    if lcbClx == 0 or fcClx + lcbClx > len(tbl):
        return []
    clx = tbl[fcClx:fcClx + lcbClx]
    i, n = 0, len(clx)
    while i < n:
        t = clx[i]
        if t == 1:            # Prc: 2-byte cbGrpprl + data
            cb = struct.unpack_from("<h", clx, i + 1)[0]
            i += 3 + cb
        elif t == 2:          # Pcdt
            lcb = struct.unpack_from("<I", clx, i + 1)[0]
            plc = clx[i + 5:i + 5 + lcb]
            npc = (lcb - 4) // 12
            cps = [struct.unpack_from("<I", plc, 4 * k)[0] for k in range(npc + 1)]
            out = []
            for k in range(npc):
                off = 4 * (npc + 1) + 8 * k
                fc = struct.unpack_from("<I", plc, off + 2)[0]
                comp = bool(fc & 0x40000000)
                if comp:
                    fc = (fc & ~0x40000000) // 2
                out.append((cps[k], cps[k + 1], fc, comp))
            return out
        else:
            break
    return []


def doc_text(path: str) -> str:
    with olefile.OleFileIO(path) as ole:
        doc = ole.openstream("WordDocument").read()
        flags = struct.unpack_from("<H", doc, 0x000A)[0]
        which = "1Table" if (flags >> 9) & 1 else "0Table"
        if not ole.exists(which):
            which = "0Table" if which == "1Table" else "1Table"
        tbl = ole.openstream(which).read() if ole.exists(which) else b""
    pieces = _clx_pieces(doc, tbl)
    if not pieces:
        return ""
    chunks = []
    for cp0, cp1, fc, comp in pieces:
        ln = cp1 - cp0
        if comp:
            raw = doc[fc:fc + ln]
            chunks.append(raw.decode("cp1252", "replace"))
        else:
            raw = doc[fc:fc + ln * 2]
            chunks.append(raw.decode("utf-16-le", "replace"))
    return "".join(chunks)


def doc_rows(path: str) -> list:
    txt = doc_text(path)
    if not txt:
        return []
    txt = txt.replace("\x07", "\t").replace("\r", "\n").replace("\x0b", "\n")
    rows = []
    for line in txt.split("\n"):
        cells = [c.strip().replace("\u3000", "") for c in line.split("\t")]
        cells = [c for c in cells]
        while cells and not cells[-1]:
            cells.pop()
        if cells:
            rows.append(cells)
    return rows


if __name__ == "__main__":
    import sys, glob
    for p in sys.argv[1:]:
        r = doc_rows(p)
        print("===", p, "rows:", len(r))
        for x in r[:12]:
            print("   ", x)
