# -*- coding: utf-8 -*-
import json, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
items = json.load(open(os.path.join(HERE, "_cache", "inno_c101481.json"), encoding="utf-8"))
print("c101481 items:", len(items), "sample:", items[0])
hit = []
for it in items:
    s = json.dumps(it, ensure_ascii=False)
    if "安徽" in s and re.search(r"20(1[6-9]|20)", s):
        hit.append(it)
print("安徽 2016-2020 条目:", len(hit))
for it in hit[:20]:
    print("  -", it)
