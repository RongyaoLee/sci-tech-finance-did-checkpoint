# -*- coding: utf-8 -*-
"""把国家网备案公告（fetch_common 产出的 省名.csv，带证书编号、无城市）
合并进 cert_lists\\<省>省.csv（含省级附件解析出的城市），城市优先保留。"""
import csv, os, sys, collections

HERE = os.path.dirname(os.path.abspath(__file__))
PAIRS = [("江苏", "江苏省.csv"), ("浙江", "浙江省.csv"),
         ("上海", "上海市.csv"), ("安徽", "安徽省.csv")]
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]


def read(p):
    with open(p, encoding="utf-8-sig", newline="") as fh:
        return [dict(r) for r in csv.DictReader(fh)]


def key_cert(r):
    c = (r.get("证书编号") or "").strip()
    return c or None


def merge(prov, target):
    mine_p = os.path.join(HERE, target)
    nat_p = os.path.join(HERE, prov + ".csv")
    mine = read(mine_p)
    if not os.path.exists(nat_p):
        print(f"[{prov}] 无国家网文件，跳过")
        return None
    nat = read(nat_p)
    by_cert = {}
    for r in mine:
        c = key_cert(r)
        if c:
            by_cert[c] = r
    by_name = {}
    for r in mine:
        by_name.setdefault((r["企业名称"].strip(), r.get("认定年度", "").strip()), []).append(r)

    added = filled = 0
    for r in nat:
        c = key_cert(r)
        nm = (r.get("企业名称") or "").strip()
        if not nm:
            continue
        if c and c in by_cert:
            t = by_cert[c]
            for f in ("城市", "区县"):
                if not t.get(f) and r.get(f):
                    t[f] = r[f]
            continue
        cand = by_name.get((nm, (r.get("认定年度") or "").strip()), [])
        if cand:
            t = cand[0]
            if not key_cert(t) and c:
                t["证书编号"] = c
                filled += 1
                by_cert[c] = t
            continue
        if c and c in by_cert:
            continue
        row = {f: (r.get(f) or "") for f in HEADER}
        mine.append(row)
        if c:
            by_cert[c] = row
        by_name.setdefault((nm, row.get("认定年度", "")), []).append(row)
        added += 1

    # 去重：证书编号优先，其次 (名称,年度,批次)
    seen_c, seen_n, out = set(), set(), []
    for r in mine:
        c = key_cert(r)
        nk = (r["企业名称"].strip(), r.get("认定年度", "").strip(), r.get("批次", "").strip())
        if c:
            if c in seen_c:
                continue
            seen_c.add(c)
        elif nk in seen_n:
            continue
        seen_n.add(nk)
        out.append(r)

    out.sort(key=lambda r: (r.get("认定年度", ""), r.get("批次", ""), r.get("证书编号", "")))
    with open(mine_p, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=HEADER)
        w.writeheader()
        for r in out:
            w.writerow({f: r.get(f, "") for f in HEADER})
    ncert = sum(1 for r in out if key_cert(r))
    ncity = sum(1 for r in out if (r.get("城市") or "").strip())
    years = sorted({r.get("认定年度", "") for r in out if r.get("认定年度")})
    print(f"[{prov}] mine={len(mine)} nat={len(nat)} added={added} cert_filled={filled} "
          f"-> rows={len(out)} cert={ncert} city={ncity} years={years[0]}-{years[-1]}")
    per = collections.Counter((r.get("认定年度", ""), "cert" if key_cert(r) else "nocert") for r in out)
    for y in years:
        print(f"    {y}: rows={per[(y,'cert')]+per[(y,'nocert')]:6d} cert={per[(y,'cert')]:6d}")
    return dict(prov=prov, rows=len(out), cert=ncert, city=ncity,
                years=f"{years[0]}-{years[-1]}", added=added, filled=filled)


if __name__ == "__main__":
    res = []
    for prov, target in PAIRS:
        if len(sys.argv) > 1 and prov not in sys.argv[1:]:
            continue
        r = merge(prov, target)
        if r:
            res.append(r)
    print("DONE", len(res))
