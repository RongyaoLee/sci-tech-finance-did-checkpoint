# -*- coding: utf-8 -*-
"""Crawl innocom.gov.cn 备案公告 list (c101481) -> per-province PDFs with 证书编号.

Usage:
  python fetch_nat.py scan [max_pages]        # only list, write _cache/nat_items.json
  python fetch_nat.py fetch 陕西 [max_pages]  # download+parse for one province
"""
import csv, json, os, re, sys, time, urllib.parse

import requests
from bs4 import BeautifulSoup
import pymupdf
import openpyxl
import urllib3

urllib3.disable_warnings()

BASE = "http://www.innocom.gov.cn"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
H = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9",
     "Accept": "text/html,application/xhtml+xml,*/*;q=0.8"}

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "_raw")
CACHE = os.path.join(HERE, "_cache")
os.makedirs(RAW, exist_ok=True)
os.makedirs(CACHE, exist_ok=True)

PROVS = ["陕西", "甘肃", "青海", "宁夏", "新疆"]
# province name variants appearing in titles
PROV_ALIAS = {
    "陕西": ["陕西省"], "甘肃": ["甘肃省"], "青海": ["青海省"],
    "宁夏": ["宁夏回族自治区", "宁夏"], "新疆": ["新疆维吾尔自治区", "新疆"],
}

CERT_RE = re.compile(r"GR\s?\d{12}", re.I)
_S = None


def sess():
    global _S
    if _S is None:
        _S = requests.Session()
        _S.headers.update(H)
        _S.verify = False
    return _S


def get(url, binary=False, tries=3):
    s = sess()
    urls = [url]
    if url.startswith("https://"):
        urls.append(url.replace("https://", "http://"))
    last = None
    for u in urls:
        for _ in range(tries):
            try:
                r = s.get(u, timeout=30)
                if r.status_code == 200:
                    time.sleep(0.5)
                    if binary:
                        return r.content, r.url
                    r.encoding = r.apparent_encoding or "utf-8"
                    return r.text, r.url
                last = "HTTP %s" % r.status_code
            except Exception as e:
                last = type(e).__name__ + ":" + str(e)[:60]
            time.sleep(1.0)
    print("   ! FAIL", url, last)
    return (None, None)


def norm_cert(s):
    m = CERT_RE.search(s or "")
    return m.group(0).upper().replace(" ", "") if m else ""


def clean(s):
    if s is None:
        return ""
    s = str(s).replace("\u3000", " ").replace("\xa0", " ")
    return re.sub(r"\s+", "", s).strip()


def scan(max_pages=60):
    items = []
    for p in range(1, max_pages + 1):
        suffix = "" if p == 1 else "_%d" % p
        url = f"{BASE}/gqrdw/c101481/list_gsgg_l2{suffix}.shtml"
        html, _ = get(url)
        if not html:
            break
        soup = BeautifulSoup(html, "lxml")
        n = 0
        for a in soup.find_all("a", href=True):
            t = a.get_text(strip=True)
            h = a["href"]
            if "/gqrdw/" not in h or not t:
                continue
            if "高新技术企业" not in t:
                continue
            full = h if h.startswith("http") else BASE + (h if h.startswith("/") else "/" + h)
            items.append({"title": t, "url": full})
            n += 1
        print(f"  page {p:2d}: {n} items")
        if n == 0:
            break
    seen, out = set(), []
    for it in items:
        if it["url"] in seen:
            continue
        seen.add(it["url"])
        out.append(it)
    json.dump(out, open(os.path.join(CACHE, "nat_items.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("total items:", len(out))
    return out


def load_items():
    p = os.path.join(CACHE, "nat_items.json")
    max_pages = int(sys.argv[2]) if sys.argv[1] == "scan" and len(sys.argv) > 2 else 60
    if not os.path.exists(p):
        return scan(max_pages)
    return json.load(open(p, encoding="utf-8"))


def meta(title):
    year = ""
    m = re.search(r"(20\d{2})\s*年", title) or re.search(r"(20\d{2})", title)
    if m:
        year = m.group(1)
    batch = ""
    m = re.search(r"第([一二三四五六七八九十]+|\d+)批", title)
    if m:
        b = m.group(1)
        cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
        if b.isdigit():
            batch = "第%s批" % b
        elif b == "十":
            batch = "第10批"
        elif b.startswith("十"):
            batch = "第%d批" % (10 + cn.get(b[1:], 0))
        elif b.endswith("十"):
            batch = "第%d批" % (cn.get(b[0], 1) * 10)
        else:
            batch = "第%d批" % cn.get(b[0], 1)
    supp = "补充" in title
    return year, batch, supp


def pick(prov):
    items = load_items()
    al = PROV_ALIAS[prov]
    out = []
    for it in items:
        t = it["title"]
        if not any(a in t for a in al):
            continue
        if re.search(r"更名|迁移|搬迁|名称变更|证书|年报|统计|撤销|取消|复核", t):
            continue
        if "备案" not in t:
            continue
        y, b, supp = meta(t)
        if y and y < "2016":
            continue
        out.append(dict(it, year=y, batch=b, supp=supp))
    return out


def attachments(detail_url):
    html, _ = get(detail_url)
    if not html:
        return []
    soup = BeautifulSoup(html, "lxml")
    out = []
    for a in soup.find_all("a", href=True):
        h = a["href"]
        if not re.search(r"\.(pdf|xlsx?|docx?|wps|et)$", h, re.I):
            continue
        out.append((a.get_text(strip=True), urllib.parse.urljoin(detail_url, h)))
    if not out:
        for m in re.findall(r'["\']([^"\']*/files/[^"\']+\.(?:pdf|xlsx?|docx?))["\']', html, re.I):
            out.append(("", urllib.parse.urljoin(detail_url, m)))
    seen, res = set(), []
    for t, u in out:
        if u in seen:
            continue
        seen.add(u)
        res.append((t, u))
    return res


def rows_pdf(path, ytol=3.0):
    doc = pymupdf.open(path)
    for page in doc:
        words = page.get_text("words")
        if not words:
            continue
        words.sort(key=lambda w: (round(w[1], 1), w[0]))
        rows, cur, cy = [], [], None
        for w in words:
            y = w[1]
            if cy is None or abs(y - cy) <= ytol:
                cur.append(w)
                cy = y if cy is None else cy
            else:
                rows.append(cur)
                cur, cy = [w], y
        if cur:
            rows.append(cur)
        for r in rows:
            r.sort(key=lambda x: x[0])
            cells, buf, px1 = [], [], None
            for w in r:
                if px1 is not None and w[0] - px1 > 6:
                    cells.append("".join(buf)); buf = []
                buf.append(w[4]); px1 = w[2]
            if buf:
                cells.append("".join(buf))
            yield [clean(c) for c in cells if clean(c)]


def rows_xlsx(path):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            cells = [clean(c) for c in row if c is not None and clean(c) != ""]
            if cells:
                yield cells


NOT_NAME = re.compile(r"[A-Za-z]{3,}|GR\d|附件|名单|通知|公告|根据|现将|详见|序号|企业名称|证书编号")


def looks_name(s):
    if not s or len(s) < 4 or len(s) > 60:
        return False
    if NOT_NAME.search(s):
        return False
    if re.fullmatch(r"[\d\.\-—、,，()（）]+", s):
        return False
    return True


def extract(path):
    low = path.lower()
    it = rows_pdf(path) if low.endswith(".pdf") else rows_xlsx(path) if low.endswith((".xlsx", ".xls")) else iter(())
    out, pending = [], None
    for cells in it:
        cert = ""
        for c in cells:
            nc = norm_cert(c)
            if nc:
                cert = nc
                break
        name = ""
        for c in cells:
            if norm_cert(c):
                continue
            if looks_name(c):
                name = c
                break
        if cert and not name and pending:
            name = pending
        if name and cert:
            out.append({"name": name, "cert": cert})
            pending = name
        elif name:
            pending = name
    return out


def download(url, prov, tag):
    ext = os.path.splitext(url.split("?")[0])[1].lower()
    if ext not in (".pdf", ".xlsx", ".xls"):
        return None
    d = os.path.join(RAW, prov)
    os.makedirs(d, exist_ok=True)
    fn = re.sub(r"[^\w\.\-]", "_", tag)[:90] + ext
    p = os.path.join(d, fn)
    if os.path.exists(p) and os.path.getsize(p) > 500:
        return p
    content, _ = get(url, binary=True)
    if not content or len(content) < 200:
        return None
    open(p, "wb").write(content)
    return p


def fetch(prov, max_pages=60):
    items = pick(prov)
    print(f"[{prov}] 备案公告 items: {len(items)}")
    rows = []
    for it in items:
        atts = attachments(it["url"])
        if not atts:
            print("   - no att:", it["title"][:56])
            continue
        for atitle, aurl in atts:
            p = download(aurl, prov, it["title"][:70] + "_" + os.path.basename(aurl)[:8])
            if not p:
                continue
            try:
                rs = extract(p)
            except Exception as e:
                print("   ! parse", os.path.basename(p), e)
                continue
            print(f"   + {it['title'][:50]:50s} {it['year']}/{it['batch']} supp={it['supp']} rows={len(rs):5d}")
            for r in rs:
                r.update(prov=prov, year=it["year"], batch=it["batch"],
                         supp=it["supp"], src=it["url"], file=os.path.basename(p))
                rows.append(r)
    json.dump(rows, open(os.path.join(CACHE, "nat_%s.json" % prov), "w", encoding="utf-8"),
              ensure_ascii=False)
    print(f"== {prov}: {len(rows)} rows, {sum(1 for r in rows if r['cert'])} with cert")
    return rows


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "scan"
    if cmd == "scan":
        scan(int(sys.argv[2]) if len(sys.argv) > 2 else 60)
    elif cmd == "pick":
        for p in PROVS:
            print(p, len(pick(p)))
    else:
        fetch(cmd, int(sys.argv[2]) if len(sys.argv) > 2 else 60)
