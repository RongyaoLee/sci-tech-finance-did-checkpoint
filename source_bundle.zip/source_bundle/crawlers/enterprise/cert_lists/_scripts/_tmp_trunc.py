﻿import csv,re,collections
for fn in ['辽宁.csv','吉林.csv','内蒙古.csv']:
    rows=list(csv.DictReader(open(fn,encoding='utf-8-sig',newline='')))
    bad=[r for r in rows if re.search(r'(第四|研$|公司$|研究所$)', r['企业名称']) and not re.search(r'(公司|研究院|研究所|中心|厂)$', r['企业名称'])]
    print('==',fn,len(bad))
    for r in bad: print('  ',r['认定年度'],r['批次'],'|',r['企业名称'],'|',r['证书编号'])
    names=[r['企业名称'] for r in rows]
    for r in bad:
        stem=r['企业名称'][:12]
        twin=[n for n in names if n.startswith(stem) and len(n)>len(r['企业名称'])]
        if twin: print('    twin:',sorted(set(twin))[:3])
