# -*- coding: utf-8 -*-
"""下载附件到 _raw/att/ 并按扩展名解析文本预览"""
import sys, os, re, json, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from common import get, ROOT

ATTDIR = os.path.join(ROOT, "_raw", "att")
os.makedirs(ATTDIR, exist_ok=True)


def fname_from(url, fallback="att"):
    base = os.path.basename(url.split("?")[0].split("#")[0])
    base = re.sub(r"[^0-9A-Za-z._\-\u4e00-\u9fa5]", "_", base)
    if not base or "." not in base:
        base = fallback
    return base


def download(url, name=None, referer=None):
    name = name or fname_from(url)
    if len(name) > 120:
        h = hashlib.md5(url.encode()).hexdigest()[:10]
        name = name[:80] + "_" + h + os.path.splitext(name)[1]
    p = os.path.join(ATTDIR, name)
    if os.path.exists(p) and os.path.getsize(p) > 0:
        return p, os.path.getsize(p)
    hdrs = {}
    if referer:
        hdrs["Referer"] = referer
    r = get(url, stream=False, headers=hdrs or None)
    data = r.content
    with open(p, "wb") as f:
        f.write(data)
    return p, len(data)


if __name__ == "__main__":
    for u in sys.argv[1:]:
        p, n = download(u)
        print(f"{n:9d}  {p}")
