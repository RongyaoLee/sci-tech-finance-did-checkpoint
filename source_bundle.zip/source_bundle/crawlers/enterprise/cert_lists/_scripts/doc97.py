# -*- coding: utf-8 -*-
"""极简 OLE2(CFB) + Word97(.doc) 文本提取器。无第三方依赖。
用法: from doc97 import doc_text; t = doc_text(path)
"""
import struct


class CFB:
    def __init__(self, data):
        self.d = data
        if data[:8] != b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
            raise ValueError("not OLE2")
        self.ssz = 1 << struct.unpack_from("<H", data, 0x1E)[0]
        self.mssz = 1 << struct.unpack_from("<H", data, 0x20)[0]
        self.nfat = struct.unpack_from("<I", data, 0x2C)[0]
        self.dirstart = struct.unpack_from("<I", data, 0x30)[0]
        self.minicut = struct.unpack_from("<I", data, 0x38)[0]
        self.ministart = struct.unpack_from("<I", data, 0x3C)[0]
        self.difstart = struct.unpack_from("<I", data, 0x44)[0]
        self.ndif = struct.unpack_from("<I", data, 0x48)[0]
        self._fat = self._read_fat()
        self.entries = self._read_dir()
        root = self.entries[0]
        self.ministream = self._read_chain(root["start"], root["size"])

    def _sec(self, i):
        off = 512 + i * self.ssz
        return self.d[off:off + self.ssz]

    def _read_fat(self):
        difat = list(struct.unpack_from("<109I", self.d, 0x4C))
        nxt = self.difstart
        cnt = 0
        while nxt not in (0xFFFFFFFE, 0xFFFFFFFF) and cnt < self.ndif + 2:
            s = self._sec(nxt)
            vals = struct.unpack_from("<%dI" % (self.ssz // 4), s, 0)
            difat.extend(vals[:-1])
            nxt = vals[-1]
            cnt += 1
        fat = []
        for fs in difat[:self.nfat]:
            if fs >= 0xFFFFFFFE:
                continue
            s = self._sec(fs)
            fat.extend(struct.unpack_from("<%dI" % (self.ssz // 4), s, 0))
        return fat

    def _read_chain(self, start, size=None):
        out, cur, guard = [], start, 0
        while cur < 0xFFFFFFFE and guard < 200000:
            out.append(self._sec(cur))
            if cur >= len(self._fat):
                break
            cur = self._fat[cur]
            guard += 1
        buf = b"".join(out)
        return buf[:size] if size else buf

    def _read_mini(self, start, size):
        out, cur, guard = [], start, 0
        while cur < 0xFFFFFFFE and guard < 200000:
            off = cur * self.mssz
            out.append(self.ministream[off:off + self.mssz])
            if cur >= len(self._fat):
                break
            cur = self._fat[cur]
            guard += 1
        return b"".join(out)[:size]

    def _read_dir(self):
        buf = self._read_chain(self.dirstart)
        ents = []
        for i in range(0, len(buf), 128):
            e = buf[i:i + 128]
            if len(e) < 128:
                break
            nlen = struct.unpack_from("<H", e, 0x40)[0]
            name = e[:max(0, nlen - 2)].decode("utf-16-le", "ignore")
            typ = e[0x42]
            start = struct.unpack_from("<I", e, 0x74)[0]
            size = struct.unpack_from("<Q", e, 0x78)[0]
            ents.append({"name": name, "type": typ, "start": start, "size": size})
        return ents

    def stream(self, name):
        for e in self.entries:
            if e["name"] == name and e["type"] == 2:
                if e["size"] < self.minicut:
                    return self._read_mini(e["start"], e["size"])
                return self._read_chain(e["start"], e["size"])
        return None


def doc_text(path):
    data = open(path, "rb").read()
    cf = CFB(data)
    wd = cf.stream("WordDocument")
    if wd is None:
        raise ValueError("no WordDocument stream")
    flags = struct.unpack_from("<H", wd, 0x0A)[0]
    which = (flags >> 9) & 1
    tbl = cf.stream("1Table" if which else "0Table")
    if tbl is None:
        tbl = cf.stream("0Table") or cf.stream("1Table")
    fcMin, fcMac = struct.unpack_from("<II", wd, 0x18)
    # fcClx/lcbClx in FibRgFcLcb97
    fcClx, lcbClx = struct.unpack_from("<II", wd, 0x01A2)
    if not tbl or lcbClx == 0 or fcClx + lcbClx > len(tbl):
        # 回退：直接按 8bit/16bit 猜
        return _fallback(wd, fcMin, fcMac)
    clx = tbl[fcClx:fcClx + lcbClx]
    i = 0
    pcdt = None
    while i < len(clx):
        t = clx[i]
        if t == 1:
            cb = struct.unpack_from("<H", clx, i + 1)[0]
            i += 3 + cb
        elif t == 2:
            lcb = struct.unpack_from("<I", clx, i + 1)[0]
            pcdt = clx[i + 5:i + 5 + lcb]
            break
        else:
            i += 1
    if pcdt is None:
        return _fallback(wd, fcMin, fcMac)
    n = (len(pcdt) - 4) // 12
    cps = list(struct.unpack_from("<%dI" % (n + 1), pcdt, 0))
    pieces = []
    base = (n + 1) * 4
    for k in range(n):
        off = base + k * 8
        fc = struct.unpack_from("<I", pcdt, off + 2)[0]
        comp = bool(fc & 0x40000000)
        real = (fc & 0x3FFFFFFF) // 2 if comp else (fc & 0x3FFFFFFF)
        ln = cps[k + 1] - cps[k]
        pieces.append((real, ln, comp))
    out = []
    for fc, ln, comp in pieces:
        if comp:
            raw = wd[fc:fc + ln]
            try:
                out.append(raw.decode("cp936", "replace"))
            except Exception:
                out.append(raw.decode("latin-1", "replace"))
        else:
            raw = wd[fc:fc + ln * 2]
            out.append(raw.decode("utf-16-le", "replace"))
    return "".join(out)


def _fallback(wd, fcMin, fcMac):
    raw = wd[fcMin:fcMac]
    try:
        return raw.decode("utf-16-le", "replace")
    except Exception:
        return raw.decode("cp936", "replace")


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    for p in sys.argv[1:]:
        t = doc_text(p)
        print("=== ", p, "chars", len(t))
        print(repr(t[:600]))
