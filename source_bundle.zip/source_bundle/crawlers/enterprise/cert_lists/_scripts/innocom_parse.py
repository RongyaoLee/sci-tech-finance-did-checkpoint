# -*- coding: utf-8 -*-
"""Download + parse every innocom 备案公告 PDF for our 6 regions."""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(__file__))
sys.stdout.reconfigure(encoding="utf-8")
from util import fetch, download, links, abs_url, parse_pdf_grid, RAW

items = json.load(open(os.path.join(RAW, "innocom_items.json"), encoding="utf-8"))
OUTJSON = os.path.join(RAW, "innocom_rows.json")
done = json.load(open(OUTJSON, encoding="utf-8")) if os.path.exists(OUTJSON) else {}

for it in items:
    key = it["url"]
    if key in done:
        continue
    r = fetch(it["url"], referer="http://www.innocom.gov.cn/gqrdw/c101481/list_gsgg_l2.shtml")
    if r is None:
        done[key] = {"error": "page"}
        continue
    pdfs = [(t, abs_url(it["url"], h)) for t, h in links(r.text)
            if re.search(r"\.pdf$", h, re.I)]
    if not pdfs:
        done[key] = {"error": "no-pdf"}
        continue
    text, url = pdfs[0]
    fn = "inno_%s_%s_%s_%s.pdf" % (it["region"], it["year"], it["batch_label"],
                                   re.sub(r"\W", "", url)[-10:])
    p = download(url, fn, referer=it["url"])
    if not p:
        done[key] = {"error": "dl", "url": url}
        continue
    rows = parse_pdf_grid(p)
    certs = [x["cert"] for x in rows if x["cert"]]
    withcert = sum(1 for c in certs if re.fullmatch(r"GR\d{12}", c))
    codes = {}
    for c in certs:
        if re.fullmatch(r"GR\d{12}", c):
            codes[c[6:10]] = codes.get(c[6:10], 0) + 1
    done[key] = {"title": it["title"], "region": it["region"], "year": it["year"],
                 "batch": it["batch_label"], "pdf": os.path.basename(p), "url": url,
                 "page": it["url"], "n": len(rows), "n_cert": withcert,
                 "codes": codes, "rows": rows}
    print("%-4s %-4s %-5s rows=%-6d cert=%-6d codes=%s" %
          (it["region"], it["year"], it["batch_label"], len(rows), withcert,
           list(codes.items())[:3]))

json.dump(done, open(OUTJSON, "w", encoding="utf-8"), ensure_ascii=False)
print("TOTAL items", len(done), "ok", sum(1 for v in done.values() if "rows" in v))
