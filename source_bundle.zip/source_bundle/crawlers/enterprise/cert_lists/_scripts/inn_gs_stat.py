# -*- coding: utf-8 -*-
"""抓 innocom 公示栏目（无证书编号），只用于统计各省各年度公示家数，做比值分母"""
import collections
import json
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")
import fetch_common as fc  # noqa: E402

PROVS = sys.argv[1:] or ["河南", "湖北", "湖南", "四川"]
stat = {}
for p in PROVS:
    print("=" * 16, p, fc.PROV_CH.get(p))
    rows = fc.harvest(p, pages=4, kinds=("gs",))
    cnt = collections.Counter(r.get("year") or "?" for r in rows if r.get("name"))
    stat[p] = dict(sorted(cnt.items()))
    print(f"== {p}: {len(rows)} rows  {stat[p]}")

out = os.path.join(HERE, "_raw", "inn_gs_stat.json")
json.dump(stat, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("saved", out)
