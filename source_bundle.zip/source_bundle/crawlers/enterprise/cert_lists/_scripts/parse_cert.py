# -*- coding: utf-8 -*-
"""证书编号名单 PDF 解析器（逐行法）"""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
import pymupdf

CERT_RE = re.compile(r"^GR\s*([0-9]{4})\s*([0-9]{2,4})\s*([0-9]{4,8})$")
SEQ_RE = re.compile(r"^\d{1,6}$")


def norm(s):
    return re.sub(r"\s+", "", s or "")


def parse_pdf_rows(path, verbose=False):
    doc = pymupdf.open(path)
    rows = []
    for pno in range(doc.page_count):
        page = doc[pno]
        txt = page.get_text("text")
        lines = [l.strip() for l in txt.splitlines()]
        lines = [l for l in lines if l]
        # 去掉页码等噪声行
        for i, l in enumerate(lines):
            n = norm(l)
            m = CERT_RE.match(n)
            if not m:
                continue
            # 往前找企业名称
            name = ""
            seq = ""
            j = i - 1
            while j >= 0 and norm(lines[j]) == "":
                j -= 1
            if j >= 0:
                name = lines[j].strip()
            k = j - 1
            if k >= 0 and SEQ_RE.match(norm(lines[k])):
                seq = norm(lines[k])
            rows.append({
                "seq": seq,
                "name": re.sub(r"\s+", "", name),
                "cert": n,
                "page": pno + 1,
            })
    return rows


if __name__ == "__main__":
    p = sys.argv[1]
    rows = parse_pdf_rows(p)
    print("rows:", len(rows))
    for r in rows[:5]:
        print(r)
    print("...")
    for r in rows[-3:]:
        print(r)
    # 证书编号结构分布
    from collections import Counter
    c = Counter(r["cert"][2:6] for r in rows)
    print("年份分布:", c.most_common())
    c2 = Counter(r["cert"][6:8] for r in rows)
    print("省码分布:", c2.most_common(10))
    c3 = Counter(r["cert"][:10] for r in rows)
    print("前10位分布 top10:", c3.most_common(10))
    print("len分布:", Counter(len(r["cert"]) for r in rows).most_common())
