# -*- coding: utf-8 -*-
"""找各省「通知公告/公示」栏目URL"""
import sys, re, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from common import get_text
import lxml.html

HOMES = [
    ("湖北省", "https://kjt.hubei.gov.cn/"),
    ("湖南省", "http://kjt.hunan.gov.cn/"),
    ("四川省", "https://kjt.sc.gov.cn/"),
    ("河南省", "https://kjt.henan.gov.cn/"),
    ("河北省", "https://kjt.hebei.gov.cn/"),
    ("福建省", "https://kjt.fujian.gov.cn/"),
]
TPAT = re.compile(r"通知公告|公示公告|公告公示|通知|公示|文件|政策|政务公开|信息公开")
HPAT = re.compile(r"tzgg|gsgg|tzgs|ggtz|xxgk|zwgk|zcwj|wjtz|notice|announce")

for prov, home in HOMES:
    print("=" * 70)
    print(prov, home)
    try:
        txt, r = get_text(home)
    except Exception as e:
        print("  FAIL", e); continue
    doc = lxml.html.fromstring(txt)
    doc.make_links_absolute(home, resolve_base_href=True)
    seen = set()
    for a in doc.iter("a"):
        t = re.sub(r"\s+", " ", (a.text_content() or "")).strip()
        h = a.get("href") or ""
        if not h or h.startswith("javascript"):
            continue
        if len(t) > 30:
            continue
        if (TPAT.search(t) or HPAT.search(h)) and h not in seen:
            seen.add(h)
            print(f"   {t or '(no text)':28s} -> {h}")
print("DONE")
