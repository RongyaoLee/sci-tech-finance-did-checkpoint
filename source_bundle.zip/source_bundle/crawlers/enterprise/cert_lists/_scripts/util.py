# -*- coding: utf-8 -*-
"""Shared helpers: polite fetching, PDF/Excel table extraction, CSV writing."""
import os, re, sys, time, csv, json
import requests
import urllib3
urllib3.disable_warnings()

RAW = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_raw"
OUT = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists"
os.makedirs(RAW, exist_ok=True)

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

S = requests.Session()
S.headers.update({"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9"})

_last = {}
INTERVAL = 0.55   # >= 2 req/s cap per host


def _throttle(host):
    now = time.time()
    prev = _last.get(host, 0)
    wait = INTERVAL - (now - prev)
    if wait > 0:
        time.sleep(wait)
    _last[host] = time.time()


def fetch(url, binary=False, referer=None, tries=3, timeout=30):
    """GET with per-host throttle, retry, https->http fallback."""
    import urllib.parse as up
    cands = [url]
    if url.startswith("https://"):
        cands.append("http://" + url[8:])
    else:
        cands.append("https://" + url[7:])
    last_err = None
    for attempt in range(tries):
        for u in cands:
            host = up.urlparse(u).netloc
            _throttle(host)
            try:
                hdr = {"Referer": referer} if referer else None
                r = S.get(u, timeout=timeout, verify=False, headers=hdr)
                if r.status_code == 200 and len(r.content) > 0:
                    if not binary:
                        r.encoding = r.apparent_encoding or "utf-8"
                        # gov CMS often mislabels; prefer utf-8 if it decodes cleanly
                        try:
                            r.content.decode("utf-8")
                            if not r.encoding or r.encoding.lower() in ("iso-8859-1", "ascii"):
                                r.encoding = "utf-8"
                        except UnicodeDecodeError:
                            pass
                    return r
                last_err = "HTTP %s" % r.status_code
            except Exception as e:
                last_err = "%s: %s" % (type(e).__name__, str(e)[:80])
        time.sleep(1.0 * (attempt + 1))
    sys.stderr.write("[fetch-fail] %s -> %s\n" % (url, last_err))
    return None


def download(url, name, referer=None):
    p = os.path.join(RAW, name)
    if os.path.exists(p) and os.path.getsize(p) > 2000:
        return p
    r = fetch(url, binary=True, referer=referer, timeout=120)
    if r is None:
        return None
    with open(p, "wb") as f:
        f.write(r.content)
    return p


def links(html, pattern=None):
    out = []
    for m in re.finditer(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', html, re.S | re.I):
        href = m.group(1).strip()
        text = re.sub(r"<[^>]+>", "", m.group(2)).strip()
        if pattern and not re.search(pattern, text):
            continue
        out.append((text, href))
    return out


def abs_url(base, href):
    import urllib.parse as up
    return up.urljoin(base, href)


GR = re.compile(r"^GR\s?(\d{12})$")


def pdf_lines(pdf_path):
    import pymupdf
    d = pymupdf.open(pdf_path)
    lines = []
    for pg in d:
        for ln in pg.get_text().split("\n"):
            ln = ln.strip()
            if ln:
                lines.append(ln)
    return lines


NAME_SPLIT = re.compile(r"^(\d{1,5})\s*(.*)$")


def parse_pdf_grid(pdf_path):
    """Coordinate-based extraction: group words into visual rows, then locate
    the GR cert cell and take the cell(s) left of it as name, right as city."""
    import pymupdf
    doc = pymupdf.open(pdf_path)
    out = []
    for page in doc:
        words = page.get_text("words")   # x0,y0,x1,y1,word,block,line,wordno
        if not words:
            continue
        rows = []
        for w in sorted(words, key=lambda t: (round(t[1], 1), t[0])):
            if rows and abs(w[1] - rows[-1][0]) <= 3.0:
                rows[-1][1].append(w)
            else:
                rows.append([w[1], [w]])
        for _, cells in rows:
            cells.sort(key=lambda t: t[0])
            texts = [c[4] for c in cells]
            cert_i = None
            for idx, t in enumerate(texts):
                if re.fullmatch(r"GR\s?\d{12}", t.replace(" ", "")):
                    cert_i = idx
                    break
            if cert_i is None:
                continue
            cert = texts[cert_i].replace(" ", "")
            left = texts[:cert_i]
            right = texts[cert_i + 1:]
            seq = ""
            if left and re.fullmatch(r"\d{1,6}", left[0]):
                seq = left[0]
                left = left[1:]
            name = "".join(left).strip()
            city = ""
            county = ""
            rest = [t for t in right if t.strip()]
            if rest:
                city = rest[0]
                if len(rest) > 1:
                    county = rest[1]
            if name:
                out.append({"seq": seq, "name": name, "cert": cert,
                            "city": city, "county": county})
    return out


def parse_pdf_rows(pdf_path, has_city=True, has_county=False):
    """State machine over text lines: [序号] 名称 / GR编号 / [地市] / [区县].

    Returns list of dict(name, cert, city, county, seq).
    """
    lines = pdf_lines(pdf_path)
    rows = []
    i = 0
    n = len(lines)
    pending_seq = None
    while i < n:
        ln = lines[i]
        m = GR.match(ln.replace(" ", ""))
        if m:
            cert = "GR" + m.group(1)
            # walk back for the name line
            j = i - 1
            name = None
            seq = None
            while j >= 0 and i - j <= 3:
                cand = lines[j]
                mm = NAME_SPLIT.match(cand)
                if mm and mm.group(2) and not GR.match(cand.replace(" ", "")):
                    # name line may carry leading 序号 like "2990 广东..."
                    if len(mm.group(2)) >= 4 and re.search(r"[\u4e00-\u9fa5]", mm.group(2)):
                        name = mm.group(2).strip()
                        seq = mm.group(1)
                        break
                j -= 1
            city = ""
            county = ""
            k = i + 1
            while k < n and k <= i + 3:
                cand = lines[k]
                if GR.match(cand.replace(" ", "")):
                    break
                if re.fullmatch(r"[\u4e00-\u9fa5]{2,12}(市|区|县|州|盟|旗|新区|开发区)?", cand) and k > i:
                    if not city and ("市" in cand or "州" in cand or "盟" in cand):
                        city = cand
                    elif not county and ("区" in cand or "县" in cand or "旗" in cand):
                        county = cand
                    else:
                        break
                    k += 1
                    continue
                break
            if name:
                rows.append({"seq": seq, "name": name, "cert": cert, "city": city, "county": county})
            i = k
            continue
        i += 1
    return rows


def read_xlsx_rows(path, sheet=None):
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb[sheet] if sheet else wb[wb.sheetnames[0]]
    rows = []
    for r in ws.iter_rows(values_only=True):
        rows.append([("" if c is None else str(c).strip()) for c in r])
    wb.close()
    return rows


HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]


def write_csv(region, rows):
    p = os.path.join(OUT, region + ".csv")
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(HEADER)
        seen = set()
        for r in rows:
            key = (r["name"], r["cert"])
            if key in seen:
                continue
            seen.add(key)
            w.writerow([r["name"], r["cert"], r.get("city", ""), r.get("county", ""),
                        r.get("year", ""), r.get("batch", ""), r.get("src", "")])
    return p, len(seen)
