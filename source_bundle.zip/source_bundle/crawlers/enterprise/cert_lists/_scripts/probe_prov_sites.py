# -*- coding: utf-8 -*-
"""Probe provincial S&T dept list pages for 高新技术企业 名单 links."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from util import fetch, abs_url

CANDS = [
    ("吉林通知公告", "https://kjt.jl.gov.cn/xwzx/tztg/"),
    ("吉林通知公告2", "https://kjt.jl.gov.cn/xwzx/tztg/index_1.html"),
    ("辽宁科技厅", "http://kjt.ln.gov.cn/"),
    ("辽宁通知", "http://kjt.ln.gov.cn/xxgk/tzgg/"),
    ("黑龙江科技厅", "http://www.hljkjt.gov.cn/"),
    ("内蒙古科技厅", "http://kjt.nmg.gov.cn/"),
    ("山西科技厅", "http://kjt.shanxi.gov.cn/"),
]

pat = re.compile(r"高新")
for label, url in CANDS:
    r = fetch(url, tries=2)
    if r is None:
        print("FAIL", label, url)
        continue
    print("==", label, url, "len", len(r.text))
    n = 0
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', r.text, re.S | re.I):
        href, text = m.group(1), re.sub(r"<[^>]+>", "", m.group(2)).strip()
        if pat.search(text) and len(text) < 80:
            print("   ", text[:70], "->", abs_url(url, href))
            n += 1
            if n > 25:
                break
