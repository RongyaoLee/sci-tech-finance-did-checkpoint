# -*- coding: utf-8 -*-
"""Patch gg_rows.json: 集成电路等领域政策试点 batches use GS + year + 省码 + serial
certificates (not GR). Re-extract those PDFs keeping the GS prefix."""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists")
sys.stdout.reconfigure(encoding="utf-8")
import fetch_common as F

RAW = os.path.join(os.path.dirname(__file__), "..", "_raw")
gg = json.load(open(os.path.join(RAW, "gg_items.json"), encoding="utf-8"))
rows = json.load(open(os.path.join(RAW, "gg_rows.json"), encoding="utf-8"))

CERT_RE = re.compile(r"(?:GR|GS)\s?\d{12}", re.I)


def extract_gs(path):
    """cells -> rows, accepting GR/GS prefixes."""
    if path.lower().endswith(".pdf"):
        cells_list = F.rows_from_pdf(path)
    else:
        return []
    out = []
    for cells in cells_list:
        cert = name = ""
        for c in cells:
            m = CERT_RE.search(c or "")
            if m and not cert:
                cert = m.group(0).upper().replace(" ", "")
                break
        if not cert:
            continue
        for c in cells:
            if CERT_RE.search(c or ""):
                continue
            if F.looks_like_name(c):
                name = c
                break
        if name:
            out.append((name, cert))
    return out


total = 0
for region, items in gg.items():
    for it in items:
        if "集成电路" not in it["title"]:
            continue
        my = re.search(r"(20\d{2})", it["title"])
        year = my.group(1) if my else ""
        mb = re.search(r"第([一二三四五六七八九十]+|\d+)批", it["title"])
        cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5}
        batch = ""
        if mb:
            b = mb.group(1)
            batch = "第%s批" % (b if b.isdigit() else cn.get(b[0], b))
        for atitle, aurl in F.attachments(it["url"]):
            p = F.download(aurl, region, it["title"][:70] + "_pdf")
            if not p:
                continue
            pairs = extract_gs(p)
            idx = {(r["name"], r["year"], r["batch"]): r for r in rows.get(region, [])}
            hit = 0
            for nm, ct in pairs:
                r = idx.get((nm, year, batch))
                if r is None:
                    rows.setdefault(region, []).append(
                        {"name": nm, "cert": ct, "year": year, "batch": batch, "src": it["url"]})
                    hit += 1
                elif not r["cert"]:
                    r["cert"] = ct
                    hit += 1
            total += hit
            print("  %-6s %-40s %s/%s pairs=%d filled=%d" %
                  (region, it["title"][:40], year, batch, len(pairs), hit))
print("filled", total)
json.dump(rows, open(os.path.join(RAW, "gg_rows.json"), "w", encoding="utf-8"), ensure_ascii=False)
print("rows per region", {k: len(v) for k, v in rows.items()})
print("GS certs", sum(1 for v in rows.values() for r in v if r["cert"].startswith("GS")))
