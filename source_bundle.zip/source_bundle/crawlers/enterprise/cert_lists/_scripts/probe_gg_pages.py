# -*- coding: utf-8 -*-
"""Check pagination depth of a PROV_GG 公告 column: list 高新 titles per page."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from util import fetch

BASE = "http://www.innocom.gov.cn/gqrdw/%s/" % sys.argv[1]
lo = int(sys.argv[2]) if len(sys.argv) > 2 else 1
hi = int(sys.argv[3]) if len(sys.argv) > 3 else 12
for pg in range(lo, hi + 1):
    u = BASE + ("list_gsgg_l3.shtml" if pg == 1 else "list_gsgg_l3_%d.shtml" % pg)
    r = fetch(u, tries=1)
    if r is None:
        print("page", pg, "FAIL")
        continue
    titles = re.findall(r'title=["\']([^"\']*高新[^"\']*)["\']', r.text)
    print("page", pg, "len", len(r.text), "高新 titles", len(titles))
    for t in titles[:6]:
        print("    ", t[:70])
