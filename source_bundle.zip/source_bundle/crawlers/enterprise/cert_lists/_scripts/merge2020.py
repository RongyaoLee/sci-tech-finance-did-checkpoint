# -*- coding: utf-8 -*-
"""把 _city_fill\<省>_2020公布名单.csv 并入 <省>.csv：优先回填同名同年度行的证书编号，其次追加"""
import csv
import os
import shutil
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

RAW = os.path.join(HERE, "_raw")
FILL = os.path.join(HERE, "_city_fill")
HEAD = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]


def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def dump(path, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=HEAD)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in HEAD})


def main():
    for prov in (sys.argv[1:] or ["四川省", "河南省", "河北省"]):
        # 已合并过则跳过，避免重复追加
        if False:
            pass
        src = os.path.join(FILL, "%s_2020公布名单.csv" % prov)
        dst = os.path.join(HERE, "%s.csv" % prov)
        if not (os.path.exists(src) and os.path.exists(dst)):
            print(prov, "缺文件，跳过")
            continue
        bak = os.path.join(RAW, "bak2020_%s.csv" % prov)
        shutil.copy2(dst, bak)
        base = load(dst)
        add = load(src)
        # (名称, 年度) -> 索引列表
        idx = {}
        for i, r in enumerate(base):
            idx.setdefault((r["企业名称"].strip(), r["认定年度"]), []).append(i)
        filled = appended = 0
        for r in add:
            nm = r["企业名称"].strip()
            key = (nm, r["认定年度"])
            hit = None
            for i in idx.get(key, []):
                if not base[i]["证书编号"].strip():
                    hit = i
                    break
            if hit is not None:
                base[hit]["证书编号"] = r["证书编号"]
                if not base[hit]["批次"].strip():
                    base[hit]["批次"] = r["批次"]
                if not base[hit]["来源URL"].strip():
                    base[hit]["来源URL"] = r["来源URL"]
                filled += 1
            else:
                base.append(dict(r))
                idx.setdefault(key, []).append(len(base) - 1)
                appended += 1
        dump(dst, base)
        certs = [r["证书编号"] for r in base if r["证书编号"].strip()]
        print("%s: 回填 %d / 追加 %d / 总行 %d / 有证 %d / 唯一证 %d"
              % (prov, filled, appended, len(base), len(certs), len(set(certs))))


if __name__ == "__main__":
    main()
