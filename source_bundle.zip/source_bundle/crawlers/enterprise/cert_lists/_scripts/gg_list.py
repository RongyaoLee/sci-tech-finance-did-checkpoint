# -*- coding: utf-8 -*-
"""Crawl innocom 认定备案公告 province columns (list_gsgg_l3) for the 6 regions."""
import sys, os, re, json, time
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists")
sys.stdout.reconfigure(encoding="utf-8")
import fetch_common as F

COLS = [("北京市", "c101443"), ("天津市", "c101444"), ("山东省", "c101460"),
        ("青岛市", "c101461"), ("广东省", "c101465"), ("深圳市", "c101466")]
MAXPAGE = 6
ITEM = re.compile(r'<li>\s*<a href="([^"]+)"[^>]*title=[\'"]([^\'"]+)[\'"][^>]*>.*?</a>\s*<span>\s*([\d\-]+)\s*</span>', re.S)


def crawl(col, maxpage=MAXPAGE):
    items, seen = [], set()
    for i in range(1, maxpage + 1):
        suf = "list_gsgg_l3.shtml" if i == 1 else "list_gsgg_l3_%d.shtml" % i
        url = "http://www.innocom.gov.cn/gqrdw/%s/%s" % (col, suf)
        html, _ = F.get(url, tries=2)
        if not html:
            print("  ! fail", url)
            break
        hits = ITEM.findall(html)
        new = 0
        for h, t, d in hits:
            if h in seen:
                continue
            seen.add(h)
            items.append({"url": "http://www.innocom.gov.cn" + h, "title": t.strip(), "date": d})
            new += 1
        print("  page %d: %d items (%s .. %s)" % (i, len(hits),
              hits[0][2] if hits else "-", hits[-1][2] if hits else "-"))
        if new == 0:
            break
        if hits and hits[-1][2] < "2021-01-01":
            break
    return items


out = {}
for region, col in COLS:
    print(region, col)
    items = crawl(col)
    out[region] = items
    print(" ", region, len(items), "items", items[-1]["date"] if items else "")

p = os.path.join(os.path.dirname(__file__), "..", "_raw", "gg_items.json")
json.dump(out, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("WROTE", p)
for region, items in out.items():
    print(region, [ (it["title"][:38], it["date"]) for it in items if it["date"] < "2022-07" ][:6])
