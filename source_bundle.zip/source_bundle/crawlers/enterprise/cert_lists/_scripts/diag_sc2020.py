# -*- coding: utf-8 -*-
"""诊断四川 2020 一批 备案复函 少 18 行的原因，并找四川复函页 URL"""
import json
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import fetch_common as fc  # noqa: E402

from decode2020 import build_map, data_rows, decode  # noqa: E402

RAW = os.path.join(HERE, "_raw")
p = os.path.join(RAW, "四川", "y2020_66c83260.pdf")
rows = data_rows(p)
print("data_rows", len(rows))
m = build_map(rows)
# 末若干行原样与解码
for r in rows[-4:]:
    print("  ", [c[:20] for c in r], "->", decode(r[-1], m))

# 全 PDF 所有 cell 数量分布（看是否有非 14 长的证书格）
import collections  # noqa: E402
cnt = collections.Counter()
tails = []
for cells in fc.rows_from_pdf(p):
    if not cells:
        continue
    cnt[len(cells[-1])] += 1
    if len(cells[-1]) != 14 and len(cells[-1]) >= 10:
        tails.append(cells[-1][:24])
print("末格长度分布", dict(sorted(cnt.items())))
print("非14长的样本", tails[:10])

# 找四川 2020 第一批备案复函页 URL
for jf in ("inn_gg.json", "inn_gg_4prov.json"):
    fp = os.path.join(RAW, jf)
    if not os.path.exists(fp):
        continue
    for it in json.load(open(fp, encoding="utf-8")):
        t = it.get("title") or ""
        if "四川" in t and "2020" in t:
            print("  ", t[:50], "|", it.get("url"))
