# -*- coding: utf-8 -*-
"""解码 2020 年备案复函 PDF 的乱码数字字形，还原证书编号

这些 PDF 的字体子集把数字映射成 ASCII 邻近码位：0->'6', 1->'=', 2->'>', 3->'?',
4->'@', 5->'A', 6->'B', 7->'C', 8->'D', 9->'E'；G->'_', R->'p'。
映射不写死，从文档自身（GR2020 固定前缀 + 顺序号连续递增）推出来。
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import fetch_common as fc  # noqa: E402

CERT_LEN = 14


def data_rows(path):
    """返回 [(行内单元格列表)]，只保留末格像证书编号的行"""
    out = []
    for cells in fc.rows_from_pdf(path):
        if len(cells) >= 2 and len(cells[-1]) == CERT_LEN:
            out.append(cells)
    return out


def build_map(rows):
    """从文档自身推出 字符->数字 映射

    依据：① 首行证书前两位是 GR，第 3-6 位是认定年度 2020；
          ② 序号列从 1 连续递增，前 9 行是单字符 1..9，第 10 行起出现两位。
    """
    m = {}
    first = rows[0][-1]
    for ch, val in zip(first[:2], "GR"):
        m[ch] = val
    for ch, val in zip(first[2:6], "2020"):
        m.setdefault(ch, val)
    seqs = [r[0] for r in rows]
    for i in range(min(9, len(seqs))):
        if len(seqs[i]) == 1:
            m[seqs[i]] = str(i + 1)
    for s in seqs[:20]:
        if len(s) == 2:
            m[s[1]] = "0"
            break
    m[first[3]] = "0"
    return m


def decode(s, m):
    return "".join(m.get(c, "?") for c in s)


def decode_pdf(path, prov_code):
    rows = data_rows(path)
    if not rows:
        return []
    m = build_map(rows)
    res = []
    for cells in rows:
        cert = decode(cells[-1], m)
        seq = decode(cells[0], m) if len(cells[0]) <= 6 else ""
        if not re.fullmatch(r"GR20\d{2}" + prov_code + r"\d{6}", cert):
            continue
        res.append({"seq": seq, "cert": cert})
    return res


if __name__ == "__main__":
    p = sys.argv[1]
    prov = sys.argv[2]
    rows = decode_pdf(p, prov)
    print("file", os.path.basename(p), "decoded", len(rows))
    for r in rows[:12]:
        print("   ", r["seq"], r["cert"])
    seqs = [int(r["seq"]) for r in rows if r["seq"].isdigit()]
    if seqs:
        print("序号 范围", min(seqs), max(seqs), "连续=", seqs == list(range(seqs[0], seqs[0] + len(seqs))))
    certs = {r["cert"] for r in rows}
    print("唯一证书", len(certs))
