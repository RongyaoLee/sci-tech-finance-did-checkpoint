# -*- coding: utf-8 -*-
"""探测 河南 2020 复函页附件；四川/河北站内搜索入口"""
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

from lxml import html as LH  # noqa: E402

from common import get_text, linkify  # noqa: E402

ATT = re.compile(r"\.(pdf|xlsx?|docx?|wps|et|csv)$", re.I)


def show(url):
    t, r = get_text(url)
    print("==", url, "len=", len(t) if t else 0)
    if not t:
        return
    d = LH.fromstring(t)
    ti = d.xpath("//title/text()")
    print("   title:", (ti[0].strip()[:80] if ti else ""))
    for a in d.xpath("//a[@href]"):
        h = a.get("href") or ""
        if ATT.search(h):
            print("   att:", (a.text_content() or "").strip()[:40], "|", linkify(url, h)[:130])
    # 若正文直接有 GR 编号
    n = len(re.findall(r"GR\s?\d{12}", t))
    print("   正文GR计数:", n)


if __name__ == "__main__":
    for u in ("http://kjt.henan.gov.cn/2020/12-25/2065912.html",
              "https://kjt.henan.gov.cn/2020/12-25/2065912.html"):
        show(u)
        break
    # 四川站内搜索入口试探
    for u in ("https://kjt.sc.gov.cn/kjt/search.shtml?keyword=2020%E5%B9%B4%E7%AC%AC%E4%B8%80%E6%89%B9%E9%AB%98%E6%96%B0%E6%8A%80%E6%9C%AF%E4%BC%81%E4%B8%9A",
              "https://kjt.sc.gov.cn/searchList.shtml?searchword=2020%E5%B9%B4%E7%AC%AC%E4%B8%80%E6%89%B9"):
        t, _ = get_text(u)
        print("probe", u[:60], "->", (len(t) if t else 0))
