# -*- coding: utf-8 -*-
"""Merge Guangdong 省厅 data + innocom 备案公告 data into the 6 regional CSVs."""
import sys, os, re, json, csv, collections
sys.path.insert(0, os.path.dirname(__file__))
sys.stdout.reconfigure(encoding="utf-8")
from util import RAW, OUT, write_csv, HEADER, read_xlsx_rows

CODE_CITY = {
    "4400": "广东省", "4401": "广州市", "4420": "深圳市",
    "3700": "山东省", "3710": "青岛市",
    "1100": "北京市", "1101": "北京市",
    "1200": "天津市",
}
SINGLE_CITY = {"北京市": "北京市", "天津市": "天津市", "深圳市": "深圳市", "青岛市": "青岛市"}


def city_from_cert(cert):
    if not cert or len(cert) < 10:
        return "", ""
    code = cert[6:10]
    city = CODE_CITY.get(code, "")
    if city in ("广东省", "山东省"):
        city = ""            # 省本级码，无法定位地级市
    return code, city


def load_guangdong():
    p = os.path.join(OUT, "广东省.csv")
    rows = []
    if not os.path.exists(p):
        return rows
    with open(p, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            rows.append({"name": r["企业名称"], "cert": r["证书编号"], "city": r["城市"],
                         "county": r["区县"], "year": r["认定年度"], "batch": r["批次"],
                         "src": r["来源URL"]})
    return rows


def main():
    gd = load_guangdong()
    # name -> city map from Guangdong 省厅 (has 所在地市 column)
    gd_city = {}
    for r in gd:
        if r["city"]:
            gd_city.setdefault(r["name"], r["city"])

    inno = json.load(open(os.path.join(RAW, "innocom_rows.json"), encoding="utf-8"))

    # Beijing 区县 lookup
    bj_county = {}
    bj_xls = os.path.join(RAW, "bj_list.xls")
    if os.path.exists(bj_xls):
        import xlrd
        sh = xlrd.open_workbook(bj_xls).sheet_by_index(0)
        for i in range(2, sh.nrows):
            nm = str(sh.cell_value(i, 1)).strip()
            ct = str(sh.cell_value(i, 2)).strip()
            if nm and ct:
                bj_county.setdefault(nm, ct)

    # Shenzhen 区县 lookup (光明区 file)
    sz_county = {}
    sz_x = os.path.join(RAW, "sz2023.xlsx")
    if os.path.exists(sz_x):
        import openpyxl
        ws = openpyxl.load_workbook(sz_x, read_only=True, data_only=True).worksheets[0]
        for row in ws.iter_rows(min_row=3, values_only=True):
            if row and row[1] and row[3]:
                sz_county.setdefault(str(row[1]).strip(), str(row[3]).strip())

    buckets = collections.defaultdict(list)
    for r in gd:
        buckets["广东省"].append(r)

    for v in inno.values():
        if "rows" not in v:
            continue
        region = v["region"]
        for x in v["rows"]:
            cert = x["cert"]
            code, city = city_from_cert(cert)
            county = ""
            name = x["name"].strip()
            if region == "广东省" and not city:
                city = gd_city.get(name, "")
            if region == "北京市":
                county = bj_county.get(name, "")
            if region == "深圳市":
                county = sz_county.get(name, "")
            buckets[region].append({
                "name": name, "cert": cert, "city": city, "county": county,
                "year": v["year"], "batch": v["batch"], "src": v["url"]})

    # de-dup: prefer rows with more info
    stamp = {}
    for region, rows in buckets.items():
        for r in rows:
            k = (r["name"], r["cert"])
            score = sum(1 for f in ("city", "county", "year", "batch") if r[f])
            cur = stamp.get((region, k))
            if cur is None or score > cur[0]:
                stamp[(region, k)] = (score, r)

    final = collections.defaultdict(list)
    for (region, k), (score, r) in stamp.items():
        final[region].append(r)

    for region in ["广东省", "深圳市", "山东省", "青岛市", "北京市", "天津市"]:
        rows = final.get(region, [])
        path, n = write_csv(region, rows)
        withcert = sum(1 for r in rows if re.fullmatch(r"GR\d{12}", r["cert"] or ""))
        withcity = sum(1 for r in rows if r["city"])
        withcounty = sum(1 for r in rows if r["county"])
        years = collections.Counter(r["year"] for r in rows)
        print("%-4s rows=%-6d cert=%-6d city=%-6d county=%-6d years=%s" %
              (region, n, withcert, withcity, withcounty, dict(sorted(years.items()))))

    # 地区码.csv
    p = os.path.join(OUT, "地区码.csv")
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["地区码", "城市"])
        for k in sorted(CODE_CITY):
            w.writerow([k, CODE_CITY[k]])
    print("WROTE", p)


if __name__ == "__main__":
    main()
