﻿import csv, os, re, collections
FILES=['内蒙古.csv','辽宁.csv','吉林.csv','黑龙江.csv']
for fn in FILES:
    rows=list(csv.DictReader(open(fn,encoding='utf-8-sig',newline='')))
    odd=[r['企业名称'] for r in rows if not re.search(r'(公司|研究院|研究所|设计院|中心|厂|集团|合作社|事务所|学校|大学|医院|工作室|商行|门市部|总店|分院)$', r['企业名称'])]
    tail=collections.Counter(n[-3:] for n in odd)
    print(fn, 'rows',len(rows),'non-standard tail',len(odd), tail.most_common(8))
    for n in odd[:6]: print('   ', n)
