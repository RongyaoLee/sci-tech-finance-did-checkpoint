# -*- coding: utf-8 -*-
"""补录湖南 2020 第一批（国家网备案复函 PDF 文本层乱码，改从省科技厅公布名单 docx 取）"""
import csv
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")
import fetch_common as fc  # noqa: E402

SRC = ("https://kjt.hunan.gov.cn/kjt/xxgk/tzgg/tzgg_1/202012/"
       "t20201223_14057842.html")
DOC = os.path.join(HERE, "_raw", "湖南", "hn2020_46120873de.docx")

path = os.path.join(HERE, "湖南省.csv")
rows = list(csv.reader(open(path, encoding="utf-8-sig")))[1:]
have = {r[1] for r in rows if r[1]}
n_add = 0
for rec in fc.extract(DOC):
    cert = rec.get("cert") or ""
    if not cert or cert in have:
        continue
    rows.append([rec["name"], cert, "", "", cert[2:6], "第一批", SRC])
    have.add(cert)
    n_add += 1

with open(path, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"])
    w.writerows(rows)
print("湖南省 rows=%d cert=%d 新增=%d" % (
    len(rows), sum(1 for r in rows if r[1]), n_add))
