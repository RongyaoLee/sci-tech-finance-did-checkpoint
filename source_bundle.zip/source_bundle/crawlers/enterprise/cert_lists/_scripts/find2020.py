# -*- coding: utf-8 -*-
"""深挖三省栏目，找 2020 年「公布高新技术企业名单」类公告"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

from lxml import html as LH  # noqa: E402

from common import get_text, linkify  # noqa: E402

PAT = re.compile(r"2020")


def scan(url):
    t, r = get_text(url)
    if not t:
        return []
    d = LH.fromstring(t)
    out = []
    for a in d.xpath("//a[@href]"):
        ti = (a.text_content() or "").strip()
        h = a.get("href") or ""
        if not ti or not h or h.startswith("javascript"):
            continue
        if not re.search(r"高新技术企业", ti):
            continue
        if not PAT.search(ti):
            continue
        out.append((ti, linkify(url, h)))
    return out


def main():
    res = {}
    # 1) 河北 通知公告 深页
    hb = "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/index.html"
    hits = []
    for n in range(61, 137):
        u = hb if n == 1 else hb.replace("index.html", "index_%d.html" % n)
        got = scan(u)
        if got:
            print("  河北 p%d 命中 %d" % (n, len(got)))
            hits.extend(got)
    res["河北"] = hits
    print("河北深页命中", len(hits))
    for t, u in hits[:15]:
        print("   ", t[:62], "|", u[:110])

    # 2) 河南 高企认定专栏
    hn = []
    for u in ("https://kjt.henan.gov.cn/gqrd/", "https://kjt.henan.gov.cn/gqrd/index_2.html"):
        t, _r = get_text(u)
        if not t:
            continue
        d = LH.fromstring(t)
        for a in d.xpath("//a[@href]"):
            ti = (a.text_content() or "").strip()
            h = a.get("href") or ""
            if not ti or h.startswith("javascript"):
                continue
            if "2020" in ti and re.search(r"高新技术企业|高企", ti):
                hn.append((ti, linkify(u, h)))
    res["河南"] = hn
    print("河南 gqrd 2020 命中", len(hn))
    for t, u in hn[:10]:
        print("   ", t[:62], "|", u[:110])

    # 3) 四川 通知公告 深页
    sc = "https://kjt.sc.gov.cn/kjt/gstz/newschild.shtml"
    sh = []
    for n in range(31, 61):
        u = sc if n == 1 else sc.replace("newschild.shtml", "newschild_%d.shtml" % n)
        got = scan(u)
        if got:
            print("  四川 p%d 命中 %d" % (n, len(got)))
            sh.extend(got)
    res["四川"] = sh
    print("四川深页命中", len(sh))
    for t, u in sh[:12]:
        print("   ", t[:62], "|", u[:110])

    json.dump(res, open(os.path.join(HERE, "_raw", "find2020.json"), "w",
                        encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
