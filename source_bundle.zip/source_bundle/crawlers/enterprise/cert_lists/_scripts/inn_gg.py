# -*- coding: utf-8 -*-
"""从 innocom 认定备案公告栏目抓 序号|企业名称|证书编号 三列名单"""
import json
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")
import fetch_common as fc  # noqa: E402

PROVS = sys.argv[1:] or ["河南", "湖北", "湖南", "四川"]
PAGES = int(os.environ.get("INN_PAGES", "4"))

allrows = []
for p in PROVS:
    print("=" * 20, p, fc.PROV_GG.get(p))
    rows = fc.harvest(p, pages=PAGES, kinds=("gg",))
    for r in rows:
        r["prov"] = p
    ncert = sum(1 for r in rows if r.get("cert"))
    print(f"== {p}: {len(rows)} rows, {ncert} cert")
    allrows.extend(rows)

out = os.path.join(HERE, "_raw", "inn_gg.json")
json.dump(allrows, open(out, "w", encoding="utf-8"), ensure_ascii=False)
print("saved", out, len(allrows))
