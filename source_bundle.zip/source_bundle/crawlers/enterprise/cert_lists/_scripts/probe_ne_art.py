# -*- coding: utf-8 -*-
"""Inspect one national 备案公告 detail page: attachment links + pdf text sample."""
import os, re, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from util import fetch, abs_url, RAW

url = sys.argv[1]
r = fetch(url)
html = r.text
print("len", len(html))
for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html, re.S | re.I):
    href = m.group(1).strip()
    text = re.sub(r"<[^>]+>", "", m.group(2)).strip()
    if re.search(r"\.(pdf|xlsx?|docx?|wps|et|zip|rar)\b", href, re.I) or "/files/" in href:
        print("ATT", text[:60], "|", abs_url(url, href))
print("--- text sample ---")
txt = re.sub(r"<script.*?</script>", "", html, flags=re.S | re.I)
txt = re.sub(r"<[^>]+>", " ", txt)
txt = re.sub(r"\s+", " ", txt)
print(txt[:800])
