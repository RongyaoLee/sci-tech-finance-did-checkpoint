# -*- coding: utf-8 -*-
"""河北 2020：检查二批/三批附件是否有文本层；若有则一并解码，并用公示 PDF 的名称合成补录 CSV"""
import csv
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import pymupdf  # noqa: E402

import fetch_common as fc  # noqa: E402

from decode2020 import decode_pdf  # noqa: E402

RAW = os.path.join(HERE, "_raw", "河北")
OUT = os.path.join(HERE, "_city_fill")

BATCH = [
    ("第一批", "t2020_2916ef54.pdf",
     "关于公示河北省2020年第一批拟认定高新技术企业名单的通知_a92c278650.pdf"),
    ("第二批", "t2020_bda4937a.pdf",
     "关于公示河北省2020年第二批拟认定高新技术企业名单的通知_1f433f1132.pdf"),
    ("第三批", "t2020_99d0e5f1.pdf",
     "关于公示河北省2020年第三批拟认定高新技术企业名单的通知_9ad983c182.pdf"),
]


def textlen(p):
    d = pymupdf.open(p)
    tot = sum(len(d[i].get_text().strip()) for i in range(d.page_count))
    return d.page_count, tot


def name_rows(path):
    out = []
    for cells in fc.rows_from_pdf(path):
        if len(cells) < 2:
            continue
        s = cells[0].strip()
        if not s.isdigit():
            continue
        nm = cells[1].strip()
        if len(nm) < 4:
            continue
        out.append((int(s), nm))
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    allrows = []
    for batch, gp, sp in BATCH:
        gpp = os.path.join(RAW, gp)
        spp = os.path.join(RAW, sp)
        pc, tl = textlen(gpp)
        print("%s 复函 %d 页 文本 %d 字符" % (batch, pc, tl))
        certs = decode_pdf(gpp, "13")
        nm = dict(name_rows(spp))
        print("   解码 %d / 公示名称 %d" % (len(certs), len(nm)))
        for r in certs:
            s = int(r["seq"]) if r["seq"].isdigit() else -1
            if s in nm:
                allrows.append([nm[s], r["cert"], "", "", "2020", batch,
                                "http://www.innocom.gov.cn/gqrdw/c101445/list_gsgg_l3.shtml"])
    p = os.path.join(OUT, "河北省_2020公布名单.csv")
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"])
        w.writerows(allrows)
    print("合计写入 %d 行 -> %s" % (len(allrows), p))


if __name__ == "__main__":
    main()
