# -*- coding: utf-8 -*-
"""发现：从6省科技厅首页找「高新技术企业认定」相关栏目入口"""
import sys, re, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from common import get_text, linkify, save_raw
import lxml.html

HOMES = [
    ("湖北省", "https://kjt.hubei.gov.cn/"),
    ("湖南省", "http://kjt.hunan.gov.cn/"),
    ("四川省", "https://kjt.sc.gov.cn/"),
    ("河南省", "https://kjt.henan.gov.cn/"),
    ("河北省", "https://kjt.hebei.gov.cn/"),
    ("福建省", "https://kjt.fujian.gov.cn/"),
]

PAT = re.compile(r"高新技术企业|高企|认定管理|科技型中小企业")

res = {}
for prov, home in HOMES:
    print("=" * 70)
    print(prov, home)
    try:
        txt, r = get_text(home)
    except Exception as e:
        print("  FAIL", e)
        res[prov] = []
        continue
    save_raw(f"home_{prov}.html", txt.encode("utf-8"))
    try:
        doc = lxml.html.fromstring(txt)
        doc.make_links_absolute(home, resolve_base_href=True)
    except Exception as e:
        print("  parse fail", e)
        res[prov] = []
        continue
    seen = set()
    hits = []
    for a in doc.iter("a"):
        t = (a.text_content() or "").strip()
        t = re.sub(r"\s+", " ", t)
        h = a.get("href") or ""
        if not t or len(t) > 60:
            continue
        if PAT.search(t) or PAT.search(h):
            if h in seen:
                continue
            seen.add(h)
            hits.append((t, h))
    for t, h in hits[:30]:
        print(f"   - {t}  ->  {h}")
    res[prov] = hits

with open(os.path.join(os.path.dirname(__file__), "..", "_raw", "home_links.json"), "w", encoding="utf-8") as f:
    json.dump(res, f, ensure_ascii=False, indent=1)
print("\nDONE")
