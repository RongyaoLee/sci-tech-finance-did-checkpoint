# -*- coding: utf-8 -*-
"""Verify cert-year consistency in gg_rows.json: the fragment repair grabbed
the nearest cert line, which can belong to another year's announcement.
Re-locate a cert whose year digits match the row year; otherwise clear it."""
import sys, os, re, json, glob
sys.stdout.reconfigure(encoding="utf-8")
import pymupdf

RAW = os.path.join(os.path.dirname(__file__), "..", "_raw")
rows = json.load(open(os.path.join(RAW, "gg_rows.json"), encoding="utf-8"))
CERT = re.compile(r"(?:GR|GS)\d{12}")

cache = {}


def pages(region):
    if region not in cache:
        out = []
        for p in glob.glob(os.path.join(RAW, region, "*.pdf")):
            try:
                d = pymupdf.open(p)
                for i in range(d.page_count):
                    t = d[i].get_text()
                    if CERT.search(t):
                        out.append(t.split("\n"))
            except Exception:
                pass
        cache[region] = out
    return cache[region]


bad = 0
for region, lst in rows.items():
    for r in lst:
        cert, year = r.get("cert") or "", r.get("year") or ""
        if not CERT.fullmatch(cert) or not year or cert[2:6] == year:
            continue
        bad += 1
        nm = r["name"].strip()
        found = ""
        for lines in pages(region):
            lines = [x.strip() for x in lines if x.strip()]
            for i, ln in enumerate(lines):
                if nm not in ln and not (len(ln) > 8 and ln in nm):
                    continue
                tail = ln if nm in ln else ln
                for j in range(1, 4):
                    if i + j < len(lines):
                        c = lines[i + j]
                        if CERT.fullmatch(c) and c[2:6] == year:
                            found = c
                            break
                if found:
                    break
            if found:
                break
        print("  %-4s %s  %s -> %s" % (region, year, cert, found or "(cleared)"))
        r["cert"] = found
json.dump(rows, open(os.path.join(RAW, "gg_rows.json"), "w", encoding="utf-8"), ensure_ascii=False)
print("checked mismatches", bad)
