# -*- coding: utf-8 -*-
"""Repair long company names that the coordinate parser split across two PDF
lines (name cell wraps, cert sits after the wrapped second line)."""
import sys, os, re, json, glob
sys.stdout.reconfigure(encoding="utf-8")
import pymupdf

RAW = os.path.join(os.path.dirname(__file__), "..", "_raw")
rows = json.load(open(os.path.join(RAW, "gg_rows.json"), encoding="utf-8"))
CERT = re.compile(r"(?:GR|GS)\d{12}")
REG = ["广东省", "深圳市", "山东省", "青岛市", "北京市", "天津市"]

# index: (region) -> list of (path, [page texts])
cache = {}


def pages(region):
    if region in cache:
        return cache[region]
    out = []
    for p in glob.glob(os.path.join(RAW, region, "*.pdf")):
        try:
            doc = pymupdf.open(p)
            for i in range(doc.page_count):
                t = doc[i].get_text()
                if CERT.search(t):
                    out.append((p, i, t))
        except Exception:
            pass
    cache[region] = out
    return out


fixed = 0
for region in REG:
    bad = [r for r in rows.get(region, []) if not CERT.fullmatch(r["cert"] or "")]
    if not bad:
        continue
    pgs = pages(region)
    for r in bad:
        frag = r["name"].strip()
        if len(frag) < 6:
            continue
        hit = None
        for path, pno, t in pgs:
            lines = [x.strip() for x in t.split("\n") if x.strip()]
            for i, ln in enumerate(lines):
                if ln == frag or (frag[:14] and frag[:14] in ln):
                    # candidate: join with next line, next-but-one must be cert
                    for j in (1, 2):
                        if i + j + 1 < len(lines):
                            joined = ln + lines[i + j]
                            if CERT.fullmatch(lines[i + j + 1]) and not CERT.search(lines[i + j]):
                                hit = (joined, lines[i + j + 1])
                                break
                    if hit:
                        break
            if hit:
                break
        if hit:
            r["name"], r["cert"] = hit[0], hit[1]
            fixed += 1
            print("  FIX %-6s %s -> %s" % (region, r["name"][:34], r["cert"]))
        else:
            print("  keep %-6s %r (cert unknown)" % (region, frag[:30]))
print("fixed", fixed)
json.dump(rows, open(os.path.join(RAW, "gg_rows.json"), "w", encoding="utf-8"), ensure_ascii=False)
