# -*- coding: utf-8 -*-
"""看河北 2020 二批/三批复函 PDF 的行结构"""
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import pymupdf  # noqa: E402

import fetch_common as fc  # noqa: E402

RAW = os.path.join(HERE, "_raw", "河北")
for fn in ("t2020_bda4937a.pdf", "t2020_99d0e5f1.pdf"):
    p = os.path.join(RAW, fn)
    print("=" * 24, fn)
    i = 0
    for cells in fc.rows_from_pdf(p):
        if not cells:
            continue
        i += 1
        if i <= 8:
            print("   ", [c[:30] for c in cells])
    print("   rows", i)
    d = pymupdf.open(p)
    print("   page0 text:", repr(d[0].get_text()[:180]))
