# -*- coding: utf-8 -*-
"""Inspect per (year,batch) cert vs blank name sets to detect systematic merge failure."""
import sys, re, csv, os, collections

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CERT = re.compile(r'^GR\d{12}$')


def canon(s):
    s = s.replace('（', '(').replace('）', ')')
    return re.sub(r'\s+', '', s)


def load(p):
    with open(p, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


p = os.path.join(BASE, sys.argv[1])
rows = load(p)
by = collections.defaultdict(lambda: {'c': [], 'b': []})
for r in rows:
    by[(r['认定年度'], r['批次'])]['c' if CERT.match(r['证书编号']) else 'b'].append(r)

for yb in sorted(by):
    g = by[yb]
    cs = {canon(r['企业名称']) for r in g['c']}
    bs = {canon(r['企业名称']) for r in g['b']}
    ov = len(cs & bs)
    print(f'{yb[0]:>4} {yb[1] or "-":<10} cert={len(g["c"]):5d} blank={len(g["b"]):5d} overlap={ov:4d} blank_only={len(bs)-ov:4d}')
    if len(bs) - ov > 80:
        for r in list(g['b'])[:6]:
            print('    b:', r['企业名称'][:50])
        for r in list(g['c'])[:4]:
            print('    c:', r['企业名称'][:50], r['证书编号'])
