# -*- coding: utf-8 -*-
"""给定文章URL，抽取标题/日期/附件链接"""
import sys, re, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from common import get_text, save_raw
import lxml.html

ATT = re.compile(r"\.(xlsx|xls|pdf|docx|doc|zip|rar|7z|csv|wps|et)(\?|$)", re.I)


def analyze(url, tag=None):
    print("=" * 78)
    print(url)
    try:
        txt, r = get_text(url)
    except Exception as e:
        print("  FAIL", type(e).__name__, str(e)[:140])
        return None
    final = r.url
    print("  final:", final, "len:", len(txt))
    safe = tag or re.sub(r"[^0-9A-Za-z\u4e00-\u9fa5]+", "_", url)[-60:]
    save_raw(f"art_{safe}.html", txt.encode("utf-8"))
    doc = lxml.html.fromstring(txt)
    doc.make_links_absolute(final, resolve_base_href=True)
    m = re.search(r"<title[^>]*>(.*?)</title>", txt, re.S | re.I)
    print("  title:", (m.group(1).strip()[:100] if m else ""))
    # 日期
    for pat in [r"(\d{4})[-年/](\d{1,2})[-月/](\d{1,2})", r"(\d{4})\.(\d{1,2})\.(\d{1,2})"]:
        ms = re.findall(pat, txt[:20000])
        if ms:
            print("  dates:", ["%s-%s-%s" % x for x in ms[:6]])
            break
    atts = []
    for a in doc.iter("a"):
        h = a.get("href") or ""
        t = re.sub(r"\s+", " ", (a.text_content() or "")).strip()
        if ATT.search(h):
            atts.append((t[:60], h))
    print(f"  attachments: {len(atts)}")
    for t, h in atts:
        print("    -", t or "(no text)", "|", h)
    # 正文纯文本片段含「附件」
    plain = re.sub(r"<[^>]+>", " ", txt)
    for mm in re.finditer(r"附件[^。]{0,60}", plain):
        print("    附近:", re.sub(r"\s+", " ", mm.group(0))[:80])
        break
    return {"url": final, "atts": atts}


if __name__ == "__main__":
    for u in sys.argv[1:]:
        analyze(u)
