# -*- coding: utf-8 -*-
"""按 URL 中的年份而不是标题，找各省 2020 年高企名单公告"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

RAW = os.path.join(HERE, "_raw")


def load(fn):
    p = os.path.join(RAW, fn)
    if not os.path.exists(p):
        return []
    d = json.load(open(p, encoding="utf-8"))
    out = []
    for x in d:
        t, u = (x[0], x[1]) if isinstance(x, list) else (x.get("title"), x.get("url"))
        out.append((t or "", u or ""))
    return out


for fn in ("items_河北省.json", "items_河南省.json", "items_河南省_x.json",
           "items_四川省tzgg.json", "items_河北省tzgg.json"):
    items = load(fn)
    if not items:
        continue
    z = [(t, u) for t, u in items if re.search(r"/(2020|2021)/\d{1,2}[-/]", u)]
    g = [(t, u) for t, u in z if re.search(r"高新技术企业|高企", t)]
    print("== %-24s 总%4d /2020|2021/ %3d / 含高企 %2d" % (fn, len(items), len(z), len(g)))
    for t, u in g[:12]:
        print("    ", t[:56], "|", u[:104])
