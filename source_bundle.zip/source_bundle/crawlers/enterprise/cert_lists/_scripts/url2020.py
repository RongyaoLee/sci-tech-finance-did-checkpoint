# -*- coding: utf-8 -*-
"""取四川 2020 年备案复函页 URL"""
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import fetch_common as fc  # noqa: E402

for prov in ("四川", "河南"):
    items = fc.list_items(prov, pages=3, kind="gg")
    for it in items:
        t = it.get("title") or ""
        if "2020" in t and "复函" in t:
            print(prov, "|", t[:52], "|", it.get("url"))
