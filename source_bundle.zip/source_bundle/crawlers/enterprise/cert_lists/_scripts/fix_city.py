# -*- coding: utf-8 -*-
"""Rebuild 广东省.csv city column WITHOUT any certificate-code inference.

Rule (per parent correction): certificate number is GR + year(4) + 省码(2) +
顺序号(6); the 4 digits at cert[6:10] are 省码 + first two serial digits, NOT a
city administrative code. City must come from an attachment column only.

Sources of city used here:
  * 广东省科技厅 公布名单 PDF —— 表头「所在地市」列 (real attachment column)
  * 其余行 (国家网 innocom 备案公告, 无地市列) —— 留空, 仅当同企业名在省厅
    PDF 中出现过才用省厅给出 的地市 (同源附件数据按名称回填)
Anything previously derived from cert[6:10] is discarded.
"""
import sys, os, re, csv, glob, json, collections
sys.path.insert(0, os.path.dirname(__file__))
sys.stdout.reconfigure(encoding="utf-8")
from util import RAW, OUT, parse_pdf_grid, write_csv

GD_PDF = sorted(glob.glob(os.path.join(RAW, "gd_*.pdf")))
print("gd pdfs", len(GD_PDF))

gd_rows = []
for p in GD_PDF:
    base = os.path.basename(p)
    m = re.match(r"gd_(\d{4})_(.+)_\d+\.pdf$", base)
    year, batch = (m.group(1), m.group(2)) if m else ("", "")
    pr = parse_pdf_grid(p)
    print("  %-28s year=%s batch=%s rows=%-5d city=%-5d" %
          (base, year, batch, len(pr), sum(1 for x in pr if x["city"])))
    for x in pr:
        gd_rows.append({"name": x["name"].strip(), "cert": x["cert"], "city": x["city"],
                        "county": x["county"], "year": year, "batch": batch,
                        "src": "http://gdstc.gd.gov.cn/ (公布名单 PDF: %s)" % base})

# name -> city from 省厅 attachment 所在地市 column
name_city = {}
tmp = collections.defaultdict(list)
for r in gd_rows:
    if r["city"]:
        tmp[r["name"]].append(r["city"])
for k, v in tmp.items():
    name_city[k] = collections.Counter(v).most_common(1)[0][0]

gd_keys = set((r["name"], r["cert"]) for r in gd_rows)

# existing merged CSV
p = os.path.join(OUT, "广东省.csv")
old = []
with open(p, encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        old.append(r)
print("existing 广东省.csv rows", len(old))

code_before = collections.Counter((r["证书编号"] or "")[6:10] for r in old)

# keep 省厅 rows (they carry the real 所在地市) and inner-national rows with
# name-based backfill only
out, seen = [], set()
for r in old:
    name = r["企业名称"]
    cert = r["证书编号"]
    src = r["来源URL"]
    city = r["城市"]
    if "gdstc.gd.gov.cn" in src and city:
        pass                                  # attachment column, keep
    else:
        city = name_city.get(name, "")        # attachment column via same enterprise
    key = (name, cert)
    if key in seen:
        continue
    seen.add(key)
    out.append({"name": name, "cert": cert, "city": city, "county": r["区县"],
                "year": r["认定年度"], "batch": r["批次"], "src": src})

# add any 省厅 row missing from the merged file (should be none)
for r in gd_rows:
    if (r["name"], r["cert"]) not in seen:
        seen.add((r["name"], r["cert"]))
        out.append(r)

path, n = write_csv("广东省", out)
print("WROTE", path, n)
print("city filled", sum(1 for r in out if r["city"]),
      "empty", sum(1 for r in out if not r["city"]))
print("city dist", collections.Counter(r["city"] for r in out if r["city"]).most_common(8))
print("cert[6:10] dist", code_before.most_common(6))

json.dump({"gd_rows": len(gd_rows), "final": n}, open(os.path.join(RAW, "fix_city.json"), "w"))
