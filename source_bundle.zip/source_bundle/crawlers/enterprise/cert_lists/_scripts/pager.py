# -*- coding: utf-8 -*-
"""测试各站分页URL模式"""
import sys, re, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from common import get, get_text

CAND = [
    ("湖北", "https://kjt.hubei.gov.cn/kjdt/tzgg/index_1.shtml"),
    ("湖北b", "https://kjt.hubei.gov.cn/kjdt/tzgg/index_2.shtml"),
    ("湖南", "http://kjt.hunan.gov.cn/kjt/xxgk/tzgg/index_1.html"),
    ("湖南b", "http://kjt.hunan.gov.cn/kjt/xxgk/tzgg/index_2.html"),
    ("四川", "https://kjt.sc.gov.cn/kjt/gstz/newschild_1.shtml"),
    ("四川b", "https://kjt.sc.gov.cn/kjt/gstz/newschild_2.shtml"),
    ("河南", "https://kjt.henan.gov.cn/tzgg/index_1.html"),
    ("河南b", "https://kjt.henan.gov.cn/tzgg/index_2.html"),
    ("河北", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/index_1.html"),
    ("河北b", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/index_2.html"),
    ("福建", "http://kjt.fujian.gov.cn/xxgk/tzgg/index_1.htm"),
    ("福建b", "http://kjt.fujian.gov.cn/xxgk/tzgg/index_2.htm"),
]

for tag, url in CAND:
    try:
        t, r = get_text(url)
        same = "NEW" if len(t) > 3000 else "short"
        # 抓第一条标题
        m = re.findall(r"t\d{8}_\d+\.(?:s?html?)", t)
        first = ""
        mm = re.search(r'<a[^>]+href="([^"]+)"[^>]*>\s*([^<]{10,60})</a>', t)
        if mm:
            first = mm.group(2).strip()[:40]
        print(f"[{r.status_code}] {tag:6s} len={len(t):6d} {same:5s} n={len(set(m))} first={first}")
    except Exception as e:
        print(f"[ERR] {tag:6s} {type(e).__name__} {str(e)[:80]}")
