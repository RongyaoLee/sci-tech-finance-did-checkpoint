# -*- coding: utf-8 -*-
"""Validate a province CSV: cert format, cert-year match, duplicates, name sanity."""
import csv, re, sys, collections
sys.stdout.reconfigure(encoding="utf-8")

p = sys.argv[1]
rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
print("file", p, "rows", len(rows))
bad = [r for r in rows if r["证书编号"] and not re.fullmatch(r"GR\d{12}", r["证书编号"])]
print("bad cert format:", len(bad), bad[:3])
mis = [r for r in rows if r["证书编号"] and r["认定年度"] and r["证书编号"][2:6] != r["认定年度"]]
print("cert-year mismatch:", len(mis), [(r["企业名称"][:20], r["证书编号"], r["认定年度"]) for r in mis[:5]])
dups = [c for c, n in collections.Counter(r["证书编号"] for r in rows if r["证书编号"]).items() if n > 1]
print("dup certs:", len(dups), dups[:5])
names = collections.Counter(r["企业名称"] for r in rows)
print("dup names:", sum(1 for k, v in names.items() if v > 1))
weird = [r["企业名称"] for r in rows if len(r["企业名称"]) < 4 or re.search(r"[A-Za-z]{4,}|\d{3,}", r["企业名称"])]
print("weird names:", len(weird), weird[:8])
print("years:", sorted(collections.Counter(r["认定年度"] for r in rows).items()))
print("cert by year:", sorted(collections.Counter(r["认定年度"] for r in rows if r["证书编号"]).items()))
