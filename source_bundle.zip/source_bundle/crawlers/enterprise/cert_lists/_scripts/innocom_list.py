# -*- coding: utf-8 -*-
"""innocom.gov.cn 认定备案公告 crawler: find our 6 regions, download PDFs, parse."""
import sys, os, re, json, time
sys.path.insert(0, os.path.dirname(__file__))
sys.stdout.reconfigure(encoding="utf-8")
from util import fetch, download, links, abs_url, parse_pdf_grid, RAW

BASE = "http://www.innocom.gov.cn/gqrdw/c101481/"
REGIONS = ["广东省", "深圳市", "山东省", "青岛市", "北京市", "天津市"]

def list_url(page):
    return BASE + ("list_gsgg_l2.shtml" if page == 1 else "list_gsgg_l2_%d.shtml" % page)

items = []
CACHE = os.path.join(RAW, "innocom_items.json")
for page in range(1, 57):
    r = fetch(list_url(page))
    if r is None:
        print("list fail", page)
        continue
    h = r.text
    # items: <a href=... title='TITLE'>TITLE</a> ... <span>2026-04-xx</span>
    for m in re.finditer(r"<a[^>]+href=[\"']([^\"']+)[\"'][^>]*title=[\"']([^\"']+)[\"']", h):
        href, title = m.group(1), m.group(2)
        if "认定机构" not in title:
            continue
        if not any(x in title for x in REGIONS):
            continue
        items.append({"title": title, "url": abs_url(BASE, href)})
    time.sleep(0.05)

# dedupe
seen = set()
uniq = []
for it in items:
    k = it["url"]
    if k in seen:
        continue
    seen.add(k)
    m = re.search(r"(20\d\d)", it["title"])
    it["year"] = m.group(1) if m else ""
    mb = re.search(r"(第[一二三四五六批]批|补充备案)", it["title"])
    it["batch"] = it["title"].split("认定机构")[0].replace("对", "")[:2] and it["title"]
    it["region"] = next(x for x in REGIONS if x in it["title"])
    b = ""
    if "补充备案" in it["title"]:
        b = "补充备案"
    mm = re.search(r"第([一二三四五六])批", it["title"])
    if mm:
        b = "第" + mm.group(1) + "批"
    it["batch_label"] = b
    uniq.append(it)

print("items", len(uniq))
json.dump(uniq, open(CACHE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for it in uniq:
    print(it["year"], it["region"], it["batch_label"], it["title"][:50])
