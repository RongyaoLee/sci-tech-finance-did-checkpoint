﻿# -*- coding: utf-8 -*-
"""把已下载附件汇总成 6 个省级 CSV"""
import os
import re
import csv
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from common import ROOT
from parse_file import parse_file

ATT = os.path.join(ROOT, "_raw", "att")
OUT = ROOT
HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]

# prov, 附件文件名, 公告页URL, 默认认定年度, 批次
SOURCES = [
    # 湖北省
    ("湖北省", "hb2023.pdf", "https://kjt.hubei.gov.cn/kjdt/tzgg/202404/t20240416_5160308.shtml", "2023", ""),
    ("湖北省", "P020250425333475346473.pdf",
     "https://kjt.hubei.gov.cn/zfxxgk_GK2020/zc2020/qtzdgk/gsgg/202504/t20250425_5629170.shtml", "2024", ""),
    # 湖南省
    ("湖南省", "hn2021_1.docx", "http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/202112/t20211220_21319535.html", "2021", "第一批"),
    ("湖南省", "hn2022_1.pdf", "http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/202211/t20221108_29119307.html", "2022", "第一批"),
    ("湖南省", "hn2022_2.pdf", "http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/202303/t20230330_29301428.html", "2022", "第二批"),
    ("湖南省", "hn2023_1.pdf", "http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/202311/t20231107_31816749.html", "2023", "第一批"),
    ("湖南省", "hn2022_supp.pdf", "http://kjt.hunan.gov.cn/kjt/zxgz/jscy/gxjsqy/202303/t20230330_29301423.html", "2022", "补充备案"),
    # 四川省（有效名单快照，认定年度取自证书编号）
    ("四川省", "sc2025_list.xlsx", "https://kjt.sc.gov.cn/kjt/gstz/2026/4/17/c38c219fc493407581a805521d7f0668.shtml", "", ""),
    ("四川省", "sc2024_list.xlsx", "https://kjt.sc.gov.cn/kjt/gstz/2025/6/23/10f6bcecc81b47fc8f40d74fffc504c9.shtml", "", ""),
    ("四川省", "sc2024_supp.xls", "https://kjt.sc.gov.cn/kjt/gstz/2025/6/23/10f6bcecc81b47fc8f40d74fffc504c9.shtml", "2024", "补充备案"),
    # 河北省
    ("河北省", "he2021_1.docx", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418344688721/index.html", "2021", "第一批"),
    ("河北省", "he2021_2.docx", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418344688721/index.html", "2021", "第二批"),
    ("河北省", "he2021_3.docx", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418344688721/index.html", "2021", "第三批"),
    ("河北省", "he2022_1.doc", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418345127412/index.html", "2022", "第一批"),
    ("河北省", "he2022_2.doc", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418345127412/index.html", "2022", "第二批"),
    ("河北省", "he2022_3.doc", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418345127412/index.html", "2022", "第三批"),
    ("河北省", "he2023_1.doc", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418345546934/index.html", "2023", "第一批"),
    ("河北省", "he2023_2.doc", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/sttz15/2024122418345546934/index.html", "2023", "第二批"),
    # 福建省
    ("福建省", "fj2023.doc", "http://kjt.fj.gov.cn/xxgk/tzgg/202404/t20240418_6432616.htm", "2023", ""),
    ("福建省", "fj2024.doc", "https://kjt.fujian.gov.cn/xxgk/zfxxgkzl/zfxxgkml/yzdgkdqtxx/202504/t20250429_6906651.htm", "2024", ""),
    ("福建省", "fj2025_list.docx", "https://kjt.fujian.gov.cn/xxgk/tzgg/202604/t20260424_7131223.htm", "2025", ""),
]


# 河南省：公示PDF/doc 有 所属地市/所在地域，无证书编号
HENAN_SOURCES = [
    ("hn2024_p1.pdf", "https://kjt.henan.gov.cn/2024/10-17/3074891.html", "2024", "第一批"),
    ("hn2024_p2.pdf", "https://kjt.henan.gov.cn/2024/11-12/3085277.html", "2024", "第二批"),
    ("hn2024_p3.pdf", "https://kjt.henan.gov.cn/2024/11-25/3090707.html", "2024", "第三批"),
    ("hn2024_p4.doc", "https://kjt.henan.gov.cn/2024/12-03/3094227.html", "2024", "第四批"),
]


def year_from_cert(cert):
    m = re.match(r"^GR(\d{4})", cert or "")
    return m.group(1) if m else ""


def main():
    per_prov = {}
    stat = []
    for prov, fn, page, dyear, batch in SOURCES:
        path = os.path.join(ATT, fn)
        if not os.path.exists(path):
            stat.append((prov, fn, -1, -1, -1, "missing"))
            continue
        rows = parse_file(path)
        good = 0
        for name, cert, city in rows:
            name = (name or "").strip()
            if not name:
                continue
            cert = (cert or "").strip()
            y = year_from_cert(cert) or dyear
            rec = [name, cert, (city or "").strip(), "", y, batch, page]
            per_prov.setdefault(prov, []).append(rec)
            good += 1
        stat.append((prov, fn, len(rows), len(rows), sum(1 for r in rows if r[1]), "ok"))

    # 河南：无证书编号，有城市/区县
    from parse_henan import rows_henan
    for fn, page, dyear, batch in HENAN_SOURCES:
        path = os.path.join(ATT, fn)
        if not os.path.exists(path):
            continue
        for name, cert, city, area in rows_henan(path):
            per_prov.setdefault("河南省", []).append(
                [name.strip(), "", city.strip(), area.strip(), dyear, batch, page])

    # 去重（同省：证书编号优先；无证书编号用 名称+年度+批次）
    final = {}
    for prov, rows in per_prov.items():
        seen = set()
        out = []
        for r in rows:
            key = r[1] if r[1] else (r[0] + "|" + r[4] + "|" + r[5])
            if key in seen:
                continue
            seen.add(key)
            out.append(r)
        final[prov] = out

    for prov, rows in final.items():
        p = os.path.join(OUT, prov + ".csv")
        with open(p, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(HEADER)
            w.writerows(rows)
        cert = sum(1 for r in rows if r[1])
        city = sum(1 for r in rows if r[2])
        print(f"{prov}: rows={len(rows)} cert={cert} city={city} -> {p}")

    print("\n-- per-file --")
    for s in stat:
        print("  %-8s %-30s rows=%-6d cert=%-6d %s" % (s[0], s[1], s[2], s[4], s[5]))


if __name__ == "__main__":
    main()

