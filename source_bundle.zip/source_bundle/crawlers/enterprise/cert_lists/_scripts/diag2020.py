# -*- coding: utf-8 -*-
"""诊断 2020 备案复函 PDF 的乱码结构，看能否用数字字形映射还原证书编号"""
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import fetch_common as fc  # noqa: E402

for name in ("河南/y2020_5257c55d.pdf", "四川/y2020_66c83260.pdf"):
    p = os.path.join(HERE, "_raw", name)
    print("=" * 30, name, os.path.exists(p))
    if not os.path.exists(p):
        continue
    n = 0
    for cells in fc.rows_from_pdf(p):
        if not cells:
            continue
        joined = "|".join(cells)
        n += 1
        if n <= 14 or n % 40 == 0:
            print("  %2d  %r" % (n, [c[:24] for c in cells]))
        if n > 60:
            break
