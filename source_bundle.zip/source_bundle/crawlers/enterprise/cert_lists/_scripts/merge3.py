# -*- coding: utf-8 -*-
"""Rebuild the six regional CSVs from innocom 认定备案公告 (province columns).

City policy (no certificate-code inference anywhere):
  * 广东省  —— only from 广东省科技厅 公布名单 PDF 的「所在地市」列 (matched by 企业名称)
  * 山东省  —— 附件无地市列，留空
  * 北京市 / 天津市 / 深圳市 / 青岛市 —— 单列/直辖市认定机构, 城市取「该行属于哪个
    认定机构的备案公告」(栏目归属), 与证书编号无关
区县:
  * 北京市 —— 市科委 xls 名单「所在区县/园区」列, 按企业名称匹配
  * 深圳市 —— 光明区 名单 xlsx「所在区」列, 按企业名称匹配
"""
import sys, os, re, csv, json, glob, collections
sys.path.insert(0, os.path.dirname(__file__))
sys.stdout.reconfigure(encoding="utf-8")
from util import RAW, OUT, parse_pdf_grid, write_csv, HEADER

REGIONS = ["广东省", "深圳市", "山东省", "青岛市", "北京市", "天津市"]
CITY_OF = {"北京市": "北京市", "天津市": "天津市", "深圳市": "深圳市", "青岛市": "青岛市"}

# ---------- 1. 广东 省厅 PDF: name -> 所在地市 (attachment column) ----------
name_city = collections.defaultdict(collections.Counter)
for p in sorted(glob.glob(os.path.join(RAW, "gd_*.pdf"))):
    for x in parse_pdf_grid(p):
        if x["city"]:
            name_city[x["name"].strip()][x["city"]] += 1
name_city = {k: v.most_common(1)[0][0] for k, v in name_city.items()}
print("gd 省厅 name->city", len(name_city))


def normn(s):
    """normalise for name matching: NFKC (full->half width brackets) + drop spaces"""
    import unicodedata
    return unicodedata.normalize("NFKC", s or "").replace(" ", "").replace("\u3000", "").lower()


name_city_n = {normn(k): v for k, v in name_city.items()}

# ---------- 2. Beijing 区县 / Shenzhen 区县 ----------
bj_county = {}
p = os.path.join(RAW, "bj_list.xls")
if os.path.exists(p):
    import xlrd
    sh = xlrd.open_workbook(p).sheet_by_index(0)
    for i in range(2, sh.nrows):
        nm = str(sh.cell_value(i, 1)).strip()
        ct = str(sh.cell_value(i, 2)).strip()
        if nm and ct:
            bj_county.setdefault(nm, ct)
bj_county_n = {normn(k): v for k, v in bj_county.items()}
print("bj county map", len(bj_county))

sz_county = {}
p = os.path.join(RAW, "sz2023.xlsx")
if os.path.exists(p):
    import openpyxl
    ws = openpyxl.load_workbook(p, read_only=True, data_only=True).worksheets[0]
    for row in ws.iter_rows(min_row=3, values_only=True):
        if row and len(row) > 3 and row[1] and row[3]:
            sz_county.setdefault(str(row[1]).strip(), str(row[3]).strip())
sz_county_n = {normn(k): v for k, v in sz_county.items()}
print("sz county map", len(sz_county))

# ---------- 3. rows: existing CSVs (keep 区县/城市 provenance) + new gg rows ----------
gg = json.load(open(os.path.join(RAW, "gg_rows.json"), encoding="utf-8"))
pool = collections.defaultdict(list)

# gg (freshly parsed 备案公告) first: it is authoritative and wins key conflicts
for region, rows in gg.items():
    pool[region].extend(rows)

for region in REGIONS:
    p = os.path.join(OUT, region + ".csv")
    if not os.path.exists(p):
        continue
    for r in csv.DictReader(open(p, encoding="utf-8-sig")):
        pool[region].append({"name": r["企业名称"], "cert": r["证书编号"],
                             "county": r["区县"], "year": r["认定年度"],
                             "batch": r["批次"], "src": r["来源URL"]})

# ---------- 4. dedupe: (name, year, batch) -> prefer cert, then county ----------
final = {}
for region in REGIONS:
    m = {}
    for r in pool[region]:
        name = (r["name"] or "").strip()
        if not name or len(name) < 3:
            continue
        key = (name, r.get("year", ""), r.get("batch", ""))
        cur = m.get(key)
        if cur is None:
            m[key] = dict(r, name=name)
            continue
        if not cur["cert"] and r["cert"]:
            cur["cert"] = r["cert"]
        if not cur.get("county") and r.get("county"):
            cur["county"] = r["county"]
        if not cur.get("src") and r.get("src"):
            cur["src"] = r["src"]
    # collapse duplicates that ended up with same (name, cert)
    m2 = {}
    for (name, year, batch), r in m.items():
        k = (name, r["cert"]) if r["cert"] else (name, "", year, batch)
        cur = m2.get(k)
        if cur is None:
            m2[k] = r
        else:
            if not cur.get("county") and r.get("county"):
                cur["county"] = r["county"]
            if r["batch"] and (not cur["batch"] or len(r["batch"]) < len(cur["batch"])):
                cur["batch"] = r["batch"]
    final[region] = list(m2.values())

# ---------- 5. fill city/county ----------
report = []
for region in REGIONS:
    rows = final[region]
    for r in rows:
        if region == "广东省":
            r["city"] = name_city.get(r["name"], "") or name_city_n.get(normn(r["name"]), "")
        elif region == "山东省":
            r["city"] = ""
        else:
            r["city"] = CITY_OF[region]
        if region == "北京市":
            r["county"] = (r.get("county") or bj_county.get(r["name"], "")
                           or bj_county_n.get(normn(r["name"]), ""))
        elif region == "深圳市":
            r["county"] = (r.get("county") or sz_county.get(r["name"], "")
                           or sz_county_n.get(normn(r["name"]), ""))
        else:
            r["county"] = r.get("county") or ""
    rows.sort(key=lambda r: (r["year"], r["batch"], r["name"]))
    path, n = write_csv(region, rows)
    cert = sum(1 for r in rows if re.fullmatch(r"(?:GR|GS)\d{12}", r["cert"] or ""))
    city = sum(1 for r in rows if r["city"])
    county = sum(1 for r in rows if r["county"])
    yrs = collections.Counter(r["year"] for r in rows)
    bats = collections.Counter((r["year"], r["batch"]) for r in rows)
    report.append({"region": region, "path": path, "rows": n, "cert": cert,
                   "city": city, "county": county,
                   "years": dict(sorted(yrs.items())),
                   "batches": {"%s/%s" % k: v for k, v in sorted(bats.items())},
                   "mb": round(os.path.getsize(path) / 1e6, 1)})
    print("%-4s rows=%-6d cert=%-6d city=%-6d county=%-5d %s" %
          (region, n, cert, city, county, dict(sorted(yrs.items()))))

json.dump(report, open(os.path.join(RAW, "report_final.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("TOTAL rows", sum(r["rows"] for r in report))
