# -*- coding: utf-8 -*-
"""Download one attachment and dump grid rows to check columns."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from util import download, parse_pdf_grid, pdf_lines, RAW

url = sys.argv[1]
name = sys.argv[2]
p = download(url, name)
print("saved", p, os.path.getsize(p) if p else -1)
if not p:
    sys.exit(1)
lines = pdf_lines(p)
print("lines", len(lines))
for ln in lines[:25]:
    print("L|", ln)
print("--- grid ---")
rows = parse_pdf_grid(p)
print("rows", len(rows))
for r in rows[:6]:
    print(r)
