# -*- coding: utf-8 -*-
"""解码 2020 补充备案复函；并从 inn JSON 找 2020 复函页 URL"""
import json
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

from decode2020 import decode_pdf  # noqa: E402

RAW = os.path.join(HERE, "_raw")

for prov, fn, code in (("四川", "四川/y2020_8bfd4e93.pdf", "51"),
                       ("河南", "河南/y2020_25493ebc.pdf", "41")):
    p = os.path.join(RAW, fn)
    rows = decode_pdf(p, code)
    seqs = [int(r["seq"]) for r in rows if r["seq"].isdigit()]
    print(prov, "补充备案 rows", len(rows),
          "seq", (min(seqs), max(seqs)) if seqs else None,
          "certs", rows[:2], rows[-2:] if rows else None)

print("-" * 30, "JSON 中的 2020 复函条目")
for jf in ("inn_gg.json", "inn_gg_4prov.json"):
    fp = os.path.join(RAW, jf)
    if not os.path.exists(fp):
        continue
    d = json.load(open(fp, encoding="utf-8"))
    print(" ", jf, type(d).__name__, len(d))
    for it in d:
        if not isinstance(it, dict):
            continue
        blob = json.dumps(it, ensure_ascii=False)
        if "2020" in blob and ("四川" in blob or "河南" in blob) and "复函" in blob:
            print("    keys:", list(it.keys()))
            print("    ", blob[:220])
            break
