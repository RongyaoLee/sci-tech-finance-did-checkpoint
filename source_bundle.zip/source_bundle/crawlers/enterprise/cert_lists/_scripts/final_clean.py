# -*- coding: utf-8 -*-
"""Final cleanup: drop leftover name fragments (rows whose cert is invalid and
whose name is clearly a PDF line-break fragment) and report final stats."""
import csv, os, re, sys, collections
sys.stdout.reconfigure(encoding="utf-8")

OUT = os.path.join(os.path.dirname(__file__), "..")
HDR = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
CERT = re.compile(r"(?:GR|GS)\d{12}")
TAIL = ("公司", "研究所", "中心", "院", "厂", "室", "部", "社", "站", "集团", "大学",
        "学校", "基地", "分公司", "工作站", "商行", "经营部", "服务部", "门市部")
REG = ["广东省", "深圳市", "山东省", "青岛市", "北京市", "天津市"]

tot = 0
for reg in REG:
    p = os.path.abspath(os.path.join(OUT, reg + ".csv"))
    with open(p, encoding="utf-8-sig", newline="") as f:
        rr = list(csv.reader(f))
    h, rows = rr[0], rr[1:]
    assert h == HDR, (reg, h)
    keep = []
    dropped = []
    for r in rows:
        if CERT.fullmatch(r[1] or ""):
            keep.append(r)
        else:
            nm = r[0].strip()
            if len(nm) >= 8 and nm.endswith(TAIL):
                keep.append(r)          # genuine row, cert just missing
            else:
                dropped.append(r[0])
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(HDR)
        w.writerows(keep)
    tot += len(keep)
    yr = collections.Counter(r[4] for r in keep)
    print("%-4s rows=%-6d cert=%-6d city=%-6d county=%-6d  %s  %.1fMB" % (
        reg, len(keep), sum(1 for r in keep if CERT.fullmatch(r[1] or "")),
        sum(1 for r in keep if r[2]), sum(1 for r in keep if r[3]),
        dict(sorted(yr.items())), os.path.getsize(p) / 1e6))
    if dropped:
        print("     dropped fragments:", dropped)
print("TOTAL", tot)
