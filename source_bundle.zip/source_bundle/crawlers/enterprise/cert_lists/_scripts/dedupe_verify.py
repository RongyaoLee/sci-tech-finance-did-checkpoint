# -*- coding: utf-8 -*-
"""六省 CSV 去重（按证书编号，保留信息最全的一行）并做完整性校验"""
import collections
import csv
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

HEAD = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
PROVS = ["湖北省", "湖南省", "四川省", "河南省", "河北省", "福建省"]
CERT = re.compile(r"^GR\d{12}$")


def score(r):
    return sum(1 for k in HEAD if (r.get(k) or "").strip())


def main():
    total_all = cert_all = city_all = 0
    for prov in PROVS:
        p = os.path.join(HERE, prov + ".csv")
        rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
        seen = {}
        out = []
        dropped = 0
        for r in rows:
            c = (r.get("证书编号") or "").strip()
            if not c:
                out.append(r)
                continue
            if c in seen:
                dropped += 1
                if score(r) > score(seen[c]):
                    out[seen[c]] = r
                    seen[c] = r
                continue
            seen[c] = r
            out.append(r)
        with open(p, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=HEAD)
            w.writeheader()
            for r in out:
                w.writerow({k: (r.get(k) or "") for k in HEAD})
        yrs = collections.Counter((r.get("认定年度") or "?").strip() for r in out)
        bad = sum(1 for r in out if (r.get("证书编号") or "").strip()
                  and not CERT.match(r["证书编号"].strip()))
        ncert = sum(1 for r in out if (r.get("证书编号") or "").strip())
        ncity = sum(1 for r in out if (r.get("城市") or "").strip())
        nname = sum(1 for r in out if (r.get("企业名称") or "").strip())
        total_all += len(out)
        cert_all += ncert
        city_all += ncity
        print("%-4s 行%6d 有证%6d 有城市%6d 有名称%6d 去重丢弃%4d 格式错%2d 年份 %s"
              % (prov[:2], len(out), ncert, ncity, nname, dropped, bad,
                 ",".join("%s:%d" % (y, n) for y, n in sorted(yrs.items()))))
    print("合计 行%d / 有证%d / 有城市%d" % (total_all, cert_all, city_all))


if __name__ == "__main__":
    main()
