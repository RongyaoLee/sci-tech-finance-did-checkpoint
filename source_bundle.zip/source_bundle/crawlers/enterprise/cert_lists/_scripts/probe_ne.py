# -*- coding: utf-8 -*-
"""Probe: national 备案公告 index for 山西/内蒙古/辽宁/吉林/黑龙江."""
import os, re, sys, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from util import fetch, abs_url, RAW

BASE = "http://www.innocom.gov.cn/gqrdw/c101481/"
SHORT = ["山西", "内蒙古", "辽宁", "吉林", "黑龙江"]

def list_url(page):
    return BASE + ("list_gsgg_l2.shtml" if page == 1 else "list_gsgg_l2_%d.shtml" % page)

items, seen = [], set()
for page in range(1, 58):
    r = fetch(list_url(page))
    if r is None:
        print("FAIL page", page)
        continue
    h = r.text
    n0 = len(items)
    for m in re.finditer(r"<a[^>]+href=[\"']([^\"']+)[\"'][^>]*title=[\"']([^\"']+)[\"']", h):
        href, title = m.group(1), m.group(2)
        if "认定机构" not in title:
            continue
        if not any(x in title for x in SHORT):
            continue
        u = abs_url(BASE, href)
        if u in seen:
            continue
        seen.add(u)
        items.append({"title": title, "url": u})
    print("page", page, "new", len(items) - n0, "total", len(items))
    time.sleep(0.05)

json.dump(items, open(os.path.join(RAW, "ne_national_items.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("ITEMS", len(items))
for it in items[:12]:
    print(it["title"][:80], it["url"])
