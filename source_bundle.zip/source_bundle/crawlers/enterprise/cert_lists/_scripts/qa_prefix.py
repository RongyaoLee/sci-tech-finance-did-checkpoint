# -*- coding: utf-8 -*-
"""Drop truncated prefix-variants of the same company inside one (year,batch)."""
import csv, os, re

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HEADER = ['企业名称', '证书编号', '城市', '区县', '认定年度', '批次', '来源URL']
CERT = re.compile(r'^GR\d{12}$')

for fn in ['内蒙古.csv', '辽宁.csv', '吉林.csv', '黑龙江.csv']:
    p = os.path.join(BASE, fn)
    rows = list(csv.DictReader(open(p, encoding='utf-8-sig', newline='')))
    groups = {}
    for r in rows:
        groups.setdefault((r['认定年度'], r['批次']), []).append(r)
    drop = set()
    xfer = 0
    for k, g in groups.items():
        names = sorted({r['企业名称'] for r in g}, key=len, reverse=True)
        for r in g:
            n = r['企业名称']
            longer = [m for m in names if m != n and m.startswith(n)]
            if not longer:
                continue
            full = min(longer, key=len)  # shortest superset = immediate completion
            tgt = next((x for x in g if x['企业名称'] == full), None)
            if tgt is None:
                continue
            if not tgt['证书编号'] and CERT.match(r['证书编号']):
                tgt['证书编号'] = r['证书编号']
                xfer += 1
            drop.add(id(r))
    out = [r for r in rows if id(r) not in drop]
    with open(p, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=HEADER, extrasaction='ignore')
        w.writeheader()
        w.writerows(out)
    nc = sum(1 for r in out if CERT.match(r['证书编号']))
    print(f'{fn}: {len(rows)} -> {len(out)} rows, cert={nc}, prefix_dropped={len(drop)}, cert_xfer={xfer}')
