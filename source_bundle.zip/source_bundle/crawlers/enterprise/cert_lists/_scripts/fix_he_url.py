# -*- coding: utf-8 -*-
"""把 河北 2020 三批行的来源URL 换成各批复函页精确地址"""
import csv
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import fetch_common as fc  # noqa: E402

HEAD = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]

items = fc.list_items("河北", pages=3, kind="gg")
url = {}
for it in items:
    t = it.get("title") or ""
    if "2020" in t and "复函" in t and "补充" not in t:
        for b in ("第一批", "第二批", "第三批"):
            if b in t:
                url[b] = it.get("url")
print("河北 2020 复函页:", url)

p = os.path.join(HERE, "河北省.csv")
rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
n = 0
for r in rows:
    if r["认定年度"] == "2020" and r["批次"] in url:
        r["来源URL"] = url[r["批次"]]
        n += 1
with open(p, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=HEAD)
    w.writeheader()
    for r in rows:
        w.writerow({k: r.get(k, "") for k in HEAD})
print("更新来源URL 行数", n)
