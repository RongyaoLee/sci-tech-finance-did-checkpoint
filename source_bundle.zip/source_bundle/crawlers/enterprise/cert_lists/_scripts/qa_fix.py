# -*- coding: utf-8 -*-
"""Clean province CSVs:
  1) drop junk rows whose 企业名称 is a sentence fragment from 复函 body text
  2) canonicalise full-width parens + whitespace, backfill cert from twin rows, dedupe
  3) report 公告-vs-公示 name overlap per (year,batch) as a parse-quality signal
Writes back UTF-8 BOM CSV with the fixed header. Never fabricates cert numbers.
"""
import sys, re, csv, os, collections

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HEADER = ['企业名称', '证书编号', '城市', '区县', '认定年度', '批次', '来源URL']
JUNK = re.compile(r'等\d+家|家企业|予以|请你们|示无异议|详见附件')
CERT = re.compile(r'^GR\d{12}$')


def canon(s):
    s = s.replace('（', '(').replace('）', ')')
    s = re.sub(r'\s+', '', s)
    return s


def is_junk(name, cert):
    if cert:
        return False
    n = name.strip()
    if not n or len(n) < 4:
        return True
    if JUNK.search(n):
        return True
    if n in ('有限公司', '股份有限公司', '有限责任公司'):
        return True
    return False


def clean(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    n0 = len(rows)
    rows = [r for r in rows if not is_junk(r['企业名称'], r['证书编号'].strip())]
    dropped = n0 - len(rows)
    for r in rows:
        r['企业名称'] = re.sub(r'\s+', '', r['企业名称'])
        r['证书编号'] = r['证书编号'].strip()

    # backfill cert across paren-style twins inside the same (year, batch)
    certmap = {}
    for r in rows:
        if CERT.match(r['证书编号']):
            certmap.setdefault((r['认定年度'], r['批次'], canon(r['企业名称'])), r['证书编号'])
    filled = 0
    for r in rows:
        if not r['证书编号']:
            c = certmap.get((r['认定年度'], r['批次'], canon(r['企业名称'])))
            if c:
                r['证书编号'] = c
                filled += 1

    # dedupe on (year, batch, canon name), prefer row with cert
    seen, out = {}, []
    for r in rows:
        k = (r['认定年度'], r['批次'], canon(r['企业名称']))
        if k in seen:
            keep = seen[k]
            if not keep['证书编号'] and r['证书编号']:
                out[out.index(keep)] = r
                seen[k] = r
            continue
        seen[k] = r
        out.append(r)
    merged = len(rows) - len(out)

    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=HEADER, extrasaction='ignore')
        w.writeheader()
        for r in out:
            w.writerow({k: r.get(k, '') for k in HEADER})

    nc = sum(1 for r in out if CERT.match(r['证书编号']))
    print(f'{os.path.basename(path)}: {n0} -> {len(out)} rows ({nc} cert)  junk_dropped={dropped} cert_backfilled={filled} merged={merged}')
    return out


def overlap(out, path):
    """for each (year,batch) having both cert rows and blank rows -> name overlap"""
    by = collections.defaultdict(lambda: [set(), set()])
    for r in out:
        yb = (r['认定年度'], r['批次'])
        by[yb][0 if CERT.match(r['证书编号']) else 1].add(canon(r['企业名称']))
    bad = []
    for yb, (hc, hn) in sorted(by.items()):
        if hc and hn:
            ov = len(hc & hn) / len(hc)
            bad.append((yb, len(hc), len(hn), round(ov, 2)))
    return bad


if __name__ == '__main__':
    for f in sys.argv[1:]:
        p = os.path.join(BASE, f)
        out = clean(p)
        ov = overlap(out, f)
        low = [x for x in ov if x[3] < 0.5 and x[1] > 20]
        print('  overlap<0.5 batches:', len(low), low[:6])
