# -*- coding: utf-8 -*-
"""Download + parse all national 备案公告 (公告) for 山西/内蒙古/辽宁/吉林/黑龙江.

Output: _raw/ne_national_rows.json  [{name,cert,year,batch,prov,src,file}]
"""
import os, re, sys, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from util import fetch, download, abs_url, parse_pdf_grid, parse_pdf_rows, read_xlsx_rows, RAW

ITEMS = os.path.join(RAW, "ne_national_items.json")
OUT = os.path.join(RAW, "ne_national_rows.json")
SHORT = {"山西省": "山西", "内蒙古自治区": "内蒙古", "辽宁省": "辽宁",
         "吉林省": "吉林", "黑龙江省": "黑龙江"}


def norm_title(title):
    for full, short in SHORT.items():
        if full in title:
            return short
    return ""


def parse_meta(title):
    y = re.search(r"(20\d{2})", title)
    year = y.group(1) if y else ""
    cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
    batch = ""
    m = re.search(r"第([一二三四五六七八九十]+|\d+)批", title)
    if m:
        b = m.group(1)
        batch = "第%s批" % b if b.isdigit() else "第%d批" % cn.get(b, 1)
    if "补充备案" in title:
        batch = (batch + "补充备案") if batch else "补充备案"
    return year, batch


def art_links(html, base):
    out = []
    for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html, re.S | re.I):
        href = m.group(1).strip()
        text = re.sub(r"<[^>]+>", "", m.group(2)).strip()
        if not re.search(r"\.(pdf|xlsx?|docx?|wps|et)$", href, re.I):
            continue
        out.append((text, abs_url(base, href)))
    if not out:
        for m in re.findall(r'["\']([^"\']*/files/[^"\']+\.(?:pdf|xlsx?|docx?))["\']', html, re.I):
            out.append(("", abs_url(base, m)))
    seen, res = set(), []
    for t, u in out:
        if u in seen:
            continue
        seen.add(u)
        res.append((t, u))
    return res


def safe(s):
    return re.sub(r"[^\w\.\-]", "_", s)[:70]


rows_all = []
done = set()
if os.path.exists(OUT):
    rows_all = json.load(open(OUT, encoding="utf-8"))
    done = {r.get("_item", "") for r in rows_all}
items = json.load(open(ITEMS, encoding="utf-8"))
print("items", len(items))

report = []
for it in items:
    title, url = it["title"], it["url"]
    prov = norm_title(title)
    year, batch = parse_meta(title)
    if not prov:
        continue
    if url in done:
        print("skip done", title[:40])
        continue
    r = fetch(url)
    if r is None:
        report.append([prov, year, batch, title, "detail-fail", 0])
        print("FAIL detail", title[:50])
        continue
    atts = art_links(r.text, url)
    if not atts:
        report.append([prov, year, batch, title, "no-attachment", 0])
        print("   no att:", title[:50])
        continue
    got = 0
    for atitle, aurl in atts:
        ext = os.path.splitext(aurl.split("?")[0])[1].lower()
        name = "%s_%s_%s_%s%s" % (prov, year, batch, safe(title)[:40], ext)
        p = download(aurl, name)
        if not p:
            print("   dl-fail", aurl[:80])
            continue
        try:
            if ext == ".pdf":
                rows = parse_pdf_grid(p)
                if not rows:
                    rows = parse_pdf_rows(p)
            elif ext in (".xlsx", ".xls"):
                rows = []
                for cells in read_xlsx_rows(p):
                    txt = [c for c in cells if c]
                    cert = ""
                    nm = ""
                    for c in txt:
                        m = re.search(r"GR\s?\d{12}", c, re.I)
                        if m:
                            cert = m.group(0).upper().replace(" ", "")
                            break
                    for c in txt:
                        if re.search(r"GR\s?\d{12}", c, re.I):
                            continue
                        if re.search(r"(公司|研究院|研究所|中心|集团|厂|合作社|事务所)$", c) and len(c) >= 4:
                            nm = c
                            break
                    if nm:
                        rows.append({"seq": "", "name": nm, "cert": cert, "city": "", "county": ""})
            else:
                rows = []
        except Exception as e:
            print("   parse-err", os.path.basename(p), e)
            rows = []
        nc = sum(1 for x in rows if x.get("cert"))
        print("   + %-6s %s %s rows=%-5d cert=%-5d %s" % (prov, year, batch, len(rows), nc, os.path.basename(p)[:50]))
        for x in rows:
            x.update(prov=prov, year=year, batch=batch, src=url, file=os.path.basename(p), _item=url)
            rows_all.append(x)
        got += len(rows)
    report.append([prov, year, batch, title, "ok", got])
    json.dump(rows_all, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)

json.dump(rows_all, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)
json.dump(report, open(os.path.join(RAW, "ne_national_report.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("TOTAL rows", len(rows_all), "cert", sum(1 for r in rows_all if r.get("cert")))
by = {}
for r in rows_all:
    by.setdefault(r["prov"], [0, 0])
    by[r["prov"]][0] += 1
    by[r["prov"]][1] += 1 if r.get("cert") else 0
for k, v in sorted(by.items()):
    print("  ", k, v)
