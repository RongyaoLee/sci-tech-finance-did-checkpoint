# -*- coding: utf-8 -*-
"""测试 河南省科技厅 oss 上的 2020 复函 PDF 是否可解析"""
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import pymupdf  # noqa: E402

import fetch_common as fc  # noqa: E402

URL = ("https://oss.henan.gov.cn/typtfile/20201225/"
       "68ab1a8194d14f338d155bcc55d48072.pdf")

p = fc.download(URL, "河南", "hn2020_p1_oss.pdf")
print("file", p, os.path.getsize(p) if p else None)
if p:
    d = pymupdf.open(p)
    t0 = d[0].get_text()
    allt = "".join(d[i].get_text() for i in range(d.page_count))
    print("pages", d.page_count, "page0 chars", len(t0.strip()),
          "GR", allt.count("GR"), "总字符", len(allt))
    print("sample:", repr(allt[:200]))
    rows = fc.extract(p)
    print("rows", len(rows), "cert", sum(1 for r in rows if r["cert"]))
    print(rows[:3])
