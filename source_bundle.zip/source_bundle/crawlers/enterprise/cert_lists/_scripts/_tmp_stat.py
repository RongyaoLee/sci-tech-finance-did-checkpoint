﻿import csv,re,collections
CERT=re.compile(r'^GR\d{12}$')
for fn in ['内蒙古.csv','辽宁.csv','吉林.csv','黑龙江.csv']:
    rows=list(csv.DictReader(open(fn,encoding='utf-8-sig',newline='')))
    tot=collections.Counter(r['认定年度'] for r in rows)
    cer=collections.Counter(r['认定年度'] for r in rows if CERT.match(r['证书编号']))
    intra=collections.Counter((r['认定年度'],r['批次'],r['企业名称']) for r in rows)
    junk=[r['企业名称'] for r in rows if re.search(r'等\d+家|家企业|予以|请你们|示无异议',r['企业名称'])]
    print(fn,'rows',len(rows),'cert',sum(cer.values()),'intra_dup',sum(v-1 for v in intra.values() if v>1),'junk',len(junk))
    print('   ',' '.join(f'{y}:{tot[y]}/{cer[y]}' for y in sorted(tot)))
    yrs=sorted(cer)
    print('    cert years',yrs)
