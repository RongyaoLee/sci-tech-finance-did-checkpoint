# -*- coding: utf-8 -*-
"""从 2020 年「拟认定公示」PDF 取企业名称（含可能的地市列），与解码出的证书编号按序号合并"""
import csv
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import fetch_common as fc  # noqa: E402

from decode2020 import decode_pdf  # noqa: E402

RAW = os.path.join(HERE, "_raw")
OUT = os.path.join(HERE, "_city_fill")

JOBS = [
    # 省, 复函pdf, 公示pdf, 省码, 批次, 复函页URL
    ("河南省", os.path.join(RAW, "河南", "y2020_5257c55d.pdf"),
     os.path.join(RAW, "河南", "关于公示河南省2020年第一批拟认定高新技术企业名单的通知_abc5499991.pdf"),
     "41", "第一批",
     "http://www.innocom.gov.cn/gqrdw/c101462/202012/978a19034f4040f6bb41eb9e26ea4bef.shtml"),
    ("四川省", os.path.join(RAW, "四川", "y2020_66c83260.pdf"),
     os.path.join(RAW, "四川", "关于公示四川省2020年第一批拟认定高新技术企业名单的通知_fdc26b61fc.pdf"),
     "51", "第一批",
     "http://www.innocom.gov.cn/gqrdw/c101470/202012/73a2b84f8c394c9983a5abe79f3b3bd3.shtml"),
]


def peek(path, n=8):
    print("--- peek", os.path.basename(path))
    i = 0
    for cells in fc.rows_from_pdf(path):
        if not cells:
            continue
        i += 1
        print("   ", [c[:26] for c in cells])
        if i >= n:
            break


def rows_of(path):
    for cells in fc.rows_from_pdf(path):
        if cells:
            yield cells


def name_rows(path):
    """公示 PDF -> [(seq:int, name:str, extra:[...])]"""
    out = []
    for cells in rows_of(path):
        if len(cells) < 2:
            continue
        s = cells[0].strip()
        if not s.isdigit():
            continue
        name = cells[1].strip()
        if len(name) < 4 or not re.search(r"[\u4e00-\u9fa5]", name):
            continue
        out.append((int(s), name, [c.strip() for c in cells[2:]]))
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    for prov, gg_pdf, gs_pdf, code, batch, src in JOBS:
        print("=" * 20, prov)
        peek(gs_pdf)
        certs = decode_pdf(gg_pdf, code)
        cert_by_seq = {int(r["seq"]): r["cert"] for r in certs if r["seq"].isdigit()}
        names = name_rows(gs_pdf)
        name_by_seq = {}
        extra3 = 0
        for s, nm, extra in names:
            name_by_seq.setdefault(s, nm)
            if extra:
                extra3 += 1
        common = sorted(set(cert_by_seq) & set(name_by_seq))
        print("  证书 %d / 公示名称 %d / 交集 %d / 公示有第3列 %d"
              % (len(cert_by_seq), len(name_by_seq), len(common), extra3))
        miss = sorted(set(cert_by_seq) - set(name_by_seq))
        print("  证书有名称缺:", len(miss), miss[:10])
        if not src:
            # 从 inn_gg.json 找复函页面URL
            for jf in ("inn_gg.json", "inn_gg_4prov.json"):
                p = os.path.join(RAW, jf)
                if not os.path.exists(p):
                    continue
                for it in json.load(open(p, encoding="utf-8")):
                    t = it.get("title") or it.get("url", "")
                    if it.get("prov") == prov and "2020" in (it.get("title") or "") \
                            and "第一批" in (it.get("title") or "") and "备案" in (it.get("title") or ""):
                        src = it.get("url")
                        print("  来源页:", src, "|", it.get("title")[:40])
                        break
                if src:
                    break
        path = os.path.join(OUT, "%s_2020公布名单.csv" % prov)
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"])
            n = 0
            for s in common:
                w.writerow([name_by_seq[s], cert_by_seq[s], "", "", "2020", batch, src])
                n += 1
        print("  写出 %d 行 -> %s" % (n, path))


if __name__ == "__main__":
    main()
