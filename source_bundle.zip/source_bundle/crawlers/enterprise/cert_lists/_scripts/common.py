# -*- coding: utf-8 -*-
"""共用抓取工具：限速≤2次/秒/站点、UA、30s超时、SSL降级重试"""
import os, re, sys, time, json, random
import requests
from urllib.parse import urljoin, urlparse, urlsplit

import urllib3
urllib3.disable_warnings()

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")

ROOT = r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists"
RAW = os.path.join(ROOT, "_raw")
os.makedirs(RAW, exist_ok=True)

_last = {}          # host -> last request time
MIN_INTERVAL = 0.55  # 保证每站 <= 2 req/s

_sess = requests.Session()
_sess.headers.update({
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Connection": "keep-alive",
})


def _throttle(url):
    h = urlsplit(url).netloc
    now = time.time()
    gap = now - _last.get(h, 0)
    if gap < MIN_INTERVAL:
        time.sleep(MIN_INTERVAL - gap)
    _last[h] = time.time()


def get(url, tries=4, timeout=30, allow_redirects=True, stream=False, headers=None):
    """GET，遇 SSLError/SSL 立即 htpp 降级 + 重试"""
    last_err = None
    cur = url
    for i in range(tries):
        _throttle(cur)
        try:
            h = dict(_sess.headers)
            if headers:
                h.update(headers)
            r = _sess.get(cur, timeout=timeout, verify=False,
                          allow_redirects=allow_redirects, stream=stream, headers=h)
            if r.status_code in (403, 412) and i < tries - 1:
                time.sleep(1.0 + i)
                continue
            return r
        except requests.exceptions.SSLError as e:
            last_err = e
            if cur.startswith("https://"):
                cur = "http://" + cur[8:]
                continue
            time.sleep(0.8)
        except requests.exceptions.RequestException as e:
            last_err = e
            time.sleep(0.8 + i * 0.7)
    raise last_err if last_err else RuntimeError("failed: " + url)


def get_text(url, **kw):
    r = get(url, **kw)
    raw = r.content
    for enc in ("utf-8", "gb18030", "gbk", "big5"):
        try:
            t = raw.decode(enc)
            if t.count("\ufffd") < len(t) * 0.002:
                r.close()
                return t, r
        except Exception:
            pass
    r.close()
    return raw.decode("utf-8", "ignore"), r


def save_raw(name, data: bytes):
    p = os.path.join(RAW, name)
    with open(p, "wb") as f:
        f.write(data)
    return p


def linkify(base, href):
    if not href:
        return ""
    href = href.strip()
    if href.startswith(("javascript:", "#", "mailto:")):
        return ""
    return urljoin(base, href)
