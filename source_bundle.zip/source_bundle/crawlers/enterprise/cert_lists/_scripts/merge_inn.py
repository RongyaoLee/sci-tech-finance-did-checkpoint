# -*- coding: utf-8 -*-
"""把 innocom 备案公告（含证书编号）合并进 6 省 CSV

合并规则（父 agent 要求）：
- 去重键优先用证书编号；无编号时用 (企业名称, 认定年度)
- 已有行缺证书编号 -> 用备案公告补齐；已有行缺批次 -> 补批次
- 城市/区县一律来自附件自带地区列，不从证书编号反推；四川原有「所属市州」保留
"""
import csv
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

HEADER = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
MAP = {"河南": "河南省", "湖北": "湖北省", "湖南": "湖南省", "四川": "四川省",
       "河北": "河北省", "福建": "福建省"}
CN = "一二三四五六七八九十"
JUNK = re.compile(r"予以|请你们|按照|等\d+家|通知|公告|附件|名单|根据")


def cn_batch(b):
    """第1批 -> 第一批；补充备案第2批 -> 补充备案第二批"""
    if not b:
        return ""
    m = re.search(r"(\d+)", b)
    if not m:
        return b
    n = int(m.group(1))
    if n <= 10:
        s = CN[n - 1]
    elif n < 20:
        s = "十" + CN[n - 11]
    else:
        s = str(n)
    return b[:m.start()] + s + b[m.end():]


def load_csv(path):
    with open(path, encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def main():
    data = []
    for fn in ("inn_gg_4prov.json", "inn_gg.json"):
        p = os.path.join(HERE, "_raw", fn)
        if os.path.exists(p):
            data.extend(json.load(open(p, encoding="utf-8")))
    # 同一 (prov, cert, 名称) 去重，避免两个 json 有重叠
    seen = set()
    uniq = []
    for r in data:
        k = (r.get("prov"), r.get("cert"), r.get("name"))
        if k in seen:
            continue
        seen.add(k)
        uniq.append(r)
    data = uniq
    byprov = {}
    for r in data:
        byprov.setdefault(r["prov"], []).append(r)

    for short, full in MAP.items():
        recs = byprov.get(short, [])
        path = os.path.join(HERE, full + ".csv")
        if not os.path.exists(path):
            print("skip (no csv)", full)
            continue
        hdr, rows = load_csv(path)
        cert_idx = {}
        name_year = {}
        for r in rows:
            r += [""] * (7 - len(r))
            if r[1]:
                cert_idx[r[1]] = r
            name_year.setdefault((r[0], r[4]), []).append(r)

        added = filled_cert = filled_batch = 0
        for rec in recs:
            name = (rec.get("name") or "").strip()
            cert = (rec.get("cert") or "").strip()
            if not name or not cert:
                continue
            if JUNK.search(name) or len(name) < 4:
                continue
            year = cert[2:6] if len(cert) == 14 else (rec.get("year") or "")
            batch = cn_batch(rec.get("batch") or "")
            src = rec.get("src") or ""
            if cert and cert in cert_idx:
                cur = cert_idx[cert]
                if not cur[5] and batch:
                    cur[5] = batch
                    filled_batch += 1
                continue
            hit = None
            for cur in name_year.get((name, year), []):
                if not cur[1]:
                    hit = cur
                    break
            if hit is not None:
                hit[1] = cert
                if not hit[5] and batch:
                    hit[5] = batch
                filled_cert += 1
                cert_idx[cert] = hit
                continue
            if (name, year) in name_year and any(x[1] for x in name_year[(name, year)]):
                # 同年度同名且已有别的证书编号 -> 视为补充批次，照常追加
                pass
            new = [name, cert, "", "", year, batch, src]
            rows.append(new)
            if cert:
                cert_idx[cert] = new
            name_year.setdefault((name, year), []).append(new)
            added += 1

        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(HEADER)
            w.writerows(rows)

        ncert = sum(1 for r in rows if r[1])
        ncity = sum(1 for r in rows if r[2])
        years = sorted({r[4] for r in rows if r[4]})
        print(f"{full}: rows={len(rows)} cert={ncert} city={ncity} "
              f"新增={added} 补证书={filled_cert} 补批次={filled_batch} 年份={years}")


if __name__ == "__main__":
    main()
