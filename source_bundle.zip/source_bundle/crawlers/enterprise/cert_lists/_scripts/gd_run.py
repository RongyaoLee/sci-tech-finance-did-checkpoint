﻿# -*- coding: utf-8 -*-
"""Guangdong: fetch notice pages, download 名单 PDFs, parse rows."""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(__file__))
sys.stdout.reconfigure(encoding="utf-8")
from util import fetch, download, links, abs_url, parse_pdf_grid, write_csv, RAW, OUT

PAGES = [
    ("http://gdstc.gd.gov.cn/zwgk_n/tzgg/content/post_4850173.html", "2025"),
    ("http://gdstc.gd.gov.cn/zwgk_n/tzgg/content/post_4663289.html", "2024"),
    ("http://gdstc.gd.gov.cn/zwgk_n/tzgg/content/post_4654751.html", "2024"),
    ("http://gdstc.gd.gov.cn/zwgk_n/tzgg/content/post_4650980.html", "2024"),
    ("http://gdstc.gd.gov.cn/zwgk_n/tzgg/content/post_4362591.html", "2023"),
    ("http://gdstc.gd.gov.cn/zwgk_n/tzgg/content/post_4116543.html", "2022"),
]

rows = []
report = []
for page, year in PAGES:
    r = fetch(page)
    if r is None:
        report.append((page, "PAGE-FAIL", 0, 0))
        continue
    html = r.text
    pdfs = [(t, abs_url(page, h)) for t, h in links(html) if re.search(r"\.pdf$", h, re.I)]
    pdfs = [(t, h) for t, h in pdfs if "名单" in t and "电话" not in t]
    if not pdfs:
        report.append((page, "NO-PDF-ATTACH", 0, 0))
        print("no pdf", page)
        continue
    for text, url in pdfs:
        mb = re.search(r"第([一二三四五六七八九十])批", text)
        batch = ("第" + mb.group(1) + "批") if mb else ""
        my = re.search(r"(20\d\d)\s*年", text)
        y = my.group(1) if my else year
        fn = "gd_%s_%s_%s.pdf" % (y, batch or "all", re.sub(r"\D", "", url)[-8:])
        p = download(url, fn, referer=page)
        if not p:
            report.append((url, "DL-FAIL", 0, 0))
            continue
        pr = parse_pdf_grid(p)
        has_cert = sum(1 for x in pr if x["cert"])
        withcity = sum(1 for x in pr if x["city"])
        for x in pr:
            rows.append({"name": x["name"], "cert": x["cert"], "city": x["city"],
                         "county": x["county"], "year": y, "batch": batch, "src": url})
        report.append((url, "OK", len(pr), has_cert))
        print("ok", text[:40], "rows", len(pr), "city", withcity, "year", y, batch)

path, n = write_csv("广东省", rows)
print("WROTE", path, n, "rows")
json.dump(report, open(os.path.join(RAW, "gd_report.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

