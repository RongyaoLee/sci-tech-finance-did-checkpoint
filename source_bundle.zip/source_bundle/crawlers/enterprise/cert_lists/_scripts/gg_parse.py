# -*- coding: utf-8 -*-
"""Parse innocom 认定备案公告 province-column PDFs (3 columns incl. 证书编号)."""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists")
sys.stdout.reconfigure(encoding="utf-8")
import fetch_common as F

RAW = os.path.join(os.path.dirname(__file__), "..", "_raw")
gg = json.load(open(os.path.join(RAW, "gg_items.json"), encoding="utf-8"))
have = json.load(open(os.path.join(RAW, "innocom_rows.json"), encoding="utf-8"))
done_urls = set(v.get("url", "") for v in have.values() if isinstance(v, dict))
print("existing innocom items", len(have), "urls", len(done_urls))

MIN_YEAR = "2021"
SKIP = re.compile(r"更名|迁移|整体搬迁|名称变更|年报|统计|证书领取|申报|培训|专家|复函")

out = {}
for region, items in gg.items():
    rows = []
    for it in items:
        title = it["title"]
        my = re.search(r"(20\d{2})", title)
        year = my.group(1) if my else ""
        if not year or year < MIN_YEAR or SKIP.search(title):
            continue
        mb = re.search(r"第([一二三四五六七八九十]+|\d+)批", title)
        cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5}
        batch = ""
        if mb:
            b = mb.group(1)
            batch = "第%s批" % (b if b.isdigit() else cn.get(b[0], b))
        if "补充备案" in title:
            batch = "补充备案" + batch
        atts = F.attachments(it["url"])
        if not atts:
            print("  - no attach", region, title[:40])
            continue
        for atitle, aurl in atts:
            p = F.download(aurl, region, title[:70] + "_" + os.path.basename(aurl).split(".")[-1][:6])
            if not p:
                print("  ! dl fail", aurl[:90])
                continue
            try:
                rr = F.extract(p)
            except Exception as e:
                print("  ! parse err", os.path.basename(p), type(e).__name__)
                continue
            ncert = sum(1 for x in rr if x["cert"])
            print("   %-10s %-42s %s/%-10s rows=%-5d cert=%-5d %s" %
                  (region, title[:42], year, batch or "-", len(rr), ncert, os.path.basename(p)[:26]))
            for x in rr:
                rows.append({"name": x["name"], "cert": x["cert"], "year": year,
                             "batch": batch, "src": it["url"]})
    out[region] = rows
    print("==", region, len(rows))

json.dump(out, open(os.path.join(RAW, "gg_rows.json"), "w", encoding="utf-8"), ensure_ascii=False)
print("WROTE gg_rows.json")
