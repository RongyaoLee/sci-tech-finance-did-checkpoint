# -*- coding: utf-8 -*-
"""河南省 拟认定名单公示 解析（无证书编号，有 所属地市/所在地域）"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

TOK = re.compile(r"[\x07\r\n\x0b\x0c]")
USCC = re.compile(r"^[0-9A-Z]{18}$")


def _tokens(text):
    return [t.strip() for t in TOK.split(text)]


def rows_henan(path):
    low = path.lower()
    if low.endswith(".doc"):
        from doc97 import doc_text
        toks = _tokens(doc_text(path))
    elif low.endswith(".pdf"):
        import fitz
        d = fitz.open(path)
        toks = _tokens("\n".join(p.get_text() for p in d))
    elif low.endswith((".xlsx", ".xls")):
        from parse_file import rows_from_xlsx, rows_from_xls
        fn = rows_from_xlsx if low.endswith(".xlsx") else rows_from_xls
        return [(n, "", c) for n, c, c in fn(path)]
    else:
        raise ValueError(path)

    out = []
    i = 0
    n = len(toks)
    while i < n - 4:
        if toks[i].isdigit() and USCC.match(toks[i + 4] or ""):
            city, area, name = toks[i + 1], toks[i + 2], toks[i + 3]
            if name and len(name) >= 4:
                out.append((name, "", city, area))
            i += 5
            continue
        i += 1
    return out


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for p in sys.argv[1:]:
        r = rows_henan(p)
        print(os.path.basename(p), "rows", len(r))
        for x in r[:4]:
            print("  ", x)
