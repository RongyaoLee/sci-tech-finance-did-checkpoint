# -*- coding: utf-8 -*-
"""QA scan for province CSVs: junk names, intra-batch duplicates, near-dup blank-cert rows."""
import sys, re, csv, collections, os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JUNK = re.compile(r'等\d+家|家企业|予以|请你们|示无异议|的公告|的公示|详见附件|名单|^附件')
CERT = re.compile(r'^GR\d{12}$')


def norm(s):
    s = re.sub(r'[（(].*?[)）]', '', s)
    s = re.sub(r'\s+', '', s)
    return s


def load(p):
    with open(p, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def run(p):
    rows = load(p)
    print('=====', os.path.basename(p), 'rows', len(rows))
    junk = [r for r in rows if JUNK.search(r['企业名称'])]
    print(' junk rows', len(junk))
    for r in junk[:12]:
        print('   J:', r['企业名称'][:60], '|', r['证书编号'], r['认定年度'], r['批次'])
    # intra (year,batch) duplicate names
    c = collections.Counter((r['认定年度'], r['批次'], r['企业名称']) for r in rows)
    dups = [(k, v) for k, v in c.items() if v > 1]
    print(' intra-batch dup keys', len(dups), 'extra rows', sum(v - 1 for k, v in dups))
    for k, v in dups[:8]:
        print('   D:', k[0], k[1], k[2][:40], 'x', v)
    # blank-cert rows whose normalized name matches a cert row in same (year,batch)
    have = collections.Counter()
    for r in rows:
        if CERT.match(r['证书编号']):
            have[(r['认定年度'], r['批次'], norm(r['企业名称']))] += 1
    near = [r for r in rows if not CERT.match(r['证书编号']) and have.get((r['认定年度'], r['批次'], norm(r['企业名称'])))]
    print(' blank-cert near-dup of cert row', len(near))
    for r in near[:8]:
        print('   N:', r['认定年度'], r['批次'], r['企业名称'][:50])
    # length / charset sanity
    short = [r['企业名称'] for r in rows if len(r['企业名称']) < 5]
    print(' very short names', len(short), short[:8])
    bad = [r['企业名称'] for r in rows if re.search(r'[A-Za-z]{3,}', r['企业名称'])]
    print(' names with latin run', len(bad), bad[:5])


if __name__ == '__main__':
    for f in sys.argv[1:]:
        run(os.path.join(BASE, f))
