# -*- coding: utf-8 -*-
"""通用栏目列表爬虫：抓取(标题,URL)并落 ndjson"""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from common import get_text, ROOT
import lxml.html

OUT = os.path.join(ROOT, "_raw")


def fetch_items(url):
    txt, r = get_text(url)
    doc = lxml.html.fromstring(txt)
    doc.make_links_absolute(r.url, resolve_base_href=True)
    items = []
    for a in doc.iter("a"):
        t = re.sub(r"\s+", " ", (a.text_content() or "")).strip()
        h = a.get("href") or ""
        if not h or h.startswith(("javascript:", "#")):
            continue
        if len(t) < 8:
            continue
        if re.search(r"\.(s?html?|htm|jhtml|action)(\?|$)", h) or "/info/" in h:
            items.append({"title": t, "url": h})
    # 去重
    seen, out = set(), []
    for it in items:
        if it["url"] in seen:
            continue
        seen.add(it["url"])
        out.append(it)
    return out, txt


def crawl(prov, pages, tag=""):
    allitems = []
    for p in pages:
        try:
            items, txt = fetch_items(p)
        except Exception as e:
            print(f"  [ERR] {p} {type(e).__name__} {str(e)[:80]}")
            continue
        new = 0
        have = {x["url"] for x in allitems}
        for it in items:
            if it["url"] not in have:
                allitems.append(it)
                new += 1
        print(f"  page {p} -> {len(items)} items, +{new}, total {len(allitems)}")
    fn = os.path.join(OUT, f"items_{prov}{tag}.json")
    with open(fn, "w", encoding="utf-8") as f:
        json.dump(allitems, f, ensure_ascii=False, indent=1)
    print(f"  saved {fn} ({len(allitems)})")
    return allitems


def show_matches(prov, pat=r"高新技术企业|高企"):
    fn = os.path.join(OUT, f"items_{prov}.json")
    if not os.path.exists(fn):
        print("no file", fn); return []
    items = json.load(open(fn, encoding="utf-8"))
    hits = [x for x in items if re.search(pat, x["title"])]
    print(f"  {prov}: {len(items)} items, {len(hits)} match")
    for h in hits:
        print(f"    {h['title'][:70]}\n       {h['url']}")
    return hits


if __name__ == "__main__":
    prov = sys.argv[1]
    pages = sys.argv[2:]
    crawl(prov, pages)
    show_matches(prov)
