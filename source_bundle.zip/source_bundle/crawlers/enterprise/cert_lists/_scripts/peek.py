# -*- coding: utf-8 -*-
"""解析名单附件（docx 表格 / xlsx / pdf）"""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from common import ROOT

ATT = os.path.join(ROOT, "_raw", "att")

CERT_RE = re.compile(r"^GR\s*([0-9]{4})\s*([0-9]{2,4})\s*([0-9]{4,8})$")


def docx_tables(path):
    import docx
    d = docx.Document(path)
    out = []
    for t in d.tables:
        rows = []
        for r in t.rows:
            rows.append([c.text.strip() for c in r.cells])
        out.append(rows)
    # 段落文本
    paras = [p.text.strip() for p in d.paragraphs if p.text.strip()]
    return out, paras


def show_docx(path, maxrows=8):
    tabs, paras = docx_tables(path)
    print(f"=== {os.path.basename(path)}  tables={len(tabs)}")
    for i, rows in enumerate(tabs):
        print(f"-- table {i}: {len(rows)} rows x {len(rows[0]) if rows else 0} cols")
        for r in rows[:maxrows]:
            print("   ", " | ".join(r))
    print("-- paragraphs:", paras[:6])


def xlsx_sheets(path):
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    for ws in wb.worksheets:
        print(f"-- sheet {ws.title}: {ws.max_row} x {ws.max_column}")


def show_xlsx(path, maxrows=8):
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    for ws in wb.worksheets:
        print(f"=== {os.path.basename(path)} sheet {ws.title}: {ws.max_row} x {ws.max_column}")
        for r in ws.iter_rows(min_row=1, max_row=maxrows, values_only=True):
            print("   ", " | ".join("" if c is None else str(c) for c in r))


if __name__ == "__main__":
    for p in sys.argv[1:]:
        low = p.lower()
        try:
            if low.endswith(".docx"):
                show_docx(p)
            elif low.endswith((".xlsx", ".xlsm")):
                show_xlsx(p)
            else:
                print("skip", p)
        except Exception as e:
            print("ERR", p, type(e).__name__, e)
