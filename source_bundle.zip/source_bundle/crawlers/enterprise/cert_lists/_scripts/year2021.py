# -*- coding: utf-8 -*-
"""Fetch 2021-year filings: per-province innocom columns + Shandong KJT 2021 PDFs."""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(__file__))
sys.stdout.reconfigure(encoding="utf-8")
from util import fetch, download, links, abs_url, parse_pdf_grid, RAW

COLS = {"广东省": "c101465", "深圳市": "c101466", "山东省": "c101460",
        "青岛市": "c101461", "北京市": "c101443", "天津市": "c101444"}
BASE = "http://www.innocom.gov.cn/gqrdw/%s/"

OUTJSON = os.path.join(RAW, "innocom_rows.json")
done = json.load(open(OUTJSON, encoding="utf-8"))

found = {}
for region, col in COLS.items():
    hits = []
    for page in range(1, 12):
        u = BASE % col + ("list_gsgg_l2.shtml" if page == 1 else "list_gsgg_l2_%d.shtml" % page)
        r = fetch(u)
        if r is None:
            break
        h = r.text
        for m in re.finditer(r"<a[^>]+href=[\"']([^\"']+)[\"'][^>]*title=[\"']([^\"']+)[\"']", h):
            href, title = m.group(1), m.group(2)
            if "认定机构" not in title and "认定的" not in title:
                continue
            if "2021年" not in title:
                continue
            if "更名" in title or "取消" in title or "搬迁" in title:
                continue
            hits.append({"title": title, "url": abs_url(u, href)})
        # stop when this page has no 2021-2022 items left
        if page > 1 and not re.search(r"202[12]年", h):
            break
    # dedupe by batch
    seen = {}
    for it in hits:
        mb = re.search(r"(第[一二三四五六]批)", it["title"])
        bat = mb.group(1) if mb else ("补充备案" if "补充" in it["title"] else "")
        if bat and bat not in seen:
            seen[bat] = it
    found[region] = seen
    print(region, list(seen.keys()), [v["title"][:46] for v in seen.values()])

# parse 2021 innocom PDFs
for region, seen in found.items():
    for bat, it in seen.items():
        if it["url"] in done:
            continue
        r = fetch(it["url"], referer="http://www.innocom.gov.cn/gqrdw/c101481/list_gsgg_l2.shtml")
        if r is None:
            continue
        pdfs = [(t, abs_url(it["url"], h)) for t, h in links(r.text) if re.search(r"\.pdf$", h, re.I)]
        if not pdfs:
            print("no pdf", it["title"][:40])
            continue
        url = pdfs[0][1]
        fn = "inno_%s_2021_%s_%s.pdf" % (region, bat, re.sub(r"\W", "", url)[-10:])
        p = download(url, fn, referer=it["url"])
        rows = parse_pdf_grid(p) if p else []
        codes = {}
        for x in rows:
            if re.fullmatch(r"GR\d{12}", x["cert"]):
                codes[x["cert"][6:10]] = codes.get(x["cert"][6:10], 0) + 1
        done[it["url"]] = {"title": it["title"], "region": region, "year": "2021",
                           "batch": bat, "pdf": os.path.basename(p) if p else "",
                           "url": url, "page": it["url"], "n": len(rows),
                           "n_cert": sum(1 for x in rows if re.fullmatch(r"GR\d{12}", x["cert"])),
                           "codes": codes, "rows": rows}
        print("2021", region, bat, len(rows), list(codes.items())[:3])

# Shandong KJT 2021
KJT = "http://kjt.shandong.gov.cn/art/2022/1/21/art_13360_10294274.html"
r = fetch(KJT)
if r:
    for t, h in links(r.text):
        m = re.search(r"第([一二三])批", t)
        if not m or not re.search(r"\.pdf$", h, re.I):
            continue
        url = abs_url(KJT, h)
        key = "kjt_sd_2021_" + m.group(1)
        if key in done:
            continue
        p = download(url, key + ".pdf", referer=KJT)
        rows = parse_pdf_grid(p) if p else []
        codes = {}
        for x in rows:
            if re.fullmatch(r"GR\d{12}", x["cert"]):
                codes[x["cert"][6:10]] = codes.get(x["cert"][6:10], 0) + 1
        done[key] = {"title": "关于公布山东省2021年高新技术企业认定名单的通知-" + t[:22],
                     "region": "山东省", "year": "2021", "batch": "第" + m.group(1) + "批",
                     "pdf": key + ".pdf", "url": url, "page": KJT,
                     "n": len(rows), "n_cert": len([1 for x in rows if x["cert"]]),
                     "codes": codes, "rows": rows}
        print("KJT 山东 2021", m.group(1), len(rows), list(codes.items())[:3])

json.dump(done, open(OUTJSON, "w", encoding="utf-8"), ensure_ascii=False)
print("TOTAL", len(done))
