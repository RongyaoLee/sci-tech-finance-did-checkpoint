# -*- coding: utf-8 -*-
"""探活：6省科技厅站点 + 国家高新技术企业认定工作网"""
import sys, ssl, time, json
import requests
from requests.adapters import HTTPAdapter

sys.stdout.reconfigure(encoding='utf-8')

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")

TARGETS = [
    ("湖北省科技厅", "https://kjt.hubei.gov.cn/"),
    ("湖北省科技厅-http", "http://kjt.hubei.gov.cn/"),
    ("湖南省科技厅", "https://kjt.hunan.gov.cn/"),
    ("湖南省科技厅-http", "http://kjt.hunan.gov.cn/"),
    ("四川省科技厅", "https://kjt.sc.gov.cn/"),
    ("四川省科技厅-http", "http://kjt.sc.gov.cn/"),
    ("河南省科技厅", "https://kjt.henan.gov.cn/"),
    ("河南省科技厅-http", "http://kjt.henan.gov.cn/"),
    ("河北省科技厅", "https://kjt.hebei.gov.cn/"),
    ("河北省科技厅-http", "http://kjt.hebei.gov.cn/"),
    ("福建省科技厅", "https://kjt.fujian.gov.cn/"),
    ("福建省科技厅-http", "http://kjt.fujian.gov.cn/"),
    ("国家认定工作网", "https://www.innocom.gov.cn/"),
]

sess = requests.Session()
sess.headers.update({"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9"})
sess.trust_env = True

out = []
for name, url in TARGETS:
    t0 = time.time()
    try:
        r = sess.get(url, timeout=30, verify=False, allow_redirects=True)
        body = r.content[:400000]
        enc = r.encoding
        try:
            txt = body.decode('utf-8', 'ignore')
        except Exception:
            txt = ''
        title = ''
        import re
        m = re.search(r'<title[^>]*>(.*?)</title>', txt, re.S | re.I)
        if m:
            title = m.group(1).strip()[:80]
        out.append((name, url, r.status_code, len(r.content), r.url, title, round(time.time()-t0, 1)))
        print(f"[OK ] {name:22s} {r.status_code} len={len(r.content):7d} {round(time.time()-t0,1)}s -> {r.url}  title={title}")
    except Exception as e:
        out.append((name, url, 'ERR', 0, '', repr(e)[:160], round(time.time()-t0, 1)))
        print(f"[ERR] {name:22s} {type(e).__name__}: {str(e)[:120]}")

with open(r"C:\Users\rongy\Documents\Codex\2026-11-07\xie\work\cert_lists\_raw\probe.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("\nDONE")
