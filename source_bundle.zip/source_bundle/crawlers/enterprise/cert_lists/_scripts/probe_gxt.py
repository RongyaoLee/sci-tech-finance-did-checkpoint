# -*- coding: utf-8 -*-
"""Final attempt: probe provincial 工信厅/科技厅 notice columns for a city-bearing 高企 list."""
import re, ssl, sys, time
import requests
from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36')
S = requests.Session()
S.headers.update({'User-Agent': UA, 'Accept-Language': 'zh-CN,zh;q=0.9'})

URLS = [
    ('辽宁工信厅', 'http://jxt.ln.gov.cn/'),
    ('辽宁工信厅-通知', 'http://jxt.ln.gov.cn/tzgg/'),
    ('吉林工信厅', 'http://gxt.jl.gov.cn/'),
    ('黑龙江工信厅', 'http://gxt.hlj.gov.cn/'),
    ('内蒙古工信厅', 'http://gxj.nmg.gov.cn/'),
]


def get(u):
    for attempt in (u, u.replace('https://', 'http://')):
        try:
            r = S.get(attempt, timeout=30, verify=False, allow_redirects=True)
            return r
        except Exception as e:
            last = f'{type(e).__name__}: {e}'[:80]
    print(f'  ! {u} -> {last}')
    return None


for name, u in URLS:
    r = get(u)
    time.sleep(0.5)
    if r is None:
        continue
    txt = r.text
    hits = re.findall(r'<a[^>]+href="([^"]+)"[^>]*>([^<]{4,60}高新技术企业[^<]{0,40})</a>', txt)
    print(f'{name} {u} -> {r.status_code} len={len(txt)} 高企links={len(hits)}')
    for h, t in hits[:5]:
        print('    ', t.strip()[:50])
