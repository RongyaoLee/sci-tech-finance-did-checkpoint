# -*- coding: utf-8 -*-
"""dump 各省通知公告列表页，分析条目结构与分页线索"""
import sys, re, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
from common import get_text, save_raw
import lxml.html

LISTS = [
    ("湖北省", "https://kjt.hubei.gov.cn/kjdt/tzgg/"),
    ("湖南省", "http://kjt.hunan.gov.cn/kjt/xxgk/tzgg/index.html"),
    ("四川省-通知", "https://kjt.sc.gov.cn/kjt/gstz/newschild.shtml"),
    ("四川省-公示", "https://kjt.sc.gov.cn/kjt/notice/newschild.shtml"),
    ("河南省-通知", "https://kjt.henan.gov.cn/tzgg/"),
    ("河南省-高企认定", "https://kjt.henan.gov.cn/gqrd/"),
    ("河北省", "https://kjt.hebei.gov.cn/hebkjt/xwzx15/tzgg35/index.html"),
    ("福建省", "http://kjt.fujian.gov.cn/xxgk/tzgg/"),
]

for tag, url in LISTS:
    print("=" * 78)
    print(tag, url)
    try:
        txt, r = get_text(url)
    except Exception as e:
        print("  FAIL", type(e).__name__, str(e)[:150]); continue
    print("  final:", r.url, "len:", len(txt))
    safe = re.sub(r"[^0-9A-Za-z\u4e00-\u9fa5]+", "_", tag)
    save_raw(f"list_{safe}.html", txt.encode("utf-8"))
    doc = lxml.html.fromstring(txt)
    doc.make_links_absolute(r.url, resolve_base_href=True)
    # 找带 (.html/.htm/.shtml) 且文字较长的链接
    items = []
    for a in doc.iter("a"):
        t = re.sub(r"\s+", " ", (a.text_content() or "")).strip()
        h = a.get("href") or ""
        if len(t) >= 8 and re.search(r"\.(html?|shtml)$", h):
            items.append((t, h))
    print(f"  item-ish links: {len(items)}")
    for t, h in items[:12]:
        print("    *", t[:60], "|", h)
    # 分页线索
    pg = set()
    for m in re.finditer(r"(index[_-]?\d+\.html?|page[=/]?\d+|\?page=\d+|createPageHTML)", txt):
        pg.add(m.group(0))
    print("  pager hints:", sorted(pg)[:12])
    for m in re.finditer(r"共\s*(\d+)\s*页|共\s*(\d+)\s*条|totalPage\s*=\s*(\d+)", txt):
        print("  pager text:", m.group(0))
print("DONE")
