# -*- coding: utf-8 -*-
"""名单解析 + CSV 生成
提取器：
  rows_from_docx(path)  -> [(企业名称, 证书编号, 城市)]  基于表格
  rows_from_xlsx(path)  -> 同上，表头自动识别
  rows_from_doc(path)   -> 基于单元格流解析
  rows_from_pdf(path)   -> 基于字符流解析
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

CERT_RE = re.compile(r"^GR\s*\d{12}$")
CERT_ANY = re.compile(r"GR\s*\d{12}")
CELL_SPLIT = re.compile(r"[\x07\r\n\x0b\x0c]")

HEAD_NAME = ("企业名称", "单位名称", "公司名称", "企业名")
HEAD_CERT = ("证书编号", "证书号", "证书编码")
HEAD_CITY = ("行政区域", "行政区划", "地市", "城市", "所在市", "所属市", "地区")


def _clean(s):
    if s is None:
        return ""
    s = str(s).replace("\u00a0", " ").replace("\u3000", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def norm_cert(s):
    s = _clean(s).upper().replace(" ", "")
    return s if CERT_ANY.fullmatch(s) else ""


def _pairs_from_cells(cells):
    """从单元格/行序列中抽取 (名称, 证书, 城市)"""
    out = []
    for i, c in enumerate(cells):
        c = _clean(c)
        cert = norm_cert(c)
        if cert:
            name = ""
            for j in range(i - 1, max(-1, i - 4), -1):
                cand = _clean(cells[j])
                if cand and not norm_cert(cand) and not cand.isdigit() and len(cand) > 3:
                    name = cand
                    break
            city = ""
            for j in range(i - 3, max(-1, i - 5), -1):
                cand = _clean(cells[j])
                if re.search(r"[市州盟旗县区]$", cand) and len(cand) <= 12:
                    city = cand
                    break
            out.append((name, cert, city))
    return out


def _cells_from_text(text):
    return [t for t in CELL_SPLIT.split(text)]


def rows_from_doc(path):
    from doc97 import doc_text
    return _pairs_from_cells(_cells_from_text(doc_text(path)))


def rows_from_pdf(path):
    import fitz
    d = fitz.open(path)
    txt = "\n".join(p.get_text() for p in d)
    return _pairs_from_cells(_cells_from_text(txt))


def _header_map(rows):
    """在若干行中找表头，返回 (header_row_idx, {字段:列号})"""
    for idx, r in enumerate(rows[:15]):
        cells = [_clean(x) for x in r]
        m = {}
        for ci, c in enumerate(cells):
            if not m.get("name") and any(k in c for k in HEAD_NAME):
                m["name"] = ci
            if not m.get("cert") and any(k in c for k in HEAD_CERT):
                m["cert"] = ci
            if "city" not in m and any(k in c for k in HEAD_CITY):
                m["city"] = ci
        if m.get("name") is not None and m.get("cert") is not None:
            return idx, m
    return None, None


def rows_from_table(table_rows):
    """table_rows: list[list[str]]"""
    hi, hm = _header_map(table_rows)
    out = []
    start = 0 if hi is None else hi + 1
    for r in table_rows[start:]:
        cells = [_clean(x) for x in r]
        if not any(cells):
            continue
        if hi is not None:
            cert = norm_cert(cells[hm["cert"]]) if hm["cert"] < len(cells) else ""
            name = cells[hm["name"]] if hm["name"] < len(cells) else ""
            city = cells[hm["city"]] if hm.get("city") is not None and hm["city"] < len(cells) else ""
            if cert and name:
                out.append((name, cert, city))
            continue
    if out:
        return out
    # 无表头 → 退化到扫描
    flat = [c for r in table_rows for c in r]
    return _pairs_from_cells(flat)


def rows_from_docx(path):
    import docx
    d = docx.Document(path)
    best = []
    for t in d.tables:
        rows = [[c.text for c in r.cells] for r in t.rows]
        got = rows_from_table(rows)
        if len(got) > len(best):
            best = got
    if best:
        return best
    from docx import Document  # noqa
    txt = "\n".join(p.text for p in d.paragraphs)
    return _pairs_from_cells(_cells_from_text(txt))


def rows_from_xlsx(path):
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    best = []
    for ws in wb.worksheets:
        rows = [["" if c is None else str(c) for c in r]
                for r in ws.iter_rows(values_only=True)]
        got = rows_from_table(rows)
        if len(got) > len(best):
            best = got
    return best


def rows_from_xls(path):
    import xlrd
    wb = xlrd.open_workbook(path)
    best = []
    for sh in wb.sheets():
        rows = [[_clean(sh.cell_value(i, j)) for j in range(sh.ncols)]
                for i in range(sh.nrows)]
        got = rows_from_table(rows)
        if len(got) > len(best):
            best = got
    return best


def parse_file(path):
    low = path.lower()
    if low.endswith(".docx"):
        return rows_from_docx(path)
    if low.endswith((".xlsx", ".xlsm")):
        return rows_from_xlsx(path)
    if low.endswith(".xls"):
        return rows_from_xls(path)
    if low.endswith(".doc"):
        return rows_from_doc(path)
    if low.endswith(".pdf"):
        return rows_from_pdf(path)
    raise ValueError("unsupported " + path)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for p in sys.argv[1:]:
        try:
            r = parse_file(p)
        except Exception as e:
            print("ERR", os.path.basename(p), type(e).__name__, e)
            continue
        withcert = [x for x in r if x[1]]
        withcity = [x for x in r if x[2]]
        print(f"{os.path.basename(p)}: rows={len(r)} cert={len(withcert)} city={len(withcity)}")
        for x in r[:5]:
            print("   ", x)
