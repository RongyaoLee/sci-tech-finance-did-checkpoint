# -*- coding: utf-8 -*-
"""查 河北省.csv 里重复的证书编号，定位来源批次"""
import collections
import csv
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

rows = list(csv.DictReader(open(os.path.join(HERE, "河北省.csv"),
                                encoding="utf-8-sig")))
print("总行", len(rows))
cnt = collections.Counter(r["证书编号"].strip() for r in rows if r["证书编号"].strip())
dup = [c for c, n in cnt.items() if n > 1]
print("重复证书", len(dup), dup[:5])
by = collections.Counter()
for r in rows:
    if r["证书编号"].strip() in set(dup):
        by[(r["认定年度"], r["批次"], r["来源URL"][:60])] += 1
for k, v in by.most_common(12):
    print("  ", k, v)
# 年度分布
print("年度分布:", dict(collections.Counter(r["认定年度"] for r in rows)))
