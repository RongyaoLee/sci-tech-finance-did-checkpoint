# -*- coding: utf-8 -*-
"""Normalise 批次 labels ('-' -> ''), ensure header + BOM, then print final stats table."""
import csv, os, re, sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HEADER = ['企业名称', '证书编号', '城市', '区县', '认定年度', '批次', '来源URL']
CERT = re.compile(r'^GR\d{12}$')
FILES = ['内蒙古.csv', '辽宁.csv', '吉林.csv', '黑龙江.csv']

for fn in FILES:
    p = os.path.join(BASE, fn)
    with open(p, encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r['批次'] in ('-', 'None'):
            r['批次'] = ''
        r['认定年度'] = (r['认定年度'] or '').strip()
    with open(p, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=HEADER, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)
    cert = sum(1 for r in rows if CERT.match(r['证书编号']))
    years = sorted({r['认定年度'] for r in rows if r['认定年度']})
    head = open(p, 'rb').read(3) == b'\xef\xbb\xbf'
    print(f'{fn:<10} rows={len(rows):6d} cert={cert:6d} years={years[0]}-{years[-1]} BOM={head} cities={sum(1 for r in rows if r["城市"])}')
