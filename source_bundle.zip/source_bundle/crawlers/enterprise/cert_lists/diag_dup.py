# -*- coding: utf-8 -*-
"""诊断：同名同年但证书号不同的行有多少、长什么样；以及公示/公告重复情况。"""
import csv
import os
import re
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
CERT = re.compile(r'^GR\d{12}$')
PROVS = ['云南', '贵州', '广西', '江西', '海南']

for p in PROVS:
    path = os.path.join(BASE, p + '.csv')
    rows = list(csv.DictReader(open(path, encoding='utf-8-sig')))
    g = defaultdict(list)
    for r in rows:
        g[(r['企业名称'], r['认定年度'])].append(r)
    multi = {k: v for k, v in g.items() if len({r['证书编号'] for r in v if r['证书编号']}) > 1}
    dup_no_cert = sum(1 for k, v in g.items() if len(v) > 1 and not any(r['证书编号'] for r in v))
    print(f'== {p}: rows {len(rows)}, groups {len(g)}, multi-cert groups {len(multi)}, '
          f'dup-no-cert groups {dup_no_cert}, mergeable gain {len(rows)-len(g)}')
    for k, v in list(multi.items())[:5]:
        print('   ', k, [(r['证书编号'], r['批次'], r['来源URL'][-20:]) for r in v])
