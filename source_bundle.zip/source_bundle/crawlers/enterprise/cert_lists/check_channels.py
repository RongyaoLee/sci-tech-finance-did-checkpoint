# -*- coding: utf-8 -*-
"""Sanity-check: each province's 公告 channel returns that province's announcements."""
import re, sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fetch_common as F

PROVS = ["陕西", "甘肃", "青海", "宁夏", "新疆",
         "山西", "内蒙古", "辽宁", "吉林", "黑龙江",
         "云南", "贵州", "广西", "江西", "海南",
         "重庆", "西藏"]

for p in PROVS:
    gg = F.PROV_GG.get(p, "-")
    gs = F.PROV_CH.get(p, "-")
    a = F.list_items(p, 1, "gg")
    b = F.list_items(p, 1, "gs")
    t1 = a[0]["title"][:38] if a else "!! NONE"
    t2 = b[0]["title"][:38] if b else "!! NONE"
    flag = "" if (a and p[:2] in a[0]["title"]) else "  <-- CHECK"
    print(f"{p:4s} gg={gg} n={len(a):2d} | {t1}{flag}")
    print(f"     gs={gs} n={len(b):2d} | {t2}")
