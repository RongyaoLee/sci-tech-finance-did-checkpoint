# -*- coding: utf-8 -*-
import re
from urllib.parse import quote

import requests
import urllib3

urllib3.disable_warnings()
H = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36'),
    'Accept-Language': 'zh-CN,zh;q=0.9',
}
r = requests.get('http://www.bing.com/search?q=' + quote('江西 高新技术企业 认定名单') + '&setlang=zh-CN',
                 headers=H, timeout=25, verify=False)
t = r.text
print(len(t), r.status_code)
i = t.find('b_algo')
print('idx', i)
print(t[i - 150:i + 1200] if i > 0 else t[:600])
