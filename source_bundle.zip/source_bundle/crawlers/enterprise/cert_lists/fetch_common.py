# -*- coding: utf-8 -*-
"""Generic innocom.gov.cn crawler: province 高新技术企业 公示 lists -> CSV rows.

Usage:
  python fetch_common.py <province> [max_pages]
  python fetch_common.py all
"""
import csv, io, os, re, sys, time, json, urllib.parse

import requests
from bs4 import BeautifulSoup
import pymupdf
import openpyxl

BASE = "http://www.innocom.gov.cn"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
H = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9",
     "Accept": "text/html,application/xhtml+xml,*/*;q=0.8"}

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "_raw")
os.makedirs(RAW, exist_ok=True)

# 公示 栏目 (列表里只有序号+企业名称，附件无证书编号)
PROV_CH = {
    "天津": "c101408", "河北": "c101409", "山西": "c101410", "内蒙古": "c101411",
    "辽宁": "c101412", "吉林": "c101414", "黑龙江": "c101415", "安徽": "c101420",
    "福建": "c101421", "江西": "c101423", "河南": "c101426", "湖北": "c101427",
    "湖南": "c101428", "广西": "c101431", "海南": "c101432", "重庆": "c101433",
    "四川": "c101434", "贵州": "c101435", "云南": "c101436", "西藏": "c101437",
    "陕西": "c101438", "甘肃": "c101439", "青海": "c101440", "宁夏": "c101441",
    "新疆": "c101442",
}

# 认定备案公告 栏目 —— 附件 PDF 带「证书编号」列，价值最高
PROV_GG = {
    "北京": "c101443", "天津": "c101444", "河北": "c101445", "山西": "c101446",
    "内蒙古": "c101447", "辽宁": "c101448", "大连": "c101449", "吉林": "c101450",
    "黑龙江": "c101451", "上海": "c101452", "江苏": "c101453", "浙江": "c101454",
    "宁波": "c101455", "安徽": "c101456", "福建": "c101457", "厦门": "c101458",
    "江西": "c101459", "山东": "c101460", "青岛": "c101461", "河南": "c101462",
    "湖北": "c101463", "湖南": "c101464", "广东": "c101465", "深圳": "c101466",
    "广西": "c101467", "海南": "c101468", "重庆": "c101469", "四川": "c101470",
    "贵州": "c101471", "云南": "c101472", "西藏": "c101473", "陕西": "c101474",
    "甘肃": "c101475", "青海": "c101476", "宁夏": "c101477", "新疆": "c101478",
}
ORDER = ["四川", "重庆", "河南", "湖北", "湖南", "河北", "山西", "陕西", "云南",
         "贵州", "广西", "江西", "安徽", "福建", "辽宁", "吉林", "黑龙江",
         "内蒙古", "甘肃", "宁夏", "青海", "新疆", "西藏", "海南", "天津"]

CERT_RE = re.compile(r"GR\s?\d{12}", re.I)
SEQ_RE = re.compile(r"^\d{1,5}$")
BAD_NAME = re.compile(r"^(序号|企业名称|证书编号|单位名称|所在|地区|地市|城市|批次|年度|备注|合计)$")


def sess():
    s = requests.Session()
    s.headers.update(H)
    s.verify = False
    return s


_S = None


def get(url, binary=False, tries=3):
    global _S
    if _S is None:
        _S = sess()
    urls = [url]
    if url.startswith("https://"):
        urls.append(url.replace("https://", "http://"))
    last = None
    for u in urls:
        for attempt in range(tries):
            try:
                r = _S.get(u, timeout=30)
                if r.status_code == 200:
                    time.sleep(0.5)
                    if binary:
                        return r.content, r.url
                    r.encoding = r.apparent_encoding or "utf-8"
                    return r.text, r.url
                last = "HTTP %s" % r.status_code
            except Exception as e:
                last = type(e).__name__ + ":" + str(e)[:80]
            time.sleep(1.0)
    print("   ! FAIL", url, last)
    return (None, None) if binary else (None, None)


# ---------------- parsing helpers ----------------

def clean(s):
    if s is None:
        return ""
    s = str(s).replace("\u3000", " ").replace("\xa0", " ")
    s = re.sub(r"\s+", "", s)
    return s.strip()


def norm_cert(s):
    m = CERT_RE.search(s or "")
    if not m:
        return ""
    return m.group(0).upper().replace(" ", "")


NAME_TAIL = re.compile(r"(公司|研究院|研究所|研究中心|中心|集团|厂|合作社|事务所|学院|大学|医院|工作室|商行|经营部)$")


def looks_like_name(s):
    if not s or len(s) < 4 or len(s) > 60:
        return False
    if BAD_NAME.match(s):
        return False
    if NOT_NAME_CHARS.search(s):
        return False
    if re.fullmatch(r"[\d\.\-—、,，()（）]+", s):
        return False
    return bool(NAME_TAIL.search(s)) or ("公司" in s)


NOT_NAME_CHARS = re.compile(r"[A-Za-z]{3,}|GR\d|附件|名单|通知|公示|根据|现将|详见")


def rows_from_pdf(path, ytol=3.0):
    """Yield list-of-cell-strings per visual row, using word y-clustering."""
    doc = pymupdf.open(path)
    for page in doc:
        words = page.get_text("words")
        if not words:
            continue
        words.sort(key=lambda w: (round(w[1], 1), w[0]))
        rows = []
        cur = []
        cy = None
        for w in words:
            y = w[1]
            if cy is None or abs(y - cy) <= ytol:
                cur.append(w)
                cy = y if cy is None else cy
            else:
                rows.append(cur)
                cur = [w]
                cy = y
        if cur:
            rows.append(cur)
        for r in rows:
            r.sort(key=lambda x: x[0])
            cells = []
            prev_x1 = None
            buf = []
            for w in r:
                if prev_x1 is not None and w[0] - prev_x1 > 6:
                    cells.append("".join(buf))
                    buf = []
                buf.append(w[4])
                prev_x1 = w[2]
            if buf:
                cells.append("".join(buf))
            yield [clean(c) for c in cells if clean(c)]


def rows_from_xlsx(path):
    if path.lower().endswith(".xls"):
        try:
            import xlrd
            bk = xlrd.open_workbook(path)
            for sh in bk.sheets():
                for rx in range(sh.nrows):
                    vals = sh.row_values(rx)
                    cells = [clean(v) for v in vals if v is not None and clean(v) != ""]
                    if cells:
                        yield cells
            return
        except Exception:
            return
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            cells = [clean(c) for c in row if c is not None and clean(c) != ""]
            if cells:
                yield cells


def rows_from_doc_text(text):
    for line in text.splitlines():
        line = clean(line)
        if line:
            yield [line]


def _flat_cells(path):
    """Return one flat list of cell strings from a Word .doc (cells lose row grouping)."""
    try:
        import doc_text
    except ImportError:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "doc_text", os.path.join(os.path.dirname(os.path.abspath(__file__)), "doc_text.py"))
        doc_text = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(doc_text)
    rows = doc_text.doc_rows(path)
    return [clean(c) for r in rows for c in r if clean(c)]


def _is_cert_cell(s):
    s = (s or "").strip().upper().replace(" ", "")
    return bool(re.fullmatch(r"GR\d{12}", s))


def _name_cell(s):
    return looks_like_name(clean(s))


def _region_cell(s):
    s = clean(s)
    return bool(s) and len(s) <= 12 and bool(re.fullmatch(r"[\u4e00-\u9fa5]{2,12}(市|区|县|州|盟|地区|旗)", s))


def rows_from_doc(path):
    """Reconstruct (name, [city], cert) triples from a .doc by anchoring on cert cells.

    Word stores table cells sequentially, so the cell immediately before a
    certificate number is that enterprise's name; a region cell may sit between.
    """
    flat = _flat_cells(path)
    out = []
    certs = 0
    for i, c in enumerate(flat):
        if not _is_cert_cell(c):
            continue
        certs += 1
        prev = flat[i - 1] if i >= 1 else ""
        prev2 = flat[i - 2] if i >= 2 else ""
        prev3 = flat[i - 3] if i >= 3 else ""
        if _name_cell(prev):
            out.append([prev, c])
        elif _name_cell(prev2):
            row = [prev2, c]
            if _region_cell(prev):
                row.append(prev)
            out.append(row)
        elif _name_cell(prev3):
            out.append([prev3, prev, c])
    if out:
        return out
    # no certs (e.g. a pre-approval 公示 doc): recover (index, name) pairs
    for j, c in enumerate(flat):
        if _name_cell(c) and j >= 1 and re.fullmatch(r"\d{1,5}", flat[j - 1].strip()):
            out.append([c])
    return out


def rows_from_docx(path):
    """Parse a .docx table structure directly (w:tbl / w:tr / w:tc)."""
    import zipfile
    from lxml import etree
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml")
    root = etree.fromstring(xml)
    out = []
    for tbl in root.iter(W + "tbl"):
        for tr in tbl.findall(W + "tr"):
            cells = []
            for tc in tr.findall(W + "tc"):
                txt = "".join(t.text or "" for t in tc.iter(W + "t"))
                txt = clean(txt)
                if txt:
                    cells.append(txt)
            if cells:
                out.append(cells)
    if out:
        return out
    txts = [clean("".join(t.text or "" for t in p.iter(W + "t"))) for p in root.iter(W + "p")]
    return [[t] for t in txts if t]


# ---------------- attachment handling ----------------

def list_items(prov, pages=3, kind="gs"):
    ch = PROV_CH.get(prov) if kind == "gs" else PROV_GG.get(prov)
    if not ch:
        return []
    items = []
    for p in range(1, pages + 1):
        suffix = "" if p == 1 else "_%d" % p
        url = f"{BASE}/gqrdw/{ch}/list_gsgg_l3{suffix}.shtml"
        html, _ = get(url)
        if not html:
            continue
        soup = BeautifulSoup(html, "lxml")
        n = 0
        for a in soup.find_all("a", href=True):
            t = a.get_text(strip=True)
            h = a["href"]
            if not re.search(r"/gqrdw/", h) or not t:
                continue
            if "高新技术企业" not in t:
                continue
            if re.search(r"更名|复审|迁移|整体搬迁|名称变更|年报|统计|证书|领取|申报|培训|专家", t):
                continue
            if not re.search(r"认定|备案", t):
                continue
            full = h if h.startswith("http") else BASE + (h if h.startswith("/") else "/" + h)
            items.append({"prov": prov, "title": t, "url": full, "kind": kind})
            n += 1
        if n == 0:
            break
    seen, out = set(), []
    for it in items:
        if it["url"] in seen:
            continue
        seen.add(it["url"])
        out.append(it)
    return out


def parse_meta(title):
    year = ""
    m = re.search(r"(20\d{2})", title)
    if m:
        year = m.group(1)
    batch = ""
    m = re.search(r"第([一二三四五六七八九十]+|\d+)批", title)
    if m:
        cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6,
              "七": 7, "八": 8, "九": 9, "十": 10}
        b = m.group(1)
        if b.isdigit():
            batch = "第%s批" % b
        else:
            if b == "十":
                num = 10
            elif b.startswith("十"):
                num = 10 + cn.get(b[1:], 0)
            elif b.endswith("十"):
                num = cn.get(b[0], 1) * 10
            else:
                num = cn.get(b[0], 1)
            batch = "第%d批" % num
    if "补充备案" in title:
        batch = ("补充备案" + batch) if batch else "补充备案"
    return year, batch


def attachments(detail_url):
    html, _ = get(detail_url)
    if not html:
        return []
    soup = BeautifulSoup(html, "lxml")
    out = []
    for a in soup.find_all("a", href=True):
        h = a["href"]
        if re.search(r"\.(pdf|xlsx?|docx?|wps|et)\b", h, re.I) or "/files/" in h:
            if not re.search(r"\.(pdf|xlsx?|docx?|wps|et)$", h, re.I):
                continue
            full = urllib.parse.urljoin(detail_url, h)
            out.append((a.get_text(strip=True), full))
    if not out:
        for m in re.findall(r'["\']([^"\']*/files/[^"\']+)["\']', html):
            if re.search(r"\.(pdf|xlsx?|docx?|wps|et)$", m, re.I):
                out.append(("", urllib.parse.urljoin(detail_url, m)))
    seen, res = set(), []
    for t, u in out:
        if u in seen:
            continue
        seen.add(u)
        res.append((t, u))
    return res


def download(url, prov, tag):
    ext = os.path.splitext(url.split("?")[0])[1].lower()
    if ext not in (".pdf", ".xlsx", ".xls", ".doc", ".docx"):
        return None
    d = os.path.join(RAW, prov)
    os.makedirs(d, exist_ok=True)
    fn = re.sub(r"[^\w\.\-]", "_", tag)[:80] + ext
    p = os.path.join(d, fn)
    if os.path.exists(p) and os.path.getsize(p) > 500:
        return p
    content, _ = get(url, binary=True)
    if not content or len(content) < 200:
        return None
    open(p, "wb").write(content)
    return p


# ---------------- extraction ----------------

def extract(path):
    """Return list of dicts: name, cert, city, county."""
    low = path.lower()
    if low.endswith(".pdf"):
        it = rows_from_pdf(path)
    elif low.endswith((".xlsx", ".xls")):
        it = rows_from_xlsx(path)
    elif low.endswith(".docx"):
        try:
            it = rows_from_docx(path)
        except Exception:
            return []
    elif low.endswith(".doc"):
        try:
            it = rows_from_doc(path)
        except Exception:
            return []
    else:
        return []
    out = []
    for cells in it:
        cert = ""
        name = ""
        city = ""
        county = ""
        for c in cells:
            nc = norm_cert(c)
            if nc and not cert:
                cert = nc
                continue
        for c in cells:
            if norm_cert(c) or _name_cell(c):
                continue
            if _region_cell(c) and not city and not county:
                if re.search(r"(区|县|旗)$", c.strip()):
                    county = c.strip()
                elif not city:
                    city = c.strip()
                continue
        if cert:
            for c in cells:
                if norm_cert(c):
                    continue
                if looks_like_name(c):
                    name = c
                    break
        if not name:
            for c in cells:
                if looks_like_name(c) and not norm_cert(c):
                    name = c
                    break
        if name:
            out.append({"name": name, "cert": cert, "city": city, "county": county})
    return out


def harvest(prov, pages=3, verbose=True, kinds=("gg", "gs")):
    allrows = []
    for kind in kinds:
        items = list_items(prov, pages, kind)
        if verbose:
            print(f"[{prov}/{kind}] list items: {len(items)}")
        for it in items:
            year, batch = parse_meta(it["title"])
            if year and year < "2016":
                continue
            atts = attachments(it["url"])
            if not atts:
                if verbose:
                    print("   - no attachment:", it["title"][:50])
                continue
            for atitle, aurl in atts:
                p = download(aurl, prov, it["title"][:60] + "_" + os.path.basename(aurl)[:10])
                if not p:
                    continue
                try:
                    rows = extract(p)
                except Exception as e:
                    if verbose:
                        print("   ! parse err", os.path.basename(p), e)
                    continue
                if verbose:
                    ncert = sum(1 for r in rows if r["cert"])
                    print(f"   [{kind}] {it['title'][:40]:40s} {year}/{batch or '-':8s} "
                          f"rows={len(rows):5d} cert={ncert:5d}")
                if len(rows) == 0:
                    continue
                for r in rows:
                    r.update(prov=prov, year=year, batch=batch, src=it["url"])
                    allrows.append(r)
    return allrows


def write_csv(prov, rows):
    """Merge rows by (name, year, batch); prefer rows that carry a cert."""
    out = os.path.join(HERE, prov + ".csv")
    merged = {}
    for r in rows:
        if not r.get("name"):
            continue
        if prov in ("重庆", "重庆直辖市") and not r.get("city"):
            r["city"] = "重庆市"
        # 补充备案 rows are separate batch; keep them
        key = (r["name"], r.get("year", ""), r.get("batch", ""))
        cur = merged.get(key)
        if cur is None:
            merged[key] = dict(r)
            continue
        for f in ("cert", "city", "county"):
            if not cur.get(f) and r.get(f):
                cur[f] = r[f]
        if len(r.get("src", "")) > 0 and not cur.get("src"):
            cur["src"] = r["src"]
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"])
        for r in merged.values():
            w.writerow([r["name"], r.get("cert", ""), r.get("city", ""),
                        r.get("county", ""), r.get("year", ""), r.get("batch", ""),
                        r.get("src", "")])
    return out, len(merged)


if __name__ == "__main__":
    args = sys.argv[1:]
    provs = ORDER if (not args or args[0] == "all") else [args[0]]
    pages = int(args[1]) if len(args) > 1 else 3
    for p in provs:
        rows = harvest(p, pages)
        f, n = write_csv(p, rows)
        ncert = sum(1 for r in rows if r.get("cert"))
        print(f"== {p}: {n} rows, {ncert} with cert -> {f}")
