# -*- coding: utf-8 -*-
"""Final polish for the province CSVs.

1) drop rows whose 企业名称 is a PDF line-break fragment ("责任公司", "有限公司" ...)
2) drop rows whose 企业名称 is shorter than 4 chars and carries no cert
3) certificate-number collision: keep the first occurrence in file order, blank the rest
   (source PDFs occasionally repeat a number for two rows, e.g. 新疆 2017 第1批 序号1/2)
4) dedupe on (企业名称, 认定年度, normalised 批次), keeping the copy that has a cert

Writes back UTF-8-BOM with the fixed header. Never invents a name or a number.
usage: python polish.py [省 ...]      (no args = all 17)
"""
import csv
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
HEAD = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
PROVS = ["重庆", "陕西", "甘肃", "青海", "宁夏", "新疆", "山西", "内蒙古", "辽宁",
         "吉林", "黑龙江", "云南", "贵州", "广西", "江西", "海南", "西藏"]
CERT = re.compile(r"^GR\d{12}$")
FRAG = re.compile(r"^(责任公司|有限公司|股份有限公司|有限责任公司|公司|有限|集团|"
                  r"研究所|研究院|中心|服务中心|技术有限公司|科技有限公司)$")
CN = {"一": "1", "二": "2", "三": "3", "四": "4", "五": "5",
      "六": "6", "七": "7", "八": "8", "九": "9", "十": "10"}


def norm_batch(b):
    b = (b or "").strip()
    b = re.sub(r"^第?\s*([一二三四五六七八九十\d]+)\s*批$", lambda m: "第" + CN.get(m.group(1), m.group(1)) + "批", b)
    return b


def run(prov):
    path = os.path.join(HERE, prov + ".csv")
    rows = list(csv.DictReader(io.open(path, encoding="utf-8-sig")))
    n0 = len(rows)
    for r in rows:
        r["企业名称"] = re.sub(r"\s+", "", r.get("企业名称") or "")
        r["证书编号"] = (r.get("证书编号") or "").strip()
        if r["证书编号"] and not CERT.match(r["证书编号"]):
            r["证书编号"] = ""

    frag = [r for r in rows if FRAG.match(r["企业名称"])]
    rows = [r for r in rows if not FRAG.match(r["企业名称"])]
    short = [r for r in rows if len(r["企业名称"]) < 4 and not r["证书编号"]]
    rows = [r for r in rows if not (len(r["企业名称"]) < 4 and not r["证书编号"])]

    seen = {}
    dupcert = 0
    for r in rows:
        c = r["证书编号"]
        if not c:
            continue
        if c in seen:
            r["证书编号"] = ""
            dupcert += 1
        else:
            seen[c] = r

    out, index, merged = [], {}, 0
    for r in rows:
        k = (r["企业名称"], r["认定年度"], norm_batch(r["批次"]))
        cur = index.get(k)
        if cur is None:
            index[k] = r
            out.append(r)
            continue
        merged += 1
        for f in ("证书编号", "城市", "区县", "来源URL"):
            if not cur.get(f) and r.get(f):
                cur[f] = r[f]

    out.sort(key=lambda r: (r["认定年度"], norm_batch(r["批次"]), r["企业名称"]))
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=HEAD, extrasaction="ignore")
        w.writeheader()
        for r in out:
            w.writerow({k: r.get(k, "") for k in HEAD})
    nc = sum(1 for r in out if CERT.match(r["证书编号"]))
    print(f"{prov:5s} {n0:7d} -> {len(out):7d} rows  cert={nc:6d}  "
          f"frag={len(frag)} short={len(short)} dupcert={dupcert} merged={merged}")


if __name__ == "__main__":
    args = [a for a in sys.argv[1:]] or PROVS
    for p in args:
        run(p)
