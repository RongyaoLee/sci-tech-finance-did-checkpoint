# -*- coding: utf-8 -*-
"""Bing（http）搜索 + bs4 解析结果。用法: python bsearch.py "查询1" "查询2" """
import re
import sys
from urllib.parse import quote

import requests
import urllib3
from bs4 import BeautifulSoup

urllib3.disable_warnings()
H = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36'),
    'Accept-Language': 'zh-CN,zh;q=0.9',
}


def bing(q, n=15):
    url = 'http://www.bing.com/search?q=' + quote(q) + '&count=30&setlang=zh-CN'
    r = requests.get(url, headers=H, timeout=25, verify=False)
    soup = BeautifulSoup(r.text, 'lxml')
    print('###', q, '| status', r.status_code)
    seen = set()
    cnt = 0
    for li in soup.select('li.b_algo'):
        a = li.find('a', href=True)
        if not a:
            continue
        u = a['href']
        if u in seen or not u.startswith('http'):
            continue
        seen.add(u)
        title = re.sub(r'\s+', ' ', a.get_text(' ', strip=True))[:80]
        print('   -', title)
        print('     ', u[:140])
        cnt += 1
        if cnt >= n:
            break
    if not cnt:
        print('   (no results parsed)')


if __name__ == '__main__':
    for q in sys.argv[1:]:
        try:
            bing(q)
        except Exception as e:  # noqa: BLE001
            print('###', q, 'ERR', type(e).__name__, str(e)[:80])
