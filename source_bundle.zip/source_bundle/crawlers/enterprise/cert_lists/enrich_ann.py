# -*- coding: utf-8 -*-
"""Harvest 证书编号 from innocom 认定备案公告 (column c101481) for selected provinces.

The 备案公告 (announcement, not 公示) attachments carry 序号/证书编号/企业名称.
Reuses fetch_common helpers (get / attachments / download / rows_from_pdf / clean).
Writes _raw/<prov>_cert_rows.json
"""
import json
import os
import re
import sys

import fetch_common as fc

COL = "c101481"
BASE = fc.BASE
MAXPAGES = int(os.environ.get("MAXPAGES", "60"))
PROVS = sys.argv[1:] or ["重庆", "西藏"]
KEYS = {"重庆": ["重庆市"], "西藏": ["西藏自治区", "西藏"]}


def collect_items(provs):
    items = []
    page = 1
    while page <= MAXPAGES:
        suffix = "" if page == 1 else "_%d" % page
        url = "%s/gqrdw/%s/list_gsgg_l2%s.shtml" % (BASE, COL, suffix)
        html, _ = fc.get(url)
        if not html:
            break
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, "lxml")
        n = 0
        for li in soup.find_all("li"):
            a = li.find("a", href=True)
            if not a:
                continue
            t = a.get_text(strip=True)
            h = a["href"]
            if not t or not re.search(r"/gqrdw/", h):
                continue
            n += 1
            for p in provs:
                if any(k in t for k in KEYS[p]):
                    full = h if h.startswith("http") else BASE + (h if h.startswith("/") else "/" + h)
                    items.append({"prov": p, "title": t, "url": full})
        print("  list page %d: %d links" % (page, n))
        if n == 0:
            break
        page += 1
    return items


def year_batch(title):
    y = ""
    m = re.search(r"(20\d{2})", title)
    if m:
        y = m.group(1)
    b = ""
    m = re.search(r"第([一二三四五六七八九十\d]+)批", title)
    if m:
        cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6,
              "七": 7, "八": 8, "九": 9, "十": 10}
        s = m.group(1)
        if s.isdigit():
            b = "第%s批" % s
        elif s == "十":
            b = "第10批"
        elif s.startswith("十"):
            b = "第%d批" % (10 + cn.get(s[1:], 0))
        elif s.endswith("十"):
            b = "第%d批" % (cn.get(s[0], 1) * 10)
        else:
            b = "第%d批" % cn.get(s[0], 1)
    if "补充" in title:
        b = (b + "补充") if b else "补充"
    return y, b


NAME_OK = re.compile(r"(公司|研究院|研究所|研究中心|中心|集团|厂|合作社|事务所|学院|大学|医院|工作室|商行|经营部)")


def parse_file(path):
    """Return [(name, cert)] rows; name+cert from the same visual row preferred."""
    low = path.lower()
    if low.endswith(".pdf"):
        it = fc.rows_from_pdf(path)
    elif low.endswith((".xlsx", ".xls")):
        it = fc.rows_from_xlsx(path)
    else:
        return []
    out = []
    pending = None
    for cells in it:
        certs = [fc.norm_cert(c) for c in cells]
        certs = [c for c in certs if c]
        name = ""
        for c in cells:
            if fc.norm_cert(c):
                continue
            if fc.looks_like_name(c):
                name = c
                break
        if not name:
            # fallback: tolerant name tail match (official lists are noisy)
            for c in cells:
                if fc.norm_cert(c):
                    continue
                if 4 <= len(c) <= 60 and NAME_OK.search(c) and not re.search(r"[A-Za-z]{3,}", c):
                    name = c
                    break
        if name:
            out.append([name, certs[0] if certs else ""])
            pending = name
        elif certs and pending:
            out.append([pending, certs[0]])
            pending = None
    # collapse exact duplicates, keep first non-empty cert
    merged = {}
    order = []
    for n, c in out:
        if n not in merged:
            merged[n] = c
            order.append(n)
        elif not merged[n] and c:
            merged[n] = c
    return [[n, merged[n]] for n in order]


def main():
    items = collect_items(PROVS)
    print("matched items:", len(items))
    allrows = {}
    for p in PROVS:
        allrows[p] = []
    for it in items:
        y, b = year_batch(it["title"])
        atts = fc.attachments(it["url"])
        if not atts:
            print("  - no attachment:", it["title"][:50])
            continue
        for atitle, aurl in atts:
            tag = (it["title"][:50] + "_" + os.path.basename(aurl)[:8])
            path = fc.download(aurl, it["prov"], tag)
            if not path:
                continue
            try:
                rows = parse_file(path)
            except Exception as e:
                print("  ! parse", os.path.basename(path), e)
                continue
            nc = sum(1 for r in rows if r[1])
            print("  + [%s] %-46s %s/%s rows=%4d cert=%4d" % (it["prov"], it["title"][:46], y, b, len(rows), nc))
            for n, c in rows:
                allrows[it["prov"]].append({"name": n, "cert": c, "year": y, "batch": b, "src": it["url"]})
    outdir = os.path.join(fc.RAW)
    for p, rows in allrows.items():
        f = os.path.join(outdir, "%s_cert_rows.json" % p)
        with open(f, "w", encoding="utf-8") as fh:
            json.dump(rows, fh, ensure_ascii=False, indent=1)
        print("== %s: %d rows, %d cert -> %s" % (p, len(rows), sum(1 for r in rows if r["cert"]), f))


if __name__ == "__main__":
    main()
