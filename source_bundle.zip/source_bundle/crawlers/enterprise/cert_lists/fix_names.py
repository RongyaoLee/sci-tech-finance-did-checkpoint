# -*- coding: utf-8 -*-
"""Repair truncated names (PDF line-wrap artifacts) by rescanning _raw for the same cert.

Usage: python fix_names.py 新疆
Only replaces a name when a strictly better (longer, complete-looking) name for the
SAME cert is found in another attachment. Never invents anything.
"""
import csv, glob, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fetch_common as fc

HEAD = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
FRAG = re.compile(r"^(责任公司|有限公司|股份公司|公司|有限|集团)$")
GOOD = re.compile(r"(公司|中心|研究院|研究所|大学|学院|厂|集团|合作社|工作室)$")


def score(n):
    if not n or FRAG.match(n):
        return -1
    return len(n) + (100 if GOOD.search(n) else 0)


def run(prov):
    path = os.path.join(HERE, prov + ".csv")
    rows = list(csv.DictReader(io.open(path, encoding="utf-8-sig")))
    bad = [r for r in rows if score(r["企业名称"]) < 0 or len(r["企业名称"]) < 5]
    if not bad:
        print(prov, "no fragment names")
        return
    targets = {r["证书编号"]: r["企业名称"] for r in bad if r["证书编号"]}
    print("fragments:", len(bad), targets)

    best = {}
    for f in glob.glob(os.path.join(HERE, "_raw", prov, "*")):
        if os.path.splitext(f)[1].lower() not in (".pdf", ".doc", ".docx", ".xlsx", ".xls"):
            continue
        try:
            for r in fc.extract(f):
                c = (r.get("cert") or "").strip().upper()
                if c in targets and score(r["name"]) > score(best.get(c, "")):
                    best[c] = r["name"]
        except Exception:
            pass

    n = 0
    for r in rows:
        if r["证书编号"] in best:
            new = re.sub(r"\s+", "", best[r["证书编号"]])
            if score(new) > score(r["企业名称"]):
                print("   %s: %r -> %r" % (r["证书编号"], r["企业名称"], new))
                r["企业名称"] = new
                n += 1
    rest = [r for r in rows if score(r["企业名称"]) < 0 or len(r["企业名称"]) < 5]
    rows = [r for r in rows if r not in rest]
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=HEAD)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in HEAD})
    print("== %s repaired=%d dropped=%d -> %d rows" % (prov, n, len(rest), len(rows)))


if __name__ == "__main__":
    for p in sys.argv[1:]:
        run(p)
