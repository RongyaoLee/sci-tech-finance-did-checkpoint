# -*- coding: utf-8 -*-
"""Crawl innocom 认定备案公告 (per-province columns) -> rows with 证书编号.

Outputs _raw/ba_rows_<prov>.json: [{name, cert, year, batch, src, title}]
"""
import sys, os, re, json, csv
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fetch_common as F

COLS = {"云南": "c101472", "贵州": "c101471", "广西": "c101467",
        "江西": "c101459", "海南": "c101468"}

CERT_RE = re.compile(r"GR\s*\d{12}", re.I)
SEQ_RE = re.compile(r"^\d{1,5}$")
NOTNAME = re.compile(r"^(序号|企业名称|证书编号|单位名称|所属地区|地区|合计|备注)$")


def parse_year_batch(title):
    y = ""
    m = re.search(r"(20\d{2})", title)
    if m:
        y = m.group(1)
    b = ""
    m = re.search(r"第([一二三四五六七八九十]+|\d+)(?:批|批补充|批)", title)
    if not m:
        m = re.search(r"第([一二三四五六七八九十]+|\d+)批", title)
    if m:
        cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6,
              "七": 7, "八": 8, "九": 9, "十": 10}
        s = m.group(1)
        if s.isdigit():
            n = int(s)
        else:
            if s == "十":
                n = 10
            elif s.startswith("十"):
                n = 10 + cn.get(s[1:], 0)
            elif s.endswith("十"):
                n = cn.get(s[0], 1) * 10
            else:
                n = cn.get(s[0], 1)
        b = "第%d批" % n
    elif "补充备案" in title:
        b = "补充备案"
    return y, b


def rows_of(path):
    low = path.lower()
    if low.endswith(".pdf"):
        return list(F.rows_from_pdf(path))
    if low.endswith((".xlsx", ".xls")):
        try:
            return list(F.rows_from_xlsx(path))
        except Exception:
            return []
    return []


def extract_cert_rows(rows):
    """Row-oriented: cert cell present -> name = longest non-cert text cell."""
    out = []
    for cells in rows:
        cert = ""
        for c in cells:
            m = CERT_RE.search(c)
            if m:
                cert = m.group(0).upper().replace(" ", "")
                break
        if not cert:
            continue
        name = ""
        best = 0
        for c in cells:
            if CERT_RE.search(c):
                continue
            if NOTNAME.match(c):
                continue
            if SEQ_RE.match(c):
                continue
            if len(c) >= 4 and len(c) > best and re.search(r"[\u4e00-\u9fa5]", c):
                # skip header-ish words
                if re.search(r"(公司|厂|中心|研究院|研究所|集团|合作社|事务所|学院|大学|医院|工作室|商行|经营部|基地|站)$", c) or "公司" in c:
                    name = c
                    best = len(c)
        if not name:
            # fallback: longest chinese cell
            for c in cells:
                if CERT_RE.search(c) or NOTNAME.match(c) or SEQ_RE.match(c):
                    continue
                if re.search(r"[\u4e00-\u9fa5]{4,}", c) and len(c) > best:
                    name = c
                    best = len(c)
        if name:
            out.append({"name": F.clean(name), "cert": cert})
    return out


def collect(prov, col, maxp=6):
    items = []
    for p in range(1, maxp + 1):
        sfx = "" if p == 1 else "_%d" % p
        html, _ = F.get("%s/gqrdw/%s/list_gsgg_l3%s.shtml" % (F.BASE, col, sfx))
        if not html:
            break
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, "lxml")
        n = 0
        for a in soup.find_all("a", href=True):
            h, t = a["href"], a.get_text(strip=True)
            if "/gqrdw/" not in h or not t:
                continue
            if "高新技术企业" not in t:
                continue
            if re.search(r"更名|迁移|搬迁|名称变更|年报|统计|证书", t):
                continue
            if "备案" not in t:
                continue
            full = h if h.startswith("http") else F.BASE + (h if h.startswith("/") else "/" + h)
            items.append({"title": t, "url": full})
            n += 1
        print("   list p%d links=%d" % (p, n))
        if n == 0:
            break
    seen, uniq = set(), []
    for it in items:
        if it["url"] in seen:
            continue
        seen.add(it["url"])
        uniq.append(it)
    # keep 公告 (not 公示) first, but keep both as fallback
    print("[%s] %s items=%d" % (prov, col, len(uniq)))
    res = []
    for it in uniq:
        y, b = parse_year_batch(it["title"])
        atts = F.attachments(it["url"])
        if not atts:
            print("    - no att:", it["title"][:50])
            continue
        got = 0
        for at, au in atts:
            p = F.download(au, prov + "_ba", it["title"][:50] + "_" + os.path.basename(au)[:8])
            if not p:
                continue
            try:
                rows = rows_of(p)
            except Exception as e:
                print("    ! parse", os.path.basename(p), e)
                continue
            recs = extract_cert_rows(rows)
            if not recs:
                print("    ~ 0 cert rows:", it["title"][:45], os.path.basename(p), "rows=%d" % len(rows))
                continue
            for r in recs:
                r.update(year=y, batch=b, src=it["url"], title=it["title"])
            res.extend(recs)
            got += len(recs)
        print("   + %-46s %s/%s cert=%d" % (it["title"][:46], y, b, got))
    return res


if __name__ == "__main__":
    provs = sys.argv[1:] or list(COLS)
    for prov in provs:
        rows = collect(prov, COLS[prov])
        out = os.path.join(F.HERE, "_raw", "ba_rows_%s.json" % prov)
        json.dump(rows, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        ncert = len({r["cert"] for r in rows})
        print("== %s: %d rows, %d unique certs -> %s" % (prov, len(rows), ncert, out))
