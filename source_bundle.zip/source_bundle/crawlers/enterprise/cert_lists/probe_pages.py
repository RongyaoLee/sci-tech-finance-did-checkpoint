# -*- coding: utf-8 -*-
"""查看 innocom 列表页分页结构，找是否还有更多页（江西 c101459 缺 2017/2018 复函）。"""
import re
import sys

import requests
import urllib3

urllib3.disable_warnings()
H = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                    '(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36')}
col = sys.argv[1] if len(sys.argv) > 1 else 'c101459'
url = f'http://www.innocom.gov.cn/gqrdw/{col}/list_gsgg_l3.shtml'
r = requests.get(url, headers=H, timeout=30, verify=False)
r.encoding = r.apparent_encoding or 'utf-8'
t = r.text
print(url, r.status_code, len(t))
# 分页信息
for pat in (r'createPageHTML\([^)]*\)', r'共\s*\d+\s*[条页]', r'pageCount\s*=\s*\d+',
            r'list_gsgg_l3_(\d+)\.shtml'):
    print(pat, '->', sorted(set(re.findall(pat, t)))[:8])
# 标题行
for m in re.finditer(r'<a[^>]*href="([^"]*list_gsgg_l3[^"]*)"[^>]*>([^<]{6,80})</a>', t):
    print('  ', m.group(1)[:60], '|', m.group(2).strip()[:50])
