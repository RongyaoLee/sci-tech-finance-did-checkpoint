# -*- coding: utf-8 -*-
"""Harvest 证书编号 from per-province 认定备案公告 columns (c101469 重庆 / c101473 西藏)."""
import json
import os
import re
import sys

from bs4 import BeautifulSoup

import fetch_common as fc

COLS = {"重庆": "c101469", "西藏": "c101473"}


def year_batch(title):
    y = ""
    m = re.search(r"(20\d{2})", title)
    if m:
        y = m.group(1)
    b = ""
    cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7,
          "八": 8, "九": 9, "十": 10}
    m = re.search(r"第([一二三四五六七八九十\d、]+)批", title)
    if m:
        s = m.group(1)
        if s.isdigit():
            b = "第%s批" % s
        elif s == "十":
            b = "第10批"
        elif s.startswith("十"):
            b = "第%d批" % (10 + cn.get(s[1:], 0))
        elif s.endswith("十"):
            b = "第%d批" % (cn.get(s[0], 1) * 10)
        else:
            b = "第%d批" % cn.get(s[0], 1)
    if "补充" in title:
        b = (b + "补充") if b else "补充"
    return y, b


NAME_OK = re.compile(r"(公司|研究院|研究所|研究中心|中心|集团|厂|合作社|事务所|学院|大学|医院|工作室|商行|经营部)")


def parse_file(path):
    low = path.lower()
    if low.endswith(".pdf"):
        it = fc.rows_from_pdf(path)
    elif low.endswith((".xlsx", ".xls")):
        it = fc.rows_from_xlsx(path)
    else:
        return []
    out, pending = [], None
    for cells in it:
        certs = [c for c in (fc.norm_cert(x) for x in cells) if c]
        name = ""
        for c in cells:
            if fc.norm_cert(c):
                continue
            if fc.looks_like_name(c):
                name = c
                break
        if not name:
            for c in cells:
                if fc.norm_cert(c):
                    continue
                if 4 <= len(c) <= 60 and NAME_OK.search(c) and not re.search(r"[A-Za-z]{3,}", c):
                    name = c
                    break
        if name:
            out.append([name, certs[0] if certs else ""])
            pending = name
        elif certs and pending:
            out.append([pending, certs[0]])
            pending = None
    merged, order = {}, []
    for n, c in out:
        if n not in merged:
            merged[n] = c
            order.append(n)
        elif not merged[n] and c:
            merged[n] = c
    return [[n, merged[n]] for n in order]


def main():
    provs = sys.argv[1:] or list(COLS)
    pages = int(os.environ.get("MAXPAGES", "6"))
    for prov in provs:
        col = COLS[prov]
        items = []
        for p in range(1, pages + 1):
            suffix = "" if p == 1 else "_%d" % p
            url = "%s/gqrdw/%s/list_gsgg_l3%s.shtml" % (fc.BASE, col, suffix)
            html, _ = fc.get(url)
            if not html:
                print("  ! page fail", url)
                continue
            soup = BeautifulSoup(html, "lxml")
            n = 0
            for a in soup.find_all("a", href=True):
                t = a.get_text(strip=True)
                h = a["href"]
                if not re.search(r"/gqrdw/c10\d+/20\d{4}/", h) or not t:
                    continue
                if not re.search(r"备案", t):
                    continue
                full = h if h.startswith("http") else fc.BASE + (h if h.startswith("/") else "/" + h)
                items.append({"title": t, "url": full})
                n += 1
            print("  [%s] page %d links=%d" % (prov, p, n))
            if n == 0:
                break
        seen, uniq = set(), []
        for it in items:
            if it["url"] in seen:
                continue
            seen.add(it["url"])
            uniq.append(it)
        print("== [%s] items=%d" % (prov, len(uniq)))

        rows_out = []
        for it in uniq:
            y, b = year_batch(it["title"])
            atts = fc.attachments(it["url"])
            if not atts:
                print("   - no attachment:", it["title"][:50])
                continue
            for atitle, aurl in atts:
                tag = it["title"][:50] + "_" + os.path.basename(aurl)[:8]
                path = fc.download(aurl, prov, tag)
                if not path:
                    continue
                try:
                    rows = parse_file(path)
                except Exception as e:
                    print("   ! parse", os.path.basename(path), e)
                    continue
                nc = sum(1 for r in rows if r[1])
                print("   + %-48s %s/%s rows=%4d cert=%4d  %s" % (
                    it["title"][:48], y, b, len(rows), nc, os.path.basename(path)[:40]))
                for n_, c_ in rows:
                    rows_out.append({"name": n_, "cert": c_, "year": y, "batch": b, "src": it["url"]})
        f = os.path.join(fc.RAW, "%s_cert_rows_prov.json" % prov)
        with open(f, "w", encoding="utf-8") as fh:
            json.dump(rows_out, fh, ensure_ascii=False, indent=1)
        print("== [%s] total=%d cert=%d -> %s" % (
            prov, len(rows_out), sum(1 for r in rows_out if r["cert"]), f))


if __name__ == "__main__":
    main()
