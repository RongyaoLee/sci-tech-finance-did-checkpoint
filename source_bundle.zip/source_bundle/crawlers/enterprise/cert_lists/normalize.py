# -*- coding: utf-8 -*-
"""规范化 + 去重合并 5 省 CSV。

规则：
1. 丢弃解析残片：同一来源 URL 内，某企业名是另一企业名的真后缀且长度差 <=4 字
   （PDF 单元格换行导致的断行碎片）。
2. 按 (企业名称, 认定年度) 合并：优先保留有证书编号的行；两侧都有编号但不同 -> 视为
   同名不同企业，各自保留。
3. 证书编号只保留 ^GR\\d{12}$，其余清空（不推算、不补齐）。
4. 输出 UTF-8 BOM、固定表头、按年度倒序 / 批次 / 企业名称排序。
"""
import csv
import os
import re
import sys
from collections import defaultdict

HEADER = ['企业名称', '证书编号', '城市', '区县', '认定年度', '批次', '来源URL']
CERT_RE = re.compile(r'^GR\d{12}$')
CJK_RE = re.compile(r'[\u4e00-\u9fff]')
BATCH_ORDER = {'第1批': 1, '第2批': 2, '第3批': 3, '第4批': 4}


def batch_rank(b):
    if not b:
        return 9
    if b.startswith('补充备案'):
        tail = re.search(r'第(\d)批', b)
        return 50 + (int(tail.group(1)) if tail else 0)
    m = BATCH_ORDER.get(b)
    if m:
        return m
    m = re.search(r'第(\d)批', b)
    return int(m.group(1)) if m else 8


SENTENCE_RE = re.compile(
    r'等\d+家|予以高新技术企业|请你们|无异议|附件|合计|小计|序号|企业名称|证书编号|'
    r'高新技术企业(备案|认定)|名单的通知')


def sane_name(n):
    if not n:
        return False
    n = n.strip()
    if len(n) < 4 or len(n) > 60:
        return False
    if not CJK_RE.search(n):
        return False
    if SENTENCE_RE.search(n):
        return False
    # PDF 单元格换行导致的断名：括号未闭合
    if n.count('（') != n.count('）') or n.count('(') != n.count(')'):
        return False
    if re.fullmatch(r'[\d\W_]+', n):
        return False
    return True


def drop_fragments(rows):
    """同一来源 URL 内，若 A 是 B 的后缀且 B 更长、A 与 B 在同一文档，
    且 A 不是以常见企业后缀开头，则丢弃 A。"""
    by_src = defaultdict(list)
    for r in rows:
        by_src[r['来源URL']].append(r)
    drop = set()
    for src, group in by_src.items():
        names = sorted({r['企业名称'] for r in group}, key=len, reverse=True)
        for i, short in enumerate(names):
            if short in drop:
                continue
            for long in names:
                if long == short or len(long) <= len(short):
                    continue
                if len(long) - len(short) > 4:
                    continue
                if long.endswith(short):
                    drop.add(short)
                    break
    return [r for r in rows if r['企业名称'] not in drop], drop


def merge(rows):
    """(name, year) 聚合，优先带证书的行。"""
    buckets = defaultdict(list)
    for r in rows:
        buckets[(r['企业名称'], r['认定年度'])].append(r)

    out = []
    for (name, year), group in buckets.items():
        cert_rows = [r for r in group if r['证书编号']]
        distinct = {r['证书编号'] for r in cert_rows}
        if len(distinct) > 1:
            # 同名不同证书号 -> 分别是不同企业，逐行保留
            out.extend(cert_rows)
            continue
        if cert_rows:
            base = dict(cert_rows[0])
        else:
            base = dict(group[0])
        # 补城市/区县/批次（来自其它行）
        for r in group:
            for k in ('城市', '区县'):
                if not base.get(k) and r.get(k):
                    base[k] = r[k]
            if not base.get('批次') and r.get('批次'):
                base['批次'] = r['批次']
        out.append(base)
    return out


def process(prov, base_dir):
    path = os.path.join(base_dir, prov + '.csv')
    if not os.path.exists(path):
        print('!! missing', path)
        return None
    rows = list(csv.DictReader(open(path, encoding='utf-8-sig')))
    raw = len(rows)
    clean = []
    for r in rows:
        name = (r.get('企业名称') or '').replace('\u3000', ' ').strip()
        name = re.sub(r'\s+', '', name)
        if not sane_name(name):
            continue
        cert = (r.get('证书编号') or '').strip().upper()
        cert = cert if CERT_RE.match(cert) else ''
        clean.append({
            '企业名称': name,
            '证书编号': cert,
            '城市': (r.get('城市') or '').strip(),
            '区县': (r.get('区县') or '').strip(),
            '认定年度': (r.get('认定年度') or '').strip(),
            '批次': (r.get('批次') or '').strip(),
            '来源URL': (r.get('来源URL') or '').strip(),
        })
    no_frag, frags = drop_fragments(clean)
    merged = merge(no_frag)
    merged.sort(key=lambda r: (-int(r['认定年度'] or 0), batch_rank(r['批次']), r['企业名称']))

    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=HEADER)
        w.writeheader()
        w.writerows(merged)

    certs = sum(1 for r in merged if r['证书编号'])
    years = sorted({r['认定年度'] for r in merged if r['认定年度']})
    print(f'{prov}: raw {raw} -> dropped_name {raw-len(clean)} frag {len(frags)} '
          f'-> final {len(merged)}, cert {certs}, years {years[0] if years else "-"}-{years[-1] if years else "-"}')
    if frags:
        print('   frags sample:', sorted(frags)[:6])
    return merged


if __name__ == '__main__':
    base = os.path.dirname(os.path.abspath(__file__))
    provs = sys.argv[1:] or ['云南', '贵州', '广西', '江西', '海南']
    tagged = []
    for p in provs:
        got = process(p, base)
        if got:
            tagged.extend([(p, r) for r in got])
    if len(provs) > 1 and tagged:
        out = os.path.join(base, '五省汇总.csv')
        with open(out, 'w', encoding='utf-8-sig', newline='') as f:
            w = csv.DictWriter(f, fieldnames=['地区'] + HEADER)
            w.writeheader()
            for p, r in tagged:
                row = dict(r)
                row['地区'] = p
                w.writerow({k: row.get(k, '') for k in (['地区'] + HEADER)})
        certs = sum(1 for _, r in tagged if r['证书编号'])
        print(f'五省汇总.csv: {len(tagged)} rows, {certs} cert -> {out}')
