# -*- coding: utf-8 -*-
"""Map province -> 公告 channel id by scanning channel nav / probing."""
import re, sys, requests
from bs4 import BeautifulSoup

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
s = requests.Session()
s.headers.update({"User-Agent": UA})


def fetch(u):
    for uu in [u] + ([u.replace("https://", "http://")] if u.startswith("https") else []):
        try:
            r = s.get(uu, timeout=30)
            r.encoding = r.apparent_encoding
            if r.status_code == 200:
                return r.text
        except Exception as e:
            pass
    return ""


def t(fn):
    return fn()


t1 = fetch("http://www.innocom.gov.cn/gqrdw/c101469/list_gsgg_l3.shtml")
print("channels in c101469:", sorted(set(re.findall(r"/gqrdw/(c10\d{4})/", t1))))
soup = BeautifulSoup(t1, "lxml")
for a in soup.find_all("a", href=True):
    if "list_gsgg" in a["href"]:
        print("NAV:", a.get_text(strip=True)[:30], "|", a["href"])

# probe channel range for 公告
print("\n--- probe 101443..101480 titles")
for cid in range(101443, 101481):
    u = f"http://www.innocom.gov.cn/gqrdw/c{cid}/list_gsgg_l3.shtml"
    h = fetch(u)
    if not h:
        print(cid, "DEAD")
        continue
    so = BeautifulSoup(h, "lxml")
    first = ""
    for a in so.find_all("a", href=True):
        if "/gqrdw/" in a["href"] and len(a.get_text(strip=True)) > 5:
            first = a.get_text(strip=True)
            break
    print(cid, "|", first[:60])
