# -*- coding: utf-8 -*-
import sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fetch_common as F
from bs4 import BeautifulSoup

COLS = {"云南": "c101472", "贵州": "c101471", "广西": "c101467",
        "江西": "c101459", "海南": "c101468"}

res = {}
for prov, col in COLS.items():
    items = []
    for p in (1, 2, 3):
        sfx = "" if p == 1 else "_%d" % p
        html, _ = F.get("%s/gqrdw/%s/list_gsgg_l3%s.shtml" % (F.BASE, col, sfx))
        if not html:
            print(prov, "page", p, "NO HTML")
            continue
        soup = BeautifulSoup(html, "lxml")
        n = 0
        for a in soup.find_all("a", href=True):
            h, t = a["href"], a.get_text(strip=True)
            if "/gqrdw/" not in h or not t:
                continue
            full = h if h.startswith("http") else F.BASE + (h if h.startswith("/") else "/" + h)
            items.append({"title": t, "url": full})
            n += 1
        print(prov, "page", p, "links", n)
        if n == 0:
            break
    seen = set()
    uniq = []
    for it in items:
        if it["url"] in seen:
            continue
        seen.add(it["url"])
        uniq.append(it)
    res[prov] = uniq
    print("== %s %s: %d items" % (prov, col, len(uniq)))
    for it in uniq[:8]:
        print("    -", it["title"][:75])

json.dump(res, open(os.path.join(F.HERE, "_raw", "ba_items.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
