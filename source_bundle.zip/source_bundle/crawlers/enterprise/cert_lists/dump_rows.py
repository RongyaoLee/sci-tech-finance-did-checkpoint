# -*- coding: utf-8 -*-
"""Dump parsed rows for one attachment to inspect column layout."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fetch_common as F

path = sys.argv[1]
n = int(sys.argv[2]) if len(sys.argv) > 2 else 15
for i, cells in enumerate(F.rows_from_pdf(path)):
    if i > n:
        break
    print(i, "|", " || ".join(cells))
