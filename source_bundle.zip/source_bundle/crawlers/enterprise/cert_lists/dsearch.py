# -*- coding: utf-8 -*-
"""DuckDuckGo html 搜索（Bing 结果被地域化污染时备用）。"""
import re
import sys
from urllib.parse import quote, unquote

import requests
import urllib3
from bs4 import BeautifulSoup

urllib3.disable_warnings()
H = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                    '(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36'),
     'Accept-Language': 'zh-CN,zh;q=0.9'}


def ddg(q, n=12):
    url = 'http://html.duckduckgo.com/html/?q=' + quote(q)
    r = requests.post(url, headers=H, timeout=25, verify=False, data={'q': q})
    soup = BeautifulSoup(r.text, 'lxml')
    print('###', q, '|', r.status_code)
    cnt = 0
    for a in soup.select('a.result__a'):
        href = a.get('href', '')
        m = re.search(r'uddg=([^&]+)', href)
        real = unquote(m.group(1)) if m else href
        print('   -', a.get_text(' ', strip=True)[:70])
        print('     ', real[:130])
        cnt += 1
        if cnt >= n:
            break
    if not cnt:
        print('   (no results)')


if __name__ == '__main__':
    for q in sys.argv[1:]:
        try:
            ddg(q)
        except Exception as e:  # noqa: BLE001
            print('###', q, 'ERR', type(e).__name__, str(e)[:70])
