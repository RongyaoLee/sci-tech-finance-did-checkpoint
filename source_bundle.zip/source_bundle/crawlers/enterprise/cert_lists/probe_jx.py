# -*- coding: utf-8 -*-
"""探测江西省科技厅站点可用性 + 站内搜索（补 2017-2020 批次证书编号）。"""
import re
import sys

import requests
import urllib3

urllib3.disable_warnings()
H = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                    '(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36'),
     'Accept-Language': 'zh-CN,zh;q=0.9'}

hosts = ['http://kjt.jiangxi.gov.cn/', 'http://www.jxstc.gov.cn/',
         'http://kjt.jiangxi.gov.cn/col/col14582/index.html']
for u in hosts:
    try:
        r = requests.get(u, headers=H, timeout=20, verify=False)
        r.encoding = r.apparent_encoding or 'utf-8'
        print(u, '->', r.status_code, len(r.text), '|', re.sub(r'\s+', ' ', r.text)[:120])
    except Exception as e:  # noqa: BLE001
        print(u, 'ERR', type(e).__name__, str(e)[:70])
