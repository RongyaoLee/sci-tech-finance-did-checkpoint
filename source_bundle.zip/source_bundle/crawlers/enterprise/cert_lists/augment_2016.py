# -*- coding: utf-8 -*-
"""Append 2016 备案复函 (.doc) rows into <prov>.csv — only-add, dedupe by cert or (name,year).

Usage: python augment_2016.py 甘肃 宁夏 新疆 青海
"""
import csv, glob, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fetch_common as fc

HEAD = ["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"]
CERT = re.compile(r"^GR\d{12}$")


def batch_of(fn):
    if "第二批" in fn:
        return "第2批"
    if "第一批" in fn:
        return "第1批"
    return ""


def run(prov, years=("2016",)):
    path = os.path.join(HERE, prov + ".csv")
    rows = list(csv.DictReader(io.open(path, encoding="utf-8-sig")))
    # drop rows this script may have added in a previous (buggy) pass
    rows = [r for r in rows if r.get("来源URL", "").find("innocom.gov.cn/gqrdw/c") < 0]
    have_cert = {r["证书编号"] for r in rows if r["证书编号"]}
    have_ny = {(re.sub(r"\s+", "", r["企业名称"]), r["认定年度"]) for r in rows if r["企业名称"]}

    col = fc.PROV_GG.get(prov, "")
    src = "http://www.innocom.gov.cn/gqrdw/c%s/list_gsgg_l3.shtml" % col
    added = 0
    for yr in years:
        for f in sorted(glob.glob(os.path.join(HERE, "_raw", prov, "*%s*复函*.doc" % yr))):
            rs = fc.extract(f)
            if not rs:
                print("   0 rows:", os.path.basename(f)[:60])
                continue
            b = batch_of(os.path.basename(f))
            n_new = 0
            for r in rs:
                name = re.sub(r"\s+", "", r["name"] or "")
                cert = (r.get("cert") or "").strip().upper()
                if not name or not CERT.match(cert or ""):
                    continue
                y = cert[2:6]
                if cert in have_cert or (name, y) in have_ny:
                    continue
                rows.append({"企业名称": name, "证书编号": cert,
                             "城市": r.get("city", ""), "区县": r.get("county", ""),
                             "认定年度": y, "批次": b, "来源URL": src})
                have_cert.add(cert)
                have_ny.add((name, y))
                n_new += 1
            added += n_new
            print("   +%3d/%3d  %s" % (n_new, len(rs), os.path.basename(f)[:58]))

    rows.sort(key=lambda r: (r["认定年度"], r["批次"], r["证书编号"]))
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=HEAD)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in HEAD})
    print("== %s: +%d -> %d rows, %d cert\n" % (
        prov, added, len(rows), sum(1 for r in rows if r["证书编号"])))


if __name__ == "__main__":
    for p in sys.argv[1:]:
        run(p)
