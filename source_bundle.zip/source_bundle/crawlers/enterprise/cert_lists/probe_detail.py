# -*- coding: utf-8 -*-
"""Probe an innocom detail page: show text length and attachment links."""
import re, sys, requests
from bs4 import BeautifulSoup

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")
H = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9"}


def get(url):
    for u in ([url] + ([url.replace("https://", "http://")] if url.startswith("https") else [])):
        for _ in range(2):
            try:
                r = requests.get(u, headers=H, timeout=30, verify=False)
                r.encoding = r.apparent_encoding or "utf-8"
                if r.status_code == 200:
                    return r
            except Exception as e:
                print("  ERR", type(e).__name__, str(e)[:80])
    return None


def probe(url):
    r = get(url)
    if not r:
        return
    soup = BeautifulSoup(r.text, "lxml")
    print("==", url, len(r.text))
    for a in soup.find_all("a", href=True):
        h = a["href"]
        if re.search(r"\.(pdf|xlsx?|docx?|zip|rar|wps|et)$", h, re.I) or "files" in h or "down" in h.lower():
            print("  ATT:", a.get_text(strip=True)[:60], "|", h)
    # also raw regex for files/ paths
    for m in set(re.findall(r'["\']([^"\']*?/files/[^"\']+)["\']', r.text)):
        print("  RAW:", m)
    txt = soup.get_text("\n", strip=True)
    print("  TEXT LEN", len(txt))
    print("  HEAD:", txt[:400].replace("\n", " / "))


if __name__ == "__main__":
    for u in sys.argv[1:]:
        probe(u)
