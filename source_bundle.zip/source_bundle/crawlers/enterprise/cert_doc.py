# -*- coding: utf-8 -*-
"""Crude .doc text extractor: decode WordDocument stream as UTF-16LE, split on 0x07 cell marks."""
import re, sys, os


def ole_streams(path):
    """Minimal OLE2 compound file reader -> dict name->bytes (only root-level streams)."""
    data = open(path, "rb").read()
    assert data[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "not OLE"
    ssz = 1 << struct_u16(data, 30)
    mini_ssz = 1 << struct_u16(data, 32)
    n_fat = struct_u32(data, 44)
    dir_start = struct_u32(data, 48)
    mini_cutoff = struct_u32(data, 56)
    mini_fat_start = struct_u32(data, 60)
    n_mini_fat = struct_u32(data, 64)
    difat_start = struct_u32(data, 68)
    n_difat = struct_u32(data, 72)

    def sect(i):
        off = (i + 1) * ssz
        return data[off:off + ssz]

    # DIFAT
    fat_sects = [struct_u32(data, 76 + 4 * i) for i in range(109)]
    fat_sects = [x for x in fat_sects if x < 0xFFFFFFFA]
    s = difat_start
    cnt = 0
    while s < 0xFFFFFFFA and cnt < n_difat + 5:
        b = sect(s)
        for i in range(ssz // 4 - 1):
            v = struct_u32(b, 4 * i)
            if v < 0xFFFFFFFA:
                fat_sects.append(v)
        s = struct_u32(b, ssz - 4)
        cnt += 1
    fat = []
    for fs in fat_sects[:max(n_fat, len(fat_sects))]:
        b = sect(fs)
        for i in range(ssz // 4):
            fat.append(struct_u32(b, 4 * i))

    def chain(start):
        out, cur, guard = [], start, 0
        while cur < 0xFFFFFFFA and guard < 100000:
            out.append(cur)
            cur = fat[cur] if cur < len(fat) else 0xFFFFFFFE
            guard += 1
        return out

    def read_chain(start, size=None):
        buf = b"".join(sect(i) for i in chain(start))
        return buf[:size] if size else buf

    # directory
    dirdata = read_chain(dir_start)
    entries = []
    for i in range(len(dirdata) // 128):
        e = dirdata[128 * i:128 * (i + 1)]
        nlen = struct_u16(e, 64)
        name = e[:max(0, nlen - 2)].decode("utf-16le", "ignore")
        typ = e[66]
        start = struct_u32(e, 116)
        size = struct_u32(e, 120)
        entries.append((name, typ, start, size))
    root = next((e for e in entries if e[1] == 5), None)
    if not root:
        raise RuntimeError("no root")
    ministream = read_chain(root[2], root[3])
    minifat = []
    mb = read_chain(mini_fat_start) if n_mini_fat else b""
    for i in range(len(mb) // 4):
        minifat.append(struct_u32(mb, 4 * i))

    def read_mini(start, size):
        out, cur, guard = b"", start, 0
        while cur < 0xFFFFFFFA and guard < 200000:
            out += ministream[cur * mini_ssz:(cur + 1) * mini_ssz]
            cur = minifat[cur] if cur < len(minifat) else 0xFFFFFFFE
            guard += 1
        return out[:size]

    streams = {}
    for name, typ, start, size in entries:
        if typ != 2:
            continue
        streams[name] = read_mini(start, size) if size < mini_cutoff else read_chain(start, size)
    return streams


def struct_u16(b, o):
    return int.from_bytes(b[o:o + 2], "little")


def struct_u32(b, o):
    return int.from_bytes(b[o:o + 4], "little")


def doc_text(path):
    st = ole_streams(path)
    wd = st.get("WordDocument", b"")
    # fcMin at 0x18, ccpText at 0x4C (FIB base)
    fcMin = struct_u32(wd, 0x18)
    # heuristic: decode everything from fcMin as utf-16le and as cp936, keep the better one
    raw = wd[fcMin:]
    u16 = raw.decode("utf-16le", "ignore")
    u16 = u16.replace("\x07", "\t")
    return u16


ROW_RE = re.compile(
    r"(?P<seq>\d{1,5})\t(?P<name>[^\t\r\x07]{2,80})\t(?P<cert>G[RＲ]\s?\d{10,14})(?:\t(?P<region>[^\t\r\x07]{0,30}))?"
)


def parse_doc(path, region_hint=None):
    """Return rows [{seq,cert,name,region}] from a .doc list table."""
    t = doc_text(path)
    t = t.replace("\x0b", "\t").replace("\x07", "\t")
    rows, seen = [], set()
    for m in ROW_RE.finditer(t):
        cert = re.sub(r"\s", "", m.group("cert")).replace("Ｒ", "R")
        if cert in seen:
            continue
        seen.add(cert)
        rows.append({
            "seq": m.group("seq"),
            "cert": cert,
            "name": m.group("name").strip(),
            "region": (m.group("region") or "").strip() or (region_hint or ""),
            "page": 0,
        })
    return rows


if __name__ == "__main__":
    p = sys.argv[1]
    rows = parse_doc(p)
    print("rows", len(rows))
    for r in rows[:3]:
        print(r)
    import collections
    print("certs", sum(1 for r in rows if r["cert"]), "regions", sum(1 for r in rows if r["region"]))
    print(collections.Counter(r["region"] for r in rows).most_common(8))
