# -*- coding: utf-8 -*-
"""Assemble per-province CSVs from parsed/<key>.json."""
import os, json, csv, collections, re

CACHE = os.path.join("cert_lists", "_cache")
PARSED = os.path.join(CACHE, "parsed")
OUTDIR = "cert_lists"
os.makedirs(OUTDIR, exist_ok=True)

PROV = {"js": ("江苏省", "江苏省"), "zj": ("浙江省", "浙江省"),
        "sh": ("上海市", "上海市"), "ah": ("安徽省", "安徽省")}

# 同一 (year,batch) 有多份时，优先省级（带地区列）
EXCLUDE = set()

def load():
    items = []
    for fn in os.listdir(PARSED):
        if not fn.endswith(".json"):
            continue
        d = json.load(open(os.path.join(PARSED, fn), encoding="utf-8"))
        items.append(d)
    return items


def norm_city(prov, region):
    r = (region or "").strip()
    if not r:
        return ""
    if prov == "sh":
        return "上海市"
    if prov == "js":
        r = r.replace(" ", "")
        if r.endswith("区") or r.endswith("县"):
            return ""
        if not r.endswith("市"):
            r += "市"
        return r
    return r


def year_of(cert, fallback):
    m = re.match(r"GR(20\d{2})\d{8,12}$", cert or "")
    if m:
        y = int(m.group(1))
        if 2015 <= y <= 2030:
            return str(y)
    return str(fallback or "")


def main():
    items = load()
    prov_items = collections.defaultdict(list)
    for d in items:
        p = d["key"][:2]
        if p not in PROV:
            continue
        prov_items[p].append(d)

    report = {}
    code_counter = collections.Counter()
    for p, lst in prov_items.items():
        # 去重：同 (year,batch) 优先 province kind（有地区）
        best = {}
        for d in lst:
            k = (d["year"], d["batch"])
            cur = best.get(k)
            if cur is None:
                best[k] = d
                continue
            score_new = (1 if d.get("kind") == "province" else 0, sum(1 for r in d["rows"] if r.get("region")))
            score_old = (1 if cur.get("kind") == "province" else 0, sum(1 for r in cur["rows"] if r.get("region")))
            if score_new > score_old:
                best[k] = d
        chosen = sorted(best.values(), key=lambda d: (d["year"], d["batch"]))
        rows_out, seen = [], set()
        for d in chosen:
            for r in d["rows"]:
                cert = (r.get("cert") or "").replace(" ", "").replace("Ｒ", "R")
                if cert and not re.fullmatch(r"GR\d{10,16}", cert):
                    cert = ""
                name = (r.get("name") or "").strip()
                if not name and not cert:
                    continue
                key = cert or ("N:" + name)
                if key in seen:
                    continue
                seen.add(key)
                city = norm_city(p, r.get("region"))
                if not city and p == "sh":
                    city = "上海市"
                rows_out.append({
                    "企业名称": name,
                    "证书编号": cert,
                    "城市": city,
                    "区县": "",
                    "认定年度": year_of(cert, d["year"]),
                    "批次": (d["batch"] or "").replace("备案公告", "备案公告（全年汇总）"),
                    "来源URL": d["src"],
                })
                m = re.match(r"GR(20\d{2})(\d{4})", cert)
                if m:
                    code_counter[m.group(2)] += 1
        name_csv = os.path.join(OUTDIR, PROV[p][0] + ".csv")
        with open(name_csv, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["企业名称", "证书编号", "城市", "区县", "认定年度", "批次", "来源URL"])
            w.writeheader()
            w.writerows(rows_out)
        certs = sum(1 for r in rows_out if r["证书编号"])
        cities = sum(1 for r in rows_out if r["城市"])
        cityset = sorted({r["城市"] for r in rows_out if r["城市"]})
        years = collections.Counter(r["认定年度"] for r in rows_out)
        batches = collections.Counter(r["批次"] for r in rows_out)
        report[p] = dict(file=name_csv, rows=len(rows_out), cert=certs, city=cities,
                         cities=cityset, years=dict(years), batches=dict(batches),
                         sources=[{"key": d["key"], "year": d["year"], "batch": d["batch"],
                                   "src": d["src"], "rows": len(d["rows"]),
                                   "region": sum(1 for r in d["rows"] if r.get("region"))} for d in chosen])
        print("=" * 80)
        print(PROV[p][0], "rows", len(rows_out), "cert", certs, "city", cities, "city_distinct", len(cityset))
        print("  years", dict(years))
        print("  batches", dict(batches))
        print("  sources", [(d["key"], len(d["rows"])) for d in chosen])

    # 地区码.csv
    labels = {"3200": "江苏省（省级码·顺序号1-9999）", "3201": "江苏省（省级码·顺序号续段）",
              "3202": "江苏省（省级码·顺序号续段2）",
              "3300": "浙江省（省级码·顺序号1-9999）", "3301": "浙江省（省级码·顺序号续段）",
              "3100": "上海市（省级码·直辖市）", "3400": "安徽省（省级码）"}
    with open(os.path.join(OUTDIR, "地区码.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["地区码", "城市"])
        for code, n in sorted(code_counter.items()):
            w.writerow([code, labels.get(code, "未映射")])
    json.dump(report, open(os.path.join(CACHE, "report.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("\ncodes:", dict(code_counter))


if __name__ == "__main__":
    main()
